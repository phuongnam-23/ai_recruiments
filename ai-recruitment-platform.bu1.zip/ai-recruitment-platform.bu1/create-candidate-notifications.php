<?php
require_once 'config/init.php';

// Get candidate users
$db = new Database();
$conn = $db->getConnection();
$stmt = $conn->query("SELECT id, full_name FROM users WHERE role = 'candidate' LIMIT 3");
$candidates = $stmt->fetchAll();

echo "Found " . count($candidates) . " candidates:\n";
foreach ($candidates as $c) {
    echo "- User ID {$c['id']}: {$c['full_name']}\n";
}

if (empty($candidates)) {
    echo "\nNo candidates found. Creating sample candidate...\n";
    // You might need to create a candidate user first
    exit;
}

$notificationModel = new Notification();

echo "\nCreating notifications for candidates...\n";
foreach ($candidates as $candidate) {
    $userId = $candidate['id'];
    
    $notificationModel->createNotification(
        $userId,
        'job_match',
        'Công việc phù hợp với bạn',
        'Có 5 công việc mới phù hợp với kỹ năng và kinh nghiệm của bạn.'
    );
    
    $notificationModel->createNotification(
        $userId,
        'application_status',
        'Cập nhật hồ sơ ứng tuyển',
        'Hồ sơ của bạn đã được chuyển sang vòng phỏng vấn tại FPT Software.'
    );
    
    $notificationModel->createNotification(
        $userId,
        'profile_view',
        'Nhà tuyển dụng quan tâm',
        'VNG Corporation vừa xem hồ sơ của bạn.'
    );
    
    echo "Created 3 notifications for user {$userId}\n";
}

echo "\n=== VERIFICATION ===\n";
foreach ($candidates as $candidate) {
    $notifications = $notificationModel->getNotifications($candidate['id'], 10, 0);
    $unreadCount = $notificationModel->countUnread($candidate['id']);
    echo "User {$candidate['id']}: " . count($notifications) . " notifications, {$unreadCount} unread\n";
}
