<?php
require_once 'config/init.php';

echo "=== CREATE SAMPLE NOTIFICATIONS ===\n\n";

// Get current logged in user or create for multiple users
$db = new Database();
$conn = $db->getConnection();

// Get some user IDs
$stmt = $conn->query("SELECT id, role, full_name FROM users LIMIT 5");
$users = $stmt->fetchAll();

echo "Found " . count($users) . " users:\n";
foreach ($users as $user) {
    echo "- User ID {$user['id']}: {$user['full_name']} ({$user['role']})\n";
}

echo "\nCreating sample notifications...\n";

$notificationModel = new Notification();

foreach ($users as $user) {
    $userId = $user['id'];
    
    // Create different types based on role
    if ($user['role'] === 'candidate') {
        // Notification 1: Job match
        $notificationModel->createNotification(
            $userId,
            'job_match',
            'Công việc phù hợp với bạn',
            'Có 3 công việc mới phù hợp với kỹ năng và kinh nghiệm của bạn.'
        );
        
        // Notification 2: Application status
        $notificationModel->createNotification(
            $userId,
            'application_status',
            'Cập nhật hồ sơ ứng tuyển',
            'Hồ sơ của bạn đã được chuyển sang vòng phỏng vấn.'
        );
        
        // Notification 3: Profile view
        $notificationModel->createNotification(
            $userId,
            'profile_view',
            'Nhà tuyển dụng xem hồ sơ',
            'FPT Software vừa xem hồ sơ của bạn.'
        );
    } else if ($user['role'] === 'recruiter') {
        // Notification for recruiter
        $notificationModel->createNotification(
            $userId,
            'new_application',
            'Hồ sơ ứng tuyển mới',
            'Bạn có 2 hồ sơ ứng tuyển mới cho vị trí Senior Developer.'
        );
        
        $notificationModel->createNotification(
            $userId,
            'candidate_message',
            'Tin nhắn từ ứng viên',
            'Ứng viên Nguyễn Văn A vừa gửi tin nhắn cho bạn.'
        );
    }
    
    echo "Created notifications for user {$userId} ({$user['role']})\n";
}

echo "\n=== VERIFICATION ===\n";
foreach ($users as $user) {
    $notifications = $notificationModel->getNotifications($user['id'], 10, 0);
    $unreadCount = $notificationModel->countUnread($user['id']);
    echo "User {$user['id']}: {count($notifications)} notifications, {$unreadCount} unread\n";
}

echo "\nDone!\n";
