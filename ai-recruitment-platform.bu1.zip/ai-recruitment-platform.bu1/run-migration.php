<?php
/**
 * Migration Runner - Add Match Score Columns
 */

require_once 'config/init.php';

try {
    $db = new Database();
    $conn = $db->getConnection();

    echo "🔄 Running migrations...\n";

    // Check if match_score column exists
    $checkQuery = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='applications' AND COLUMN_NAME='match_score'";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->execute();
    
    if ($checkStmt->rowCount() === 0) {
        echo "➕ Adding match_score column...\n";
        $conn->exec("ALTER TABLE applications ADD COLUMN match_score INT DEFAULT 0");
        echo "✅ match_score added\n";
    } else {
        echo "⏭️  match_score already exists\n";
    }

    // Check if ai_analysis column exists
    $checkQuery = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='applications' AND COLUMN_NAME='ai_analysis'";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->execute();
    
    if ($checkStmt->rowCount() === 0) {
        echo "➕ Adding ai_analysis column...\n";
        $conn->exec("ALTER TABLE applications ADD COLUMN ai_analysis JSON NULL");
        echo "✅ ai_analysis added\n";
    } else {
        echo "⏭️  ai_analysis already exists\n";
    }

    echo "\n✅ Migration completed successfully!\n";

} catch (Exception $e) {
    echo "❌ Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
?>
