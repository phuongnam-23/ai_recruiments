<?php
require_once 'config/init.php';
require_once 'utils/middleware/Auth.php';

addSecurityHeaders();

// Lấy danh sách công việc featured
$jobModel = new Job();
$featuredJobs = $jobModel->getActiveJobs(6, 0); // 6 jobs

// Lấy danh sách công ty
$recruiterModel = new RecruiterProfile();
$recruiters = $recruiterModel->getAllRecruiters(6, 0); // 6 recruiters

// Đồng nhất thông tin địa điểm - ưu tiên địa chỉ đầy đủ
foreach ($recruiters as &$recruiter) {
    $locationParts = [];
    if (!empty($recruiter['company_address'])) {
        $locationParts[] = $recruiter['company_address'];
    }
    if (!empty($recruiter['company_city']) && !stripos($recruiter['company_address'] ?? '', $recruiter['company_city'])) {
        $locationParts[] = $recruiter['company_city'];
    }
    
    if (!empty($locationParts)) {
        $recruiter['display_location'] = implode(', ', $locationParts);
    } elseif (!empty($recruiter['location'])) {
        $recruiter['display_location'] = $recruiter['location'];
    } else {
        $recruiter['display_location'] = 'Không xác định';
    }
}

// Lấy thông tin user hiện tại nếu đã đăng nhập
$currentUser = null;
if (isLoggedIn()) {
    $userModel = new User();
    $currentUser = $userModel->getUserById($_SESSION['user_id']);
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Recruitment - Nền tảng tuyển dụng thông minh</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 min-h-screen text-slate-900 dark:text-white transition-colors duration-300">
    <!-- Navigation -->
    <nav class="bg-white/90 dark:bg-gray-900/80 backdrop-blur-md border-b border-slate-200 dark:border-gray-700 sticky top-0 z-50 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center text-sm">
            <div class="flex items-center gap-8">
                <a href="index.php" class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">AI Recruitment</a>
                <div class="hidden md:flex gap-6 text-slate-600 dark:text-gray-300">
                    <a href="index.php" class="hover:text-blue-600 dark:hover:text-white transition font-medium">Trang chủ</a>
                    <a href="views/public/jobs-list.php" class="hover:text-blue-600 dark:hover:text-white transition font-medium">Tìm việc</a>
                    <a href="views/public/companies.php" class="hover:text-blue-600 dark:hover:text-white transition font-medium">Công ty</a>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <?php if (isLoggedIn()): ?>
                    <?php include __DIR__ . '/components/notification-bell.php'; ?>
                    <div class="relative group dropdown-group" style="padding-bottom: 8px;">
                        <button class="flex items-center gap-2 hover:opacity-80 transition dropdown-btn text-slate-900 dark:text-white">
                            <?php 
                            // Lấy avatar URL dựa trên role
                            $avatarUrl = '';
                            if (!empty($currentUser['avatar_url'])) {
                                // Nếu đã có http hoặc ui-avatars, dùng luôn
                                if (strpos($currentUser['avatar_url'], 'http') === 0 || strpos($currentUser['avatar_url'], 'ui-avatars') === 0) {
                                    $avatarUrl = $currentUser['avatar_url'];
                                } else {
                                    // Nếu là path tương đối, thêm BASE_URL
                                    $avatarUrl = BASE_URL . $currentUser['avatar_url'];
                                }
                            } else {
                                $avatarUrl = 'https://ui-avatars.com/api/?name=' . urlencode($currentUser['full_name']) . '&background=random';
                            }
                            ?>
                            <div class="w-8 h-8 rounded-full overflow-hidden border-2 border-blue-500 dark:border-blue-400">
                                <img src="<?php echo $avatarUrl; ?>" class="w-full h-full object-cover" alt="avatar">
                            </div>
                            <span class="font-semibold"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                            <span class="text-slate-400 dark:text-slate-300">▼</span>
                        </button>
                        <div class="absolute right-0 mt-0 w-52 bg-white dark:bg-slate-800 rounded-lg shadow-xl text-slate-700 dark:text-slate-200 opacity-0 group-hover:opacity-100 transition hidden group-hover:block z-50 dropdown-menu border border-slate-200 dark:border-slate-700">
                            <a href="views/<?php echo $_SESSION['role']; ?>/dashboard.php" class="block px-4 py-3 hover:bg-slate-100 dark:hover:bg-slate-700 font-semibold">📊 Trang cá nhân</a>
                            <hr class="border-slate-200 dark:border-slate-600">
                            <a href="logout.php" class="block px-4 py-3 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20">Đăng xuất</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="px-4 py-2 text-slate-700 dark:text-white hover:bg-slate-100 dark:hover:bg-gray-700 rounded-lg transition font-medium">Đăng nhập</a>
                    <a href="register.php" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-semibold shadow-md">Đăng ký</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="py-20">
        <div class="max-w-7xl mx-auto px-4 flex flex-col gap-12 lg:flex-row lg:items-center">
            <div class="flex-1 space-y-6">
                <div class="inline-block px-4 py-2 bg-blue-100 dark:bg-blue-500/20 text-blue-700 dark:text-blue-300 rounded-full text-sm font-bold w-fit border border-blue-200 dark:border-blue-400/30">AI Matching • Career Journey</div>
                <div>
                    <h1 class="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight text-slate-900 dark:text-white">
                        Bắt đầu sự nghiệp với <span class="bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-500 dark:to-purple-500 bg-clip-text text-transparent">AI Recruitment</span>
                    </h1>
                    <p class="text-slate-600 dark:text-slate-200 mt-4 text-lg font-medium leading-relaxed">
                        Khám phá hàng nghìn cơ hội việc làm được cá nhân hóa, nhận phản hồi tức thì từ nhà tuyển dụng và quản lý hành trình nghề nghiệp của bạn trên một nền tảng duy nhất.
                    </p>
                </div>
                <div class="flex flex-col sm:flex-row gap-4">
                    <a href="views/public/jobs-list.php" class="px-8 py-4 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition text-center shadow-lg hover:shadow-xl transform hover:scale-105">Khám phá việc làm</a>
                    <a href="views/public/companies.php" class="px-8 py-4 bg-slate-700 dark:bg-gray-700 text-white font-bold rounded-xl hover:bg-slate-800 dark:hover:bg-gray-600 transition text-center border-2 border-slate-600 dark:border-gray-600">Xem công ty nổi bật</a>
                </div>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div class="bg-white dark:bg-gray-800/60 backdrop-blur-sm rounded-xl p-4 text-center border-2 border-slate-200 dark:border-slate-700 shadow-lg">
                        <p class="text-3xl font-bold text-slate-900 dark:text-white">3,200+</p>
                        <p class="text-slate-600 dark:text-slate-300 font-semibold">Công việc mới</p>
                    </div>
                    <div class="bg-white dark:bg-gray-800/60 backdrop-blur-sm rounded-xl p-4 text-center border-2 border-slate-200 dark:border-slate-700 shadow-lg">
                        <p class="text-3xl font-bold text-slate-900 dark:text-white">780+</p>
                        <p class="text-slate-600 dark:text-slate-300 font-semibold">Công ty active</p>
                    </div>
                    <div class="bg-white dark:bg-gray-800/60 backdrop-blur-sm rounded-xl p-4 text-center border-2 border-slate-200 dark:border-slate-700 shadow-lg">
                        <p class="text-3xl font-bold text-slate-900 dark:text-white">95%</p>
                        <p class="text-slate-600 dark:text-slate-300 font-semibold">Match chính xác</p>
                    </div>
                    <div class="bg-white dark:bg-gray-800/60 backdrop-blur-sm rounded-xl p-4 text-center border-2 border-slate-200 dark:border-slate-700 shadow-lg">
                        <p class="text-3xl font-bold text-slate-900 dark:text-white">24/7</p>
                        <p class="text-slate-600 dark:text-slate-300 font-semibold">AI Career Coach</p>
                    </div>
                </div>
            </div>
            <div class="flex-1 flex justify-center">
                <div class="bg-white/95 dark:bg-slate-800/90 backdrop-blur-md rounded-2xl shadow-2xl p-6 border border-slate-200 dark:border-slate-700 max-w-md w-full space-y-6">
                    <div>
                        <p class="inline-block px-3 py-1 bg-purple-100 dark:bg-purple-500/20 text-purple-700 dark:text-purple-300 rounded-full text-xs font-semibold mb-3">Quick Search</p>
                        <h3 class="text-2xl font-bold text-slate-900 dark:text-white">Tìm kiếm thông minh</h3>
                        <p class="text-slate-600 dark:text-slate-300 text-sm">AI gợi ý những kết quả phù hợp nhất dựa trên profile của bạn.</p>
                    </div>
                    <form method="GET" action="<?php echo BASE_URL; ?>views/public/jobs-list.php" class="space-y-4">
                        <div>
                            <label class="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-widest font-semibold">Vị trí / Công ty</label>
                            <input type="text" name="keyword" placeholder="Senior Product Designer..." class="w-full mt-2 px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:border-blue-500 dark:focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20">
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-widest font-semibold">Thành phố</label>
                                <input type="text" name="city" placeholder="Hồ Chí Minh" class="w-full mt-2 px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:border-blue-500 dark:focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20">
                            </div>
                            <div>
                                <label class="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-widest font-semibold">Cấp bậc</label>
                                <select name="level" class="w-full mt-2 px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white focus:border-blue-500 dark:focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20">
                                    <option value="">Tất cả</option>
                                    <option value="junior">Junior</option>
                                    <option value="mid">Middle</option>
                                    <option value="senior">Senior</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition w-full">
                            Tìm kiếm ngay
                        </button>
                    </form>
                    <div class="flex items-center gap-3 text-sm text-slate-600 dark:text-slate-400 bg-blue-50 dark:bg-slate-700/50 p-3 rounded-lg border border-blue-100 dark:border-slate-600">
                        <span class="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-500/20 flex items-center justify-center text-xl">⚡</span>
                        <p><strong class="text-slate-900 dark:text-white">48 ứng viên</strong> đã tìm được job trong 24h qua.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Jobs Section -->
    <section class="max-w-7xl mx-auto px-4 py-20 bg-gradient-to-b from-transparent to-slate-50 dark:to-transparent">
        <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-12">
            <div>
                <p class="inline-block px-4 py-2 bg-blue-100 dark:bg-blue-500/20 text-blue-700 dark:text-blue-300 rounded-full text-sm font-semibold mb-3">Recommended for you</p>
                <h2 class="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white">Việc làm nổi bật tuần này</h2>
                <p class="text-slate-600 dark:text-slate-300 mt-2 max-w-2xl">Được chọn lọc dựa trên xu hướng tuyển dụng và nhu cầu của các công ty công nghệ hàng đầu.</p>
            </div>
            <a href="views/public/jobs-list.php" class="px-6 py-3 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-600 transition shadow-md border border-slate-200 dark:border-slate-600 font-semibold">Xem tất cả</a>
        </div>

        <?php if (!empty($featuredJobs)): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($featuredJobs as $job): ?>
                    <a href="views/public/job-detail.php?id=<?php echo $job['id']; ?>" 
                       class="group bg-white dark:bg-slate-700/95 backdrop-blur-md rounded-2xl shadow-xl hover:shadow-2xl border-2 border-slate-200 dark:border-slate-600 hover:border-blue-400 dark:hover:border-blue-400 transition-all duration-300 overflow-hidden hover:scale-[1.02]">
                        <!-- Header -->
                        <div class="p-6 pb-4 bg-gradient-to-br from-blue-50/50 to-purple-50/50 dark:from-slate-600/40 dark:to-slate-700/40">
                            <div class="flex items-start justify-between mb-3">
                                <h3 class="text-xl font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-300 transition line-clamp-2 flex-1">
                                    <?php echo htmlspecialchars($job['title']); ?>
                                </h3>
                                <span class="inline-flex items-center gap-1 px-3 py-1.5 bg-purple-100 dark:bg-purple-500/30 text-purple-700 dark:text-purple-200 rounded-full text-xs font-semibold whitespace-nowrap ml-2 border border-purple-200 dark:border-purple-400/30">
                                    <i class="fa-solid fa-clock text-xs"></i> Full-time
                                </span>
                            </div>
                            <p class="text-slate-600 dark:text-slate-200 font-medium"><?php echo htmlspecialchars($job['company_name'] ?? 'Công ty'); ?></p>
                        </div>

                        <!-- Info Section -->
                        <div class="px-6 pb-4 pt-4 space-y-3 text-sm text-slate-700 dark:text-slate-100 bg-slate-50/50 dark:bg-slate-700/30">
                            <!-- Địa điểm -->
                            <div>
                                <h4 class="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wide">Địa điểm</h4>
                                <div class="flex items-center gap-3">
                                    <i class="fa-solid fa-location-dot text-red-500 dark:text-red-300 w-5 text-base"></i>
                                    <span class="font-medium"><?php echo htmlspecialchars($job['location'] ?? 'Không xác định'); ?></span>
                                </div>
                            </div>
                            
                            <!-- Mức lương -->
                            <div>
                                <h4 class="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wide">Mức lương</h4>
                                <div class="flex items-center gap-3">
                                    <i class="fa-solid fa-money-bill-wave text-green-600 dark:text-green-300 w-5 text-base"></i>
                                    <span class="font-medium"><?php echo number_format($job['salary_min'] ?? 0, 0, '.', ','); ?> - <?php echo number_format($job['salary_max'] ?? 0, 0, '.', ','); ?> VND</span>
                                </div>
                            </div>
                            
                            <!-- Hạn nộp hồ sơ -->
                            <div>
                                <h4 class="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wide">Hạn nộp hồ sơ</h4>
                                <div class="flex items-center gap-3">
                                    <i class="fa-regular fa-calendar text-blue-600 dark:text-blue-300 w-5 text-base"></i>
                                    <span class="font-medium"><?php echo !empty($job['application_deadline']) ? date('d/m/Y', strtotime($job['application_deadline'])) : 'Không giới hạn'; ?></span>
                                </div>
                            </div>
                        </div>

                        <!-- Skills Tags -->
                        <?php if ($job['required_skills']): ?>
                            <div class="px-6 pb-4">
                                <div class="flex gap-2 flex-wrap">
                                    <?php foreach (array_slice(explode(',', $job['required_skills']), 0, 3) as $skill): ?>
                                        <span class="bg-blue-50 dark:bg-slate-600/60 text-blue-700 dark:text-slate-100 text-xs px-3 py-1.5 rounded-full border border-blue-200 dark:border-slate-500 font-medium">
                                            <?php echo htmlspecialchars(trim($skill)); ?>
                                        </span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <!-- Footer -->
                        <div class="px-6 py-4 bg-slate-100/80 dark:bg-slate-800/70 border-t-2 border-slate-200 dark:border-slate-600 flex items-center justify-between text-sm">
                            <span class="flex items-center gap-2 text-orange-600 dark:text-orange-300">
                                <i class="fa-solid fa-fire text-base"></i>
                                <span class="font-semibold">32 ứng viên đang xem</span>
                            </span>
                            <span class="text-blue-600 dark:text-blue-300 font-bold group-hover:translate-x-1 transition-transform flex items-center gap-2">
                                Xem chi tiết <i class="fa-solid fa-arrow-right"></i>
                            </span>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="bg-gray-800/90 backdrop-blur-sm rounded-xl shadow-lg p-6 border border-gray-700 text-center text-slate-300">
                <p>Hiện chưa có công việc nào. Vui lòng quay lại sau!</p>
            </div>
        <?php endif; ?>
    </section>

    <!-- Companies Section -->
    <section class="py-20">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-6 mb-12">
                <div>
                    <p class="inline-block px-4 py-2 bg-blue-500/20 text-blue-300 rounded-full text-sm font-semibold mb-3">Top employers</p>
                    <h2 class="text-3xl md:text-4xl font-bold">Công ty đang tuyển gấp</h2>
                    <p class="text-slate-300 mt-2">Hãy xem văn hóa, phúc lợi và vị trí đang mở của họ.</p>
                </div>
                <a href="views/public/companies.php" class="px-4 py-2 bg-gray-700 text-white rounded hover:bg-gray-600 transition">Khám phá toàn bộ</a>
            </div>

            <?php if (!empty($recruiters)): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach ($recruiters as $recruiter): ?>
                        <a href="views/public/company-profile.php?recruiter_id=<?php echo $recruiter['user_id']; ?>" 
                           class="group bg-white dark:bg-slate-700/95 backdrop-blur-md rounded-2xl shadow-xl hover:shadow-2xl border-2 border-slate-200 dark:border-slate-600 hover:border-blue-400 dark:hover:border-blue-400 transition-all duration-300 overflow-hidden hover:scale-[1.02]">
                            <!-- Header -->
                            <div class="p-6 pb-4 bg-gradient-to-br from-blue-50/50 to-purple-50/50 dark:from-slate-600/40 dark:to-slate-700/40">
                                <h3 class="text-xl font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-300 transition mb-2 line-clamp-2">
                                    <?php echo htmlspecialchars($recruiter['company_name']); ?>
                                </h3>
                                <p class="text-slate-600 dark:text-slate-200 text-sm font-semibold"><?php echo htmlspecialchars($recruiter['industry'] ?? 'Công nghệ thông tin'); ?></p>
                            </div>

                            <!-- Info Section -->
                            <div class="px-6 pb-4 pt-4 space-y-3 text-sm text-slate-700 dark:text-slate-100 bg-slate-50/50 dark:bg-slate-700/30">
                                <!-- Ngành nghề -->
                                <div>
                                    <h4 class="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wide">Ngành nghề</h4>
                                    <div class="flex items-center gap-3">
                                        <i class="fa-solid fa-building text-indigo-600 dark:text-indigo-300 w-5 text-base"></i>
                                        <span class="font-medium"><?php echo htmlspecialchars($recruiter['industry'] ?? 'Công nghệ thông tin'); ?></span>
                                    </div>
                                </div>
                                
                                <!-- Quy mô -->
                                <div>
                                    <h4 class="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wide">Quy mô công ty</h4>
                                    <div class="flex items-center gap-3">
                                        <i class="fa-solid fa-users text-purple-600 dark:text-purple-300 w-5 text-base"></i>
                                        <span class="font-medium"><?php echo htmlspecialchars($recruiter['company_size'] ?? '201-500'); ?></span>
                                    </div>
                                </div>
                                
                                <!-- Địa điểm -->
                                <div>
                                    <h4 class="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wide">Địa điểm</h4>
                                    <div class="flex items-center gap-3">
                                        <i class="fa-solid fa-location-dot text-red-500 dark:text-red-300 w-5 text-base"></i>
                                        <span class="font-medium"><?php echo htmlspecialchars($recruiter['display_location']); ?></span>
                                    </div>
                                </div>
                            </div>

                            <!-- Footer -->
                            <div class="px-6 py-4 bg-slate-100/80 dark:bg-slate-800/70 border-t-2 border-slate-200 dark:border-slate-600 flex items-center justify-between text-sm">
                                <span class="text-blue-600 dark:text-blue-300 font-bold group-hover:translate-x-1 transition-transform flex items-center gap-2">
                                    Xem trang công ty <i class="fa-solid fa-arrow-right"></i>
                                </span>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="bg-gray-800/90 backdrop-blur-sm rounded-xl shadow-lg p-6 border border-gray-700 text-center text-slate-300">
                    <p>Hiện chưa có công ty nào. Vui lòng quay lại sau!</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="py-16">
        <div class="max-w-5xl mx-auto px-4">
            <div class="bg-gray-800/90 backdrop-blur-sm rounded-xl shadow-lg p-6 border border-gray-700">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                    <div>
                        <p class="text-5xl font-bold">
                            <?php 
                            $jobs = $jobModel->getActiveJobs(10000, 0);
                            echo count($jobs);
                            ?>
                        </p>
                        <p class="text-slate-300 mt-2">Công việc đang tuyển</p>
                    </div>
                    <div>
                        <p class="text-5xl font-bold">
                            <?php 
                            $recs = $recruiterModel->getAllRecruiters(10000, 0);
                            echo count($recs);
                            ?>
                        </p>
                        <p class="text-slate-300 mt-2">Công ty tham gia</p>
                    </div>
                    <div>
                        <p class="text-5xl font-bold">
                            <?php 
                            $userModel = new User();
                            echo $userModel->countUsersByRole('candidate');
                            ?>
                        </p>
                        <p class="text-slate-300 mt-2">Ứng viên</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include __DIR__ . '/components/lazy-load-widgets.php'; ?>

    <!-- CTA Section -->
    <section class="max-w-7xl mx-auto px-4 py-16 text-center">
        <h2 class="text-3xl font-bold mb-4">Sẵn sàng bắt đầu?</h2>
        <p class="text-gray-600 mb-8">Tham gia cộng đồng tuyển dụng thông minh ngay hôm nay</p>
        
        <?php if (!isLoggedIn()): ?>
            <div class="flex gap-4 justify-center flex-wrap">
                <a href="register.php" class="bg-blue-600 text-white px-8 py-3 rounded hover:bg-blue-700 font-semibold">
                    Đăng ký ngay
                </a>
                <a href="login.php" class="border-2 border-blue-600 text-blue-600 px-8 py-3 rounded hover:bg-blue-50 font-semibold">
                    Đăng nhập
                </a>
            </div>
        <?php else: ?>
            <a href="views/<?php echo $_SESSION['role']; ?>/dashboard.php" class="bg-blue-600 text-white px-8 py-3 rounded hover:bg-blue-700 font-semibold inline-block">
                Vào trang cá nhân →
            </a>
        <?php endif; ?>
    </section>

    <!-- Footer -->
    <footer class="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-slate-300 pt-16 pb-8 border-t border-slate-700">
        <div class="max-w-7xl mx-auto px-4">
            <!-- Hotline Section -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12 pb-12 border-b border-slate-700">
                <!-- Hotline cho Người tìm việc -->
                <div class="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-8 border border-slate-700 hover:border-blue-500 transition">
                    <h3 class="text-2xl font-bold text-blue-400 mb-6 flex items-center gap-2">
                        <span>💼</span> Hotline cho Người tìm việc
                    </h3>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
                        <div>
                            <p class="text-slate-400 text-sm mb-2 flex items-center gap-2">
                                <span>📞</span> Hotline hỗ trợ miền Nam
                            </p>
                            <a href="tel:02871092424" class="text-2xl font-bold text-blue-400 hover:text-blue-300 transition">
                                HCM: (028) 7109 2424
                            </a>
                        </div>
                        <div>
                            <p class="text-slate-400 text-sm mb-2 flex items-center gap-2">
                                <span>📞</span> Hotline hỗ trợ miền Bắc
                            </p>
                            <a href="tel:02473092424" class="text-2xl font-bold text-purple-400 hover:text-purple-300 transition">
                                HN: (024) 7309 2424
                            </a>
                        </div>
                    </div>
                    <a href="views/candidate/dashboard.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition">
                        Tư vấn cho Người tìm việc
                    </a>
                </div>

                <!-- Hotline cho Nhà tuyển dụng -->
                <div class="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-8 border border-slate-700 hover:border-purple-500 transition">
                    <h3 class="text-2xl font-bold text-purple-400 mb-6 flex items-center gap-2">
                        <span>🏢</span> Hotline cho Nhà tuyển dụng
                    </h3>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
                        <div>
                            <p class="text-slate-400 text-sm mb-2 flex items-center gap-2">
                                <span>📞</span> Hotline hỗ trợ miền Nam
                            </p>
                            <a href="tel:02871082424" class="text-2xl font-bold text-blue-400 hover:text-blue-300 transition">
                                HCM: (028) 7108 2424
                            </a>
                        </div>
                        <div>
                            <p class="text-slate-400 text-sm mb-2 flex items-center gap-2">
                                <span>📞</span> Hotline hỗ trợ miền Bắc
                            </p>
                            <a href="tel:02473082424" class="text-2xl font-bold text-purple-400 hover:text-purple-300 transition">
                                HN: (024) 7308 2424
                            </a>
                        </div>
                    </div>
                    <a href="views/recruiter/dashboard.php" class="inline-block bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold transition">
                        Tư vấn cho Nhà tuyển dụng
                    </a>
                </div>
            </div>

            <!-- Footer Main Content -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
                <!-- Về chúng tôi -->
                <div>
                    <h4 class="text-lg font-bold text-white mb-4">Về chúng tôi</h4>
                    <p class="text-sm text-slate-400 mb-4">
                        AI Recruitment - Nền tảng tuyển dụng thông minh, kết nối ứng viên và nhà tuyển dụng với công nghệ AI tiên tiến.
                    </p>
                    <div class="text-sm text-slate-400">
                        <p class="mb-2"><strong>Trụ sở chính:</strong></p>
                        <p>Tầng 16, Tòa nhà HTC, Số 19 Phố Duy Tân, Phường Cầu Giấy, Hà Nội</p>
                    </div>
                </div>

                <!-- Thông tin -->
                <div>
                    <h4 class="text-lg font-bold text-white mb-4">Thông tin</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="#" class="text-slate-400 hover:text-blue-400 transition">Cẩm nang nghề nghiệp</a></li>
                        <li><a href="#" class="text-slate-400 hover:text-blue-400 transition">Báo giá dịch vụ</a></li>
                        <li><a href="#" class="text-slate-400 hover:text-blue-400 transition">Điều khoản sử dụng</a></li>
                        <li><a href="#" class="text-slate-400 hover:text-blue-400 transition">Quy định bảo mật</a></li>
                        <li><a href="#" class="text-slate-400 hover:text-blue-400 transition">Chính sách dữ liệu cá nhân</a></li>
                    </ul>
                </div>

                <!-- Liên hệ -->
                <div>
                    <h4 class="text-lg font-bold text-white mb-4">Liên hệ</h4>
                    <ul class="space-y-3 text-sm">
                        <li class="flex items-center gap-2">
                            <span>📧</span>
                            <a href="mailto:support@airecruitment.vn" class="text-slate-400 hover:text-blue-400 transition">support@airecruitment.vn</a>
                        </li>
                        <li class="flex items-center gap-2">
                            <span>📧</span>
                            <a href="mailto:hr@airecruitment.vn" class="text-slate-400 hover:text-blue-400 transition">hr@airecruitment.vn</a>
                        </li>
                        <li class="flex items-center gap-2">
                            <span>🌐</span>
                            <a href="#" class="text-slate-400 hover:text-blue-400 transition">www.airecruitment.vn</a>
                        </li>
                    </ul>
                </div>

                <!-- Kết nối với chúng tôi -->
                <div>
                    <h4 class="text-lg font-bold text-white mb-4">Kết nối với chúng tôi</h4>
                    <div class="flex gap-3 mb-6">
                        <a href="#" class="w-10 h-10 bg-slate-700 hover:bg-blue-600 rounded-full flex items-center justify-center transition">
                            <span class="text-xl">📘</span>
                        </a>
                        <a href="#" class="w-10 h-10 bg-slate-700 hover:bg-blue-400 rounded-full flex items-center justify-center transition">
                            <span class="text-xl">🐦</span>
                        </a>
                        <a href="#" class="w-10 h-10 bg-slate-700 hover:bg-pink-600 rounded-full flex items-center justify-center transition">
                            <span class="text-xl">📸</span>
                        </a>
                        <a href="#" class="w-10 h-10 bg-slate-700 hover:bg-blue-700 rounded-full flex items-center justify-center transition">
                            <span class="text-xl">💼</span>
                        </a>
                        <a href="#" class="w-10 h-10 bg-slate-700 hover:bg-red-600 rounded-full flex items-center justify-center transition">
                            <span class="text-xl">▶️</span>
                        </a>
                    </div>
                    <div class="bg-slate-800/50 p-4 rounded-lg border border-slate-700">
                        <p class="text-xs text-slate-400 mb-2">Tải ứng dụng</p>
                        <div class="space-y-2">
                            <a href="#" class="block bg-slate-700 hover:bg-slate-600 px-3 py-2 rounded text-xs text-white transition">
                                📱 Get it on Google Play
                            </a>
                            <a href="#" class="block bg-slate-700 hover:bg-slate-600 px-3 py-2 rounded text-xs text-white transition">
                                🍎 Available on App Store
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer Bottom -->
            <div class="pt-8 border-t border-slate-700 text-center">
                <p class="text-sm text-slate-400">
                    © 2025 - Bản quyền thuộc về <strong class="text-white">AI Recruitment Platform</strong>
                </p>
                <p class="text-xs text-slate-500 mt-2">
                    Giấy phép hoạt động dịch vụ việc làm số: 28957/2024/SLĐTBXH-VLATLĐ
                </p>
            </div>
        </div>
    </footer>

    <script>
        // Fix dropdown menu not disappearing on mouse leave
        document.querySelectorAll('.dropdown-group').forEach(group => {
            const btn = group.querySelector('.dropdown-btn');
            const menu = group.querySelector('.dropdown-menu');
            
            if (btn && menu) {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    menu.classList.toggle('!block');
                    menu.classList.toggle('!opacity-100');
                });
                
                group.addEventListener('mouseleave', () => {
                    menu.classList.remove('!block');
                    menu.classList.remove('!opacity-100');
                });
            }
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            document.querySelectorAll('.dropdown-menu').forEach(menu => {
                if (!menu.closest('.dropdown-group')?.contains(e.target)) {
                    menu.classList.remove('!block');
                    menu.classList.remove('!opacity-100');
                }
            });
        });
    </script>

    <?php /* Widgets are now lazy loaded via lazy-load-widgets.php */ ?>
    
    <!-- AI Chatbot Widget -->
    <?php include __DIR__ . '/views/components/chatbot-widget.php'; ?>
    
    <!-- Chat Widget (Real-time messaging) -->
    <?php include __DIR__ . '/components/chat-widget.php'; ?>
</body>
</html>