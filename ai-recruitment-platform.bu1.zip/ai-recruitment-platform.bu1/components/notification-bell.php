<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!function_exists('isLoggedIn')) {
    require_once __DIR__ . '/../utils/middleware/Auth.php';
}

if (!class_exists('Notification')) {
    require_once __DIR__ . '/../utils/models/Notification.php';
}

if (!class_exists('Database')) {
    require_once __DIR__ . '/../config/database.php';
}

if (!isLoggedIn()) {
    return;
}

$notificationModel = new Notification();
$notifications = [];
$notificationUnread = 0;
$chatUnread = 0;

try {
    $notifications = $notificationModel->getNotifications($_SESSION['user_id'], 5, 0);
    $notificationUnread = (int)$notificationModel->countUnread($_SESSION['user_id']);
} catch (Exception $e) {
    // ignore
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    if (($_SESSION['role'] ?? '') === 'candidate') {
        $stmt = $conn->prepare("SELECT COALESCE(SUM(candidate_unread_count), 0) FROM conversations WHERE candidate_id = :uid AND status = 'active'");
    } else {
        $stmt = $conn->prepare("SELECT COALESCE(SUM(recruiter_unread_count), 0) FROM conversations WHERE recruiter_id = :uid AND status = 'active'");
    }
    $stmt->execute([':uid' => $_SESSION['user_id']]);
    $chatUnread = (int)$stmt->fetchColumn();
} catch (Exception $e) {
    // ignore
}

$totalBadge = $notificationUnread + $chatUnread;
$role = $_SESSION['role'] ?? 'candidate';
$messageLink = $role === 'recruiter'
    ? BASE_URL . 'views/recruiter/applications.php'
    : BASE_URL . 'views/candidate/messages.php';
$fallbackAttr = htmlspecialchars($messageLink, ENT_QUOTES, 'UTF-8');
?>
<div class="relative" id="notificationBell">
    <button type="button" id="notificationBellToggle" class="relative w-11 h-11 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
            <path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75V9a6 6 0 10-12 0v.75a8.967 8.967 0 01-2.312 6.022c1.766.64 3.61 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
        </svg>
        <?php if ($totalBadge > 0): ?>
            <span class="absolute -top-1 -right-1 bg-red-500 text-white text-[11px] font-semibold px-1.5 rounded-full">
                <?php echo $totalBadge > 99 ? '99+' : $totalBadge; ?>
            </span>
        <?php endif; ?>
    </button>
    <div id="notificationPanel" class="hidden absolute right-0 mt-3 w-80 bg-white shadow-2xl rounded-2xl border border-slate-200/70 z-50">
        <div class="px-4 py-3 border-b border-slate-200/60 flex justify-between items-center">
            <div>
                <p class="text-sm font-semibold text-slate-800">Hoạt động gần đây</p>
                <p class="text-xs text-slate-500"><?php echo $totalBadge > 0 ? 'Bạn có thông báo/tin nhắn mới' : 'Đã đọc hết thông báo'; ?></p>
            </div>
            <span class="text-xs text-blue-500 font-semibold"><?php echo $totalBadge; ?></span>
        </div>

        <div class="max-h-64 overflow-y-auto">
            <?php if (empty($notifications)): ?>
                <div class="px-4 py-6 text-center text-sm text-slate-500">
                    Chưa có thông báo mới.
                </div>
            <?php else: ?>
                <?php foreach ($notifications as $notification): 
                    // Generate link based on notification type
                    $link = '#';
                    $type = $notification['type'] ?? '';
                    $relatedId = $notification['related_id'] ?? null;
                    
                    switch ($type) {
                        case 'new_application':
                        case 'application_status':
                            if ($role === 'recruiter' && $relatedId) {
                                $link = BASE_URL . 'views/recruiter/applications.php?job_id=' . $relatedId;
                            } else if ($role === 'candidate') {
                                $link = BASE_URL . 'views/candidate/applications.php';
                            }
                            break;
                        case 'job_match':
                        case 'new_job':
                            if ($relatedId) {
                                $link = BASE_URL . 'views/public/job-detail.php?id=' . $relatedId;
                            } else {
                                $link = BASE_URL . 'views/candidate/search-jobs.php';
                            }
                            break;
                        case 'message':
                        case 'candidate_message':
                        case 'recruiter_message':
                            if ($role === 'candidate') {
                                $link = BASE_URL . 'views/candidate/messages.php';
                            } else {
                                $link = BASE_URL . 'views/recruiter/applications.php';
                            }
                            break;
                        case 'profile_view':
                        case 'profile_incomplete':
                            $link = BASE_URL . 'views/candidate/profile.php';
                            break;
                        case 'interview_scheduled':
                            if ($role === 'recruiter' && $relatedId) {
                                $link = BASE_URL . 'views/recruiter/applications.php?job_id=' . $relatedId;
                            } else {
                                $link = BASE_URL . 'views/candidate/applications.php';
                            }
                            break;
                        default:
                            $link = BASE_URL . 'views/' . $role . '/dashboard.php';
                    }
                ?>
                    <a href="<?php echo htmlspecialchars($link, ENT_QUOTES, 'UTF-8'); ?>" 
                       data-notification-id="<?php echo $notification['id']; ?>"
                       class="block px-4 py-3 border-b border-slate-200/60 last:border-b-0 hover:bg-slate-50 transition <?php echo empty($notification['is_read']) ? 'bg-blue-50/50' : ''; ?>">
                        <p class="text-sm font-semibold text-slate-800 flex items-center gap-2">
                            <?php if (empty($notification['is_read'])): ?><span class="w-2 h-2 bg-blue-500 rounded-full"></span><?php endif; ?>
                            <?php echo htmlspecialchars($notification['title'] ?? 'Thông báo', ENT_QUOTES, 'UTF-8'); ?>
                        </p>
                        <p class="text-xs text-slate-500 mt-1 leading-relaxed">
                            <?php echo htmlspecialchars($notification['content'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                        </p>
                        <span class="text-[11px] text-slate-400 mt-1 inline-block">
                            <?php echo date('H:i d/m', strtotime($notification['created_at'] ?? 'now')); ?>
                        </span>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php if (!defined('NOTIFICATION_BELL_SCRIPT')): ?>
<script>
(function(){
    const toggle = document.getElementById('notificationBellToggle');
    const panel = document.getElementById('notificationPanel');
    if (!toggle || !panel) return;
    const handler = (event) => {
        if (panel.contains(event.target) || toggle.contains(event.target)) {
            return;
        }
        panel.classList.add('hidden');
    };
    toggle.addEventListener('click', () => {
        panel.classList.toggle('hidden');
    });
    document.addEventListener('click', handler);
    
    // Mark notification as read when clicked
    panel.querySelectorAll('a[data-notification-id]').forEach(link => {
        link.addEventListener('click', function(e) {
            const notificationId = this.dataset.notificationId;
            if (notificationId) {
                // Send async request to mark as read
                fetch('<?php echo BASE_URL; ?>api.php?action=mark-notification-read', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'notification_id=' + notificationId
                }).catch(err => console.error('Failed to mark notification as read:', err));
            }
        });
    });
})();
</script>
<?php define('NOTIFICATION_BELL_SCRIPT', true); endif; ?>
