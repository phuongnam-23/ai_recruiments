<!-- Avatar Upload Component -->
<!-- Sử dụng ở: views/candidate/profile.php, views/recruiter/dashboard.php, views/admin/dashboard.php -->

<style>
    .avatar-wrapper {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 12px;
    }

    .avatar-container {
        position: relative;
        width: 160px;
        height: 160px;
        border-radius: 50%;
        overflow: hidden;
        border: 4px solid #e5e7eb;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        background: #f3f4f6;
    }

    .avatar-container img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
    }

    .avatar-overlay {
        position: absolute;
        inset: 0;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.3s;
        backdrop-filter: blur(2px);
    }

    .avatar-container:hover .avatar-overlay {
        opacity: 1;
    }

    .avatar-overlay-icon {
        background: #3b82f6;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s;
        box-shadow: 0 2px 8px rgba(59, 130, 246, 0.5);
    }

    .avatar-overlay-icon:hover {
        background: #2563eb;
        transform: scale(1.1);
    }

    .avatar-overlay-icon svg {
        width: 24px;
        height: 24px;
        color: white;
    }

    .avatar-loading {
        display: none;
        position: absolute;
        inset: 0;
        background: rgba(0, 0, 0, 0.7);
        border-radius: 50%;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 12px;
        font-weight: 600;
        z-index: 20;
    }

    .avatar-actions {
        display: flex;
        gap: 8px;
        justify-content: center;
    }

    .avatar-btn {
        padding: 8px 16px;
        border-radius: 6px;
        border: none;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .avatar-btn-upload {
        background: #3b82f6;
        color: white;
    }

    .avatar-btn-upload:hover {
        background: #2563eb;
    }

    .avatar-btn-view {
        background: #e5e7eb;
        color: #1f2937;
    }

    .avatar-btn-view:hover {
        background: #d1d5db;
    }

    #avatar-file-input {
        display: none;
    }
</style>

<div class="avatar-wrapper">
    <div class="avatar-container" id="avatar-container">
        <?php
        // Debug: In ra console để kiểm tra
        echo "<!-- DEBUG Avatar: " . var_export($user['avatar_url'] ?? 'NULL', true) . " -->\n";
        
        $avatarSrc = 'https://ui-avatars.com/api/?name=' . urlencode($user['full_name'] ?? 'User') . '&background=random&size=320';
        if (!empty($user['avatar_url'])) {
            // Nếu đã có http/https thì dùng luôn
            if (strpos($user['avatar_url'], 'http') === 0) {
                $avatarSrc = $user['avatar_url'];
            } else {
                // Nếu là path tương đối, thêm BASE_URL
                $avatarSrc = BASE_URL . ltrim($user['avatar_url'], '/');
            }
        }
        echo "<!-- Avatar SRC: " . htmlspecialchars($avatarSrc) . " -->\n";
        ?>
        <img id="avatar-img" 
             src="<?php echo htmlspecialchars($avatarSrc); ?>" 
             alt="<?php echo htmlspecialchars($user['full_name'] ?? 'User'); ?>"
             onerror="console.error('Failed to load avatar:', this.src)">
        <div class="avatar-overlay" id="avatar-overlay">
            <div class="avatar-overlay-icon" id="avatar-upload-icon" title="Tải ảnh lên">
                <svg fill="currentColor" viewBox="0 0 20 20">
                    <path d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z"/>
                </svg>
            </div>
        </div>
        <div class="avatar-loading" id="avatar-loading">⏳ Đang tải...</div>
    </div>

    <div class="avatar-actions">
        <button type="button" class="avatar-btn avatar-btn-view" id="avatar-view-btn" title="Xem ảnh đầy đủ">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
            </svg>
            Xem Ảnh
        </button>
        <button type="button" class="avatar-btn avatar-btn-upload" id="avatar-upload-btn" title="Tải ảnh lên">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
            </svg>
            Tải Ảnh
        </button>
    </div>
</div>

<input type="file" id="avatar-file-input" accept="image/jpeg,image/png,image/gif,image/webp">

<script>
(function() {
    const container = document.getElementById('avatar-container');
    const fileInput = document.getElementById('avatar-file-input');
    const avatarImg = document.getElementById('avatar-img');
    const loadingIndicator = document.getElementById('avatar-loading');
    const uploadIcon = document.getElementById('avatar-upload-icon');
    const uploadBtn = document.getElementById('avatar-upload-btn');
    const viewBtn = document.getElementById('avatar-view-btn');
    const overlay = document.getElementById('avatar-overlay');
    
    if (!container || !fileInput || !avatarImg) {
        console.warn('Avatar upload component elements not found');
        return;
    }
    
    // Click icon or upload button to select file
    uploadIcon.addEventListener('click', () => fileInput.click());
    uploadBtn.addEventListener('click', () => fileInput.click());
    
    // View button - open image in new tab
    viewBtn.addEventListener('click', () => {
        window.open(avatarImg.src, '_blank');
    });
    
    // Handle file selection
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        // Validate file type
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!allowedTypes.includes(file.type)) {
            alert('❌ Chỉ chấp nhận file ảnh (JPG, PNG, GIF, WebP)');
            return;
        }
        
        // Validate file size (20MB)
        const maxSize = 20 * 1024 * 1024;
        if (file.size > maxSize) {
            alert('❌ Kích thước file không được vượt quá 20MB');
            return;
        }
        
        // Upload file
        uploadAvatar(file);
    });
    
    function uploadAvatar(file) {
        const formData = new FormData();
        formData.append('avatar', file);
        
        // Show loading indicator
        loadingIndicator.style.display = 'flex';
        overlay.style.pointerEvents = 'none';
        
        fetch('<?php echo BASE_URL; ?>upload-avatar.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            console.log('Response text:', text);
            try {
                return JSON.parse(text);
            } catch (e) {
                throw new Error('JSON parse error: ' + text.substring(0, 100));
            }
        })
        .then(data => {
            if (data.success) {
                // Update avatar image with cache buster
                const timestamp = new Date().getTime();
                const newSrc = '<?php echo BASE_URL; ?>' + data.path + '?t=' + timestamp;
                avatarImg.src = newSrc;
                
                // Update all avatar images on the page (navbar, profile, etc)
                updateAllAvatars(newSrc);
                
                alert('✅ ' + data.message);
                fileInput.value = '';
            } else {
                alert('❌ ' + data.message);
            }
        })
        .catch(error => {
            console.error('Upload error:', error);
            alert('❌ Lỗi tải lên: ' + error.message);
        })
        .finally(() => {
            // Hide loading indicator
            loadingIndicator.style.display = 'none';
            overlay.style.pointerEvents = 'auto';
        });
    }
    
    // Update all avatar images on page
    function updateAllAvatars(newSrc) {
        console.log('Updating avatars with src:', newSrc);
        
        // Update navbar avatar (by id) - HIGHEST PRIORITY
        const navAvatar = document.getElementById('nav-avatar');
        if (navAvatar) {
            console.log('Found nav-avatar, updating...');
            navAvatar.src = newSrc;
        } else {
            console.log('nav-avatar not found');
        }
        
        // Update profile avatar (by id)
        const profileAvatar = document.getElementById('preview-avatar');
        if (profileAvatar) {
            console.log('Found preview-avatar, updating...');
            profileAvatar.src = newSrc;
        }
        
        // Update view link
        const viewLink = document.getElementById('view-avatar-link');
        if (viewLink) {
            console.log('Found view-avatar-link, updating...');
            viewLink.href = newSrc.split('?')[0]; // Remove timestamp from href
        }
        
        // Update any other avatar images on page
        const allAvatars = document.querySelectorAll('img[alt*="avatar"], img.avatar-img');
        allAvatars.forEach(img => {
            if (img.id !== 'avatar-img') {
                console.log('Updating additional avatar:', img.id);
                img.src = newSrc;
            }
        });
    }
})();
</script>

