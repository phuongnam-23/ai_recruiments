<!-- Lazy Load Widgets Container -->
<div id="lazy-widgets-container"></div>

<!-- Lazy Load Widgets Script -->
<script>
(function() {
    // Prevent multiple loads
    if (window.widgetsLazyLoader) return;
    window.widgetsLazyLoader = true;
    
    let widgetsLoaded = false;
    
    function loadWidgets() {
        if (widgetsLoaded) return;
        widgetsLoaded = true;
        
        const container = document.getElementById('lazy-widgets-container');
        if (!container) return;
        
        console.log('⚡ Loading chat widgets...');
        
        // Load widgets via AJAX
        fetch('<?php echo BASE_URL; ?>api.php?action=load-widgets')
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.text();
            })
            .then(html => {
                container.innerHTML = html;
                console.log('✅ Chat widgets loaded successfully');
                
                // Dispatch event for other scripts that might need to know
                window.dispatchEvent(new CustomEvent('widgetsLoaded'));
            })
            .catch(error => {
                console.error('❌ Failed to load widgets:', error);
            });
    }
    
    // Strategy 1: User scrolls past 40% of page
    let scrollTriggered = false;
    window.addEventListener('scroll', function() {
        if (scrollTriggered) return;
        
        const scrollPercent = (window.scrollY + window.innerHeight) / document.documentElement.scrollHeight;
        if (scrollPercent > 0.4) {
            scrollTriggered = true;
            loadWidgets();
        }
    }, { passive: true });
    
    // Strategy 2: User hovers over notification bell (intends to interact)
    setTimeout(function() {
        const notificationBell = document.getElementById('notificationBell');
        if (notificationBell) {
            notificationBell.addEventListener('mouseenter', function() {
                loadWidgets();
            }, { once: true });
        }
    }, 500);
    
    // Strategy 3: User interacts with page (mousemove, click, etc)
    let interactionTimer;
    function onInteraction() {
        clearTimeout(interactionTimer);
        interactionTimer = setTimeout(function() {
            loadWidgets();
        }, 2000); // Load 2s after last interaction
    }
    
    ['mousemove', 'click', 'keydown', 'touchstart'].forEach(event => {
        document.addEventListener(event, onInteraction, { passive: true, once: true });
    });
    
    // Strategy 4: 3 seconds after page fully loaded (fallback)
    if (document.readyState === 'complete') {
        setTimeout(loadWidgets, 3000);
    } else {
        window.addEventListener('load', function() {
            setTimeout(loadWidgets, 3000);
        });
    }
    
    // Strategy 5: Page visibility change (user returns to tab)
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            setTimeout(loadWidgets, 500);
        }
    });
})();
</script>
