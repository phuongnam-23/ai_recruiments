<!-- Chat Widget Component -->
<style>
/* Chat Widget Styles */
.chat-widget {
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 9999;
}

.chat-toggle-btn {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    display: flex !important;
    align-items: center;
    justify-content: center;
    position: relative;
    transition: all 0.3s ease;
}

.chat-toggle-btn:hover {
    transform: scale(1.1);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
}

.chat-toggle-btn .badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background: #ef4444;
    color: white;
    border-radius: 50%;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: bold;
}

.chat-window {
    position: fixed;
    bottom: 90px;
    right: 20px;
    width: 380px;
    height: 600px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
    display: none;
    flex-direction: column;
    overflow: hidden;
    z-index: 999;
}

.chat-window.active {
    display: flex;
}

.chat-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.chat-header h3 {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
}

.chat-close-btn {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: white;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s;
}

.chat-close-btn:hover {
    background: rgba(255, 255, 255, 0.3);
}

.chat-conversations-list {
    flex: 1;
    overflow-y: auto;
    padding: 12px;
}

.conversation-item {
    padding: 12px;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.2s;
    margin-bottom: 8px;
    display: flex;
    align-items: flex-start;
    gap: 12px;
}

.conversation-item:hover {
    background: #f3f4f6;
}

.conversation-item.active {
    background: #e0e7ff;
}

.conversation-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: #667eea;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    flex-shrink: 0;
}

.conversation-avatar img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
}

.conversation-info {
    flex: 1;
    min-width: 0;
}

.conversation-name {
    font-weight: 600;
    font-size: 14px;
    margin-bottom: 2px;
    color: #1f2937;
}

.conversation-job {
    font-size: 12px;
    color: #6b7280;
    margin-bottom: 4px;
}

.conversation-last-message {
    font-size: 13px;
    color: #9ca3af;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.conversation-meta {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 4px;
}

.conversation-time {
    font-size: 11px;
    color: #9ca3af;
}

.conversation-unread {
    background: #ef4444;
    color: white;
    border-radius: 12px;
    padding: 2px 8px;
    font-size: 11px;
    font-weight: 600;
}

/* Chat Messages View */
.chat-messages-view {
    display: none;
    flex-direction: column;
    height: 100%;
}

.chat-messages-view.active {
    display: flex;
}

.chat-messages-header {
    padding: 12px 16px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    align-items: center;
    gap: 12px;
}

.chat-back-btn {
    background: none;
    border: none;
    cursor: pointer;
    color: #6b7280;
    padding: 4px;
}

.chat-messages-container {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
    background: #f9fafb;
}

.message-group {
    margin-bottom: 16px;
}

.message-item {
    display: flex;
    gap: 8px;
    margin-bottom: 8px;
}

.message-item.sent {
    flex-direction: row-reverse;
}

.message-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: #667eea;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: 600;
    flex-shrink: 0;
}

.message-avatar img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
}

.message-content {
    max-width: 70%;
}

.message-bubble {
    padding: 10px 14px;
    border-radius: 12px;
    background: white;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    word-wrap: break-word;
}

.message-item.sent .message-bubble {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.message-time {
    font-size: 11px;
    color: #9ca3af;
    margin-top: 4px;
    padding: 0 8px;
}

.chat-input-area {
    padding: 12px 16px;
    border-top: 1px solid #e5e7eb;
    background: white;
}

.chat-input-form {
    display: flex;
    gap: 8px;
    align-items: center;
}

.chat-input {
    flex: 1;
    border: 1px solid #e5e7eb;
    border-radius: 20px;
    padding: 10px 16px;
    font-size: 14px;
    outline: none;
}

.chat-input:focus {
    border-color: #667eea;
}

.chat-send-btn {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    color: white;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.chat-send-btn:hover {
    opacity: 0.9;
}

.chat-send-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: #9ca3af;
    padding: 32px;
    text-align: center;
}

.empty-state svg {
    margin-bottom: 16px;
}

/* Scrollbar styling */
.chat-conversations-list::-webkit-scrollbar,
.chat-messages-container::-webkit-scrollbar {
    width: 6px;
}

.chat-conversations-list::-webkit-scrollbar-track,
.chat-messages-container::-webkit-scrollbar-track {
    background: #f3f4f6;
}

.chat-conversations-list::-webkit-scrollbar-thumb,
.chat-messages-container::-webkit-scrollbar-thumb {
    background: #d1d5db;
    border-radius: 3px;
}

.chat-conversations-list::-webkit-scrollbar-thumb:hover,
.chat-messages-container::-webkit-scrollbar-thumb:hover {
    background: #9ca3af;
}

@media (max-width: 640px) {
    .chat-window {
        width: 100%;
        height: 100%;
        bottom: 0;
        right: 0;
        border-radius: 0;
    }
    
    .chat-toggle-btn {
        bottom: 10px;
        right: 10px;
    }
}
</style>

<!-- Chat Widget HTML -->
<?php if (isset($_SESSION['user_id'])): ?>
<div class="chat-widget">
    <!-- Toggle Button -->
    <button class="chat-toggle-btn" id="chatToggleBtn" onclick="ChatWidget.toggle()">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" style="width: 28px; height: 28px;">
            <path stroke-linecap="round" stroke-linejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 01-2.555-.337A5.972 5.972 0 015.41 20.97a5.969 5.969 0 01-.474-.065 4.48 4.48 0 00.978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z" />
        </svg>
        <span class="badge" id="chatUnreadBadge" style="display: none;">0</span>
    </button>

    <!-- Chat Window -->
    <div class="chat-window" id="chatWindow">
        <!-- Header -->
        <div class="chat-header">
            <h3>Tin nhắn</h3>
            <button class="chat-close-btn" onclick="ChatWidget.close()">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" style="width: 16px; height: 16px;">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <!-- Conversations List View -->
        <div class="chat-conversations-list" id="conversationsList">
            <!-- Empty state -->
            <div class="empty-state">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width: 64px; height: 64px;">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 01-.825-.242m9.345-8.334a2.126 2.126 0 00-.476-.095 48.64 48.64 0 00-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0011.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155" />
                </svg>
                <p>Chưa có cuộc trò chuyện nào</p>
            </div>
        </div>

        <!-- Messages View -->
        <div class="chat-messages-view" id="messagesView">
            <div class="chat-messages-header">
                <button class="chat-back-btn" onclick="ChatWidget.backToList()">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" style="width: 20px; height: 20px;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
                    </svg>
                </button>
                <div class="conversation-avatar" id="chatPartnerAvatar"></div>
                <div style="flex: 1; min-width: 0;">
                    <div class="conversation-name" id="chatPartnerName"></div>
                    <div class="conversation-job" id="chatJobTitle"></div>
                </div>
            </div>

            <div class="chat-messages-container" id="messagesContainer">
                <!-- Messages will be loaded here -->
            </div>

            <div class="chat-input-area">
                <form class="chat-input-form" onsubmit="ChatWidget.sendMessage(event)">
                    <input type="text" class="chat-input" id="messageInput" placeholder="Nhập tin nhắn..." autocomplete="off">
                    <button type="submit" class="chat-send-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" style="width: 20px; height: 20px;">
                            <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" />
                        </svg>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Chat Widget JavaScript
const ChatWidget = {
    currentConversationId: null,
    pollingInterval: null,
    lastMessageTime: null,
    apiBase: '<?php echo BASE_URL; ?>api.php',
    
    init() {
        this.loadUnreadCount();
        this.startUnreadPolling();
    },
    
    toggle() {
        const window = document.getElementById('chatWindow');
        const isActive = window.classList.contains('active');
        
        if (isActive) {
            this.close();
        } else {
            this.open();
        }
    },
    
    open() {
        document.getElementById('chatWindow').classList.add('active');
        this.loadConversations();
    },
    
    close() {
        document.getElementById('chatWindow').classList.remove('active');
        this.backToList();
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
            this.pollingInterval = null;
        }
    },
    
    async loadUnreadCount() {
        try {
            const response = await fetch(`${this.apiBase}?action=get-unread-count`, {
                credentials: 'include'
            });
            const data = await response.json();
            
            if (data.success && data.unread_count > 0) {
                const badge = document.getElementById('chatUnreadBadge');
                badge.textContent = data.unread_count;
                badge.style.display = 'flex';
            } else {
                document.getElementById('chatUnreadBadge').style.display = 'none';
            }
        } catch (error) {
            console.error('Error loading unread count:', error);
        }
    },
    
    startUnreadPolling() {
        // Poll mỗi 30 giây
        setInterval(() => this.loadUnreadCount(), 30000);
    },
    
    async loadConversations() {
        try {
            const response = await fetch(`${this.apiBase}?action=get-conversations`, {
                credentials: 'include'
            });
            const data = await response.json();
            
            if (data.success) {
                this.renderConversations(data.conversations);
            }
        } catch (error) {
            console.error('Error loading conversations:', error);
        }
    },
    
    renderConversations(conversations) {
        const container = document.getElementById('conversationsList');
        
        if (conversations.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" style="width: 64px; height: 64px;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 01-.825-.242m9.345-8.334a2.126 2.126 0 00-.476-.095 48.64 48.64 0 00-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0011.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155" />
                    </svg>
                    <p>Chưa có cuộc trò chuyện nào</p>
                </div>
            `;
            return;
        }
        
        const role = '<?php echo $_SESSION['role'] ?? ''; ?>';
        const html = conversations.map(conv => {
            const partnerName = role === 'candidate' ? conv.recruiter_name : conv.candidate_name;
            const partnerAvatar = role === 'candidate' ? conv.recruiter_avatar : conv.candidate_avatar;
            const unreadCount = role === 'candidate' ? conv.candidate_unread_count : conv.recruiter_unread_count;
            const initials = partnerName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
            
            return `
                <div class="conversation-item" onclick="ChatWidget.openConversation(${conv.id})">
                    <div class="conversation-avatar">
                        ${partnerAvatar ? `<img src="${partnerAvatar}" alt="${partnerName}">` : initials}
                    </div>
                    <div class="conversation-info">
                        <div class="conversation-name">${partnerName}</div>
                        <div class="conversation-job">${conv.job_title} - ${conv.company_name}</div>
                        <div class="conversation-last-message">${conv.last_message || 'Chưa có tin nhắn'}</div>
                    </div>
                    <div class="conversation-meta">
                        <div class="conversation-time">${conv.last_message_time ? this.formatTime(conv.last_message_time) : ''}</div>
                        ${unreadCount > 0 ? `<div class="conversation-unread">${unreadCount}</div>` : ''}
                    </div>
                </div>
            `;
        }).join('');
        
        container.innerHTML = html;
    },
    
    async openConversation(conversationId) {
        this.currentConversationId = conversationId;
        
        try {
            const response = await fetch(`${this.apiBase}?action=get-conversation&id=${conversationId}`, {
                credentials: 'include'
            });
            const data = await response.json();
            
            if (data.success) {
                this.renderMessages(data.conversation, data.messages);
                this.markAsRead(conversationId);
                this.startMessagePolling();
            }
        } catch (error) {
            console.error('Error loading conversation:', error);
        }
    },
    
    renderMessages(conversation, messages) {
        const role = '<?php echo $_SESSION['role'] ?? ''; ?>';
        const userId = <?php echo $_SESSION['user_id'] ?? 0; ?>;
        
        const partnerName = role === 'candidate' ? conversation.recruiter_name : conversation.candidate_name;
        const partnerAvatar = role === 'candidate' ? conversation.recruiter_avatar : conversation.candidate_avatar;
        const initials = partnerName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
        
        // Update header
        const avatarEl = document.getElementById('chatPartnerAvatar');
        avatarEl.innerHTML = partnerAvatar ? `<img src="${partnerAvatar}" alt="${partnerName}">` : initials;
        document.getElementById('chatPartnerName').textContent = partnerName;
        document.getElementById('chatJobTitle').textContent = `${conversation.job_title} - ${conversation.company_name}`;
        
        // Render messages
        const container = document.getElementById('messagesContainer');
        if (messages.length === 0) {
            container.innerHTML = '<div class="empty-state"><p>Chưa có tin nhắn. Hãy bắt đầu cuộc trò chuyện!</p></div>';
        } else {
            const html = messages.map(msg => {
                const isSent = msg.sender_id == userId;
                const senderInitials = msg.sender_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
                
                return `
                    <div class="message-item ${isSent ? 'sent' : ''}">
                        <div class="message-avatar">
                            ${msg.sender_avatar ? `<img src="${msg.sender_avatar}" alt="${msg.sender_name}">` : senderInitials}
                        </div>
                        <div class="message-content">
                            <div class="message-bubble">${this.escapeHtml(msg.message)}</div>
                            <div class="message-time">${this.formatTime(msg.created_at)}</div>
                        </div>
                    </div>
                `;
            }).join('');
            
            container.innerHTML = html;
            this.lastMessageTime = messages[messages.length - 1].created_at;
        }
        
        // Show messages view
        document.getElementById('conversationsList').style.display = 'none';
        document.getElementById('messagesView').classList.add('active');
        
        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    },
    
    backToList() {
        document.getElementById('messagesView').classList.remove('active');
        document.getElementById('conversationsList').style.display = 'block';
        this.currentConversationId = null;
        
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
            this.pollingInterval = null;
        }
        
        this.loadConversations();
    },
    
    async sendMessage(event) {
        event.preventDefault();
        
        const input = document.getElementById('messageInput');
        const message = input.value.trim();
        
        if (!message || !this.currentConversationId) return;
        
        try {
            const response = await fetch(`${this.apiBase}?action=send-message`, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    conversation_id: this.currentConversationId,
                    message: message
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                input.value = '';
                this.appendMessage(data.message);
                this.lastMessageTime = data.message.created_at;
            }
        } catch (error) {
            console.error('Error sending message:', error);
        }
    },
    
    appendMessage(message) {
        const userId = <?php echo $_SESSION['user_id'] ?? 0; ?>;
        const container = document.getElementById('messagesContainer');
        const isSent = message.sender_id == userId;
        const senderInitials = message.sender_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
        
        // Remove empty state if exists
        if (container.querySelector('.empty-state')) {
            container.innerHTML = '';
        }
        
        const html = `
            <div class="message-item ${isSent ? 'sent' : ''}">
                <div class="message-avatar">
                    ${message.sender_avatar ? `<img src="${message.sender_avatar}" alt="${message.sender_name}">` : senderInitials}
                </div>
                <div class="message-content">
                    <div class="message-bubble">${this.escapeHtml(message.message)}</div>
                    <div class="message-time">${this.formatTime(message.created_at)}</div>
                </div>
            </div>
        `;
        
        container.insertAdjacentHTML('beforeend', html);
        container.scrollTop = container.scrollHeight;
    },
    
    startMessagePolling() {
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
        }
        
        // Poll every 3 seconds
        this.pollingInterval = setInterval(() => {
            if (this.currentConversationId && this.lastMessageTime) {
                this.pollNewMessages();
            }
        }, 3000);
    },
    
    async pollNewMessages() {
        try {
            const response = await fetch(
                `${this.apiBase}?action=poll-messages&conversation_id=${this.currentConversationId}&after=${encodeURIComponent(this.lastMessageTime)}`,
                { credentials: 'include' }
            );
            const data = await response.json();
            
            if (data.success && data.messages.length > 0) {
                data.messages.forEach(msg => this.appendMessage(msg));
                this.lastMessageTime = data.messages[data.messages.length - 1].created_at;
            }
        } catch (error) {
            console.error('Error polling messages:', error);
        }
    },
    
    async markAsRead(conversationId) {
        try {
            await fetch(`${this.apiBase}?action=mark-conversation-read`, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ conversation_id: conversationId })
            });
            
            this.loadUnreadCount();
        } catch (error) {
            console.error('Error marking as read:', error);
        }
    },
    
    formatTime(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);
        
        if (diffMins < 1) return 'Vừa xong';
        if (diffMins < 60) return `${diffMins} phút trước`;
        if (diffHours < 24) return `${diffHours} giờ trước`;
        if (diffDays < 7) return `${diffDays} ngày trước`;
        
        return date.toLocaleDateString('vi-VN');
    },
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
};

// Initialize on page load
<?php if (isset($_SESSION['user_id'])): ?>
document.addEventListener('DOMContentLoaded', () => {
    ChatWidget.init();
});
<?php endif; ?>
</script>
