-- Add matching score and AI analysis columns to applications table
ALTER TABLE applications ADD COLUMN IF NOT EXISTS match_score INT DEFAULT 0;
ALTER TABLE applications ADD COLUMN IF NOT EXISTS ai_analysis JSON NULL;
