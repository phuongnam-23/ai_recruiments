#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import json
import os

# Test UTF-8 encoding with Vietnamese text
test_data = {
    "success": True,
    "data": {
        "name": "Lê Tuấn Anh",
        "email": "test@example.com"
    }
}

def output_json(data):
    """Output JSON safely"""
    try:
        json_str = json.dumps(data, ensure_ascii=False)
        if hasattr(sys.stdout, 'buffer'):
            sys.stdout.buffer.write((json_str + '\n').encode('utf-8'))
        else:
            print(json_str)
        sys.stdout.flush()
    except Exception as e:
        error_msg = f'{{"success": false, "error": "{str(e)}"}}\n'
        if hasattr(sys.stdout, 'buffer'):
            sys.stdout.buffer.write(error_msg.encode('utf-8', errors='replace'))
        else:
            print(error_msg)

output_json(test_data)
