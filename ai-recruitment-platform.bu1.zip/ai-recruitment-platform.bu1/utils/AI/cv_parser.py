#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CV Parser Engine - Python Backend
Extracts text from PDF/DOCX and parses with Gemini API
"""

import sys
import os

# IMPORTANT: Set UTF-8 encoding BEFORE importing anything else
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    os.environ['PYTHONIOENCODING'] = 'utf-8'

import json
import re
from pathlib import Path

# Try to import required libraries
try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False
    print(json.dumps({"error": "google-generativeai not installed"}))
    sys.exit(1)

try:
    from PyPDF2 import PdfReader
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

try:
    from docx import Document
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False


class CVParser:
    # Multiple API keys for failover
    API_KEYS = [
        'AIzaSyAtITA06akwg1aj2bWT85N_5iSxbx4qxbA',
        'AIzaSyBqbmsPpRKeU8tZvBXKwZMxPvDncilQNB8',
        'AIzaSyBDD8pFkEky4mzgmIptc4LI_Rsuk4FDfkk',
        'AIzaSyD5oFWBT_GLsF-ucqMj3aq3ZsfdJqwyfAw',
    ]
    
    # Model fallback sequence (try models in order)
    MODELS = [
        'gemini-2.5-flash',  # Primary (best performance)
        'gemini-1.5-pro',    # Fallback 1 (more stable)
        'gemini-1.5-flash',  # Fallback 2 (lightweight)
    ]
    
    def __init__(self, api_key=None, model_name=None):
        """Initialize Gemini API with fallback support"""
        self.api_key_index = 0
        self.model_index = 0
        self.api_key = api_key
        self.model_name = model_name
        
        # Use provided API key or start with first one
        if not self.api_key:
            self.api_key = self.API_KEYS[0]
        
        if not self.model_name:
            self.model_name = self.MODELS[0]
        
        self.model = None
        self._configure_api()
    
    def _configure_api(self):
        """Configure Gemini API with current key and model"""
        try:
            genai.configure(api_key=self.api_key)
            self.model = genai.GenerativeModel(self.model_name)
            return True
        except Exception as e:
            print(f"Failed to configure API with key: {self.api_key[:20]}... and model: {self.model_name}")
            return False
    
    def _switch_api_key(self):
        """Switch to next available API key"""
        if self.api_key_index < len(self.API_KEYS) - 1:
            self.api_key_index += 1
            self.api_key = self.API_KEYS[self.api_key_index]
            print(f"Switching to API key {self.api_key_index + 1}/{len(self.API_KEYS)}")
            return self._configure_api()
        return False
    
    def _switch_model(self):
        """Switch to next available model"""
        if self.model_index < len(self.MODELS) - 1:
            self.model_index += 1
            self.model_name = self.MODELS[self.model_index]
            print(f"Switching to model: {self.model_name}")
            genai.configure(api_key=self.api_key)
            self.model = genai.GenerativeModel(self.model_name)
            return True
        return False
    
    def extract_text_from_pdf(self, file_path):
        """Extract text from PDF file"""
        if not PDF_AVAILABLE:
            raise Exception("PyPDF2 not installed. Install with: pip install PyPDF2")
        
        try:
            reader = PdfReader(file_path)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"
            return text.strip()
        except Exception as e:
            raise Exception(f"PDF extraction failed: {str(e)}")
    
    def extract_text_from_docx(self, file_path):
        """Extract text from DOCX file"""
        if not DOCX_AVAILABLE:
            raise Exception("python-docx not installed. Install with: pip install python-docx")
        
        try:
            doc = Document(file_path)
            text = ""
            for para in doc.paragraphs:
                text += para.text + "\n"
            return text.strip()
        except Exception as e:
            raise Exception(f"DOCX extraction failed: {str(e)}")
    
    def extract_text_from_txt(self, file_path):
        """Extract text from TXT file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read().strip()
        except Exception as e:
            raise Exception(f"TXT extraction failed: {str(e)}")
    
    def extract_text(self, file_path):
        """Extract text from CV file based on extension"""
        ext = Path(file_path).suffix.lower()
        
        if ext == '.pdf':
            return self.extract_text_from_pdf(file_path)
        elif ext == '.docx':
            return self.extract_text_from_docx(file_path)
        elif ext == '.doc':
            raise Exception("DOC format not supported. Please convert to DOCX or PDF")
        elif ext == '.txt':
            return self.extract_text_from_txt(file_path)
        else:
            raise Exception(f"Unsupported file format: {ext}")
    
    def clean_json_response(self, response_text):
        """Clean Gemini response to extract pure JSON"""
        # Remove markdown code blocks
        response_text = re.sub(r'```json\s*', '', response_text)
        response_text = re.sub(r'```\s*', '', response_text)
        response_text = response_text.strip()
        
        # Try to find JSON object in response
        try:
            return json.loads(response_text)
        except json.JSONDecodeError:
            # Try to extract JSON from surrounding text
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                try:
                    return json.loads(json_match.group())
                except json.JSONDecodeError:
                    pass
        
        raise Exception("Could not parse JSON from Gemini response")
    
    def parse_cv(self, cv_text):
        """Parse CV text using Gemini API with fallback support"""
        # Limit CV text to avoid token limits (increase to 4000 for better analysis)
        cv_text_limited = cv_text[:4000]
        
        prompt = """Bạn là chuyên gia phân tích CV. Hãy phân tích CV dưới đây và trích xuất CHÍNH XÁC các thông tin.

**QUAN TRỌNG:**
- Đọc KỸ toàn bộ CV trước khi trích xuất
- Tìm số điện thoại ở bất kỳ đâu trong CV (đầu trang, cuối trang, phần liên hệ)
- Tìm email chính xác (không bỏ sót)
- Skills phải là danh sách đầy đủ các kỹ năng được đề cập
- Experience_years: tính theo tổng số năm kinh nghiệm làm việc
- Education_level: high_school (THPT), associate (Cao đẳng), bachelor (Đại học), master (Thạc sĩ), phd (Tiến sĩ)

**CV TEXT:**
{cv_text}

**YÊU CẦU OUTPUT:**
Trả về CHỈ JSON object (không có markdown, không có text thừa):
{{
  "name": "Họ tên đầy đủ",
  "email": "email@example.com",
  "phone": "0912345678",
  "address": "Địa chỉ đầy đủ",
  "summary": "Tóm tắt kinh nghiệm và mục tiêu nghề nghiệp",
  "skills": ["Python", "JavaScript", "SQL"],
  "experience_years": 3,
  "education_level": "bachelor"
}}

Nếu không tìm thấy thông tin nào, để giá trị mặc định:
- Chuỗi: ""
- Số: 0
- Mảng: []

PHÂN TÍCH:""".format(cv_text=cv_text_limited)
        
        max_retries = len(self.API_KEYS) * len(self.MODELS)
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                response = self.model.generate_content(prompt)
                return self.clean_json_response(response.text)
            
            except Exception as e:
                error_msg = str(e).lower()
                retry_count += 1
                
                # Check if it's a rate limit error
                if 'rate_limit' in error_msg or '429' in error_msg or 'quota' in error_msg or 'limit' in error_msg:
                    print(f"Rate limit detected: {str(e)[:100]}")
                    
                    # First try switching model
                    if self._switch_model():
                        print(f"Retrying with model: {self.model_name}")
                        continue
                    
                    # If all models exhausted, switch API key and reset models
                    if self._switch_api_key():
                        self.model_index = 0
                        self.model_name = self.MODELS[0]
                        genai.configure(api_key=self.api_key)
                        self.model = genai.GenerativeModel(self.model_name)
                        print(f"Retrying with new API key and model: {self.model_name}")
                        continue
                
                # For other errors, just raise
                raise Exception(f"Gemini API error: {str(e)}")
        
        raise Exception("Failed to parse CV: All API keys and models exhausted or rate limited")
    
    def process_file(self, file_path):
        """Process CV file: extract text and parse with Gemini"""
        if not os.path.exists(file_path):
            raise Exception(f"File not found: {file_path}")
        
        # Extract text
        cv_text = self.extract_text(file_path)
        
        if not cv_text or len(cv_text.strip()) < 10:
            raise Exception("Could not extract meaningful text from CV")
        
        # Parse with Gemini
        parsed_data = self.parse_cv(cv_text)
        
        return {
            "success": True,
            "data": parsed_data
        }


def main():
    """Main entry point for command-line usage"""
    if len(sys.argv) < 2:
        result = {"error": "File path required"}
        output_json(result)
        sys.exit(1)
    
    file_path = sys.argv[1]
    
    try:
        parser = CVParser()
        result = parser.process_file(file_path)
        output_json(result)
    except Exception as e:
        result = {
            "success": False,
            "error": str(e)
        }
        output_json(result)
        sys.exit(1)


def output_json(data):
    """Output JSON safely to stdout with UTF-8 encoding"""
    try:
        json_str = json.dumps(data, ensure_ascii=False)
        # Write directly to stdout.buffer with UTF-8 encoding
        if hasattr(sys.stdout, 'buffer'):
            sys.stdout.buffer.write((json_str + '\n').encode('utf-8'))
        else:
            print(json_str)
        sys.stdout.flush()
    except Exception as e:
        # Fallback: write error
        error_msg = f'{{"success": false, "error": "Output encoding error: {str(e)}"}}\n'
        if hasattr(sys.stdout, 'buffer'):
            sys.stdout.buffer.write(error_msg.encode('utf-8', errors='replace'))
        else:
            print(error_msg)


if __name__ == '__main__':
    main()


if __name__ == "__main__":
    main()
