#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI Job Recommender
Tính matching score giữa CV của candidate và các jobs trong database
"""

import sys
import json
import io
import base64
import google.generativeai as genai

# Force UTF-8 encoding
sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8')
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

def get_api_keys():
    """Rotate API keys to avoid quota limits"""
    return [
        'AIzaSyAtITA06akwg1aj2bWT85N_5iSxbx4qxbA',
        'AIzaSyBqbmsPpRKeU8tZvBXKwZMxPvDncilQNB8',
        'AIzaSyBDD8pFkEky4mzgmIptc4LI_Rsuk4FDfkk',
        'AIzaSyD5oFWBT_GLsF-ucqMj3aq3ZsfdJqwyfAw'
    ]

def get_model_candidates():
    """List of Gemini models to try"""
    return [
        'gemini-1.5-flash',
        'gemini-2.0-flash-lite',
        'gemini-2.5-flash-lite'
    ]

def build_prompt(cv_data, job):
    """Build prompt for Gemini to calculate match score"""
    prompt = f"""Bạn là AI chuyên phân tích tương thích công việc.

**CANDIDATE CV:**
- Skills: {cv_data.get('skills', 'N/A')}
- Experience: {cv_data.get('experience_years', 0)} năm
- Education: {cv_data.get('education', 'N/A')}
- Summary: {cv_data.get('summary', 'N/A')}

**JOB REQUIREMENTS:**
- Title: {job['title']}
- Description: {job['description']}
- Requirements: {job.get('requirements', 'N/A')}
- Location: {job.get('location', 'N/A')}
- Salary: {job.get('salary_range', 'N/A')}

**NHIỆM VỤ:**
Tính matching score từ 0-100 dựa trên:
1. Kỹ năng phù hợp (40%)
2. Kinh nghiệm phù hợp (30%)
3. Học vấn phù hợp (20%)
4. Vị trí địa lý (10%)

**OUTPUT FORMAT (JSON):**
{{
  "score": 85,
  "reasons": ["Kỹ năng Python khớp với yêu cầu", "3 năm kinh nghiệm phù hợp"],
  "missing": ["Thiếu kinh nghiệm AWS", "Chưa có chứng chỉ PMP"]
}}

CHỈ trả về JSON, không giải thích thêm."""
    return prompt

def call_gemini(prompt, api_keys, models):
    """Call Gemini API with retry logic"""
    for api_key in api_keys:
        for model_name in models:
            try:
                genai.configure(api_key=api_key)
                model = genai.GenerativeModel(model_name)
                
                response = model.generate_content(
                    prompt,
                    generation_config={
                        'temperature': 0.3,
                        'max_output_tokens': 500
                    }
                )
                
                return response.text.strip()
            except Exception as e:
                error_msg = str(e)
                if '429' in error_msg or 'quota' in error_msg.lower():
                    continue  # Try next key/model
                elif '404' in error_msg:
                    continue  # Try next model
                else:
                    # Other error, try next combination
                    continue
    
    # All attempts failed
    return None

def parse_ai_response(text):
    """Parse AI response to extract JSON"""
    # Remove markdown code blocks
    text = text.replace('```json', '').replace('```', '').strip()
    
    try:
        return json.loads(text)
    except:
        # Fallback parsing
        import re
        score_match = re.search(r'"score"\s*:\s*(\d+)', text)
        if score_match:
            return {
                'score': int(score_match.group(1)),
                'reasons': ['AI analysis completed'],
                'missing': []
            }
        return None

def generate_mock_score(cv_data, job):
    """Generate mock score when API fails"""
    # Simple keyword matching
    cv_text = f"{cv_data.get('skills', '')} {cv_data.get('summary', '')}".lower()
    job_text = f"{job['title']} {job['description']}".lower()
    
    # Count matching keywords
    keywords = ['python', 'javascript', 'java', 'react', 'nodejs', 'sql', 'aws', 'docker']
    matches = sum(1 for kw in keywords if kw in cv_text and kw in job_text)
    
    base_score = 50 + (matches * 5)
    
    # Experience bonus
    exp_years = cv_data.get('experience_years', 0)
    if exp_years >= 3:
        base_score += 10
    elif exp_years >= 1:
        base_score += 5
    
    return {
        'score': min(base_score, 95),
        'reasons': [f'Tìm thấy {matches} kỹ năng khớp', f'{exp_years} năm kinh nghiệm'],
        'missing': ['Phân tích chi tiết cần API']
    }

def recommend_jobs(cv_data, jobs):
    """Calculate match scores for all jobs"""
    api_keys = get_api_keys()
    models = get_model_candidates()
    
    results = []
    
    for job in jobs:
        prompt = build_prompt(cv_data, job)
        ai_response = call_gemini(prompt, api_keys, models)
        
        if ai_response:
            match_data = parse_ai_response(ai_response)
            if match_data:
                results.append({
                    'job_id': job['id'],
                    'title': job['title'],
                    'company': job.get('company_name', 'N/A'),
                    'location': job.get('location', 'N/A'),
                    'salary': job.get('salary_range', 'N/A'),
                    'score': match_data['score'],
                    'reasons': match_data.get('reasons', []),
                    'missing': match_data.get('missing', [])
                })
                continue
        
        # Fallback to mock score
        mock = generate_mock_score(cv_data, job)
        results.append({
            'job_id': job['id'],
            'title': job['title'],
            'company': job.get('company_name', 'N/A'),
            'location': job.get('location', 'N/A'),
            'salary': job.get('salary_range', 'N/A'),
            'score': mock['score'],
            'reasons': mock.get('reasons', []),
            'missing': mock.get('missing', [])
        })
    
    # Sort by score descending
    results.sort(key=lambda x: x['score'], reverse=True)
    
    # Return top 10
    return results[:10]

def main():
    try:
        # Read input from stdin
        input_data = sys.stdin.read()
        data = json.loads(input_data)
        
        cv_data = data.get('cv_data', {})
        jobs = data.get('jobs', [])
        
        if not jobs:
            print(json.dumps({
                'success': False,
                'message': 'Không có công việc nào để gợi ý'
            }, ensure_ascii=False))
            return
        
        recommendations = recommend_jobs(cv_data, jobs)
        
        print(json.dumps({
            'success': True,
            'recommendations': recommendations
        }, ensure_ascii=False))
        
    except Exception as e:
        print(json.dumps({
            'success': False,
            'message': f'Lỗi: {str(e)}'
        }, ensure_ascii=False))

if __name__ == '__main__':
    main()
