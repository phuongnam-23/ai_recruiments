#!/usr/bin/env python3
"""AI Career Chatbot Engine.
Reads base64-encoded message + user context, calls Gemini, prints JSON.
"""
import base64
import io
import json
import os
import sys
from typing import Any, Dict, List, Optional

# Ensure UTF-8 output (especially on Windows)
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
if sys.stderr.encoding != 'utf-8':
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
os.environ.setdefault('PYTHONIOENCODING', 'utf-8')

try:
    import google.generativeai as genai  # type: ignore
    GEMINI_AVAILABLE = True
except Exception:  # pragma: no cover - fallback path
    genai = None
    GEMINI_AVAILABLE = False

MODEL_NAME = os.getenv('CHATBOT_MODEL', 'gemini-1.5-flash')
HARDCODED_KEYS = [
    'AIzaSyAtITA06akwg1aj2bWT85N_5iSxbx4qxbA',
    'AIzaSyBqbmsPpRKeU8tZvBXKwZMxPvDncilQNB8',
    'AIzaSyBDD8pFkEky4mzgmIptc4LI_Rsuk4FDfkk',
    'AIzaSyD5oFWBT_GLsF-ucqMj3aq3ZsfdJqwyfAw',
]
SYSTEM_PROMPT_TEMPLATE = (
    "Bạn là AI Career Advisor của nền tảng tuyển dụng. Nhiệm vụ của bạn là tư vấn nghề nghiệp, "
    "sửa CV và gợi ý phỏng vấn.\n"
    "Phong cách: Chuyên nghiệp, ngắn gọn, khích lệ. Sử dụng Markdown và Emoji.\n"
    "Nếu người dùng hỏi về CV, hãy đưa ra lời khuyên cụ thể (định lượng, từ khóa).\n"
    "Context người dùng hiện tại: {context}\n"
)

def emit(payload: Dict[str, Any]) -> None:
    """Print JSON and exit."""
    sys.stdout.write(json.dumps(payload, ensure_ascii=False))


def list_from_env(var_name: str) -> List[str]:
    raw = os.getenv(var_name, '')
    if not raw:
        return []
    return [item.strip() for item in raw.replace('\n', ',').split(',') if item.strip()]


def get_api_keys() -> List[str]:
    keys = list_from_env('GEMINI_API_KEYS')
    for fallback in (os.getenv('GEMINI_API_KEY'), os.getenv('GEMINI_KEY')):
        if fallback:
            keys.append(fallback)
    keys.extend(HARDCODED_KEYS)
    # Remove duplicates while preserving order
    seen = set()
    unique_keys = []
    for key in keys:
        if key and key not in seen:
            unique_keys.append(key)
            seen.add(key)
    return unique_keys


def get_model_candidates() -> List[str]:
    env_models = list_from_env('CHATBOT_MODELS')
    if env_models:
        return env_models
    # Use only models available in free tier with quota remaining
    defaults = ['gemini-1.5-flash', 'gemini-2.0-flash-lite', 'gemini-2.5-flash-lite']
    result: List[str] = []
    for name in defaults:
        if name and name not in result:
            result.append(name)
    return result

def decode_arg(value: str) -> str:
    try:
        return base64.b64decode(value).decode('utf-8')
    except Exception:
        return ''

def parse_context(raw: str) -> Dict[str, Any]:
    try:
        data = json.loads(raw or '{}')
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def build_system_prompt(user_context: Dict[str, Any]) -> str:
    serialized = json.dumps(user_context, ensure_ascii=False)
    return SYSTEM_PROMPT_TEMPLATE.format(context=serialized)

def build_mock_reply(message: str, context: Dict[str, Any]) -> str:
    name = context.get('name') or 'ứng viên'
    top_skill = ''
    skills = context.get('skills')
    if isinstance(skills, list) and skills:
        top_skill = skills[0]
    bullet = f"• Ưu tiên làm nổi bật kỹ năng {top_skill}." if top_skill else "• Nêu rõ kỹ năng chính trong CV."
    return (
        f"💡 **Chào {name}!**\n"
        "Mình tạm thời chưa kết nối được với AI thật nên gửi gợi ý nhanh:\n"
        f"{bullet}\n"
        "• Dùng số liệu định lượng (ví dụ: tăng 25% doanh thu).\n"
        "• Kết thúc bằng câu hỏi để tiếp tục cuộc trò chuyện."
    )

def call_gemini(message: str, prompt: str) -> str:
    if not GEMINI_AVAILABLE:
        raise RuntimeError('Thiếu thư viện google-generativeai. Vui lòng cài đặt theo requirements.')

    keys = get_api_keys()
    models = get_model_candidates()
    if not keys:
        raise RuntimeError('Chưa cấu hình GEMINI_API_KEY / GEMINI_API_KEYS')

    last_error: Optional[str] = None

    for api_key in keys:
        try:
            genai.configure(api_key=api_key)
        except Exception as exc:  # bad key format etc.
            last_error = f'configure key failed: {exc}'
            continue

        for model_name in models:
            try:
                model = genai.GenerativeModel(model_name=model_name, system_instruction=prompt)
                response = model.generate_content([
                    {"role": "user", "parts": [message[:6000]]}
                ], generation_config={
                    'temperature': 0.4,
                    'top_p': 0.9,
                    'top_k': 40,
                    'max_output_tokens': 768,
                })

                text = getattr(response, 'text', '').strip() if response else ''
                if not text:
                    raise RuntimeError('Gemini không trả lời')
                return text
            except Exception as exc:  # quota, model limit, etc.
                last_error = f'{model_name}: {exc}'
                continue

    raise RuntimeError(last_error or 'Gemini không phản hồi với các khóa hiện tại')

def main() -> None:
    if len(sys.argv) < 3:
        emit({'success': False, 'error': 'Missing arguments'})
        return

    raw_message = decode_arg(sys.argv[1])
    raw_context = decode_arg(sys.argv[2])
    user_context = parse_context(raw_context)

    if not raw_message:
        emit({'success': False, 'error': 'Empty message'})
        return

    prompt = build_system_prompt(user_context)

    try:
        reply = call_gemini(raw_message, prompt)
        emit({'success': True, 'reply': reply})
    except Exception as exc:
        fallback = build_mock_reply(raw_message, user_context)
        emit({'success': True, 'reply': fallback, 'warning': str(exc)})

if __name__ == '__main__':
    main()
