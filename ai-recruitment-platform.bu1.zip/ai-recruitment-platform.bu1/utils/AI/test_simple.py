#!/usr/bin/env python3
"""Simple test to write output to file"""
import sys
import json

output = {
    "success": True,
    "test": "Script is working",
    "args": sys.argv
}

print(json.dumps(output, ensure_ascii=False, indent=2))
