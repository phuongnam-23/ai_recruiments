<?php
/**
 * Gemini AI Service
 * Tích hợp với Google Gemini API để xử lý CV parsing
 */

class GeminiService {
    private $apiKey;
    private $apiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';
    private $maxRetries = 3;
    private $retryDelay = 1000; // milliseconds

    public function __construct($apiKey = null) {
        // Lấy API key từ parameter hoặc từ env variable
        $this->apiKey = $apiKey ?: getenv('GEMINI_API_KEY');
        
        // Nếu không có API key, gọi setApiKey để người dùng có thể set sau
        if (!$this->apiKey) {
            // Try from config or environment
            if (defined('GEMINI_API_KEY')) {
                $this->apiKey = GEMINI_API_KEY;
            }
        }
    }

    public function setApiKey($apiKey) {
        $this->apiKey = $apiKey;
        return $this;
    }

    /**
     * Parse CV text thành structured data
     */
    public function parseCV($cvText) {
        $prompt = $this->buildCVParsePrompt($cvText);
        
        try {
            $response = $this->callGeminiAPI($prompt);
            return $this->parseCVResponse($response);
        } catch (Exception $e) {
            throw new Exception("CV Parse Error: " . $e->getMessage());
        }
    }

    /**
     * Analyze CV and generate score
     */
    public function analyzeCV($cvText) {
        // Demo mode: if no API key, return mock analysis
        if (empty($this->apiKey)) {
            error_log('⚠️ GeminiService: No API key - returning DEMO analysis');
            return $this->generateMockAnalysis($cvText);
        }

        $prompt = <<<PROMPT
Bạn là chuyên gia đánh giá CV chuyên nghiệp. Hãy phân tích KỸ LƯỠNG CV dưới đây.

**HƯỚNG DẪN ĐÁNH GIÁ:**

1. **Structure (20 điểm)**: Định dạng, bố cục, dễ đọc
   - Có header với thông tin liên hệ đầy đủ (email, phone, address): 10 điểm
   - Cấu trúc rõ ràng, phân chia section hợp lý: 5 điểm
   - Định dạng nhất quán: 5 điểm

2. **Content (30 điểm)**: Chất lượng nội dung
   - Có tóm tắt bản thân/mục tiêu nghề nghiệp: 10 điểm
   - Kinh nghiệm làm việc chi tiết với thời gian, công ty: 15 điểm
   - Học vấn rõ ràng: 5 điểm

3. **Skills (30 điểm)**: Kỹ năng kỹ thuật
   - Liệt kê kỹ năng chuyên môn cụ thể: 20 điểm
   - Có chứng chỉ/dự án minh chứng: 10 điểm

4. **Clarity (20 điểm)**: Ngôn ngữ, trình bày
   - Ngữ pháp tốt, không lỗi chính tả: 10 điểm
   - Nội dung súc tích, không dài dòng: 10 điểm

**CV TEXT:**
---
{$cvText}
---

**YÊU CẦU OUTPUT:**
Trả về CHỈ JSON object (không có markdown, không có text thừa):
{
  "score": tổng điểm từ 0-100,
  "grade": "A" nếu 85-100, "B" nếu 75-84, "C" nếu 65-74, "D" nếu 50-64, "F" nếu <50,
  "breakdown": {
    "structure": điểm thực tế 0-20,
    "content": điểm thực tế 0-30,
    "skills": điểm thực tế 0-30,
    "clarity": điểm thực tế 0-20
  },
  "strengths": ["Điểm mạnh 1", "Điểm mạnh 2", "Điểm mạnh 3"],
  "weaknesses": ["Điểm yếu 1", "Điểm yếu 2"],
  "improvements": ["Gợi ý cải thiện 1", "Gợi ý cải thiện 2", "Gợi ý cải thiện 3"]
}

**QUAN TRỌNG:**
- Phải đọc KỸ CV để tìm email, phone, address
- Nếu có thông tin thì KHÔNG được nói "thiếu"
- Strengths/weaknesses phải DỰA TRÊN NỘI DUNG THỰC TẾ của CV
- Score phải công bằng và phản ánh đúng chất lượng CV
PROMPT;

        try {
            $response = $this->callGeminiAPI($prompt);
            $result = json_decode($response, true);
            
            if (!$result) {
                throw new Exception("Invalid JSON response from Gemini API");
            }
            
            return $result;
        } catch (Exception $e) {
            throw new Exception("CV Analysis Error: " . $e->getMessage());
        }
    }

    /**
     * Generate mock analysis for demo/testing purposes
     */
    private function generateMockAnalysis($cvText) {
        // Simple heuristic-based scoring based on text length and keywords
        $length = strlen($cvText);
        $hasEmail = preg_match('/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/', $cvText) ? 1 : 0;
        $hasPhone = preg_match('/\b\d{10,11}\b/', $cvText) ? 1 : 0;
        $hasEducation = preg_match('/(bachelor|master|phd|degree|university|college|high school)/i', $cvText) ? 1 : 0;
        $hasExperience = preg_match('/(experience|worked|managed|developed|led|team|project)/i', $cvText) ? 1 : 0;
        $hasSkills = preg_match('/(php|python|javascript|java|sql|html|css|react|laravel)/i', $cvText) ? 1 : 0;

        // Calculate base score (0-100)
        $score = min(100, max(30, 
            ($length > 500 ? 15 : 5) +
            ($hasEmail * 15) +
            ($hasPhone * 10) +
            ($hasEducation * 15) +
            ($hasExperience * 20) +
            ($hasSkills * 20)
        ));

        $grade = $score >= 85 ? 'A' : ($score >= 75 ? 'B' : ($score >= 65 ? 'C' : ($score >= 50 ? 'D' : 'F')));

        return [
            'score' => $score,
            'grade' => $grade,
            'breakdown' => [
                'structure' => (int)($score * 0.20),
                'content' => (int)($score * 0.30),
                'skills' => (int)($score * 0.30),
                'clarity' => (int)($score * 0.20)
            ],
            'strengths' => [
                'CV có độ dài hợp lý',
                $hasEmail ? 'Có email liên hệ' : 'Thiếu thông tin liên hệ',
                $hasEducation ? 'Có thông tin giáo dục' : 'Cần thêm giáo dục',
                $hasExperience ? 'Có kinh nghiệm công việc' : 'Cần thêm kinh nghiệm'
            ],
            'weaknesses' => [
                $hasSkills ? '' : 'Cần liệt kê kỹ năng kỹ thuật',
                $hasPhone ? '' : 'Thiếu số điện thoại',
                'Định dạng có thể cải thiện',
                'Cần thêm chi tiết về dự án'
            ],
            'improvements' => [
                'Sử dụng format rõ ràng với các section: Contact, Experience, Education, Skills',
                'Thêm các từ khóa kỹ năng liên quan đến công việc mong muốn',
                'Mô tả thành tích cụ thể bằng con số (ví dụ: tăng hiệu suất 30%)',
                'Kiểm tra lại lỗi chính tả và ngữ pháp'
            ]
        ];
    }

    /**
     * Build prompt cho CV parsing
     */
    private function buildCVParsePrompt($cvText) {
        return <<<PROMPT
Phân tích CV dưới đây và trích xuất thông tin theo định dạng JSON. 
Trả về CHỈ JSON object (không có text khác), không có markdown code blocks.

CV Text:
---
{$cvText}
---

Trích xuất các thông tin sau (nếu không có thì để trống):
{
  "name": "Họ tên",
  "email": "Email",
  "phone": "Số điện thoại",
  "address": "Địa chỉ",
  "summary": "Giới thiệu bản thân (2-3 câu)",
  "skills": [
    {"skill": "Kỹ năng 1", "level": "Intermediate"},
    {"skill": "Kỹ năng 2", "level": "Expert"}
  ],
  "experience_years": số năm kinh nghiệm,
  "education_level": "bachelor|master|associate|high_school|phd",
  "experience": [
    {"title": "Vị trí", "company": "Công ty", "years": "1 năm"},
  ],
  "certifications": ["Chứng chỉ 1", "Chứng chỉ 2"]
}

Lưu ý:
- Chỉ trả về JSON object
- Email phải là đúng định dạng
- Kỹ năng nên được chuẩn hóa (viết hoa chữ cái đầu)
- experience_years là số nguyên
PROMPT;
    }

    /**
     * Parse Gemini API response
     */
    private function parseCVResponse($responseText) {
        // Clean response text
        $responseText = trim($responseText);
        
        // Remove markdown code blocks if present
        if (strpos($responseText, '```json') !== false) {
            $responseText = preg_replace('/```json\s*/', '', $responseText);
            $responseText = preg_replace('/```\s*/', '', $responseText);
        } elseif (strpos($responseText, '```') !== false) {
            $responseText = preg_replace('/```\s*/', '', $responseText);
        }
        
        $decoded = json_decode($responseText, true);
        
        if (!$decoded) {
            throw new Exception("Invalid JSON response from Gemini API");
        }
        
        return $decoded;
    }

    /**
     * Call Gemini API with retry logic
     */
    private function callGeminiAPI($prompt, $attempt = 1) {
        if (!$this->apiKey) {
            throw new Exception("Gemini API Key not configured. Please set GEMINI_API_KEY environment variable or call setApiKey()");
        }

        $url = $this->apiUrl . '?key=' . urlencode($this->apiKey);
        error_log('🔗 GeminiService: Calling API at ' . substr($url, 0, 100) . '...');
        
        $payload = json_encode([
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature' => 0.3,
                'topK' => 40,
                'topP' => 0.95,
                'maxOutputTokens' => 2048
            ]
        ]);

        error_log('📤 GeminiService: Payload size = ' . strlen($payload) . ' bytes');

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Accept: application/json'
            ],
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        error_log('📥 GeminiService: HTTP ' . $httpCode . ' | Error: ' . ($error ?: 'None'));

        // Handle errors
        if ($error) {
            if ($attempt < $this->maxRetries) {
                usleep($this->retryDelay * 1000);
                return $this->callGeminiAPI($prompt, $attempt + 1);
            }
            throw new Exception("cURL Error: $error");
        }

        if ($httpCode === 429 || $httpCode === 500 || $httpCode === 503) {
            if ($attempt < $this->maxRetries) {
                $backoff = pow(2, $attempt - 1) * $this->retryDelay;
                error_log('⏱️ GeminiService: Retrying after ' . $backoff . 'ms (attempt ' . ($attempt + 1) . ')');
                usleep($backoff * 1000);
                return $this->callGeminiAPI($prompt, $attempt + 1);
            }
            throw new Exception("API Error (HTTP $httpCode). Max retries exceeded.");
        }

        if ($httpCode !== 200) {
            $decoded = json_decode($response, true);
            $errMsg = $decoded['error']['message'] ?? 'Unknown error';
            error_log('❌ GeminiService: API Error - ' . $errMsg);
            throw new Exception("API Error (HTTP $httpCode): $errMsg");
        }

        // Parse response
        $data = json_decode($response, true);
        error_log('✅ GeminiService: Response parsed successfully');
        
        if (!isset($data['candidates'][0]['content']['parts'][0]['text'])) {
            error_log('❌ GeminiService: Invalid response structure');
            throw new Exception("Invalid response structure from Gemini API");
        }

        return $data['candidates'][0]['content']['parts'][0]['text'];
    }

    /**
     * Test connection
     */
    public function testConnection() {
        try {
            $testPrompt = "Return JSON: {\"status\": \"ok\"}";
            $response = $this->callGeminiAPI($testPrompt);
            return json_decode($response, true);
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }
}
?>
