#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Job Matcher Engine - Python Backend (Fixed Language & Error Handling)
"""

import sys
import os
import json
import re
import io

# Force UTF-8 encoding for Windows/Console
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    os.environ['PYTHONIOENCODING'] = 'utf-8'

try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False
    print(json.dumps({"success": False, "error": "google-generativeai not installed"}))
    sys.exit(1)

class JobMatcher:
    # Giữ nguyên danh sách Key của bạn
    API_KEYS = [
        'AIzaSyAtITA06akwg1aj2bWT85N_5iSxbx4qxbA',
        'AIzaSyBqbmsPpRKeU8tZvBXKwZMxPvDncilQNB8',
        'AIzaSyBDD8pFkEky4mzgmIptc4LI_Rsuk4FDfkk',
        'AIzaSyD5oFWBT_GLsF-ucqMj3aq3ZsfdJqwyfAw',
    ]
    
    # Cập nhật models theo API mới (gemini-1.5 đã deprecated)
    MODELS = [
        'gemini-2.0-flash-lite',  # Model mới nhất, nhanh và free
        'gemini-2.0-flash',       # Backup
        'gemini-2.5-flash-lite',  # Backup 2
        'gemini-2.5-flash',       # Backup 3
    ]

    def __init__(self, api_key=None):
        self.api_key = api_key or self.API_KEYS[0]
        self.model_name = self.MODELS[0]
        self.model = None
        self.current_key_index = 0
        self.current_model_index = 0
        self._configure_api()

    def _configure_api(self):
        try:
            genai.configure(api_key=self.api_key)
            self.model = genai.GenerativeModel(self.model_name)
            return True
        except Exception as e:
            return False
    
    def _try_next_config(self):
        """Thử API key hoặc model tiếp theo"""
        # Thử model tiếp theo
        self.current_model_index += 1
        if self.current_model_index < len(self.MODELS):
            self.model_name = self.MODELS[self.current_model_index]
            return self._configure_api()
        
        # Hết model, thử API key tiếp theo
        self.current_key_index += 1
        if self.current_key_index < len(self.API_KEYS):
            self.api_key = self.API_KEYS[self.current_key_index]
            self.current_model_index = 0
            self.model_name = self.MODELS[0]
            return self._configure_api()
        
        return False

    def match(self, cv_text, job_description):
        # Validation cơ bản ngay tại Python để đỡ tốn quota AI
        if len(cv_text.strip()) < 50 or len(job_description.strip()) < 20:
             return {
                "success": True,
                "data": {
                    "score": 0,
                    "recommendation": "KHÔNG THỂ ĐÁNH GIÁ",
                    "pros": [],
                    "cons": [],
                    "missing_skills": [],
                    "reason": "Nội dung CV hoặc mô tả công việc quá ngắn hoặc vô nghĩa."
                }
            }

        prompt = self._build_prompt(cv_text, job_description)
        
        max_retries = len(self.API_KEYS) * len(self.MODELS)
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                response = self.model.generate_content(prompt)
                return self._parse_response(response.text)
            except Exception as e:
                error_msg = str(e)
                # Nếu lỗi model không tồn tại hoặc không support, thử config khác
                if '404' in error_msg or 'not found' in error_msg.lower() or 'not supported' in error_msg.lower():
                    if not self._try_next_config():
                        break
                    retry_count += 1
                else:
                    # Lỗi khác (rate limit, quota, etc.)
                    return {
                        "success": False,
                        "error": error_msg,
                        "score": 0
                    }
        
        # Hết tất cả configs
        return {
            "success": False,
            "error": "Đã thử tất cả API keys và models nhưng không thành công",
            "score": 0
        }

    def _build_prompt(self, cv_text, job_description):
        # Prompt được tối ưu để ép buộc Tiếng Việt và JSON
        return f"""
        Đóng vai: Chuyên gia tuyển dụng tại Việt Nam.
        Nhiệm vụ: So sánh CV và JD (Job Description) bên dưới.

        INPUT:
        --- CV ---
        {cv_text[:3000]}
        --- JD ---
        {job_description[:3000]}

        YÊU CẦU BẮT BUỘC:
        1. Trả về định dạng JSON thuần túy (Raw JSON). Không dùng Markdown (```json).
        2. NGÔN NGỮ: 100% TIẾNG VIỆT (Vietnamese). Kể cả các từ khóa technical có thể giữ tiếng Anh, nhưng câu văn phải là tiếng Việt.
        3. Nếu nội dung vô nghĩa (ví dụ: 'asdf', 'test'), hãy trả về score 0 và lý do bằng tiếng Việt.

        CẤU TRÚC JSON OUTPUT:
        {{
          "score": <số nguyên 0-100>,
          "recommendation": "<PHỎNG VẤN | CÂN NHẮC | TỪ CHỐI>",
          "pros": ["<điểm mạnh 1>", "<điểm mạnh 2>"],
          "cons": ["<điểm yếu 1>", "<điểm yếu 2>"],
          "missing_skills": ["<kỹ năng thiếu 1>", "<kỹ năng thiếu 2>"],
          "reason": "<Đánh giá tổng quan ngắn gọn bằng Tiếng Việt>"
        }}
        """

    def _parse_response(self, response_text):
        try:
            # Làm sạch chuỗi trước khi parse
            text = response_text.strip()
            # Xóa markdown code block nếu có
            if text.startswith("```"):
                text = re.sub(r"^```(json)?", "", text)
                text = re.sub(r"```$", "", text)
            
            text = text.strip()
            
            # Tìm JSON object trong text (phòng trường hợp AI nói nhảm phía trước)
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
                return { "success": True, "data": result }
            
            raise Exception("No JSON found")

        except json.JSONDecodeError:
            return {
                "success": True, # Vẫn trả về success để Frontend hiện lỗi đẹp
                "data": {
                    "score": 0,
                    "recommendation": "LỖI PHÂN TÍCH",
                    "pros": [], "cons": [], "missing_skills": [],
                    "reason": "Hệ thống không đọc được phản hồi từ AI. Vui lòng thử lại."
                }
            }

def main():
    if len(sys.argv) < 3:
        # Fallback test mode nếu chạy tay không tham số
        print(json.dumps({"success": False, "error": "Missing arguments"}))
        sys.exit(1)
    
    cv_path = sys.argv[1]
    job_description_encoded = sys.argv[2]
    
    try:
        # Thêm encoding='utf-8-sig' để xử lý BOM nếu có
        with open(cv_path, 'r', encoding='utf-8-sig', errors='ignore') as f:
            cv_text = f.read()
        
        # Decode base64 job description
        import base64
        try:
            job_description = base64.b64decode(job_description_encoded).decode('utf-8')
        except:
            # Nếu không phải base64, dùng trực tiếp
            job_description = job_description_encoded
        
        matcher = JobMatcher()
        result = matcher.match(cv_text, job_description)
        
        # In kết quả JSON cuối cùng
        print(json.dumps(result, ensure_ascii=False))
        
    except Exception as e:
        print(json.dumps({ "success": False, "error": str(e) }))
        sys.exit(1)

if __name__ == '__main__':
    main()
