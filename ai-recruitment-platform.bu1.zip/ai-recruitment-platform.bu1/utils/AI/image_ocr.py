#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Image OCR using Gemini Vision API via REST
Extract text from PNG/JPG images
"""

import sys
import os
import json
import base64
import mimetypes

# Set UTF-8 encoding
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

try:
    import requests
except ImportError as e:
    print(json.dumps({"error": f"Missing library: {str(e)}"}))
    sys.exit(1)


def extract_text_from_image(image_path):
    """Extract text from image using Gemini Vision API via REST"""
    
    api_keys = [
        'AIzaSyAtITA06akwg1aj2bWT85N_5iSxbx4qxbA',
        'AIzaSyBqbmsPpRKeU8tZvBXKwZMxPvDncilQNB8',
        'AIzaSyBDD8pFkEky4mzgmIptc4LI_Rsuk4FDfkk',
        'AIzaSyD5oFWBT_GLsF-ucqMj3aq3ZsfdJqwyfAw'
    ]
    
    # Models that support vision - Updated for v1beta API
    models = ['gemini-2.5-flash', 'gemini-2.0-flash-exp']
    
    prompt = """Extract ALL text from this CV/Resume image. 
Return ONLY the text content, preserving line breaks and structure.
Include ALL information: name, email, phone, address, experience, education, skills, etc.
Do not add any comments or explanations, just the extracted text."""
    
    # Read and encode image
    try:
        with open(image_path, 'rb') as f:
            image_data = base64.b64encode(f.read()).decode('utf-8')
        
        # Detect MIME type
        mime_type, _ = mimetypes.guess_type(image_path)
        if not mime_type:
            mime_type = 'image/png'
            
    except Exception as e:
        return {"error": f"Cannot read image: {str(e)}"}
    
    # Try each API key and model combination
    for i, api_key in enumerate(api_keys):
        for model_name in models:
            try:
                print(f"DEBUG: Trying API key {i+1}/{len(api_keys)}, Model: {model_name}", file=sys.stderr)
                
                url = f'https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={api_key}'
                
                payload = {
                    "contents": [
                        {
                            "parts": [
                                {"text": prompt},
                                {
                                    "inline_data": {
                                        "mime_type": mime_type,
                                        "data": image_data
                                    }
                                }
                            ]
                        }
                    ]
                }
                
                headers = {'Content-Type': 'application/json'}
                
                response = requests.post(url, headers=headers, json=payload, timeout=30)
                
                if response.status_code == 200:
                    result = response.json()
                    if 'candidates' in result and len(result['candidates']) > 0:
                        text = result['candidates'][0]['content']['parts'][0]['text']
                        print(f"DEBUG: Success! Extracted {len(text)} chars", file=sys.stderr)
                        return {
                            "success": True,
                            "text": text,
                            "length": len(text)
                        }
                else:
                    error_msg = f"{response.status_code} - {response.text[:200]}"
                    print(f"DEBUG: Error with key {i+1}, model {model_name}: {error_msg}", file=sys.stderr)
                    
            except Exception as e:
                error_msg = str(e)
                print(f"DEBUG: Exception with key {i+1}, model {model_name}: {error_msg[:100]}", file=sys.stderr)
                continue
    
    return {"error": "All API keys exhausted or failed"}


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Image path required"}))
        sys.exit(1)
    
    image_path = sys.argv[1]
    
    if not os.path.exists(image_path):
        print(json.dumps({"error": "Image file not found"}))
        sys.exit(1)
    
    result = extract_text_from_image(image_path)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
