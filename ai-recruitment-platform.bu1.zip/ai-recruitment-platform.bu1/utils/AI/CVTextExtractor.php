<?php
/**
 * CV Text Extractor
 * Tách text từ PDF, DOCX, TXT files
 */

class CVTextExtractor {
    
    /**
     * Extract text từ CV file
     */
    public static function extractText($cvPath) {
        error_log('📂 CVTextExtractor: Attempting to extract from ' . $cvPath);
        
        if (!file_exists($cvPath)) {
            error_log('❌ CVTextExtractor: File not found');
            throw new Exception("CV file not found: " . htmlspecialchars($cvPath));
        }

        error_log('✅ CVTextExtractor: File exists');
        $ext = strtolower(pathinfo($cvPath, PATHINFO_EXTENSION));
        error_log('📄 CVTextExtractor: File type = ' . $ext);
        
        switch ($ext) {
            case 'txt':
                error_log('📋 CVTextExtractor: Extracting TXT');
                return self::extractTXT($cvPath);
            case 'pdf':
                error_log('📋 CVTextExtractor: Extracting PDF');
                return self::extractPDF($cvPath);
            case 'docx':
                error_log('📋 CVTextExtractor: Extracting DOCX');
                return self::extractDOCX($cvPath);
            case 'doc':
                error_log('📋 CVTextExtractor: Extracting DOC');
                return self::extractDOC($cvPath);
            case 'jpg':
            case 'jpeg':
            case 'png':
                error_log('📋 CVTextExtractor: Extracting IMAGE (OCR)');
                return self::extractImageOCR($cvPath);
            default:
                error_log('❌ CVTextExtractor: Unsupported format = ' . $ext);
                throw new Exception("Unsupported file format: " . htmlspecialchars($ext));
        }
    }

    /**
     * Extract text từ TXT file
     */
    private static function extractTXT($filePath) {
        $text = file_get_contents($filePath);
        if ($text === false) {
            throw new Exception("Cannot read TXT file");
        }
        return $text;
    }

    /**
     * Extract text từ PDF file using Python parser (cv_parser.py)
     */
    private static function extractPDF($filePath) {
        try {
            // Use Python CV Parser (same as parse-cv endpoint)
            $pythonScript = __DIR__ . '/cv_parser.py';
            
            if (!file_exists($pythonScript)) {
                throw new Exception("CV Parser script not found");
            }
            
            // Build command to call Python script
            $command = sprintf(
                'cd /d %s && chcp 65001 > nul && python cv_parser.py %s 2>&1',
                escapeshellarg(__DIR__),
                escapeshellarg($filePath)
            );
            
            $output = [];
            $returnCode = 0;
            exec($command, $output, $returnCode);
            
            if ($returnCode === 0 && !empty($output)) {
                // Parse JSON response from Python
                $response = implode("\n", $output);
                $lines = array_filter(explode("\n", $response), function($line) {
                    return trim($line) !== '';
                });
                
                if (!empty($lines)) {
                    $jsonLine = end($lines);
                    $data = json_decode($jsonLine, true);
                    
                    if ($data && ($data['success'] ?? false)) {
                        // Extract text from parsed CV
                        $cvData = $data['data'] ?? [];
                        $text = "";
                        
                        // Combine all fields into readable text
                        if (!empty($cvData['name'])) $text .= "Name: " . $cvData['name'] . "\n";
                        if (!empty($cvData['email'])) $text .= "Email: " . $cvData['email'] . "\n";
                        if (!empty($cvData['phone'])) $text .= "Phone: " . $cvData['phone'] . "\n";
                        if (!empty($cvData['summary'])) $text .= "Summary: " . $cvData['summary'] . "\n";
                        if (!empty($cvData['experience'])) $text .= "Experience: " . $cvData['experience'] . "\n";
                        if (!empty($cvData['education'])) $text .= "Education: " . $cvData['education'] . "\n";
                        if (!empty($cvData['skills'])) {
                            $skills = is_array($cvData['skills']) ? implode(", ", $cvData['skills']) : $cvData['skills'];
                            $text .= "Skills: " . $skills . "\n";
                        }
                        
                        if (!empty($text)) {
                            return $text;
                        }
                    }
                }
            }
            
            throw new Exception("Failed to extract PDF text using Python parser");
            
        } catch (Exception $e) {
            throw new Exception("PDF extraction failed: " . $e->getMessage());
        }
    }

    /**
     * Extract text từ DOCX file
     */
    private static function extractDOCX($filePath) {
        try {
            // DOCX is a ZIP file containing XML
            $zip = new ZipArchive();
            
            if ($zip->open($filePath) === true) {
                // Read document.xml
                $xml = $zip->getFromName('word/document.xml');
                
                if ($xml === false) {
                    throw new Exception("Cannot read document.xml from DOCX");
                }
                
                $zip->close();
                
                // Extract text from XML
                return self::parseDOCXXML($xml);
            } else {
                throw new Exception("Cannot open DOCX file as ZIP");
            }
        } catch (Exception $e) {
            throw new Exception("DOCX parsing error: " . $e->getMessage());
        }
    }

    /**
     * Parse DOCX XML to extract text
     */
    private static function parseDOCXXML($xml) {
        // Remove namespaces for easier parsing
        $xml = preg_replace('/xmlns[^=]*="[^"]*"/i', '', $xml);
        
        // Load as DOMDocument with error suppression
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        
        if (!$dom->loadXML($xml)) {
            $errors = libxml_get_errors();
            libxml_clear_errors();
            throw new Exception("Invalid DOCX XML");
        }
        
        // Extract all text nodes from <t> elements
        $xpath = new DOMXPath($dom);
        $textNodes = $xpath->query('//t');
        
        $text = [];
        foreach ($textNodes as $node) {
            $text[] = $node->nodeValue;
        }
        
        libxml_use_internal_errors(false);
        return implode('', $text);
    }

    /**
     * Extract text từ DOC file (Microsoft Word 97-2003)
     * Fallback method
     */
    private static function extractDOC($filePath) {
        // DOC format is binary and complex to parse
        // Recommend converting to DOCX or TXT
        throw new Exception("DOC format is not directly supported. Please save as DOCX or convert to PDF/TXT");
    }

    /**
     * Extract text from images using Python OCR script
     */
    private static function extractImageOCR($filePath) {
        error_log('🖼️ CVTextExtractor: Starting OCR for image');
        
        // Use Python OCR script
        $pythonScript = __DIR__ . '/image_ocr.py';
        
        if (!file_exists($pythonScript)) {
            throw new Exception("Image OCR script not found");
        }
        
        // Build command
        $command = sprintf(
            'cd /d %s && python image_ocr.py %s 2>&1',
            escapeshellarg(__DIR__),
            escapeshellarg($filePath)
        );
        
        error_log("🐍 Running Python OCR: $command");
        
        $output = [];
        $returnCode = 0;
        exec($command, $output, $returnCode);
        
        error_log("📤 Python output: " . implode("\n", $output));
        
        if ($returnCode === 0 && !empty($output)) {
            // Parse JSON response
            $response = implode("\n", $output);
            $lines = array_filter(explode("\n", $response), function($line) {
                return trim($line) !== '';
            });
            
            if (!empty($lines)) {
                $jsonLine = end($lines);
                $data = json_decode($jsonLine, true);
                
                if ($data && isset($data['success']) && $data['success']) {
                    error_log('✅ CVTextExtractor: OCR successful, extracted ' . $data['length'] . ' chars');
                    return $data['text'];
                } else if (isset($data['error'])) {
                    error_log('❌ OCR Error: ' . $data['error']);
                    throw new Exception("OCR failed: " . $data['error']);
                }
            }
        }
        
        throw new Exception("Could not extract text from image. Python script failed.");
    }

    /**
     * Check if file is supported
     */
    public static function isSupportedFormat($filePath) {
        $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        return in_array($ext, ['txt', 'pdf', 'docx', 'doc', 'jpg', 'jpeg', 'png']);
    }
}

/**
 * Helper function to find command in PATH
 */
function which($command) {
    if (stripos(PHP_OS, 'WIN') === 0) {
        // Windows
        $output = [];
        exec('where ' . escapeshellarg($command), $output);
        return !empty($output) ? trim($output[0]) : false;
    } else {
        // Linux/Mac
        $output = [];
        exec('which ' . escapeshellarg($command), $output);
        return !empty($output) ? trim($output[0]) : false;
    }
}
?>
