#!/usr/bin/env python3
"""
Simple test - just extract text from CV
"""

import sys
import json
from pathlib import Path

try:
    from docx import Document
    
    if len(sys.argv) < 2:
        print(json.dumps({"error": "No file path provided"}))
        sys.exit(1)
    
    file_path = sys.argv[1]
    
    if not Path(file_path).exists():
        print(json.dumps({"error": f"File not found: {file_path}"}))
        sys.exit(1)
    
    # Extract text
    doc = Document(file_path)
    text = ""
    for para in doc.paragraphs:
        text += para.text + "\n"
    
    result = {
        "success": True,
        "file": file_path,
        "text_length": len(text),
        "text_preview": text[:500]
    }
    
    print(json.dumps(result, ensure_ascii=False, indent=2))
    
except Exception as e:
    print(json.dumps({
        "error": str(e),
        "type": type(e).__name__
    }, ensure_ascii=False))
    sys.exit(1)
