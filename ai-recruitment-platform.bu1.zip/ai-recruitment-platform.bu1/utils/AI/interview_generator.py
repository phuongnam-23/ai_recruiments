#!/usr/bin/env python3
"""AI Interview Question Generator.
Generates technical, behavioral, and situational interview questions from job description.
"""
import base64
import io
import json
import os
import sys
from typing import Any, Dict, List, Optional

# Ensure UTF-8 output
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
if sys.stderr.encoding != 'utf-8':
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
os.environ.setdefault('PYTHONIOENCODING', 'utf-8')

try:
    import google.generativeai as genai  # type: ignore
    GEMINI_AVAILABLE = True
except Exception:
    genai = None
    GEMINI_AVAILABLE = False

HARDCODED_KEYS = [
    'AIzaSyAtITA06akwg1aj2bWT85N_5iSxbx4qxbA',
    'AIzaSyBqbmsPpRKeU8tZvBXKwZMxPvDncilQNB8',
    'AIzaSyBDD8pFkEky4mzgmIptc4LI_Rsuk4FDfkk',
    'AIzaSyD5oFWBT_GLsF-ucqMj3aq3ZsfdJqwyfAw',
]

SYSTEM_PROMPT = """Bạn là chuyên gia tuyển dụng chuyên nghiệp. Nhiệm vụ của bạn là tạo câu hỏi phỏng vấn từ Job Description.

YÊU CẦU:
- Tạo CHÍNH XÁC 10 câu hỏi phỏng vấn
- Phân loại: 5 technical (kỹ thuật), 3 behavioral (hành vi), 2 situational (tình huống)
- Câu hỏi phải cụ thể, liên quan trực tiếp đến JD
- Trả về JSON thuần túy (không markdown, không ```json)

CẤU TRÚC JSON OUTPUT:
{
  "questions": [
    {
      "type": "technical|behavioral|situational",
      "question": "Nội dung câu hỏi bằng Tiếng Việt",
      "category": "Chủ đề (VD: PHP, Leadership, Problem Solving)"
    }
  ]
}
"""


def emit(payload: Dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(payload, ensure_ascii=False))


def list_from_env(var_name: str) -> List[str]:
    raw = os.getenv(var_name, '')
    if not raw:
        return []
    return [item.strip() for item in raw.replace('\n', ',').split(',') if item.strip()]


def get_api_keys() -> List[str]:
    keys = list_from_env('GEMINI_API_KEYS')
    for fallback in (os.getenv('GEMINI_API_KEY'), os.getenv('GEMINI_KEY')):
        if fallback:
            keys.append(fallback)
    keys.extend(HARDCODED_KEYS)
    seen = set()
    unique_keys = []
    for key in keys:
        if key and key not in seen:
            unique_keys.append(key)
            seen.add(key)
    return unique_keys


def get_model_candidates() -> List[str]:
    env_models = list_from_env('INTERVIEW_MODELS')
    if env_models:
        return env_models
    return ['gemini-1.5-flash', 'gemini-2.0-flash-lite', 'gemini-2.5-flash-lite']


def decode_arg(value: str) -> str:
    try:
        return base64.b64decode(value).decode('utf-8')
    except Exception:
        return ''


def parse_job_data(raw: str) -> Dict[str, Any]:
    try:
        data = json.loads(raw or '{}')
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def build_prompt(job_data: Dict[str, Any]) -> str:
    title = job_data.get('title', 'Chưa rõ vị trí')
    description = job_data.get('description', '')
    requirements = job_data.get('requirements', '')
    skills = job_data.get('required_skills', [])
    
    if isinstance(skills, str):
        try:
            skills = json.loads(skills)
        except Exception:
            skills = [s.strip() for s in skills.split(',') if s.strip()]
    
    skills_str = ', '.join(skills) if skills else 'Không xác định'
    
    return f"""JOB DESCRIPTION:
Vị trí: {title}
Mô tả: {description[:500]}
Yêu cầu: {requirements[:500]}
Kỹ năng: {skills_str}

Hãy tạo 10 câu hỏi phỏng vấn (5 technical, 3 behavioral, 2 situational) phù hợp với vị trí này."""


def generate_mock_questions(job_data: Dict[str, Any]) -> List[Dict[str, str]]:
    """Fallback questions when AI unavailable"""
    title = job_data.get('title', 'ứng viên')
    return [
        {"type": "technical", "question": f"Mô tả kinh nghiệm của bạn với công nghệ liên quan đến {title}?", "category": "Experience"},
        {"type": "technical", "question": "Bạn giải quyết vấn đề kỹ thuật phức tạp như thế nào?", "category": "Problem Solving"},
        {"type": "technical", "question": "Kể về dự án kỹ thuật bạn tự hào nhất.", "category": "Projects"},
        {"type": "technical", "question": "Bạn cập nhật kiến thức công nghệ mới như thế nào?", "category": "Learning"},
        {"type": "technical", "question": "So sánh các công cụ/framework bạn đã sử dụng.", "category": "Tools"},
        {"type": "behavioral", "question": "Kể về lần bạn phải làm việc với đồng nghiệp khó tính.", "category": "Teamwork"},
        {"type": "behavioral", "question": "Mô tả tình huống bạn phải đưa ra quyết định khó khăn.", "category": "Decision Making"},
        {"type": "behavioral", "question": "Bạn xử lý feedback tiêu cực như thế nào?", "category": "Adaptability"},
        {"type": "situational", "question": "Nếu deadline sắp đến nhưng task chưa xong, bạn làm gì?", "category": "Time Management"},
        {"type": "situational", "question": "Bạn xử lý xung đột trong team như thế nào?", "category": "Conflict Resolution"},
    ]


def call_gemini(prompt: str) -> str:
    if not GEMINI_AVAILABLE:
        raise RuntimeError('Thiếu thư viện google-generativeai')
    
    keys = get_api_keys()
    models = get_model_candidates()
    if not keys:
        raise RuntimeError('Chưa cấu hình GEMINI_API_KEY')
    
    last_error: Optional[str] = None
    
    for api_key in keys:
        try:
            genai.configure(api_key=api_key)
        except Exception as exc:
            last_error = f'configure key failed: {exc}'
            continue
        
        for model_name in models:
            try:
                model = genai.GenerativeModel(model_name=model_name, system_instruction=SYSTEM_PROMPT)
                response = model.generate_content([prompt], generation_config={
                    'temperature': 0.7,
                    'top_p': 0.9,
                    'top_k': 40,
                    'max_output_tokens': 2048,
                })
                
                text = getattr(response, 'text', '').strip() if response else ''
                if not text:
                    raise RuntimeError('Gemini không trả lời')
                return text
            except Exception as exc:
                last_error = f'{model_name}: {exc}'
                continue
    
    raise RuntimeError(last_error or 'Gemini không phản hồi')


def parse_ai_response(text: str) -> List[Dict[str, str]]:
    """Parse JSON from AI response"""
    # Remove markdown code blocks
    if '```json' in text:
        text = text.split('```json')[1].split('```')[0]
    elif '```' in text:
        text = text.split('```')[1].split('```')[0]
    
    text = text.strip()
    
    try:
        data = json.loads(text)
        if isinstance(data, dict) and 'questions' in data:
            return data['questions']
        return []
    except Exception:
        return []


def main() -> None:
    if len(sys.argv) < 2:
        emit({'success': False, 'error': 'Missing job data argument'})
        return
    
    raw_job_data = decode_arg(sys.argv[1])
    job_data = parse_job_data(raw_job_data)
    
    if not job_data:
        emit({'success': False, 'error': 'Invalid job data'})
        return
    
    prompt = build_prompt(job_data)
    
    try:
        ai_text = call_gemini(prompt)
        questions = parse_ai_response(ai_text)
        
        if not questions or len(questions) < 5:
            raise RuntimeError('AI trả về không đủ câu hỏi')
        
        emit({'success': True, 'questions': questions})
    except Exception as exc:
        fallback_questions = generate_mock_questions(job_data)
        emit({'success': True, 'questions': fallback_questions, 'warning': str(exc)})


if __name__ == '__main__':
    main()
