<?php
/**
 * MessageController
 * API endpoints cho chat system
 */

require_once __DIR__ . '/../models/Conversation.php';
require_once __DIR__ . '/../models/Message.php';
require_once __DIR__ . '/../models/Notification.php';

class MessageController {
    private $db;
    private $conversationModel;
    private $messageModel;
    private $notificationModel;
    
    public function __construct($db) {
        $this->db = $db;
        $this->conversationModel = new Conversation($db);
        $this->messageModel = new Message($db);
        $this->notificationModel = new Notification();
    }
    
    /**
     * Khởi tạo conversation từ application
     * POST /api?action=start-conversation
     * Body: { application_id }
     */
    public function startConversation($user_id, $role) {
        try {
            $data = json_decode(file_get_contents('php://input'), true);
            $application_id = $data['application_id'] ?? null;
            
            error_log("🔵 startConversation: user_id=$user_id, role=$role, app_id=$application_id");
            
            if (!$application_id) {
                error_log("❌ Missing application_id");
                return ['success' => false, 'message' => 'Missing application_id'];
            }
            
            // Lấy thông tin application với MySQLi
            $query = "SELECT a.*, j.recruiter_id, a.candidate_id as user_id 
                      FROM applications a
                      JOIN jobs j ON a.job_id = j.id
                      WHERE a.id = ?";
            
            error_log("🔍 Querying application: $query");
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("i", $application_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $application = $result->fetch_assoc();
            
            error_log("📦 Application data: " . json_encode($application));
            
            if (!$application) {
                error_log("❌ Application not found");
                return ['success' => false, 'message' => 'Application not found'];
            }
            
            // Kiểm tra quyền: candidate phải là người nộp đơn HOẶC recruiter phải là người đăng job
            if ($role === 'candidate' && $application['user_id'] != $user_id) {
                error_log("❌ Unauthorized candidate: {$application['user_id']} != $user_id");
                return ['success' => false, 'message' => 'Unauthorized - Not your application'];
            }
            
            if ($role === 'recruiter' && $application['recruiter_id'] != $user_id) {
                error_log("❌ Unauthorized recruiter: {$application['recruiter_id']} != $user_id");
                return ['success' => false, 'message' => 'Unauthorized - Not your job'];
            }
            
            error_log("✅ Authorization passed. Creating conversation...");
            
            // Tạo hoặc lấy conversation
            $conversation = $this->conversationModel->getOrCreate(
                $application['user_id'],
                $application['recruiter_id'],
                $application['job_id'],
                $application_id
            );
            
            error_log("💬 Conversation result: " . json_encode($conversation));
            
            if ($conversation) {
                return [
                    'success' => true,
                    'conversation' => $conversation
                ];
            }
            
            error_log("❌ Failed to create conversation");
            return ['success' => false, 'message' => 'Failed to create conversation'];
        } catch (Exception $e) {
            error_log("💥 Exception in startConversation: " . $e->getMessage());
            error_log("Stack trace: " . $e->getTraceAsString());
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
    
    /**
     * Lấy danh sách conversations
     * GET /api?action=get-conversations
     */
    public function getConversations($user_id, $role) {
        $conversations = $this->conversationModel->getUserConversations($user_id, $role);
        
        return [
            'success' => true,
            'conversations' => $conversations,
            'total_unread' => $this->conversationModel->getTotalUnread($user_id, $role)
        ];
    }
    
    /**
     * Lấy chi tiết conversation và messages
     * GET /api?action=get-conversation&id=123
     */
    public function getConversation($user_id, $conversation_id) {
        // Kiểm tra quyền truy cập
        if (!$this->conversationModel->canAccess($conversation_id, $user_id)) {
            return ['success' => false, 'message' => 'Unauthorized'];
        }
        
        $conversation = $this->conversationModel->getById($conversation_id);
        $messages = $this->messageModel->getByConversation($conversation_id);
        
        return [
            'success' => true,
            'conversation' => $conversation,
            'messages' => $messages
        ];
    }
    
    /**
     * Gửi tin nhắn
     * POST /api?action=send-message
     * Body: { conversation_id, message, attachment_url?, attachment_name? }
     */
    public function sendMessage($user_id, $role) {
        $data = json_decode(file_get_contents('php://input'), true);
        $conversation_id = $data['conversation_id'] ?? null;
        $message = $data['message'] ?? '';
        $attachment_url = $data['attachment_url'] ?? null;
        $attachment_name = $data['attachment_name'] ?? null;
        
        if (!$conversation_id) {
            return ['success' => false, 'message' => 'Missing conversation_id'];
        }
        
        // Kiểm tra quyền
        if (!$this->conversationModel->canAccess($conversation_id, $user_id)) {
            return ['success' => false, 'message' => 'Unauthorized'];
        }
        
        // Tạo message
        $message_id = $this->messageModel->create(
            $conversation_id,
            $user_id,
            $message,
            $attachment_url,
            $attachment_name
        );
        
        if ($message_id) {
            // Cập nhật last_message_at và unread count
            $this->conversationModel->updateLastMessage($conversation_id, $user_id);
            
            // Tạo notification cho người nhận
            $conversation = $this->conversationModel->getById($conversation_id);
            if ($conversation) {
                $receiver_id = ($role === 'candidate') ? $conversation['recruiter_id'] : $conversation['candidate_id'];
                $sender_name = $_SESSION['full_name'] ?? 'Người dùng';
                $notif_type = ($role === 'candidate') ? 'candidate_message' : 'recruiter_message';
                
                $this->notificationModel->createNotification(
                    $receiver_id,
                    $notif_type,
                    'Tin nhắn mới',
                    $sender_name . ' đã gửi tin nhắn cho bạn.',
                    $conversation_id
                );
            }
            
            // Lấy message vừa tạo để trả về
            $messages = $this->messageModel->getByConversation($conversation_id, 1);
            
            return [
                'success' => true,
                'message' => $messages[0] ?? null
            ];
        }
        
        return ['success' => false, 'message' => 'Failed to send message'];
    }
    
    /**
     * Lấy tin nhắn mới (polling)
     * GET /api?action=poll-messages&conversation_id=123&after=2024-12-02 10:00:00
     */
    public function pollMessages($user_id, $conversation_id, $after_timestamp) {
        // Kiểm tra quyền
        if (!$this->conversationModel->canAccess($conversation_id, $user_id)) {
            return ['success' => false, 'message' => 'Unauthorized'];
        }
        
        $new_messages = $this->messageModel->getNewMessages($conversation_id, $after_timestamp);
        
        return [
            'success' => true,
            'messages' => $new_messages,
            'count' => count($new_messages)
        ];
    }
    
    /**
     * Đánh dấu conversation đã đọc
     * POST /api?action=mark-conversation-read
     * Body: { conversation_id }
     */
    public function markConversationRead($user_id, $role) {
        $data = json_decode(file_get_contents('php://input'), true);
        $conversation_id = $data['conversation_id'] ?? null;
        
        if (!$conversation_id) {
            return ['success' => false, 'message' => 'Missing conversation_id'];
        }
        
        // Kiểm tra quyền
        if (!$this->conversationModel->canAccess($conversation_id, $user_id)) {
            return ['success' => false, 'message' => 'Unauthorized'];
        }
        
        $this->conversationModel->markAsRead($conversation_id, $user_id, $role);
        $this->messageModel->markAsRead($conversation_id, $user_id);
        
        return [
            'success' => true,
            'message' => 'Marked as read'
        ];
    }
    
    /**
     * Lấy số tin nhắn chưa đọc
     * GET /api?action=get-unread-count
     */
    public function getUnreadCount($user_id, $role) {
        $total_unread = $this->conversationModel->getTotalUnread($user_id, $role);
        
        return [
            'success' => true,
            'unread_count' => $total_unread
        ];
    }
    
    /**
     * Upload attachment
     * POST /api?action=upload-chat-attachment
     */
    public function uploadAttachment() {
        if (!isset($_FILES['file'])) {
            return ['success' => false, 'message' => 'No file uploaded'];
        }
        
        $file = $_FILES['file'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 
                         'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        
        if (!in_array($file['type'], $allowed_types)) {
            return ['success' => false, 'message' => 'Invalid file type'];
        }
        
        if ($file['size'] > 5 * 1024 * 1024) { // 5MB limit
            return ['success' => false, 'message' => 'File too large (max 5MB)'];
        }
        
        // Tạo unique filename
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'chat_' . time() . '_' . uniqid() . '.' . $ext;
        $upload_dir = __DIR__ . '/../../uploads/chat/';
        
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $upload_path = $upload_dir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            return [
                'success' => true,
                'url' => '/uploads/chat/' . $filename,
                'name' => $file['name']
            ];
        }
        
        return ['success' => false, 'message' => 'Upload failed'];
    }
}
