<?php
/**
 * AIController - Handle all AI-related API requests
 * Routes requests to appropriate AI services
 */

require_once __DIR__ . '/../AI/AIService.php';
require_once __DIR__ . '/../AI/CVScorer.php';
require_once __DIR__ . '/../AI/CVParser.php';
require_once __DIR__ . '/../AI/JobMatcher.php';
require_once __DIR__ . '/../AI/ChatbotService.php';
require_once __DIR__ . '/../AI/InterviewGenerator.php';
require_once __DIR__ . '/../AI/JobRecommender.php';

class AIController {
    private $db;
    private $cvScorer;
    private $cvParser;
    private $jobMatcher;
    private $chatbot;
    private $interviewGen;
    private $jobRecommender;
    private $aiService;

    public function __construct($db = null) {
        $this->db = $db;
        $this->cvScorer = new CVScorer($db);
        $this->cvParser = new CVParser($db);
        $this->jobMatcher = new JobMatcher($db);
        $this->chatbot = new ChatbotService($db);
        $this->interviewGen = new InterviewGenerator($db);
        $this->jobRecommender = new JobRecommender($db);
        $this->aiService = new AIService();
    }

    /**
     * Score a CV against job requirements
     * POST /api/ai-score-cv
     */
    public function scoreCv($cvText, $jobData) {
        return $this->cvScorer->scoreCV($cvText, $jobData);
    }

    /**
     * Parse CV and extract structured data
     * POST /api/ai-parse-cv
     */
    public function parseCv($cvText) {
        return $this->cvParser->parseCV($cvText);
    }

    /**
     * Match candidate to job
     * POST /api/ai-match-job
     */
    public function matchJob($candidateData, $jobData) {
        return $this->jobMatcher->matchCandidateToJob($candidateData, $jobData);
    }

    /**
     * Find matching jobs for candidate
     * GET /api/ai-find-matching-jobs
     */
    public function findMatchingJobs($candidateData, $jobsList) {
        return $this->jobMatcher->findMatchingJobs($candidateData, $jobsList);
    }

    /**
     * Chat with AI bot
     * POST /api/ai-chatbot
     */
    public function chat($message, $userType = 'candidate', $context = []) {
        return $this->chatbot->processMessage($message, $userType, $context);
    }

    /**
     * Generate interview questions
     * POST /api/ai-interview-questions
     */
    public function generateInterviewQuestions($jobData, $candidateData, $options = []) {
        return $this->interviewGen->generateQuestions($jobData, $candidateData, $options);
    }

    /**
     * Recommend jobs to candidate
     * GET /api/ai-recommend-jobs
     */
    public function recommendJobs($candidateData, $jobsList, $preferences = []) {
        return $this->jobRecommender->recommendJobs($candidateData, $jobsList, $preferences);
    }

    /**
     * Recommend jobs by skill
     * GET /api/ai-recommend-by-skill
     */
    public function recommendBySkill($skill, $jobsList) {
        return $this->jobRecommender->recommendJobsBySkill($skill, $jobsList);
    }

    /**
     * Recommend jobs by location
     * GET /api/ai-recommend-by-location
     */
    public function recommendByLocation($location, $jobsList) {
        return $this->jobRecommender->recommendJobsByLocation($location, $jobsList);
    }

    /**
     * Recommend jobs by salary
     * GET /api/ai-recommend-by-salary
     */
    public function recommendBySalary($minSalary, $maxSalary, $jobsList) {
        return $this->jobRecommender->recommendJobsBySalary($minSalary, $maxSalary, $jobsList);
    }

    /**
     * Get trending jobs
     * GET /api/ai-trending-jobs
     */
    public function getTrendingJobs($jobsList) {
        return $this->jobRecommender->getTrendingJobs($jobsList);
    }

    /**
     * Get chat suggestions
     * GET /api/ai-chat-suggestions
     */
    public function getChatSuggestions($userType = 'candidate', $context = []) {
        return $this->chatbot->getSuggestions($userType, $context);
    }

    /**
     * Test AI service connection
     * GET /api/ai-test
     */
    public function testConnection() {
        return $this->aiService->testConnection();
    }

    /**
     * Get API status
     * GET /api/ai-status
     */
    public function getStatus() {
        return [
            'success' => true,
            'api_key' => $this->aiService->getApiKeyStatus(),
            'services' => [
                'cv_scorer' => 'Available',
                'cv_parser' => 'Available',
                'job_matcher' => 'Available',
                'chatbot' => 'Available',
                'interview_generator' => 'Available',
                'job_recommender' => 'Available'
            ],
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }

    /**
     * Batch score multiple CVs
     * POST /api/ai-batch-score
     */
    public function batchScoreCvs($cvList, $jobData) {
        return $this->cvScorer->scoreMultipleCVs($cvList, $jobData);
    }

    /**
     * Batch match candidates to jobs
     * POST /api/ai-batch-match
     */
    public function batchMatch($candidates, $jobs) {
        return $this->jobMatcher->batchMatch($candidates, $jobs);
    }

    /**
     * Initialize chat session
     * POST /api/ai-init-chat
     */
    public function initChatSession($userId, $userType) {
        return $this->chatbot->initConversation($userId, $userType);
    }

    /**
     * Load chat history
     * GET /api/ai-chat-history
     */
    public function getChatHistory($sessionId) {
        return $this->chatbot->loadConversation($sessionId);
    }

    /**
     * Save chat message
     * POST /api/ai-save-message
     */
    public function saveChatMessage($sessionId, $userMessage, $botResponse) {
        return $this->chatbot->saveMessage($sessionId, $userMessage, $botResponse);
    }

    /**
     * Generate interview feedback template
     * GET /api/ai-interview-feedback-template
     */
    public function getInterviewFeedbackTemplate($questionData, $candidateName) {
        return $this->interviewGen->generateFeedbackTemplate($questionData, $candidateName);
    }

    /**
     * Save interview feedback
     * POST /api/ai-save-interview-feedback
     */
    public function saveInterviewFeedback($jobId, $candidateId, $feedback) {
        return $this->interviewGen->saveFeedback($jobId, $candidateId, $feedback);
    }

    /**
     * Parse CV from file
     * POST /api/ai-parse-cv-file
     */
    public function parseCvFromFile($filePath) {
        $text = $this->cvParser->extractTextFromPDF($filePath);
        
        if ($text === false) {
            return [
                'success' => false,
                'error' => 'Failed to extract text from file',
                'code' => 'FILE_PARSE_ERROR'
            ];
        }

        return $this->cvParser->parseCV($text);
    }
}
?>
