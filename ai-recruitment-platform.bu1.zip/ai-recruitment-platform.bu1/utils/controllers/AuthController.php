<?php
class AuthController {
    private $userModel;
    
    public function __construct() {
        $this->userModel = new User();
    }
    
    // Đăng ký
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = sanitize($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            $fullName = sanitize($_POST['full_name'] ?? '');
            $phone = sanitize($_POST['phone'] ?? '');
            $role = sanitize($_POST['role'] ?? 'candidate');
            
            // Validate
            if (empty($email) || empty($password) || empty($fullName)) {
                return ['success' => false, 'message' => 'Vui lòng điền đầy đủ thông tin'];
            }
            
            if (strlen($password) < 6) {
                return ['success' => false, 'message' => 'Mật khẩu phải ít nhất 6 ký tự'];
            }
            
            if ($password !== $confirmPassword) {
                return ['success' => false, 'message' => 'Mật khẩu không khớp'];
            }
            
            if ($this->userModel->getUserByEmail($email)) {
                return ['success' => false, 'message' => 'Email đã tồn tại'];
            }
            
            $userId = $this->userModel->register($email, $password, $role, $fullName, $phone);
            
            if ($userId) {
                // Tạo profile tương ứng
                if ($role === 'candidate') {
                    $candidateModel = new CandidateProfile();
                    $candidateModel->createProfile($userId);
                } elseif ($role === 'recruiter') {
                    $companyName = sanitize($_POST['company_name'] ?? 'Company');
                    $companySize = sanitize($_POST['company_size'] ?? '');
                    $industry = sanitize($_POST['industry'] ?? '');
                    $recruiterModel = new RecruiterProfile();
                    $recruiterModel->createProfile($userId, $companyName, $companySize, $industry);
                }
                
                return ['success' => true, 'message' => 'Đăng ký thành công! Vui lòng đăng nhập'];
            }
            
            return ['success' => false, 'message' => 'Lỗi đăng ký. Vui lòng thử lại'];
        }
        return null;
    }
    
    // Đăng nhập
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = sanitize($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            
            if (empty($email) || empty($password)) {
                return ['success' => false, 'message' => 'Vui lòng điền email và mật khẩu'];
            }
            
            $user = $this->userModel->verifyPassword($email, $password);
            
            if ($user) {
                if ($user['status'] === 'banned') {
                    return ['success' => false, 'message' => 'Tài khoản này bị khóa'];
                }
                
                if ($user['status'] === 'suspended') {
                    return ['success' => false, 'message' => 'Tài khoản tạm thời bị tạm ngừng'];
                }
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['avatar_url'] = $user['avatar_url'];
                
                $this->userModel->updateLastLogin($user['id']);
                
                return ['success' => true, 'message' => 'Đăng nhập thành công'];
            }
            
            return ['success' => false, 'message' => 'Email hoặc mật khẩu không đúng'];
        }
        return null;
    }
    
    // Đăng xuất
    public function logout() {
        session_destroy();
        redirect('login.php');
    }
    
    // Kiểm tra token
    public function verifyToken($token) {
        // Kiểm tra từ session hoặc cookie
        return isset($_SESSION['token']) && $_SESSION['token'] === $token;
    }
}