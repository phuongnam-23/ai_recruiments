<?php
// utils/controllers/JobController.php

class JobController {
    private $jobModel;
    private $applicationModel;
    private $notificationModel;
    
    public function __construct() {
        if (class_exists('Job')) $this->jobModel = new Job();
        if (class_exists('Application')) $this->applicationModel = new Application();
        if (class_exists('Notification')) $this->notificationModel = new Notification();
    }
    
    public function createJob() {
        if (!isLoggedIn() || $_SESSION['role'] !== 'recruiter') {
            return ['success' => false, 'message' => 'Quyền truy cập bị từ chối'];
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // 1. Xử lý Location (Nếu không nhập location cụ thể, lấy City đắp vào)
            $city = sanitize($_POST['city'] ?? '');
            $location = sanitize($_POST['location'] ?? '');
            if (empty($location)) {
                $location = $city;
            }

            // 2. Chuẩn bị dữ liệu (Khớp với các cột trong ảnh DB bạn gửi)
            $data = [
                'title' => sanitize($_POST['title'] ?? ''),
                'description' => $_POST['description'] ?? '',     // Cho phép HTML/Text dài
                'requirements' => $_POST['requirements'] ?? '',   // Cho phép HTML/Text dài
                'benefits' => $_POST['benefits'] ?? '',           // Cho phép HTML/Text dài
                'job_type' => sanitize($_POST['job_type'] ?? 'full_time'),
                'job_level' => sanitize($_POST['job_level'] ?? 'junior'),
                'category' => sanitize($_POST['category'] ?? ''),
                'salary_min' => (float)($_POST['salary_min'] ?? 0),
                'salary_max' => (float)($_POST['salary_max'] ?? 0),
                'location' => $location,
                'city' => $city,
                'required_skills' => sanitize($_POST['required_skills'] ?? ''),
                'experience_required' => (int)($_POST['experience_required'] ?? 0),
                
                // QUAN TRỌNG: Xử lý education_required
                // Nếu không có dữ liệu, gửi NULL để DB không báo lỗi
                'education_required' => !empty($_POST['education_required']) ? sanitize($_POST['education_required']) : null,
                
                'num_positions' => (int)($_POST['num_positions'] ?? 1),
                'application_deadline' => !empty($_POST['application_deadline']) ? sanitize($_POST['application_deadline']) : null,
                'status' => sanitize($_POST['status'] ?? 'draft')
            ];
            
            // 3. Validate
            $errors = [];
            if (empty($data['title'])) $errors['title'] = 'Tiêu đề không được để trống';
            if (empty($data['description'])) $errors['description'] = 'Mô tả không được để trống';
            
            if (!empty($errors)) {
                return ['success' => false, 'message' => 'Dữ liệu không hợp lệ', 'errors' => $errors];
            }
            
            // 4. Gọi Model để lưu
            try {
                $jobId = $this->jobModel->createJob($_SESSION['user_id'], $data);
                if ($jobId) {
                    return ['success' => true, 'message' => 'Tạo tin thành công', 'job_id' => $jobId];
                }
            } catch (Exception $e) {
                return ['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()];
            }
            
            return ['success' => false, 'message' => 'Lỗi cơ sở dữ liệu: Không thể lưu tin.'];
        }
        return null;
    }

    // ... Giữ nguyên các hàm updateJob, getMyJobs, searchJobs như cũ ...
    // (Bạn copy lại các hàm đó từ phiên bản trước hoặc giữ nguyên nếu đã có)
    
    // Cập nhật job
    public function updateJob($jobId) {
        if (!isLoggedIn() || $_SESSION['role'] !== 'recruiter') {
            return ['success' => false, 'message' => 'Quyền truy cập bị từ chối'];
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $job = $this->jobModel->getJobById($jobId);
            
            if (!$job || $job['recruiter_id'] != $_SESSION['user_id']) {
                return ['success' => false, 'message' => 'Không có quyền chỉnh sửa'];
            }
            
            $data = [];
            // Danh sách các trường cho phép update
            $allowedFields = ['title', 'description', 'requirements', 'benefits', 'status',
                             'salary_min', 'salary_max', 'num_positions', 'application_deadline',
                             'city', 'location', 'required_skills', 'job_type', 'job_level', 'category', 'education_required', 'experience_required']; 
            
            foreach ($allowedFields as $field) {
                if (isset($_POST[$field])) {
                     $data[$field] = sanitize($_POST[$field]);
                }
            }
            
            if ($this->jobModel->updateJob($jobId, $data)) {
                return ['success' => true, 'message' => 'Cập nhật thành công'];
            }
            
            return ['success' => false, 'message' => 'Lỗi cập nhật'];
        }
        return null;
    }

    public function getMyJobs($status = null) {
        if (!isLoggedIn() || $_SESSION['role'] !== 'recruiter') return [];
        return $this->jobModel->getJobsByRecruiter($_SESSION['user_id'], $status);
    }

    public function searchJobs() {
        $keyword = sanitize($_GET['keyword'] ?? '');
        $filters = [
            'category' => sanitize($_GET['category'] ?? ''),
            'job_type' => sanitize($_GET['job_type'] ?? ''),
            'city' => sanitize($_GET['city'] ?? ''),
            'salary_min' => (int)($_GET['salary_min'] ?? 0)
        ];
        return $this->jobModel->searchJobs($keyword, $filters);
    }
}