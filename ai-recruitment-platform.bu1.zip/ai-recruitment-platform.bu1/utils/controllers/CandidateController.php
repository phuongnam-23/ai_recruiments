<?php
class CandidateController {
    private $candidateModel;
    private $userModel;

    public function __construct() {
        if (class_exists('CandidateProfile')) {
            $this->candidateModel = new CandidateProfile();
        }
        if (class_exists('User')) {
            $this->userModel = new User();
        }
    }

    /**
     * Cập nhật Candidate Profile (Bio, Skills, Experience, v.v.)
     * Logic xử lý "No rows affected" một cách hợp lý
     */
    public function updateProfile() {
        try {
            // Kiểm tra đăng nhập
            if (session_status() === PHP_SESSION_NONE) session_start();
            if (!isset($_SESSION['user_id'])) {
                return ['success' => false, 'message' => 'Bạn chưa đăng nhập'];
            }
            
            $userId = $_SESSION['user_id'];
            $data = [];

            // Lấy tất cả 8 trường từ POST
            $postFields = [
                'bio' => $_POST['bio'] ?? '',
                'date_of_birth' => $_POST['date_of_birth'] ?? '',
                'gender' => $_POST['gender'] ?? '',
                'city' => $_POST['city'] ?? '',
                'address' => $_POST['address'] ?? '',
                'experience_years' => $_POST['experience_years'] ?? 0,
                'education_level' => $_POST['education_level'] ?? '',
                'skills' => $_POST['skills'] ?? ''
            ];

            // Lọc và sanitize dữ liệu
            foreach ($postFields as $key => $value) {
                // Strip HTML tags
                $value = strip_tags($value);
                
                // Xử lý riêng từng field
                if ($key === 'experience_years') {
                    $value = (int) $value;
                } elseif ($key === 'date_of_birth') {
                    // Nếu rỗng thì set NULL
                    if (empty($value)) {
                        $value = null;
                    } else {
                        // Kiểm tra định dạng ngày
                        $dateObj = DateTime::createFromFormat('Y-m-d', $value);
                        if ($dateObj === false) {
                            return ['success' => false, 'message' => 'Định dạng ngày sinh không hợp lệ'];
                        }
                        $value = $dateObj->format('Y-m-d');
                    }
                }
                
                $data[$key] = $value;
            }

            // Log dữ liệu được gửi
            error_log('CandidateController::updateProfile - Data: ' . json_encode($data));

            // Cập nhật profile
            $result = $this->candidateModel->updateProfile($userId, $data);

            if ($result === false) {
                return ['success' => false, 'message' => 'Lỗi: Không thể cập nhật thông tin'];
            }

            // Success: Cập nhật thành công
            return [
                'success' => true,
                'message' => 'Cập nhật thông tin thành công!',
                'data' => $data
            ];

        } catch (Exception $e) {
            error_log('CandidateController::updateProfile Error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()];
        }
    }

    /**
     * Lấy CV theo candidate
     */
    public function getProfileWithCV() {
        try {
            if (session_status() === PHP_SESSION_NONE) session_start();
            if (!isset($_SESSION['user_id'])) {
                return ['success' => false, 'message' => 'Unauthorized'];
            }

            $profile = $this->candidateModel->getProfile($_SESSION['user_id']);
            
            if (!$profile) {
                return ['success' => false, 'message' => 'Profile not found'];
            }

            return ['success' => true, 'data' => $profile];

        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
?>
