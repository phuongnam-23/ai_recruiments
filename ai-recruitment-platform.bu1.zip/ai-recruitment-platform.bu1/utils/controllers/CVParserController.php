<?php
/**
 * CV Parser Controller - Python Backend Wrapper
 * Calls Python script for CV parsing
 */

class CVParserController {
    private $pythonScript = __DIR__ . '/../ai/cv_parser.py';
    
    public function parseCVFile($filePath) {
        try {
            // Validate file exists
            if (!file_exists($filePath)) {
                return [
                    'success' => false,
                    'message' => 'File not found: ' . $filePath
                ];
            }
            
            // Call Python script with proper paths
            $output = [];
            $returnCode = 0;
            
            // Get the absolute path to the Python script
            $scriptDir = dirname($this->pythonScript);
            $pythonScript = realpath($this->pythonScript);
            $pythonPath = 'python';
            
            // Build command using absolute paths
            $command = sprintf(
                'cd /d %s && chcp 65001 > nul && %s %s %s 2>&1',
                escapeshellarg($scriptDir),
                $pythonPath,
                escapeshellarg(basename($pythonScript)),
                escapeshellarg($filePath)
            );
            
            error_log('🐍 CVParserController: Script dir = ' . $scriptDir);
            error_log('🐍 CVParserController: Python script = ' . $pythonScript);
            error_log('🐍 CVParserController: Executing: ' . $command);
            
            exec($command, $output, $returnCode);
            
            // Combine output and get only the last non-empty line (the actual JSON response)
            $response = implode("\n", array_filter($output, function($line) {
                return !empty(trim($line));
            }));
            
            // If multiple lines, try to get just the last JSON object
            $lines = array_filter(explode("\n", $response), function($line) {
                return trim($line) !== '';
            });
            
            if (count($lines) > 1) {
                // Take the last line which should be the actual JSON response
                $response = end($lines);
            }
            
            error_log('🐍 CVParserController: Return code = ' . $returnCode);
            error_log('🐍 CVParserController: Output lines = ' . count($output));
            error_log('🐍 CVParserController: Response length = ' . strlen($response));
            
            if (strlen($response) > 0) {
                error_log('🐍 CVParserController: First 500 chars = ' . substr($response, 0, 500));
            }
            
            // Check if response is empty
            if (empty($response)) {
                error_log('❌ CVParserController: Empty response from Python script');
                return [
                    'success' => false,
                    'message' => 'Python script returned no output. Return code: ' . $returnCode
                ];
            }
            
            // Parse JSON response
            $result = json_decode($response, true);
            
            if ($result === null) {
                error_log('❌ CVParserController: Invalid JSON response');
                error_log('Raw response: ' . $response);
                return [
                    'success' => false,
                    'message' => 'Invalid JSON from parser: ' . substr($response, 0, 100)
                ];
            }
            
            return $result;
            
        } catch (Exception $e) {
            error_log('❌ CVParserController: Exception - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
}
?>
