<?php
class UserController {
    private $userModel;

    public function __construct() {
        if (class_exists('User')) {
            $this->userModel = new User();
        }
    }

    public function updateProfile() {
        // Kiểm tra đăng nhập
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['user_id'])) {
            return ['success' => false, 'message' => 'Bạn chưa đăng nhập'];
        }
        
        $userId = $_SESSION['user_id'];
        $data = [];

        // 1. Xử lý Upload Avatar (SỬA LỖI TẠI ĐÂY)
        if (isset($_FILES['avatar_file']) && $_FILES['avatar_file']['error'] === UPLOAD_ERR_OK) {
            // Kiểm tra class FileHandler có tồn tại không
            if (!class_exists('FileHandler')) {
                return ['success' => false, 'message' => 'Lỗi server: Thiếu FileHandler'];
            }

            // Gọi hàm uploadImage từ FileHandler (file Helpers.php của bạn)
            $up = FileHandler::uploadImage($_FILES['avatar_file'], $userId, 'avatars/'); // Thêm 'avatars/' vào subFolder
            
            if ($up['success']) {
                // Lưu đường dẫn đầy đủ vào DB. 
                // Lưu ý: path trả về từ FileHandler đã là 'uploads/avatars/...'
                // Nếu cần full URL thì thêm BASE_URL
                $data['avatar_url'] = defined('BASE_URL') ? BASE_URL . $up['path'] : $up['path'];
            } else {
                return ['success' => false, 'message' => $up['message']];
            }
        }

        // 2. Update thông tin text
        if (isset($_POST['full_name'])) {
            $data['full_name'] = strip_tags($_POST['full_name']);
        }
        if (isset($_POST['phone'])) {
            $data['phone'] = strip_tags($_POST['phone']);
        }

        // 3. Lưu vào DB
        if (!empty($data)) {
            if ($this->userModel->updateUser($userId, $data)) {
                // Update Session ngay lập tức để hiển thị
                if (isset($data['full_name'])) $_SESSION['full_name'] = $data['full_name'];
                if (isset($data['avatar_url'])) $_SESSION['avatar_url'] = $data['avatar_url'];
                
                return [
                    'success' => true, 
                    'message' => 'Cập nhật thành công!', 
                    'avatar_url' => $data['avatar_url'] ?? null
                ];
            }
            return ['success' => false, 'message' => 'Lỗi: Không thể ghi vào Database'];
        }
        
        return ['success' => false, 'message' => 'Không có dữ liệu nào thay đổi'];
    }
}
?>