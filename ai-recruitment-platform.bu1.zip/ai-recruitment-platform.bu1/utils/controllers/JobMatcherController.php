<?php
/**
 * Job Matcher Controller
 * Handles AI-based job matching
 */

class JobMatcherController {
    private $pythonScript = __DIR__ . '/../AI/job_matcher.py';

    public function matchJob($cvText, $jobDescription) {
        try {
            if (!file_exists($this->pythonScript)) {
                return [
                    'success' => false,
                    'message' => 'Job matcher script not found'
                ];
            }

            // Create temporary files for CV and job description
            $cvFile = tempnam(sys_get_temp_dir(), 'cv_');
            file_put_contents($cvFile, $cvText);

            try {
                $command = sprintf(
                    'chcp 65001 > nul && python "%s" "%s" "%s" 2>&1',
                    $this->pythonScript,
                    $cvFile,
                    base64_encode($jobDescription)
                );

                $output = [];
                $returnCode = 0;
                exec($command, $output, $returnCode);

                @unlink($cvFile);

                if ($returnCode !== 0) {
                    return [
                        'success' => false,
                        'message' => 'Python execution failed',
                        'error' => implode("\n", $output)
                    ];
                }

                $result = json_decode(implode("\n", $output), true);
                return $result ?: ['success' => false, 'message' => 'Invalid response'];

            } catch (Exception $e) {
                @unlink($cvFile);
                throw $e;
            }

        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
}
?>
