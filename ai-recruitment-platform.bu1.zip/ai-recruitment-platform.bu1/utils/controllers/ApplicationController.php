<?php
class ApplicationController {
    private $applicationModel;
    private $jobModel;
    private $notificationModel;
    
    public function __construct() {
        $this->applicationModel = new Application();
        $this->jobModel = new Job();
        $this->notificationModel = new Notification();
    }
    
    // Tạo application
    public function applyJob($jobId) {
        if (!isLoggedIn() || $_SESSION['role'] !== 'candidate') {
            return ['success' => false, 'message' => 'Chỉ ứng viên mới có thể apply'];
        }
        
        $job = $this->jobModel->getJobById($jobId);
        if (!$job) {
            return ['success' => false, 'message' => 'Tin tuyển dụng không tồn tại'];
        }
        
        if ($this->applicationModel->hasApplied($jobId, $_SESSION['user_id'])) {
            return ['success' => false, 'message' => 'Bạn đã apply tin này rồi'];
        }
        
        $data = [
            'cover_letter' => sanitize($_POST['cover_letter'] ?? '')
        ];
        
        $appId = $this->applicationModel->createApplication($jobId, $_SESSION['user_id'], $data);
        
        if ($appId) {
            // Tạo notification cho recruiter
            $this->notificationModel->createNotification(
                $job['recruiter_id'],
                'new_application',
                'Ứng viên mới apply',
                'Bạn có 1 ứng viên mới apply cho vị trí: ' . $job['title'],
                $appId
            );
            
            return ['success' => true, 'message' => 'Apply thành công'];
        }
        
        return ['success' => false, 'message' => 'Lỗi apply'];
    }
    
    // Cập nhật trạng thái application
    public function updateApplicationStatus($appId, $status) {
        if (!isLoggedIn()) {
            return ['success' => false, 'message' => 'Vui lòng đăng nhập'];
        }
        
        $app = $this->applicationModel->getApplicationById($appId);
        if (!$app) {
            return ['success' => false, 'message' => 'Application không tồn tại'];
        }
        
        // Kiểm tra quyền
        if ($_SESSION['role'] === 'recruiter') {
            // Recruiter chỉ có thể cập nhật ứng dụng của mình
            $job = $this->jobModel->getJobById($app['job_id']);
            if ($job['recruiter_id'] != $_SESSION['user_id']) {
                return ['success' => false, 'message' => 'Không có quyền cập nhật'];
            }
        } elseif ($_SESSION['role'] === 'candidate') {
            // Candidate chỉ có thể rút đơn
            if ($app['candidate_id'] != $_SESSION['user_id'] || $status !== 'withdrawn') {
                return ['success' => false, 'message' => 'Không có quyền cập nhật'];
            }
        }
        
        if ($this->applicationModel->updateApplication($appId, ['status' => $status])) {
            // Tạo notification cho ứng viên
            $this->notificationModel->createNotification(
                $app['candidate_id'],
                'application_status_changed',
                'Cập nhật trạng thái đơn apply',
                'Trạng thái đơn apply của bạn: ' . $status,
                $appId
            );
            
            return ['success' => true, 'message' => 'Cập nhật thành công'];
        }
        
        return ['success' => false, 'message' => 'Lỗi cập nhật'];
    }
    
    // Lấy applications của job
    public function getApplicationsByJob($jobId, $status = null) {
        if (!isLoggedIn() || $_SESSION['role'] !== 'recruiter') {
            return [];
        }
        
        $job = $this->jobModel->getJobById($jobId);
        if (!$job || $job['recruiter_id'] != $_SESSION['user_id']) {
            return [];
        }
        
        return $this->applicationModel->getApplicationsByJob($jobId, $status);
    }
    
    // Lấy applications của candidate
    public function getMyApplications() {
        if (!isLoggedIn() || $_SESSION['role'] !== 'candidate') {
            return [];
        }
        
        return $this->applicationModel->getApplicationsByCandidate($_SESSION['user_id']);
    }
}