<?php
class RecruiterController {
    private $recruiterModel;
    private $userModel;

    public function __construct() {
        if (class_exists('RecruiterProfile')) {
            $this->recruiterModel = new RecruiterProfile();
        }
        if (class_exists('User')) {
            $this->userModel = new User();
        }
    }

    public function updateProfile() {
        // Log for debugging
        error_log('RecruiterController::updateProfile called');
        error_log('POST data: ' . json_encode($_POST));
        
        try {
            // Kiểm tra đăng nhập
            if (session_status() === PHP_SESSION_NONE) session_start();
            if (!isset($_SESSION['user_id'])) {
                return ['success' => false, 'message' => 'Bạn chưa đăng nhập'];
            }
            
            $userId = $_SESSION['user_id'];
            $data = [];

            // 1. Xử lý Upload Avatar
            if (isset($_FILES['avatar_file']) && $_FILES['avatar_file']['error'] === UPLOAD_ERR_OK) {
                if (!class_exists('FileHandler')) {
                    return ['success' => false, 'message' => 'Lỗi server: Thiếu FileHandler'];
                }

                $up = FileHandler::uploadImage($_FILES['avatar_file'], $userId, 'avatars/');
                
                if ($up['success']) {
                    $data['avatar_url'] = $up['path']; // Lưu relative path, không add BASE_URL
                } else {
                    return ['success' => false, 'message' => $up['message']];
                }
            }

            // 2. Update thông tin User (full_name, phone, avatar_url)
            $userData = [];
            
            if (!empty($_POST['full_name'])) {
                $userData['full_name'] = strip_tags($_POST['full_name']);
            }
            if (!empty($_POST['phone'])) {
                $userData['phone'] = strip_tags($_POST['phone']);
            }
            if (!empty($data['avatar_url'])) {
                $userData['avatar_url'] = $data['avatar_url'];
            }

            if (!empty($userData)) {
                if (!$this->userModel->updateUser($userId, $userData)) {
                    return ['success' => false, 'message' => 'Lỗi: Không thể cập nhật thông tin user'];
                }
                // Update Session
                foreach ($userData as $key => $value) {
                    $_SESSION[$key] = $value;
                }
            }

            // 3. Update thông tin RecruiterProfile
            $recruiterData = [];
            
            // Only include fields that have non-empty values
            if (!empty($_POST['company_name'])) {
                $recruiterData['company_name'] = strip_tags($_POST['company_name']);
            }
            if (!empty($_POST['company_website'])) {
                $recruiterData['company_website'] = strip_tags($_POST['company_website']);
            }
            if (!empty($_POST['industry'])) {
                $recruiterData['industry'] = strip_tags($_POST['industry']);
            }
            if (!empty($_POST['company_address'])) {
                $recruiterData['company_address'] = strip_tags($_POST['company_address']);
            }
            if (!empty($_POST['address'])) {
                $recruiterData['company_address'] = strip_tags($_POST['address']);
            }
            if (!empty($_POST['tax_code'])) {
                $recruiterData['tax_code'] = strip_tags($_POST['tax_code']);
            }
            if (!empty($_POST['company_city'])) {
                $recruiterData['company_city'] = strip_tags($_POST['company_city']);
            }
            if (!empty($_POST['company_size'])) {
                $recruiterData['company_size'] = strip_tags($_POST['company_size']);
            }

            if (!empty($recruiterData)) {
                error_log('RecruiterController: Updating recruiter data - ' . json_encode($recruiterData));
                if (!$this->recruiterModel->updateProfile($userId, $recruiterData)) {
                    error_log('RecruiterController: updateProfile returned false');
                    return ['success' => false, 'message' => 'Lỗi: Không thể cập nhật thông tin công ty'];
                }
                error_log('RecruiterController: updateProfile successful');
            } else {
                error_log('RecruiterController: recruiterData is empty, nothing to update');
            }

            error_log('RecruiterController: returning success response');
            return [
                'success' => true, 
                'message' => 'Cập nhật thành công!', 
                'avatar_url' => $data['avatar_url'] ?? null
            ];
        } catch (Exception $e) {
            error_log('RecruiterController Exception: ' . $e->getMessage());
            error_log('Stack trace: ' . $e->getTraceAsString());
            return ['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()];
        }
    }
}
?>
