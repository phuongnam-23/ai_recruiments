<?php
class RecruiterProfile {
    private $db;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }
    
    // Lấy profile theo user_id
    public function getProfile($userId) {
        $query = "SELECT * FROM recruiter_profiles WHERE user_id = :user_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Tạo profile mới
    public function createProfile($userId, $companyName, $companySize, $industry) {
        try {
            $query = "INSERT INTO recruiter_profiles (user_id, company_name, company_size, industry) 
                      VALUES (:user_id, :company_name, :company_size, :industry)";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':user_id', $userId);
            $stmt->bindParam(':company_name', $companyName);
            $stmt->bindParam(':company_size', $companySize);
            $stmt->bindParam(':industry', $industry);
            
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }
    
    // Cập nhật profile
    public function updateProfile($userId, $data) {
        $allowedFields = [
            'company_name', 'company_size', 'industry', 'company_description',
            'company_website', 'company_logo_url', 'company_address', 'company_city',
            'tax_code', 'verification_documents'
        ];
        
        $updateFields = [];
        $params = [':user_id' => $userId];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                if ($key === 'verification_documents') {
                    $value = is_array($value) ? json_encode($value) : $value;
                }
                $updateFields[] = "$key = :$key";
                $params[":$key"] = $value;
            }
        }
        
        if (empty($updateFields)) return false;
        
        $query = "UPDATE recruiter_profiles SET " . implode(', ', $updateFields) . 
                 ", updated_at = NOW() WHERE user_id = :user_id";
        $stmt = $this->db->prepare($query);
        $result = $stmt->execute($params);
        
        if (!$result) {
            error_log('RecruiterProfile::updateProfile failed - ' . json_encode($stmt->errorInfo()));
        }
        
        return $result;
    }
    
    // Lấy danh sách recruiter theo ngành
    public function getRecruitersByIndustry($industry, $limit = 20, $offset = 0) {
        $query = "SELECT rp.*, u.full_name, u.email, u.phone 
                  FROM recruiter_profiles rp
                  JOIN users u ON rp.user_id = u.id
                  WHERE rp.industry = :industry AND rp.verification_status = 'verified' AND u.status = 'active'
                  LIMIT :limit OFFSET :offset";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':industry', $industry);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Cập nhật trạng thái xác thực
    public function updateVerificationStatus($userId, $status) {
        $query = "UPDATE recruiter_profiles SET verification_status = :status, updated_at = NOW() WHERE user_id = :user_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':user_id', $userId);
        return $stmt->execute();
    }
    
    // Lấy recruiter theo công ty
    public function getRecruiterByCompanyName($companyName) {
        $query = "SELECT * FROM recruiter_profiles WHERE company_name = :company_name LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':company_name', $companyName);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Lấy profile theo user_id (alias)
    public function getProfileByUserId($userId) {
        return $this->getProfile($userId);
    }

    // Lấy tất cả recruiters (public)
    public function getAllRecruiters($limit = 20, $offset = 0) {
        $query = "SELECT rp.*, u.full_name, u.email, u.phone 
                  FROM recruiter_profiles rp
                  JOIN users u ON rp.user_id = u.id
                  WHERE u.status = 'active'
                  ORDER BY rp.created_at DESC
                  LIMIT :limit OFFSET :offset";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
