<?php
// utils/models/User.php

require_once __DIR__ . '/../../config/database.php';

class User {
    private $db;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }
    
    // Lấy user theo ID
    public function getUserById($id) {
        $query = "SELECT * FROM users WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Lấy user theo email
    public function getUserByEmail($email) {
        $query = "SELECT * FROM users WHERE email = :email";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Đăng ký user mới
    public function register($email, $password, $role, $fullName, $phone = null) {
        try {
            $query = "INSERT INTO users (email, password_hash, role, full_name, phone, status) 
                      VALUES (:email, :password, :role, :fullName, :phone, 'active')"; // Mặc định active để test cho dễ
            $stmt = $this->db->prepare($query);
            
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $hashedPassword);
            $stmt->bindParam(':role', $role);
            $stmt->bindParam(':fullName', $fullName);
            $stmt->bindParam(':phone', $phone);
            
            if ($stmt->execute()) {
                return $this->db->lastInsertId();
            }
            return false;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    // Kiểm tra password
    public function verifyPassword($email, $password) {
        $user = $this->getUserByEmail($email);
        if ($user && password_verify($password, $user['password_hash'])) {
            // Kiểm tra nếu bị ban thì không cho đăng nhập
            if ($user['status'] === 'banned' || $user['status'] === 'suspended') {
                return 'banned';
            }
            return $user;
        }
        return false;
    }
    
    // Cập nhật thông tin user
    public function updateUser($id, $data) {
        $allowedFields = ['full_name', 'phone', 'avatar_url', 'two_factor_enabled'];
        $updateFields = [];
        $params = [':id' => $id];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                $updateFields[] = "$key = :$key";
                $params[":$key"] = $value;
            }
        }
        
        if (empty($updateFields)) return false;
        
        $query = "UPDATE users SET " . implode(', ', $updateFields) . ", updated_at = NOW() WHERE id = :id";
        $stmt = $this->db->prepare($query);
        return $stmt->execute($params);
    }

    // --- CÁC HÀM MỚI BỔ SUNG CHO ADMIN ---

    // 1. Lấy tất cả User (Có phân trang) - Dùng cho Admin List
    public function getAllUsers($limit = 20, $offset = 0) {
        $query = "SELECT * FROM users ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // 2. Cập nhật trạng thái (Dùng cho Ban/Unban)
    public function updateStatus($id, $status) {
        $query = "UPDATE users SET status = :status WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // 3. Sửa lại: Lấy danh sách user theo role (Bỏ điều kiện active để Admin thấy hết)
    public function getUsersByRole($role, $limit = 20, $offset = 0) {
        $query = "SELECT * FROM users WHERE role = :role 
                  ORDER BY created_at DESC 
                  LIMIT :limit OFFSET :offset";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':role', $role);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // 4. Sửa lại: Đếm user theo role (Đếm tất cả để thống kê chính xác)
    public function countUsersByRole($role) {
        $query = "SELECT COUNT(*) as total FROM users WHERE role = :role";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':role', $role);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'] ?? 0;
    }
    
    // Xóa user (soft delete)
    public function deleteUser($id) {
        // Thực chất là Ban vĩnh viễn hoặc xóa khỏi DB tùy logic
        // Ở đây dùng xóa khỏi DB nếu muốn dọn sạch, hoặc update status = 'deleted'
        // Theo code admin users.php, nút Delete gọi hàm này.
        $query = "DELETE FROM users WHERE id = :id"; // Xóa cứng (Cẩn thận)
        // Hoặc Soft delete: $query = "UPDATE users SET status = 'banned' WHERE id = :id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function updateLastLogin($id) {
        $query = "UPDATE users SET last_login = NOW() WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}