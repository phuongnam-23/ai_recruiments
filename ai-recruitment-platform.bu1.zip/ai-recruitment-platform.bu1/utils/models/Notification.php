<?php
class Notification {
    private $db;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }
    
    // Tạo notification mới
    public function createNotification($userId, $type, $title, $content, $relatedId = null) {
        try {
            $query = "INSERT INTO notifications (user_id, type, title, content, related_id) 
                      VALUES (:user_id, :type, :title, :content, :related_id)";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':user_id', $userId);
            $stmt->bindParam(':type', $type);
            $stmt->bindParam(':title', $title);
            $stmt->bindParam(':content', $content);
            $stmt->bindParam(':related_id', $relatedId);
            
            return $stmt->execute() ? $this->db->lastInsertId() : false;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    // Lấy notification
    public function getNotifications($userId, $limit = 20, $offset = 0) {
        $query = "SELECT * FROM notifications 
                  WHERE user_id = :user_id 
                  ORDER BY created_at DESC 
                  LIMIT :limit OFFSET :offset";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Đánh dấu đã đọc
    public function markAsRead($notificationId) {
        $query = "UPDATE notifications SET is_read = TRUE WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $notificationId);
        return $stmt->execute();
    }
    
    // Đếm unread
    public function countUnread($userId) {
        $query = "SELECT COUNT(*) as count FROM notifications WHERE user_id = :user_id AND is_read = FALSE";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    }
    
    // Xóa notification
    public function deleteNotification($id) {
        $query = "DELETE FROM notifications WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}