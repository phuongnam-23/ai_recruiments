<?php
class CandidateProfile {
    private $db;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }
    
    // Lấy profile theo user_id
    public function getProfile($userId) {
        $query = "SELECT * FROM candidate_profiles WHERE user_id = :user_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Tạo profile mới
    public function createProfile($userId, $data = []) {
        try {
            $query = "INSERT INTO candidate_profiles (user_id) VALUES (:user_id)";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':user_id', $userId);
            
            if ($stmt->execute()) {
                return $this->updateProfile($userId, $data);
            }
            return false;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    // Cập nhật profile (hoặc tạo mới nếu chưa tồn tại)
    public function updateProfile($userId, $data) {
        try {
            // Bước 1: Kiểm tra xem profile đã tồn tại chưa
            $checkQuery = "SELECT id FROM candidate_profiles WHERE user_id = :user_id LIMIT 1";
            $checkStmt = $this->db->prepare($checkQuery);
            $checkStmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $checkStmt->execute();
            $profileExists = $checkStmt->fetch(PDO::FETCH_ASSOC);

            if (!$profileExists) {
                // Bước 2a: Profile chưa tồn tại -> INSERT
                return $this->_insertProfile($userId, $data);
            } else {
                // Bước 2b: Profile đã tồn tại -> UPDATE
                return $this->_updateProfileData($userId, $data);
            }

        } catch (PDOException $e) {
            error_log('CandidateProfile::updateProfile PDO Error: ' . $e->getMessage());
            return false;
        } catch (Exception $e) {
            error_log('CandidateProfile::updateProfile Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Tạo mới profile (INSERT)
     */
    private function _insertProfile($userId, $data) {
        try {
            // Chuẩn bị các field để INSERT
            $fields = ['user_id'];
            $placeholders = [':user_id'];
            $params = [':user_id' => $userId];

            // Danh sách các field được phép
            $allowedFields = [
                'date_of_birth', 'gender', 'address', 'city', 'skills', 'experience_years',
                'education_level', 'bio', 'desired_salary_min', 'desired_salary_max',
                'desired_positions', 'linkedin_url', 'github_url', 'portfolio_url'
            ];

            foreach ($data as $key => $value) {
                if (in_array($key, $allowedFields)) {
                    $fields[] = $key;
                    $placeholders[] = ':' . $key;
                    
                    // Xử lý NULL cho date_of_birth
                    if ($key === 'date_of_birth' && $value === null) {
                        $params[':' . $key] = null;
                    }
                    // Xử lý JSON fields - MUST be valid JSON format
                    elseif (in_array($key, ['skills', 'desired_positions'])) {
                        if (is_array($value)) {
                            $params[':' . $key] = json_encode($value, JSON_UNESCAPED_UNICODE);
                        } elseif (is_string($value) && !empty($value)) {
                            // Convert comma-separated string to JSON array
                            $items = array_map('trim', explode(',', $value));
                            $items = array_filter($items); // Remove empty items
                            $params[':' . $key] = json_encode($items, JSON_UNESCAPED_UNICODE);
                        } else {
                            // Empty string or null - store as empty JSON array
                            $params[':' . $key] = json_encode([], JSON_UNESCAPED_UNICODE);
                        }
                    }
                    // Xử lý type casting cho experience_years
                    elseif ($key === 'experience_years') {
                        $params[':' . $key] = (int)$value;
                    }
                    else {
                        $params[':' . $key] = $value;
                    }
                }
            }

            $insertQuery = "INSERT INTO candidate_profiles (" . implode(', ', $fields) . ") " .
                          "VALUES (" . implode(', ', $placeholders) . ")";

            error_log('CandidateProfile::_insertProfile Query: ' . $insertQuery);
            error_log('CandidateProfile::_insertProfile Params: ' . json_encode($params, JSON_UNESCAPED_UNICODE));

            $stmt = $this->db->prepare($insertQuery);
            
            // Bind params với type hints
            foreach ($params as $key => $value) {
                if ($value === null) {
                    $stmt->bindValue($key, null, PDO::PARAM_NULL);
                } elseif (is_int($value)) {
                    $stmt->bindValue($key, $value, PDO::PARAM_INT);
                } else {
                    $stmt->bindValue($key, $value, PDO::PARAM_STR);
                }
            }
            
            $result = $stmt->execute();

            if ($result === false) {
                error_log('CandidateProfile::_insertProfile Execute failed');
                error_log('CandidateProfile::_insertProfile Error Info: ' . json_encode($stmt->errorInfo()));
                return false;
            }

            error_log('CandidateProfile::_insertProfile Success - New profile created for user ' . $userId);
            return true;

        } catch (PDOException $e) {
            error_log('CandidateProfile::_insertProfile PDO Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Cập nhật profile hiện tại (UPDATE)
     */
    private function _updateProfileData($userId, $data) {
        try {
            // Danh sách các field được phép
            $allowedFields = [
                'date_of_birth', 'gender', 'address', 'city', 'skills', 'experience_years',
                'education_level', 'bio', 'desired_salary_min', 'desired_salary_max',
                'desired_positions', 'linkedin_url', 'github_url', 'portfolio_url'
            ];

            $updateFields = [];
            $params = [':user_id' => $userId];

            foreach ($data as $key => $value) {
                if (in_array($key, $allowedFields)) {
                    // Xử lý NULL cho date_of_birth
                    if ($key === 'date_of_birth' && $value === null) {
                        $updateFields[] = "$key = NULL";
                        // Không thêm vào params vì đã xử lý bằng NULL
                    }
                    // Xử lý JSON fields - MUST be valid JSON format
                    elseif (in_array($key, ['skills', 'desired_positions'])) {
                        $updateFields[] = "$key = :$key";
                        if (is_array($value)) {
                            $params[':' . $key] = json_encode($value, JSON_UNESCAPED_UNICODE);
                        } elseif (is_string($value) && !empty($value)) {
                            // Convert comma-separated string to JSON array
                            $items = array_map('trim', explode(',', $value));
                            $items = array_filter($items); // Remove empty items
                            $params[':' . $key] = json_encode($items, JSON_UNESCAPED_UNICODE);
                        } else {
                            // Empty string or null - store as empty JSON array
                            $params[':' . $key] = json_encode([], JSON_UNESCAPED_UNICODE);
                        }
                    }
                    // Xử lý type casting cho experience_years
                    elseif ($key === 'experience_years') {
                        $updateFields[] = "$key = :$key";
                        $params[':' . $key] = (int)$value;
                    }
                    else {
                        $updateFields[] = "$key = :$key";
                        $params[':' . $key] = $value;
                    }
                }
            }

            // Nếu không có field nào để update, coi là thành công
            if (empty($updateFields)) {
                error_log('CandidateProfile::_updateProfileData No fields to update');
                return true;
            }

            // Xây dựng câu lệnh UPDATE
            $updateQuery = "UPDATE candidate_profiles SET " . 
                          implode(', ', $updateFields) . 
                          ", updated_at = NOW() " .
                          "WHERE user_id = :user_id";

            error_log('CandidateProfile::_updateProfileData Query: ' . $updateQuery);
            error_log('CandidateProfile::_updateProfileData Params: ' . json_encode($params, JSON_UNESCAPED_UNICODE));

            $stmt = $this->db->prepare($updateQuery);
            
            // Bind params với type hints
            foreach ($params as $key => $value) {
                if ($value === null) {
                    $stmt->bindValue($key, null, PDO::PARAM_NULL);
                } elseif (is_int($value)) {
                    $stmt->bindValue($key, $value, PDO::PARAM_INT);
                } else {
                    $stmt->bindValue($key, $value, PDO::PARAM_STR);
                }
            }
            
            $result = $stmt->execute();

            if ($result === false) {
                error_log('CandidateProfile::_updateProfileData Execute failed');
                error_log('CandidateProfile::_updateProfileData Error Info: ' . json_encode($stmt->errorInfo()));
                return false;
            }

            $affectedRows = $stmt->rowCount();
            error_log('CandidateProfile::_updateProfileData Success - Affected rows: ' . $affectedRows);

            // Luôn return true nếu execute() thành công, bất kể rowCount
            return true;

        } catch (PDOException $e) {
            error_log('CandidateProfile::_updateProfileData PDO Error: ' . $e->getMessage());
            return false;
        }
    }
    
    // Tải CV
    public function uploadCV($userId, $cvFilePath) {
        $query = "UPDATE candidate_profiles SET cv_file_url = :cv_url, updated_at = NOW() WHERE user_id = :user_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':cv_url', $cvFilePath);
        $stmt->bindParam(':user_id', $userId);
        return $stmt->execute();
    }
    
    // Cập nhật CV score từ AI
    public function updateCVScore($userId, $score, $parsedData = null) {
        $query = "UPDATE candidate_profiles SET cv_score = :score";
        if ($parsedData) {
            $query .= ", cv_parsed_data = :parsed";
        }
        $query .= ", updated_at = NOW() WHERE user_id = :user_id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':score', $score);
        $stmt->bindParam(':user_id', $userId);
        if ($parsedData) {
            $jsonData = json_encode($parsedData, JSON_UNESCAPED_UNICODE);
            $stmt->bindParam(':parsed', $jsonData);
        }
        return $stmt->execute();
    }

    /**
     * Cập nhật kết quả phân tích CV (json) và điểm
     * Lưu vào trường `cv_analysis` (nếu tồn tại) và `cv_score`.
     */
    public function updateCVAnalysis($userId, $score, $analysisJson) {
        try {
            $query = "UPDATE candidate_profiles SET cv_score = :score, cv_analysis = :analysis, updated_at = NOW() WHERE user_id = :user_id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':score', $score, PDO::PARAM_INT);
            $stmt->bindParam(':analysis', $analysisJson);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log('CandidateProfile::updateCVAnalysis PDO Error: ' . $e->getMessage());
            return false;
        }
    }
    
    // Lấy danh sách ứng viên theo kỹ năng
    public function getCandidatesBySkills($skills, $limit = 20, $offset = 0) {
        $skillPattern = implode('|', $skills);
        $query = "SELECT cp.*, u.full_name, u.email, u.phone 
                  FROM candidate_profiles cp
                  JOIN users u ON cp.user_id = u.id
                  WHERE cp.skills LIKE :skills AND u.status = 'active'
                  ORDER BY cp.cv_score DESC
                  LIMIT :limit OFFSET :offset";
        $stmt = $this->db->prepare($query);
        $stmt->bindValue(':skills', '%' . $skillPattern . '%');
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Lấy ứng viên tốt nhất
    public function getTopCandidates($city = null, $limit = 10) {
        $query = "SELECT cp.*, u.full_name, u.email, u.phone 
                  FROM candidate_profiles cp
                  JOIN users u ON cp.user_id = u.id
                  WHERE u.status = 'active'";
        
        $params = [];
        if ($city) {
            $query .= " AND cp.city = :city";
            $params[':city'] = $city;
        }
        
        $query .= " ORDER BY cp.cv_score DESC LIMIT :limit";
        $params[':limit'] = $limit;
        
        $stmt = $this->db->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindParam($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
