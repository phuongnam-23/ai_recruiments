<?php
class CompanyReview {
    private $db;
    
    public function __construct() {
        $this->db = (new Database())->getConnection();
    }
    
    /**
     * Add a new review
     */
    public function addReview($companyId, $candidateId, $rating, $title, $comment, $jobPosition = null, $employmentStatus = 'current_employee') {
        try {
            $query = "INSERT INTO company_reviews (company_id, candidate_id, rating, title, review, status) 
                      VALUES (:company_id, :candidate_id, :rating, :title, :review, :status)
                      ON DUPLICATE KEY UPDATE 
                      rating = :rating, 
                      title = :title, 
                      review = :review,
                      status = :status";
            
            $stmt = $this->db->prepare($query);
            $stmt->execute([
                ':company_id' => $companyId,
                ':candidate_id' => $candidateId,
                ':rating' => $rating,
                ':title' => $title,
                ':review' => $comment,
                ':status' => 'approved'
            ]);
            
            return true;
        } catch (PDOException $e) {
            error_log('Add Review Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get all reviews for a company
     */
    public function getCompanyReviews($companyId, $limit = 10, $offset = 0) {
        try {
            $query = "SELECT cr.*, u.full_name, u.avatar_url
                      FROM company_reviews cr
                      JOIN users u ON cr.candidate_id = u.id
                      WHERE cr.company_id = :company_id AND cr.status = 'approved'
                      ORDER BY cr.created_at DESC
                      LIMIT :limit OFFSET :offset";
            
            $stmt = $this->db->prepare($query);
            $stmt->bindValue(':company_id', $companyId, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Get Reviews Error: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get company rating statistics
     */
    public function getCompanyRatingStats($companyId) {
        try {
            $query = "SELECT 
                        COUNT(*) as total_reviews,
                        AVG(rating) as average_rating,
                        SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as five_star,
                        SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as four_star,
                        SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as three_star,
                        SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as two_star,
                        SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as one_star
                      FROM company_reviews
                      WHERE company_id = :company_id AND status = 'approved'";
            
            $stmt = $this->db->prepare($query);
            $stmt->execute([':company_id' => $companyId]);
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Get Rating Stats Error: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Check if user has already reviewed
     */
    public function hasReviewed($companyId, $userId) {
        try {
            $query = "SELECT id FROM company_reviews WHERE company_id = :company_id AND candidate_id = :candidate_id";
            $stmt = $this->db->prepare($query);
            $stmt->execute([
                ':company_id' => $companyId,
                ':candidate_id' => $userId
            ]);
            
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log('Check Review Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Delete a review
     */
    public function deleteReview($reviewId, $userId) {
        try {
            $query = "DELETE FROM company_reviews WHERE id = :id AND candidate_id = :user_id";
            $stmt = $this->db->prepare($query);
            $stmt->execute([
                ':id' => $reviewId,
                ':user_id' => $userId
            ]);
            
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log('Delete Review Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Mark review as helpful
     */
    public function markHelpful($reviewId, $isHelpful = true) {
        try {
            $field = $isHelpful ? 'helpful_count' : 'unhelpful_count';
            $query = "UPDATE company_reviews SET {$field} = {$field} + 1 WHERE id = :id";
            $stmt = $this->db->prepare($query);
            $stmt->execute([':id' => $reviewId]);
            
            return true;
        } catch (PDOException $e) {
            error_log('Mark Helpful Error: ' . $e->getMessage());
            return false;
        }
    }
}
?>
