<?php
class Application {
    private $db;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }
    
    // Lấy application theo ID
    public function getApplicationById($id) {
        $query = "SELECT a.*, j.title as job_title, u.full_name, u.email 
                  FROM applications a
                  JOIN jobs j ON a.job_id = j.id
                  JOIN users u ON a.candidate_id = u.id
                  WHERE a.id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Tạo application mới
    public function createApplication($jobId, $candidateId, $data = []) {
        try {
            $query = "INSERT INTO applications (job_id, candidate_id, status";
            $params = [':job_id' => $jobId, ':candidate_id' => $candidateId];
            
            if (!empty($data['cover_letter'])) {
                $query .= ", cover_letter";
                $params[':cover_letter'] = $data['cover_letter'];
            }
            
            $query .= ") VALUES (:job_id, :candidate_id, 'pending'";
            if (!empty($data['cover_letter'])) {
                $query .= ", :cover_letter";
            }
            $query .= ")";
            
            $stmt = $this->db->prepare($query);
            
            if ($stmt->execute($params)) {
                // Tăng application count của job
                $this->updateJobApplicationCount($jobId);
                return $this->db->lastInsertId();
            }
            return false;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    // Cập nhật application
    public function updateApplication($id, $data) {
        $allowedFields = ['status', 'notes', 'matching_score', 'ai_analysis', 'cv_file_url', 'cover_letter'];
        
        $updateFields = [];
        $params = [':id' => $id];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                if (in_array($key, ['ai_analysis'])) {
                    $value = is_array($value) ? json_encode($value, JSON_UNESCAPED_UNICODE) : $value;
                }
                $updateFields[] = "$key = :$key";
                $params[":$key"] = $value;
            }
        }
        
        if (empty($updateFields)) return false;
        
        $query = "UPDATE applications SET " . implode(', ', $updateFields) . ", updated_at = NOW() WHERE id = :id";
        $stmt = $this->db->prepare($query);
        return $stmt->execute($params);
    }
    
    // Lấy danh sách application của job
    public function getApplicationsByJob($jobId, $status = null, $limit = 20, $offset = 0) {
        $query = "SELECT a.*, u.full_name, u.email, u.phone, cp.city, cp.cv_score
                  FROM applications a
                  JOIN users u ON a.candidate_id = u.id
                  LEFT JOIN candidate_profiles cp ON u.id = cp.user_id
                  WHERE a.job_id = :job_id";
        
        if ($status) {
            $query .= " AND a.status = :status";
        }
        
        $query .= " ORDER BY a.match_score DESC, a.applied_at DESC LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':job_id', $jobId);
        if ($status) {
            $stmt->bindParam(':status', $status);
        }
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Lấy danh sách application của candidate
    public function getApplicationsByCandidate($candidateId, $limit = 20, $offset = 0) {
        $query = "SELECT a.*, j.title as job_title, rp.company_name
                  FROM applications a
                  JOIN jobs j ON a.job_id = j.id
                  JOIN users u ON j.recruiter_id = u.id
                  LEFT JOIN recruiter_profiles rp ON u.id = rp.user_id
                  WHERE a.candidate_id = :candidate_id
                  ORDER BY a.applied_at DESC LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':candidate_id', $candidateId);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Lấy danh sách application của recruiter
    public function getApplicationsByRecruiter($recruiterId, $limit = 20, $offset = 0) {
        $query = "SELECT a.*, j.title as job_title, u.full_name as candidate_name, 
                         cp.experience_years, cp.education_level
                  FROM applications a
                  JOIN jobs j ON a.job_id = j.id
                  JOIN users u ON j.recruiter_id = u.id
                  JOIN users uc ON a.candidate_id = uc.id
                  LEFT JOIN candidate_profiles cp ON uc.id = cp.user_id
                  WHERE u.id = :recruiter_id
                  ORDER BY a.applied_at DESC LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':recruiter_id', $recruiterId);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Kiểm tra xem ứng viên đã apply job chưa
    public function hasApplied($jobId, $candidateId) {
        $query = "SELECT id FROM applications WHERE job_id = :job_id AND candidate_id = :candidate_id LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':job_id', $jobId);
        $stmt->bindParam(':candidate_id', $candidateId);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC) ? true : false;
    }

    // Lấy application của ứng viên cho job cụ thể
    public function getApplicationByJobAndCandidate($jobId, $candidateId) {
        $query = "SELECT a.* FROM applications a
                  WHERE a.job_id = :job_id AND a.candidate_id = :candidate_id LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':job_id', $jobId);
        $stmt->bindParam(':candidate_id', $candidateId);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Cập nhật AI analysis score
    public function updateAIAnalysis($id, $matchingScore, $analysis) {
        $query = "UPDATE applications SET matching_score = :score, ai_analysis = :analysis, updated_at = NOW() WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':score', $matchingScore);
        $analysis_json = json_encode($analysis, JSON_UNESCAPED_UNICODE);
        $stmt->bindParam(':analysis', $analysis_json);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
    
    // Tăng application count của job
    private function updateJobApplicationCount($jobId) {
        $query = "UPDATE jobs SET applications_count = applications_count + 1 WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $jobId);
        return $stmt->execute();
    }

    // Cập nhật matching score cho application
    public function updateMatchScore($id, $matchScore, $analysis = null) {
        try {
            $query = "UPDATE applications SET matching_score = :score";
            $params = [':id' => $id, ':score' => (int)$matchScore];
            
            if ($analysis) {
                $query .= ", ai_analysis = :analysis";
                $params[':analysis'] = json_encode($analysis, JSON_UNESCAPED_UNICODE);
            }
            
            $query .= ", updated_at = NOW() WHERE id = :id";
            
            $stmt = $this->db->prepare($query);
            return $stmt->execute($params);
        } catch (Exception $e) {
            error_log("Error updating match score: " . $e->getMessage());
            return false;
        }
    }

    // Lấy applications theo matching score threshold
    public function getApplicationsByMatchScore($jobId, $minScore = 0, $limit = 20, $offset = 0) {
        try {
            $query = "SELECT a.*, u.full_name, u.email, cp.city, cp.cv_score
                      FROM applications a
                      JOIN users u ON a.candidate_id = u.id
                      LEFT JOIN candidate_profiles cp ON u.id = cp.user_id
                      WHERE a.job_id = :job_id AND a.match_score >= :min_score
                      ORDER BY a.match_score DESC
                      LIMIT :limit OFFSET :offset";
            
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':job_id', $jobId, PDO::PARAM_INT);
            $stmt->bindParam(':min_score', $minScore, PDO::PARAM_INT);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }

    // Rút đơn
    public function withdrawApplication($id) {
        try {
            // Lấy thông tin application trước khi rút
            $app = $this->getApplicationById($id);
            if (!$app) {
                return false;
            }
            
            // Cập nhật status thành withdrawn
            $query = "UPDATE applications SET status = 'withdrawn', updated_at = NOW() WHERE id = :id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id);
            
            if ($stmt->execute()) {
                // Giảm applications_count của job
                $this->decrementJobApplicationCount($app['job_id']);
                return true;
            }
            return false;
        } catch (Exception $e) {
            return false;
        }
    }
    
    // Giảm application count của job
    private function decrementJobApplicationCount($jobId) {
        $query = "UPDATE jobs SET applications_count = GREATEST(0, applications_count - 1) WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $jobId);
        return $stmt->execute();
    }
}
