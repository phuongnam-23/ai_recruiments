<?php
// utils/models/Job.php

require_once __DIR__ . '/../../config/database.php';

class Job {
    private $db;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }
    
    // --- 1. CÁC HÀM CƠ BẢN (Cho Recruiter & Public) ---

    public function getJobById($id) {
        $query = "SELECT j.*, u.full_name as recruiter_name, rp.company_name, rp.company_logo_url 
                  FROM jobs j
                  JOIN users u ON j.recruiter_id = u.id
                  LEFT JOIN recruiter_profiles rp ON u.id = rp.user_id
                  WHERE j.id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function createJob($recruiterId, $data) {
        try {
            // Chỉ liệt kê các cột chắc chắn có trong bảng jobs của bạn
            $fields = ['recruiter_id', 'title', 'description', 'requirements', 'benefits', 
                       'job_type', 'job_level', 'category', 'salary_min', 'salary_max',
                       'location', 'city', 'required_skills', 'experience_required',
                       'num_positions', 'application_deadline', 'status'];
            
            $placeholders = [];
            $params = [];
            
            $params[':recruiter_id'] = $recruiterId;

            foreach ($fields as $field) {
                if ($field === 'recruiter_id') continue;

                $placeholders[] = ':' . $field;
                $value = $data[$field] ?? null;

                // Xử lý dữ liệu đặc biệt
                if ($field === 'application_deadline' && empty($value)) {
                    $value = null;
                }
                if ($field === 'required_skills' && is_array($value)) {
                    $value = json_encode($value, JSON_UNESCAPED_UNICODE);
                }

                $params[':' . $field] = $value;
            }
            
            $columnList = implode(', ', $fields); 
            $valueList = ':recruiter_id, ' . implode(', ', $placeholders);

            $query = "INSERT INTO jobs ($columnList) VALUES ($valueList)";
            $stmt = $this->db->prepare($query);
            
            if ($stmt->execute($params)) {
                return $this->db->lastInsertId();
            }
            return false;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function updateJob($id, $data) {
        $allowedFields = ['title', 'description', 'requirements', 'benefits', 'job_type',
                         'job_level', 'category', 'salary_min', 'salary_max', 'location',
                         'city', 'required_skills', 'experience_required',
                         'num_positions', 'application_deadline', 'status', 'ai_generated_questions'];
        
        $updateFields = [];
        $params = [':id' => $id];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                if ($key === 'required_skills' && is_array($value)) {
                    $value = json_encode($value, JSON_UNESCAPED_UNICODE);
                }
                if ($key === 'ai_generated_questions' && is_array($value)) {
                    $value = json_encode($value, JSON_UNESCAPED_UNICODE);
                }
                if ($key === 'application_deadline' && empty($value)) {
                    $value = null;
                }
                $updateFields[] = "$key = :$key";
                $params[":$key"] = $value;
            }
        }
        
        if (empty($updateFields)) return false;
        
        $query = "UPDATE jobs SET " . implode(', ', $updateFields) . ", updated_at = NOW() WHERE id = :id";
        $stmt = $this->db->prepare($query);
        return $stmt->execute($params);
    }
    
    public function saveInterviewQuestions($jobId, $questions) {
        try {
            $query = "UPDATE jobs SET ai_generated_questions = :questions, updated_at = NOW() WHERE id = :id";
            $stmt = $this->db->prepare($query);
            $jsonQuestions = is_array($questions) ? json_encode($questions, JSON_UNESCAPED_UNICODE) : $questions;
            $stmt->bindParam(':questions', $jsonQuestions);
            $stmt->bindParam(':id', $jobId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log('Job::saveInterviewQuestions error: ' . $e->getMessage());
            return false;
        }
    }
    
    public function getJobsByRecruiter($recruiterId, $status = null) {
        $query = "SELECT * FROM jobs WHERE recruiter_id = :recruiter_id";
        if ($status) {
            $query .= " AND status = :status";
        }
        $query .= " ORDER BY created_at DESC";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':recruiter_id', $recruiterId);
        if ($status) {
            $stmt->bindParam(':status', $status);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getActiveJobs($limit = 20, $offset = 0) {
        $query = "SELECT j.*, rp.company_name, rp.company_logo_url
                  FROM jobs j
                  LEFT JOIN recruiter_profiles rp ON j.recruiter_id = rp.user_id
                  WHERE j.status = 'active' 
                  ORDER BY j.created_at DESC 
                  LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function searchJobs($keyword = '', $filters = [], $limit = 20, $offset = 0) {
        try {
            // Xây dựng query với phân tích toàn diện
            $query = "SELECT j.*, rp.company_name, rp.company_logo_url 
                      FROM jobs j
                      LEFT JOIN recruiter_profiles rp ON j.recruiter_id = rp.user_id
                      WHERE j.status = 'active'";
            
            $params = [];
            
            // Tìm kiếm theo từ khóa (không phân biệt hoa/thường)
            if (!empty($keyword)) {
                // Sử dụng LIKE với % wildcard cho tìm kiếm linh hoạt
                $query .= " AND (
                            j.title LIKE :keyword 
                            OR j.description LIKE :keyword 
                            OR j.requirements LIKE :keyword
                            OR rp.company_name LIKE :keyword
                        )";
                // Thêm ký tự wildcard để tìm kiếm từng phần
                $params[':keyword'] = "%$keyword%";
            }
            
            // Lọc theo danh mục
            if (!empty($filters['category'])) {
                $query .= " AND j.category = :category";
                $params[':category'] = $filters['category'];
            }
            
            // Lọc theo thành phố/địa điểm
            if (!empty($filters['city'])) {
                $query .= " AND j.city = :city";
                $params[':city'] = $filters['city'];
            }
            
            // Lọc theo loại công việc
            if (!empty($filters['job_type'])) {
                $query .= " AND j.job_type = :job_type";
                $params[':job_type'] = $filters['job_type'];
            }
            
            // Lọc theo mức lương tối thiểu
            if (!empty($filters['salary_min']) && (int)$filters['salary_min'] > 0) {
                $query .= " AND j.salary_min >= :salary_min";
                $params[':salary_min'] = (int)$filters['salary_min'];
            }
            
            // Lọc theo trình độ công việc
            if (!empty($filters['job_level'])) {
                $query .= " AND j.job_level = :job_level";
                $params[':job_level'] = $filters['job_level'];
            }
            
            // Sắp xếp theo ngày tạo mới nhất trước
            $query .= " ORDER BY j.created_at DESC LIMIT :limit OFFSET :offset";
            
            $stmt = $this->db->prepare($query);
            
            // Bind tất cả parameters
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            return [];
        } catch (PDOException $e) {
            error_log('SearchJobs Error: ' . $e->getMessage());
            return [];
        }
    }

    // --- 2. CÁC HÀM DÀNH RIÊNG CHO ADMIN (Fix lỗi 500 ở đây) ---

    // Lấy tất cả Job cho Admin
    public function getAllJobsAdmin($filters = [], $limit = 20, $offset = 0) {
        // SELECT đầy đủ thông tin để tránh lỗi Undefined index ở View
        $query = "SELECT j.*, u.full_name as recruiter_name, rp.company_name, rp.company_logo_url
                  FROM jobs j
                  JOIN users u ON j.recruiter_id = u.id
                  LEFT JOIN recruiter_profiles rp ON u.id = rp.user_id
                  WHERE 1=1";
        
        $params = [];

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $query .= " AND j.status = :status";
            $params[':status'] = $filters['status'];
        }

        if (!empty($filters['search'])) {
            $query .= " AND (j.title LIKE :search OR rp.company_name LIKE :search)";
            $params[':search'] = "%" . $filters['search'] . "%";
        }

        $query .= " ORDER BY j.created_at DESC LIMIT :limit OFFSET :offset";

        $stmt = $this->db->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Đếm tổng job cho Admin
    public function countAllJobsAdmin($filters = []) {
        $query = "SELECT COUNT(*) as total 
                  FROM jobs j
                  LEFT JOIN recruiter_profiles rp ON j.recruiter_id = rp.user_id
                  WHERE 1=1";
        
        $params = [];

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $query .= " AND j.status = :status";
            $params[':status'] = $filters['status'];
        }

        if (!empty($filters['search'])) {
            $query .= " AND (j.title LIKE :search OR rp.company_name LIKE :search)";
            $params[':search'] = "%" . $filters['search'] . "%";
        }

        $stmt = $this->db->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'] ?? 0;
    }

    // Admin cập nhật trạng thái job (Duyệt/Khóa)
    public function updateStatus($id, $status) {
        $query = "UPDATE jobs SET status = :status WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // Xóa Job
    public function deleteJob($id) {
        $query = "DELETE FROM jobs WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // Tăng lượt xem job
    public function incrementViewCount($id) {
        try {
            $query = "UPDATE jobs SET views_count = COALESCE(views_count, 0) + 1 WHERE id = :id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id);
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    // Tăng số lượng ứng tuyển
    public function incrementApplicationCount($id) {
        try {
            $query = "UPDATE jobs SET applications_count = COALESCE(applications_count, 0) + 1 WHERE id = :id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id);
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    // Lấy các job tương tự (cùng category, location, hoặc skills)
    public function getSimilarJobs($jobId, $category, $location, $skills = '', $limit = 6) {
        try {
            // Tách skills thành array
            $skillsArray = !empty($skills) ? array_map('trim', explode(',', $skills)) : [];
            
            $query = "SELECT j.*, rp.company_name, rp.company_logo_url
                      FROM jobs j
                      LEFT JOIN recruiter_profiles rp ON j.recruiter_id = rp.user_id
                      WHERE j.id != :job_id 
                      AND j.status = 'active'
                      AND (
                          j.category = :category
                          OR j.city = :city";
            
            $params = [
                ':job_id' => $jobId,
                ':category' => $category,
                ':city' => $location
            ];
            
            // Thêm điều kiện skills nếu có
            if (!empty($skillsArray)) {
                $skillConditions = [];
                foreach ($skillsArray as $index => $skill) {
                    $paramKey = ':skill' . $index;
                    $skillConditions[] = "j.required_skills LIKE $paramKey";
                    $params[$paramKey] = '%' . $skill . '%';
                }
                $query .= " OR (" . implode(' OR ', $skillConditions) . ")";
            }
            
            $query .= ")
                      ORDER BY 
                        CASE WHEN j.category = :category THEN 1 ELSE 0 END DESC,
                        CASE WHEN j.city = :city THEN 1 ELSE 0 END DESC,
                        j.created_at DESC
                      LIMIT :limit";
            
            $stmt = $this->db->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
            
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
}