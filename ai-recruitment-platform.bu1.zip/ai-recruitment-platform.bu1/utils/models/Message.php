<?php
/**
 * Message Model - Updated for Chat System
 * Quản lý tin nhắn trong conversations
 */

class Message {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    /**
     * Tạo tin nhắn mới
     */
    public function create($conversation_id, $sender_id, $message, $attachment_url = null, $attachment_name = null) {
        // Validate message không rỗng
        $message = trim($message);
        if (empty($message) && empty($attachment_url)) {
            return false;
        }
        
        $query = "INSERT INTO messages 
                  (conversation_id, sender_id, message, attachment_url, attachment_name) 
                  VALUES (?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iisss", $conversation_id, $sender_id, $message, $attachment_url, $attachment_name);
        
        if ($stmt->execute()) {
            return $stmt->insert_id;
        }
        
        return false;
    }
    
    /**
     * Lấy danh sách tin nhắn trong conversation
     */
    public function getByConversation($conversation_id, $limit = 50, $offset = 0) {
        $query = "SELECT m.*, 
                 u.full_name as sender_name, u.avatar_url as sender_avatar
                  FROM messages m
                  JOIN users u ON m.sender_id = u.id
                  WHERE m.conversation_id = ?
                  ORDER BY m.created_at DESC
                  LIMIT ? OFFSET ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iii", $conversation_id, $limit, $offset);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
        
        // Reverse để hiển thị từ cũ đến mới
        return array_reverse($messages);
    }
    
    /**
     * Lấy tin nhắn mới sau một thời điểm
     */
    public function getNewMessages($conversation_id, $after_timestamp) {
        $query = "SELECT m.*, 
                 u.full_name as sender_name, u.avatar_url as sender_avatar
                  FROM messages m
                  JOIN users u ON m.sender_id = u.id
                  WHERE m.conversation_id = ? AND m.created_at > ?
                  ORDER BY m.created_at ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("is", $conversation_id, $after_timestamp);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
        
        return $messages;
    }
    
    /**
     * Đánh dấu tin nhắn đã đọc
     */
    public function markAsRead($conversation_id, $user_id) {
        $query = "UPDATE messages 
                  SET is_read = 1
                  WHERE conversation_id = ? AND sender_id != ? AND is_read = 0";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $conversation_id, $user_id);
        
        return $stmt->execute();
    }
    
    /**
     * Xóa tin nhắn (soft delete bằng cách set message rỗng)
     */
    public function delete($message_id, $sender_id) {
        $query = "UPDATE messages 
                  SET message = '[Tin nhắn đã bị xóa]', attachment_url = NULL, attachment_name = NULL
                  WHERE id = ? AND sender_id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $message_id, $sender_id);
        
        return $stmt->execute();
    }
    
    /**
     * Đếm số tin nhắn chưa đọc trong conversation
     */
    public function countUnread($conversation_id, $user_id) {
        $query = "SELECT COUNT(*) as count 
                  FROM messages 
                  WHERE conversation_id = ? AND sender_id != ? AND is_read = 0";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $conversation_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        return (int)$row['count'];
    }
    
    /**
     * Tìm kiếm tin nhắn trong conversation
     */
    public function search($conversation_id, $keyword) {
        $keyword = '%' . $keyword . '%';
        
        $query = "SELECT m.*, 
                         u.full_name as sender_name, u.avatar as sender_avatar
                  FROM messages m
                  JOIN users u ON m.sender_id = u.id
                  WHERE m.conversation_id = ? AND m.message LIKE ?
                  ORDER BY m.created_at DESC
                  LIMIT 20";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("is", $conversation_id, $keyword);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
        
        return $messages;
    }
}
