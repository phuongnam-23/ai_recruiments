<?php
require_once __DIR__ . '/../../config/database.php';

class SavedJob {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    /**
     * Lưu công việc
     */
    public function saveJob($userId, $jobId, $notes = null) {
        try {
            $query = "INSERT INTO saved_jobs (candidate_id, job_id) VALUES (?, ?)
                      ON DUPLICATE KEY UPDATE created_at = CURRENT_TIMESTAMP";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$userId, $jobId]);
            return true;
        } catch (PDOException $e) {
            error_log("SavedJob::saveJob error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Bỏ lưu công việc
     */
    public function unsaveJob($userId, $jobId) {
        try {
            $query = "DELETE FROM saved_jobs WHERE candidate_id = ? AND job_id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$userId, $jobId]);
            return true;
        } catch (PDOException $e) {
            error_log("SavedJob::unsaveJob error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Kiểm tra công việc đã được lưu chưa
     */
    public function isSaved($userId, $jobId) {
        try {
            $query = "SELECT id FROM saved_jobs WHERE candidate_id = ? AND job_id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$userId, $jobId]);
            return $stmt->fetch(PDO::FETCH_ASSOC) !== false;
        } catch (PDOException $e) {
            error_log("SavedJob::isSaved error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Lấy danh sách công việc đã lưu của user
     */
    public function getSavedJobs($userId, $limit = 50, $offset = 0) {
        try {
            $query = "SELECT 
                        sj.id as saved_id,
                        sj.created_at as saved_at,
                        j.*,
                        rp.company_name,
                        rp.company_logo_url,
                        rp.company_address,
                        rp.company_city,
                        u.full_name as recruiter_name,
                        u.email as recruiter_email,
                        (SELECT COUNT(*) FROM applications WHERE job_id = j.id) as total_applications
                      FROM saved_jobs sj
                      INNER JOIN jobs j ON sj.job_id = j.id
                      INNER JOIN users u ON j.recruiter_id = u.id
                      LEFT JOIN recruiter_profiles rp ON u.id = rp.user_id
                      WHERE sj.candidate_id = :userId
                      ORDER BY sj.created_at DESC
                      LIMIT :limit OFFSET :offset";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(':userId', $userId, PDO::PARAM_INT);
            $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("SavedJob::getSavedJobs error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Đếm số công việc đã lưu
     */
    public function countSavedJobs($userId) {
        try {
            $query = "SELECT COUNT(*) as total FROM saved_jobs WHERE candidate_id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$userId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return (int) $result['total'];
        } catch (PDOException $e) {
            error_log("SavedJob::countSavedJobs error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Lấy danh sách job IDs đã lưu của user (để check nhanh)
     */
    public function getSavedJobIds($userId) {
        try {
            $query = "SELECT job_id FROM saved_jobs WHERE candidate_id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$userId]);
            return array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'job_id');
        } catch (PDOException $e) {
            error_log("SavedJob::getSavedJobIds error: " . $e->getMessage());
            return [];
        }
    }
}
