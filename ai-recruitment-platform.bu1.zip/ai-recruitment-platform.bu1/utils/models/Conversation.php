<?php
/**
 * Conversation Model
 * Quản lý cuộc trò chuyện giữa ứng viên và nhà tuyển dụng
 */

class Conversation {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    /**
     * Tạo hoặc lấy conversation giữa candidate và recruiter về một job
     */
    public function getOrCreate($candidate_id, $recruiter_id, $job_id, $application_id) {
        // Kiểm tra xem conversation đã tồn tại chưa
        $query = "SELECT * FROM conversations 
                  WHERE candidate_id = ? AND recruiter_id = ? AND job_id = ?
                  LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iii", $candidate_id, $recruiter_id, $job_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            return $result->fetch_assoc();
        }
        
        // Nếu chưa có thì tạo mới
        $query = "INSERT INTO conversations 
                  (candidate_id, recruiter_id, job_id, application_id, status) 
                  VALUES (?, ?, ?, ?, 'active')";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iiii", $candidate_id, $recruiter_id, $job_id, $application_id);
        
        if ($stmt->execute()) {
            $conversation_id = $stmt->insert_id;
            return $this->getById($conversation_id);
        }
        
        return null;
    }
    
    /**
     * Lấy conversation theo ID
     */
    public function getById($id) {
         $query = "SELECT c.*, 
                    u1.full_name as candidate_name, u1.avatar_url as candidate_avatar,
                    u2.full_name as recruiter_name, u2.avatar_url as recruiter_avatar,
                    j.title as job_title,
                    COALESCE(rp.company_name, 'Chưa cập nhật') as company_name
                FROM conversations c
                JOIN users u1 ON c.candidate_id = u1.id
                JOIN users u2 ON c.recruiter_id = u2.id
                JOIN jobs j ON c.job_id = j.id
                LEFT JOIN recruiter_profiles rp ON j.recruiter_id = rp.user_id
                WHERE c.id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    /**
     * Lấy danh sách conversations của user (chỉ hiển thị nếu application không withdrawn)
     */
    public function getUserConversations($user_id, $role) {
        if ($role === 'candidate') {
                 $query = "SELECT c.*, 
                         u.full_name as recruiter_name, u.avatar_url as recruiter_avatar,
                         j.title as job_title,
                         COALESCE(rp.company_name, 'Chưa cập nhật') as company_name,
                             m.message as last_message, m.created_at as last_message_time
                      FROM conversations c
                      JOIN users u ON c.recruiter_id = u.id
                     JOIN jobs j ON c.job_id = j.id
                     JOIN applications a ON c.application_id = a.id
                     LEFT JOIN recruiter_profiles rp ON j.recruiter_id = rp.user_id
                      LEFT JOIN messages m ON m.id = (
                          SELECT id FROM messages 
                          WHERE conversation_id = c.id 
                          ORDER BY created_at DESC LIMIT 1
                      )
                      WHERE c.candidate_id = ? AND c.status = 'active' AND a.status != 'withdrawn'
                      ORDER BY c.last_message_at DESC, c.created_at DESC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param("i", $user_id);
        } else {
                 $query = "SELECT c.*, 
                         u.full_name as candidate_name, u.avatar_url as candidate_avatar,
                         j.title as job_title,
                         COALESCE(rp.company_name, 'Chưa cập nhật') as company_name,
                             m.message as last_message, m.created_at as last_message_time
                      FROM conversations c
                      JOIN users u ON c.candidate_id = u.id
                     JOIN jobs j ON c.job_id = j.id
                     JOIN applications a ON c.application_id = a.id
                     LEFT JOIN recruiter_profiles rp ON j.recruiter_id = rp.user_id
                      LEFT JOIN messages m ON m.id = (
                          SELECT id FROM messages 
                          WHERE conversation_id = c.id 
                          ORDER BY created_at DESC LIMIT 1
                      )
                      WHERE c.recruiter_id = ? AND c.status = 'active' AND a.status != 'withdrawn'
                      ORDER BY c.last_message_at DESC, c.created_at DESC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param("i", $user_id);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $conversations = [];
        while ($row = $result->fetch_assoc()) {
            $conversations[] = $row;
        }
        
        return $conversations;
    }
    
    /**
     * Cập nhật thời gian tin nhắn cuối
     */
    public function updateLastMessage($conversation_id, $sender_id) {
        // Cập nhật last_message_at
        $query = "UPDATE conversations 
                  SET last_message_at = NOW()
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $conversation_id);
        $stmt->execute();
        
        // Tăng unread count cho người nhận
        $conv = $this->getById($conversation_id);
        
        if ($conv['candidate_id'] == $sender_id) {
            // Candidate gửi -> tăng recruiter unread count
            $query = "UPDATE conversations 
                      SET recruiter_unread_count = recruiter_unread_count + 1
                      WHERE id = ?";
        } else {
            // Recruiter gửi -> tăng candidate unread count
            $query = "UPDATE conversations 
                      SET candidate_unread_count = candidate_unread_count + 1
                      WHERE id = ?";
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $conversation_id);
        $stmt->execute();
    }
    
    /**
     * Reset unread count khi user mở conversation
     */
    public function markAsRead($conversation_id, $user_id, $role) {
        if ($role === 'candidate') {
            $query = "UPDATE conversations 
                      SET candidate_unread_count = 0
                      WHERE id = ? AND candidate_id = ?";
        } else {
            $query = "UPDATE conversations 
                      SET recruiter_unread_count = 0
                      WHERE id = ? AND recruiter_id = ?";
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $conversation_id, $user_id);
        $stmt->execute();
        
        // Đánh dấu tất cả messages là đã đọc
        $query = "UPDATE messages 
                  SET is_read = 1
                  WHERE conversation_id = ? AND sender_id != ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $conversation_id, $user_id);
        $stmt->execute();
    }
    
    /**
     * Kiểm tra user có quyền truy cập conversation không
     */
    public function canAccess($conversation_id, $user_id) {
        $query = "SELECT id FROM conversations 
                  WHERE id = ? AND (candidate_id = ? OR recruiter_id = ?)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iii", $conversation_id, $user_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->num_rows > 0;
    }
    
    /**
     * Lấy tổng số tin chưa đọc của user
     */
    public function getTotalUnread($user_id, $role) {
        if ($role === 'candidate') {
            $query = "SELECT SUM(candidate_unread_count) as total 
                      FROM conversations 
                      WHERE candidate_id = ? AND status = 'active'";
        } else {
            $query = "SELECT SUM(recruiter_unread_count) as total 
                      FROM conversations 
                      WHERE recruiter_id = ? AND status = 'active'";
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        return (int)($row['total'] ?? 0);
    }
}
