<?php
// utils/Helpers.php

// Định nghĩa hằng số đường dẫn upload nếu chưa có (để tránh lỗi)
if (!defined('UPLOAD_PATH')) {
    define('UPLOAD_PATH', __DIR__ . '/../uploads/');
}

// =================================================================
// 1. DATE HELPER (Xử lý ngày tháng)
// =================================================================
class DateHelper {
    public static function formatDate($date) {
        if (empty($date)) return '';
        return date('d/m/Y', strtotime($date));
    }
    
    public static function formatDateTime($date) {
        if (empty($date)) return '';
        return date('d/m/Y H:i', strtotime($date));
    }
    
    public static function timeAgo($date) {
        $now = time();
        $time = strtotime($date);
        $diff = $now - $time;
        
        if ($diff < 60) {
            return "vừa xong";
        } elseif ($diff < 3600) {
            return floor($diff / 60) . " phút trước";
        } elseif ($diff < 86400) {
            return floor($diff / 3600) . " giờ trước";
        } elseif ($diff < 2592000) {
            return floor($diff / 86400) . " ngày trước";
        } else {
            return self::formatDate($date);
        }
    }
}

// =================================================================
// 2. HELPERS (Class tiện ích chung - Giữ lại code cũ để tương thích)
// =================================================================
class Helpers {
    // Wrapper gọi sang DateHelper để không phá vỡ code cũ
    public static function formatDate($date) {
        return DateHelper::formatDate($date);
    }
    
    public static function formatDateTime($date) {
        return DateHelper::formatDateTime($date);
    }
    
    /**
     * Hàm upload file đa năng (Giữ nguyên logic cũ của Recruiter Dashboard)
     * Hỗ trợ tạo tên file unique và kiểm tra thư mục
     */
    public static function uploadFile($file, $targetDir = 'uploads/avatars/') {
        // 1. Kiểm tra lỗi upload
        if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => 'Lỗi upload file (Mã lỗi: ' . ($file['error'] ?? 'Unknown') . ')'];
        }

        // 2. Kiểm tra định dạng ảnh
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($file['type'], $allowedTypes)) {
            return ['success' => false, 'message' => 'Chỉ chấp nhận file ảnh (JPG, PNG, GIF, WEBP)'];
        }

        // 3. Kiểm tra kích thước (ví dụ: giới hạn 5MB)
        if ($file['size'] > 5 * 1024 * 1024) {
            return ['success' => false, 'message' => 'File quá lớn (Tối đa 5MB)'];
        }

        // 4. Tạo thư mục nếu chưa có
        $uploadPath = __DIR__ . '/../' . $targetDir; // Fix đường dẫn tuyệt đối
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0777, true);
        }

        // 5. Tạo tên file mới (Unique) để tránh trùng
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $newFileName = uniqid('avatar_') . '.' . $extension;
        $destination = $uploadPath . $newFileName;

        // 6. Di chuyển file
        if (move_uploaded_file($file['tmp_name'], $destination)) {
            // Trả về đường dẫn tương đối để lưu vào DB (Dùng BASE_URL nếu cần hiển thị)
            return ['success' => true, 'path' => BASE_URL . $targetDir . $newFileName];
        }

        return ['success' => false, 'message' => 'Không thể lưu file vào server.'];
    }
}

// =================================================================
// 3. FILE HANDLER (Xử lý CV & Ảnh chuyên biệt - Tích hợp mới)
// =================================================================
class FileHandler {
    const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

    public static function uploadCV($file, $userId) {
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return ['success' => false, 'message' => 'Tệp tải lên không hợp lệ'];
        }
        
        $allowedExtensions = ['pdf', 'doc', 'docx', 'txt'];
        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($fileExtension, $allowedExtensions)) {
            return ['success' => false, 'message' => 'Chỉ chấp nhận file PDF, DOC, DOCX hoặc TXT'];
        }
        
        if ($file['size'] > self::MAX_FILE_SIZE) {
            return ['success' => false, 'message' => 'Kích thước file vượt quá 5MB'];
        }
        
        // Đảm bảo thư mục tồn tại
        $targetDir = UPLOAD_PATH . 'cv/';
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $filename = 'cv_' . $userId . '_' . time() . '.' . $fileExtension;
        $uploadPath = $targetDir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            $relativePath = 'uploads/cv/' . $filename; // Đường dẫn để lưu DB
            return ['success' => true, 'message' => 'Tải lên thành công', 'filename' => $filename, 'path' => $relativePath];
        }
        
        return ['success' => false, 'message' => 'Lỗi di chuyển file'];
    }
    
    public static function uploadImage($file, $userId, $subFolder = 'images/') {
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return ['success' => false, 'message' => 'Tệp tải lên không hợp lệ'];
        }
        
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($fileExtension, $allowedExtensions)) {
            return ['success' => false, 'message' => 'Chỉ chấp nhận file ảnh (JPG, PNG, GIF, WEBP)'];
        }
        
        if ($file['size'] > 20 * 1024 * 1024) { // 20MB
            return ['success' => false, 'message' => 'Kích thước ảnh không vượt quá 20MB'];
        }
        
        $targetDir = UPLOAD_PATH . $subFolder;
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $filename = 'img_' . $userId . '_' . time() . '.' . $fileExtension;
        $uploadPath = $targetDir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            return ['success' => true, 'message' => 'Tải lên thành công', 'filename' => $filename, 'path' => 'uploads/' . $subFolder . $filename];
        }
        
        return ['success' => false, 'message' => 'Lỗi tải lên tệp'];
    }
    
    public static function deleteFile($filePath) {
        // Xử lý đường dẫn tương đối thành tuyệt đối nếu cần
        $realPath = __DIR__ . '/../../' . $filePath;
        if (file_exists($realPath)) {
            return unlink($realPath);
        }
        return false;
    }
}

// =================================================================
// 4. EMAIL HELPER (Gửi mail thông báo)
// =================================================================
class EmailHelper {
    public static function sendWelcomeEmail($email, $fullName) {
        $subject = "Chào mừng bạn đến AI Recruitment Platform";
        $message = "
            <html>
            <body>
                <h2>Chào mừng $fullName!</h2>
                <p>Cảm ơn bạn đã đăng ký tài khoản trên AI Recruitment Platform.</p>
                <p>Chúc bạn sớm tìm được công việc ưng ý!</p>
            </body>
            </html>
        ";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
        $headers .= "From: no-reply@airecruitment.com" . "\r\n";
        
        // Lưu ý: Hàm mail() cần cấu hình SMTP server (như Sendmail hoặc Postfix) mới chạy được trên localhost
        return @mail($email, $subject, $message, $headers);
    }
    
    public static function sendApplicationNotification($recruiterEmail, $recruiterName, $jobTitle, $candidateName) {
        $subject = "Ứng viên mới apply cho vị trí: " . $jobTitle;
        $message = "
            <html>
            <body>
                <h2>Chào $recruiterName,</h2>
                <p>Bạn có 1 ứng viên mới:</p>
                <p><strong>$candidateName</strong> vừa apply cho vị trí <strong>$jobTitle</strong></p>
                <p>Vui lòng đăng nhập vào hệ thống để xem chi tiết.</p>
            </body>
            </html>
        ";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
        $headers .= "From: no-reply@airecruitment.com" . "\r\n";
        
        return @mail($recruiterEmail, $subject, $message, $headers);
    }
}

// =================================================================
// 5. VALIDATOR (Kiểm tra dữ liệu)
// =================================================================
class Validator {
    public static function isValidEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    public static function isValidPhone($phone) {
        return preg_match('/^0\d{9,10}$/', $phone);
    }
    
    public static function isValidDate($date) {
        return strtotime($date) !== false;
    }
    
    public static function isValidURL($url) {
        return filter_var($url, FILTER_VALIDATE_URL) !== false;
    }
}

// =================================================================
// 6. NUMBER FORMATTER (Định dạng số tiền)
// =================================================================
class NumberFormatter {
    public static function formatCurrency($number) {
        return number_format($number, 0, ',', '.') . ' VND';
    }
    
    public static function formatNumber($number) {
        return number_format($number, 0, ',', '.');
    }
}

// =================================================================
// 7. PAGINATION (Phân trang)
// =================================================================
class Pagination {
    private $totalRecords;
    private $recordsPerPage;
    private $currentPage;
    
    public function __construct($totalRecords, $recordsPerPage = 20, $currentPage = 1) {
        $this->totalRecords = $totalRecords;
        $this->recordsPerPage = $recordsPerPage;
        $this->currentPage = max(1, $currentPage);
    }
    
    public function getTotalPages() {
        return ceil($this->totalRecords / $this->recordsPerPage);
    }
    
    public function getOffset() {
        return ($this->currentPage - 1) * $this->recordsPerPage;
    }
    
    public function getCurrentPage() {
        return $this->currentPage;
    }
    
    public function getLimit() {
        return $this->recordsPerPage;
    }
    
    public function getPaginationHTML($baseUrl) {
        $totalPages = $this->getTotalPages();
        if ($totalPages <= 1) return ''; // Không cần phân trang nếu chỉ có 1 trang

        $html = '<nav class="flex justify-center gap-2 mt-6">';
        
        // Nút Trước
        if ($this->currentPage > 1) {
            $html .= '<a href="' . $baseUrl . '&page=1" class="px-3 py-2 border rounded bg-white hover:bg-gray-100 text-sm">« Đầu</a>';
            $html .= '<a href="' . $baseUrl . '&page=' . ($this->currentPage - 1) . '" class="px-3 py-2 border rounded bg-white hover:bg-gray-100 text-sm">‹ Trước</a>';
        }
        
        // Các trang số
        $start = max(1, $this->currentPage - 2);
        $end = min($totalPages, $this->currentPage + 2);
        
        for ($i = $start; $i <= $end; $i++) {
            if ($i === $this->currentPage) {
                $html .= '<span class="px-3 py-2 bg-blue-600 text-white rounded text-sm font-bold">' . $i . '</span>';
            } else {
                $html .= '<a href="' . $baseUrl . '&page=' . $i . '" class="px-3 py-2 border rounded bg-white hover:bg-gray-100 text-sm">' . $i . '</a>';
            }
        }
        
        // Nút Sau
        if ($this->currentPage < $totalPages) {
            $html .= '<a href="' . $baseUrl . '&page=' . ($this->currentPage + 1) . '" class="px-3 py-2 border rounded bg-white hover:bg-gray-100 text-sm">Sau ›</a>';
            $html .= '<a href="' . $baseUrl . '&page=' . $totalPages . '" class="px-3 py-2 border rounded bg-white hover:bg-gray-100 text-sm">Cuối »</a>';
        }
        
        $html .= '</nav>';
        return $html;
    }
}
?>