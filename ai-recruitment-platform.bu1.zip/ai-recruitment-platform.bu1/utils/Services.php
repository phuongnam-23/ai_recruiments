<?php
require_once 'config/init.php';

// Một số hàm tiện ích bổ sung cho Helpers.php

class AIService {
    private $apiUrl;
    private $apiKey;
    
    public function __construct() {
        $this->apiUrl = AI_SERVICE_URL;
        $this->apiKey = AI_SERVICE_KEY ?? '';
    }
    
    /**
     * Phân tích CV
     */
    public function analyzeCV($filePath) {
        $data = [
            'file' => curl_file_create($filePath),
            'api_key' => $this->apiKey
        ];
        
        return $this->makeRequest('POST', 'analyze-cv', $data, true);
    }
    
    /**
     * Tính điểm matching giữa ứng viên và vị trí
     */
    public function calculateMatchingScore($candidateProfile, $jobRequirements) {
        $data = [
            'candidate' => $candidateProfile,
            'job' => $jobRequirements,
            'api_key' => $this->apiKey
        ];
        
        return $this->makeRequest('POST', 'match-score', $data);
    }
    
    /**
     * Tạo câu hỏi phỏng vấn
     */
    public function generateInterviewQuestions($jobDescription, $count = 5) {
        $data = [
            'job_description' => $jobDescription,
            'count' => $count,
            'api_key' => $this->apiKey
        ];
        
        return $this->makeRequest('POST', 'generate-questions', $data);
    }
    
    /**
     * Gợi ý công việc cho ứng viên
     */
    public function recommendJobs($candidateProfile, $limit = 5) {
        $data = [
            'candidate' => $candidateProfile,
            'limit' => $limit,
            'api_key' => $this->apiKey
        ];
        
        return $this->makeRequest('POST', 'recommend-jobs', $data);
    }
    
    /**
     * Gợi ý ứng viên cho công việc
     */
    public function recommendCandidates($jobDescription, $limit = 10) {
        $data = [
            'job' => $jobDescription,
            'limit' => $limit,
            'api_key' => $this->apiKey
        ];
        
        return $this->makeRequest('POST', 'recommend-candidates', $data);
    }
    
    /**
     * Tạo tóm tắt CV
     */
    public function summarizeCV($cvText) {
        $data = [
            'cv_text' => $cvText,
            'api_key' => $this->apiKey
        ];
        
        return $this->makeRequest('POST', 'summarize-cv', $data);
    }
    
    /**
     * Phát hiện kỹ năng từ CV
     */
    public function extractSkills($cvText) {
        $data = [
            'cv_text' => $cvText,
            'api_key' => $this->apiKey
        ];
        
        return $this->makeRequest('POST', 'extract-skills', $data);
    }
    
    /**
     * Gọi API request
     */
    private function makeRequest($method, $endpoint, $data, $isFile = false) {
        $url = $this->apiUrl . $endpoint;
        $ch = curl_init($url);
        
        curl_setopt($ch, CURLOPT_TIMEOUT, AI_SERVICE_TIMEOUT ?? 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($isFile) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            } else {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            }
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            return json_decode($response, true);
        }
        
        return ['success' => false, 'message' => 'API Error: ' . $httpCode];
    }
}

class ReportService {
    private $db;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }
    
    /**
     * Tạo báo cáo
     */
    public function createReport($reporterId, $reportedType, $reportedId, $reason, $description) {
        try {
            $query = "INSERT INTO reports (reporter_id, reported_type, reported_id, reason, description, status) 
                      VALUES (:reporter_id, :reported_type, :reported_id, :reason, :description, 'pending')";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':reporter_id', $reporterId);
            $stmt->bindParam(':reported_type', $reportedType);
            $stmt->bindParam(':reported_id', $reportedId);
            $stmt->bindParam(':reason', $reason);
            $stmt->bindParam(':description', $description);
            
            return $stmt->execute() ? $this->db->lastInsertId() : false;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    /**
     * Lấy báo cáo chưa xử lý
     */
    public function getPendingReports($limit = 20, $offset = 0) {
        $query = "SELECT * FROM reports WHERE status = 'pending' 
                  ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

class AnalyticsService {
    private $db;
    
    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }
    
    /**
     * Lấy thống kê hệ thống
     */
    public function getSystemStats() {
        $query = "SELECT 
                    (SELECT COUNT(*) FROM users WHERE role='candidate' AND status='active') as total_candidates,
                    (SELECT COUNT(*) FROM users WHERE role='recruiter' AND status='active') as total_recruiters,
                    (SELECT COUNT(*) FROM jobs WHERE status='active') as active_jobs,
                    (SELECT COUNT(*) FROM applications WHERE DATE(applied_at) = CURDATE()) as today_applications,
                    (SELECT AVG(matching_score) FROM applications WHERE matching_score > 0) as avg_matching_score";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Lấy thống kê theo recruiter
     */
    public function getRecruiterStats($recruiterId) {
        $query = "SELECT 
                    COUNT(DISTINCT id) as total_jobs,
                    SUM(views_count) as total_views,
                    SUM(applications_count) as total_applications,
                    (SELECT COUNT(*) FROM applications a 
                     JOIN jobs j ON a.job_id = j.id 
                     WHERE j.recruiter_id = :recruiter_id AND DATE(a.applied_at) = CURDATE()) as today_applications
                  FROM jobs WHERE recruiter_id = :recruiter_id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':recruiter_id', $recruiterId);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

class ExportService {
    /**
     * Export danh sách ứng viên thành CSV
     */
    public static function exportCandidatesToCSV($candidates, $filename = 'candidates.csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Tên', 'Email', 'Thành phố', 'Kinh nghiệm', 'CV Score']);
        
        foreach ($candidates as $candidate) {
            fputcsv($output, [
                $candidate['id'],
                $candidate['full_name'],
                $candidate['email'],
                $candidate['city'],
                $candidate['experience_years'],
                $candidate['cv_score']
            ]);
        }
        
        fclose($output);
        exit;
    }
    
    /**
     * Export danh sách công việc thành CSV
     */
    public static function exportJobsToCSV($jobs, $filename = 'jobs.csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Tiêu đề', 'Công ty', 'Thành phố', 'Lương', 'Views', 'Đơn apply', 'Trạng thái']);
        
        foreach ($jobs as $job) {
            fputcsv($output, [
                $job['id'],
                $job['title'],
                $job['recruiter_name'],
                $job['city'],
                $job['salary_min'] . ' - ' . $job['salary_max'],
                $job['views_count'],
                $job['applications_count'],
                $job['status']
            ]);
        }
        
        fclose($output);
        exit;
    }
}