<?php
// Auth Middleware
function requireRole($role) {
    if (!isLoggedIn()) {
        redirect('login.php');
    }
    
    if ($_SESSION['role'] !== $role) {
        header("HTTP/1.0 403 Forbidden");
        echo "403 - Forbidden Access";
        exit();
    }
}

function requireRoles($roles = []) {
    if (!isLoggedIn()) {
        redirect('login.php');
    }
    
    if (!in_array($_SESSION['role'], $roles)) {
        header("HTTP/1.0 403 Forbidden");
        echo "403 - Forbidden Access";
        exit();
    }
}

// CSRF Protection
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Rate limiting
$rateLimit = [];

function checkRateLimit($key, $maxAttempts = 5, $timeWindow = 300) {
    global $rateLimit;
    
    $now = time();
    if (!isset($rateLimit[$key])) {
        $rateLimit[$key] = [];
    }
    
    // Xóa attempts cũ
    $rateLimit[$key] = array_filter($rateLimit[$key], function($time) use ($now, $timeWindow) {
        return $time > ($now - $timeWindow);
    });
    
    if (count($rateLimit[$key]) >= $maxAttempts) {
        return false;
    }
    
    $rateLimit[$key][] = $now;
    return true;
}

// Security headers
function addSecurityHeaders() {
    // Prevent MIME type sniffing
    header("X-Content-Type-Options: nosniff");
    
    // Clickjacking protection
    header("X-Frame-Options: SAMEORIGIN");
    
    // XSS Protection
    header("X-XSS-Protection: 1; mode=block");
    
    // HSTS (HTTP Strict Transport Security)
    header("Strict-Transport-Security: max-age=31536000; includeSubDomains");
    
    // Content Security Policy with whitelisted CDNs
    $csp = "Content-Security-Policy: " .
           "default-src 'self'; " .
           "script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://cdn.jsdelivr.net https://unpkg.com; " .
           "style-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://cdnjs.cloudflare.com https://fonts.googleapis.com; " .
           "font-src 'self' https://cdnjs.cloudflare.com https://fonts.gstatic.com; " .
           "img-src 'self' data: https: http:; " .
           "connect-src 'self' https: http:; " .
           "frame-ancestors 'self'; " .
           "upgrade-insecure-requests";
    
    header($csp);
}

// Request logging
function logRequest($action, $details = []) {
    try {
        $database = new Database();
        $db = $database->getConnection();
        
        $query = "INSERT INTO system_logs (user_id, action, table_name, record_id, ip_address, user_agent) 
                  VALUES (:user_id, :action, :table_name, :record_id, :ip_address, :user_agent)";
        
        $stmt = $db->prepare($query);
        
        $user_id = $_SESSION['user_id'] ?? null;
        $table_name = $details['table_name'] ?? null;
        $record_id = $details['record_id'] ?? null;
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? '';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':action', $action);
        $stmt->bindParam(':table_name', $table_name);
        $stmt->bindParam(':record_id', $record_id);
        $stmt->bindParam(':ip_address', $ip_address);
        $stmt->bindParam(':user_agent', $user_agent);
        
        $stmt->execute();
    } catch (Exception $e) {
        // Không log nếu có lỗi
    }
}
