<?php
require_once 'config/init.php';
require_once 'utils/middleware/Auth.php';

addSecurityHeaders();

if (isLoggedIn()) {
    switch ($_SESSION['role']) {
        case 'admin':
            redirect('views/admin/dashboard.php');
            break;
        case 'recruiter':
            redirect('views/recruiter/dashboard.php');
            break;
        case 'candidate':
            redirect('views/candidate/dashboard.php');
            break;
    }
}

$authController = new AuthController();
$result = $authController->login();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập - AI Recruitment</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900">
    <div class="min-h-screen flex items-center justify-center p-4">
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border-2 border-slate-200 dark:border-slate-700 p-8 w-full max-w-md">
            <div class="text-center mb-8">
                <h1 class="text-4xl font-extrabold text-blue-600 dark:text-blue-400">AI Recruitment</h1>
                <p class="text-slate-600 dark:text-slate-300 mt-2 font-medium">Nền tảng tuyển dụng thông minh</p>
            </div>

            <?php if ($result && !$result['success']): ?>
                <div class="bg-red-100 dark:bg-red-900/40 border-2 border-red-400 dark:border-red-700 text-red-800 dark:text-red-300 px-4 py-3 rounded-lg mb-4 font-bold">
                    <?php echo htmlspecialchars($result['message']); ?>
                </div>
            <?php elseif ($result && $result['success']): ?>
                <div class="bg-green-100 dark:bg-green-900/40 border-2 border-green-400 dark:border-green-700 text-green-800 dark:text-green-300 px-4 py-3 rounded-lg mb-4 font-bold">
                    <?php echo htmlspecialchars($result['message']); ?>
                </div>
                <meta http-equiv="refresh" content="1; url=index.php">
            <?php endif; ?>

            <form method="POST" class="space-y-4">
                <div>
                    <label class="block text-slate-900 dark:text-white font-bold mb-2">Email</label>
                    <input type="email" name="email" required class="w-full border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2.5 focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 font-medium">
                </div>

                <div>
                    <label class="block text-slate-900 dark:text-white font-bold mb-2">Mật khẩu</label>
                    <input type="password" name="password" required class="w-full border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2.5 focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 font-medium">
                </div>

                <button type="submit" class="w-full bg-blue-600 dark:bg-blue-500 text-white font-bold py-3 rounded-lg hover:bg-blue-700 dark:hover:bg-blue-600 transition shadow-lg shadow-blue-500/30">
                    Đăng nhập
                </button>
            </form>

            <div class="mt-6 text-center">
                <p class="text-slate-600 dark:text-slate-300 font-medium">Bạn chưa có tài khoản?</p>
                <a href="register.php" class="text-blue-600 dark:text-blue-400 font-bold hover:underline">Đăng ký ngay →</a>
            </div>

            <div class="mt-4 text-center text-xs text-slate-500 dark:text-slate-400 font-medium">
                <p>Tài khoản test:</p>
                <p>Email: admin@airecruitment.com | Mật khẩu: admin123</p>
                <p>Email: recruiter@test.com | Mật khẩu: 123456</p>
                <p>Email: candidate@test.com | Mật khẩu: 123456</p>
            </div>
        </div>
    </div>
</body>
</html>
