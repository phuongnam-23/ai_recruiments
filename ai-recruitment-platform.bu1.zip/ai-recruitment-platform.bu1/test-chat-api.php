<?php
// Test chat API - Simple version
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Testing chat API...\n\n";

// Simulate logged in user
$_SESSION['user_id'] = 3; // Change to your recruiter ID
$_SESSION['role'] = 'recruiter';

// Read API response
$url = 'http://localhost/ai-recruitment-platform/api.php?action=start-conversation';
$data = json_encode(['application_id' => 1]); // Change to valid application ID

echo "URL: $url\n";
echo "Data: $data\n\n";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "HTTP Code: $httpCode\n";
if ($error) {
    echo "CURL Error: $error\n";
}
echo "Response:\n$response\n";

