<?php
require_once 'config.php';
require_once 'database.php';

// Session handling - start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

spl_autoload_register(function ($class_name) {
    $base_path = __DIR__ . '/..';
    $directories = [
        $base_path . '/utils/models/',
        $base_path . '/utils/controllers/',
        $base_path . '/utils/',
        $base_path . '/models/',
        $base_path . '/controllers/'
    ];
    foreach ($directories as $directory) {
        $file = $directory . $class_name . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

function redirect($url) {
    header("Location: " . BASE_URL . $url);
    exit();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        redirect('login.php');
    }
}

function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function generateToken() {
    return bin2hex(random_bytes(32));
}

// Initialize CSRF token
if (session_status() === PHP_SESSION_ACTIVE && !isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = generateToken();
}