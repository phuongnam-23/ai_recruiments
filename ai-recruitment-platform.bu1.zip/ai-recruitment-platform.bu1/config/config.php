<?php
define('BASE_URL', 'http://localhost/ai-recruitment-platform/');
define('UPLOAD_PATH', $_SERVER['DOCUMENT_ROOT'] . '/ai-recruitment-platform/uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024);

date_default_timezone_set('Asia/Ho_Chi_Minh');
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

define('AI_SERVICE_URL', 'http://localhost:8000/api/');

// Gemini AI API Key - Set from environment variable or here
define('GEMINI_API_KEY', getenv('GEMINI_API_KEY') ?: '');