<?php
require_once 'config/init.php';
require_once 'utils/middleware/Auth.php';

if (isLoggedIn()) {
    require_once 'utils/middleware/Auth.php';
    logRequest('user_logout', ['table_name' => 'users', 'record_id' => $_SESSION['user_id']]);
}

session_destroy();
redirect('login.php');
?>
