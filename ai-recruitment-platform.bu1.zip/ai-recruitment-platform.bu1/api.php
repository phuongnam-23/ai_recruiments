<?php
/**
 * API ENDPOINT - FULL VERSION
 * File: api.php (Nằm ở thư mục gốc dự án)
 */

// Log the very beginning
error_log('🚀 API ENDPOINT STARTED');

// Start output buffering FIRST to prevent any output before JSON
ob_start();

// Set JSON header
header('Content-Type: application/json; charset=utf-8');

// Tắt hiển thị lỗi HTML để tránh làm hỏng JSON response
ini_set('display_errors', 0);
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');

// Log API request to file for debugging
$debug_log = __DIR__ . '/api_debug.log';
$debug_msg = '[' . date('Y-m-d H:i:s') . '] ' . $_SERVER['REQUEST_METHOD'] . ' action=' . ($_GET['action'] ?? $_POST['action'] ?? 'NONE') . "\n";
file_put_contents($debug_log, $debug_msg, FILE_APPEND);

// Set up error handler to catch all errors
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    global $debug_log;
    file_put_contents($debug_log, "PHP Error [$errno]: $errstr in $errfile:$errline\n", FILE_APPEND);
    return false;
});

// Set up shutdown handler to catch fatal errors
register_shutdown_function(function() {
    global $debug_log;
    $error = error_get_last();
    if ($error !== null) {
        file_put_contents($debug_log, "Fatal error: " . $error['message'] . " in " . $error['file'] . ":" . $error['line'] . "\n", FILE_APPEND);
    }
});

try {
    file_put_contents($debug_log, "About to load config/init.php\n", FILE_APPEND);
    require_once 'config/init.php';
    file_put_contents($debug_log, "Loaded config/init.php\n", FILE_APPEND);
    
    require_once 'utils/middleware/Auth.php';
    file_put_contents($debug_log, "Loaded utils/middleware/Auth.php\n", FILE_APPEND);
    
    require_once 'utils/Helpers.php';
    file_put_contents($debug_log, "Loaded utils/Helpers.php\n", FILE_APPEND);
    
    file_put_contents($debug_log, "Config loaded OK\n", FILE_APPEND);
} catch (Exception $e) {
    file_put_contents($debug_log, "Config error: " . $e->getMessage() . "\n", FILE_APPEND);
    ob_clean();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Config error: ' . $e->getMessage()]);
    ob_end_flush();
    exit;
} catch (Throwable $t) {
    file_put_contents($debug_log, "Config Throwable: " . $t->getMessage() . " at " . $t->getFile() . ":" . $t->getLine() . "\n", FILE_APPEND);
    ob_clean();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Config error: ' . $t->getMessage()]);
    ob_end_flush();
    exit;
}

file_put_contents($debug_log, "Models loading...\n", FILE_APPEND);
// Load Models
require_once 'utils/models/User.php';
require_once 'utils/models/RecruiterProfile.php';
require_once 'utils/models/Application.php';
require_once 'utils/models/Job.php';
require_once 'utils/models/CandidateProfile.php';
require_once 'utils/models/Message.php';
require_once 'utils/models/Notification.php';
require_once 'utils/models/Conversation.php';

// Load Controllers (Mới thêm)
require_once 'utils/controllers/UserController.php'; 
require_once 'utils/controllers/RecruiterController.php';
require_once 'utils/controllers/CandidateController.php';
require_once 'utils/controllers/MessageController.php';
// require_once 'utils/controllers/JobController.php'; // Bỏ comment nếu bạn đã chuyển hết logic job sang controller
// require_once 'utils/controllers/ApplicationController.php'; // Tương tự cho App

// [QUAN TRỌNG] Nhận action từ cả GET và POST
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

file_put_contents($debug_log, "Action received: '$action', Method: $method\n", FILE_APPEND);

// Disable CSRF check cho API endpoints nhất định
$publicEndpoints = ['login', 'register', 'search-jobs', 'parse-cv', 'match-job', 'apply-job', 'submit-report', 'admin-delete-file', 'add-company-review'];

// Chat endpoints không cần CSRF vì dùng JSON và kiểm tra session
$chatEndpoints = ['start-conversation', 'get-conversations', 'get-conversation', 'send-message', 'poll-messages', 'mark-conversation-read', 'get-unread-count', 'upload-chat-attachment', 'chat-bot'];

// Kiểm tra CSRF Token
if (!in_array($action, $publicEndpoints) && !in_array($action, $chatEndpoints)) {
    $token = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
    // Lưu ý: Nếu function verifyCSRFToken chưa được define trong Auth.php thì comment dòng dưới lại
    if (function_exists('verifyCSRFToken') && !verifyCSRFToken($token)) {
        http_response_code(403);
        die(json_encode(['success' => false, 'message' => 'CSRF token không hợp lệ hoặc đã hết hạn']));
    }
}

file_put_contents($debug_log, "Entering switch statement with action: '$action'\n", FILE_APPEND);

try {
    switch ($action) {
        // --- [MỚI] Dùng chung cho Admin, Candidate, Recruiter ---
        // Cập nhật Avatar, Tên, SĐT...
        case 'update-profile': 
            $controller = new UserController();
            $response = $controller->updateProfile();
            echo json_encode($response);
            break;

        // Cập nhật profile Recruiter (Công ty + Thông tin liên hệ)
        case 'update-recruiter-profile':
            requireRole('recruiter');
            $controller = new RecruiterController();
            $response = $controller->updateProfile();
            echo json_encode($response);
            break;

        // Cập nhật profile Candidate (Bio, Skills, Experience, etc)
        case 'update-candidate-profile':
            // Set response headers and default HTTP code
            http_response_code(200);
            header('Content-Type: application/json; charset=utf-8');
            
            try {
                requireRole('candidate');
                
                if (session_status() === PHP_SESSION_NONE) session_start();
                if (!isset($_SESSION['user_id'])) {
                    http_response_code(401);
                    echo json_encode(['success' => false, 'message' => 'Bạn chưa đăng nhập']);
                    break;
                }

                $userId = $_SESSION['user_id'];
                
                // Log request details for debugging
                error_log('=== API: update-candidate-profile ===');
                error_log('User ID: ' . $userId);
                error_log('POST Keys: ' . json_encode(array_keys($_POST)));
                
                // Lấy tất cả dữ liệu từ POST với xử lý đặc biệt
                $data = [
                    'bio' => isset($_POST['bio']) ? trim($_POST['bio']) : '',
                    'date_of_birth' => !empty($_POST['date_of_birth']) ? trim($_POST['date_of_birth']) : null,
                    'gender' => isset($_POST['gender']) ? trim($_POST['gender']) : '',
                    'city' => isset($_POST['city']) ? trim($_POST['city']) : '',
                    'address' => isset($_POST['address']) ? trim($_POST['address']) : '',
                    'experience_years' => !empty($_POST['experience_years']) ? (int)$_POST['experience_years'] : 0,
                    'education_level' => isset($_POST['education_level']) ? trim($_POST['education_level']) : '',
                    'skills' => isset($_POST['skills']) ? trim($_POST['skills']) : ''
                ];

                // Log extracted data
                error_log('Extracted Data: ' . json_encode($data));

                // Kiểm tra dữ liệu
                if (empty($data['bio']) && empty($data['skills'])) {
                    echo json_encode(['success' => false, 'message' => 'Vui lòng cung cấp ít nhất bio hoặc kỹ năng']);
                    break;
                }

                // Gọi Model
                $candidateModel = new CandidateProfile();
                $result = $candidateModel->updateProfile($userId, $data);

                if ($result === false) {
                    error_log('Profile update failed for user ' . $userId);
                    echo json_encode(['success' => false, 'message' => 'Lỗi cập nhật hồ sơ. Vui lòng kiểm tra dữ liệu.']);
                } else {
                    error_log('Profile update successful for user ' . $userId);
                    echo json_encode([
                        'success' => true,
                        'message' => 'Cập nhật thông tin thành công!',
                        'data' => $data
                    ]);
                }

            } catch (Exception $e) {
                error_log('Exception in update-candidate-profile: ' . $e->getMessage());
                error_log('Trace: ' . $e->getTraceAsString());
                
                echo json_encode([
                    'success' => false,
                    'message' => 'Lỗi hệ thống: ' . $e->getMessage()
                ]);
            }
            break;

        case 'chat-bot':
            if (!isLoggedIn()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Bạn cần đăng nhập để sử dụng AI Advisor']);
                break;
            }

            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }

            $message = trim($_POST['message'] ?? '');
            if ($message === '') {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Vui lòng nhập nội dung tin nhắn']);
                break;
            }

            try {
                $userId = $_SESSION['user_id'];
                $userModel = new User();
                $user = $userModel->getUserById($userId) ?: [];

                $skills = [];
                $experienceYears = null;
                $city = null;

                if (($_SESSION['role'] ?? '') === 'candidate') {
                    $candidateModel = new CandidateProfile();
                    $profile = $candidateModel->getProfile($userId) ?: [];
                    $experienceYears = $profile['experience_years'] ?? null;
                    $city = $profile['city'] ?? null;

                    if (!empty($profile['skills'])) {
                        if (is_array($profile['skills'])) {
                            $skills = $profile['skills'];
                        } else {
                            // Decode JSON recursively until we get an array
                            $decoded = $profile['skills'];
                            $maxAttempts = 10; // Prevent infinite loop
                            $attempts = 0;
                            
                            while (is_string($decoded) && $attempts < $maxAttempts) {
                                $temp = json_decode($decoded, true);
                                if (json_last_error() === JSON_ERROR_NONE) {
                                    $decoded = $temp;
                                    $attempts++;
                                } else {
                                    break;
                                }
                            }
                            
                            if (is_array($decoded)) {
                                // Flatten array if needed
                                $skills = is_array(reset($decoded)) ? array_merge(...$decoded) : $decoded;
                                // Remove duplicates and clean up
                                $skills = array_unique(array_filter(array_map('trim', $skills)));
                            } else {
                                // Fallback: split by comma
                                $skills = array_filter(array_map('trim', explode(',', (string)$profile['skills'])));
                            }
                        }
                    }
                }

                $userContext = [
                    'id' => $userId,
                    'name' => $user['full_name'] ?? ($_SESSION['full_name'] ?? 'Ứng viên'),
                    'role' => $_SESSION['role'] ?? 'guest',
                    'skills' => array_values($skills),
                    'experience_years' => $experienceYears,
                    'city' => $city,
                ];

                $scriptPath = __DIR__ . '/utils/AI/chatbot.py';
                if (!file_exists($scriptPath)) {
                    throw new Exception('Chatbot engine not found');
                }

                $pythonBinary = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN' ? 'python' : 'python3';
                $encodedMessage = base64_encode($message);
                $encodedContext = base64_encode(json_encode($userContext, JSON_UNESCAPED_UNICODE));
                $command = escapeshellcmd($pythonBinary) . ' ' .
                    escapeshellarg($scriptPath) . ' ' .
                    escapeshellarg($encodedMessage) . ' ' .
                    escapeshellarg($encodedContext) . ' 2>&1';

                $rawOutput = shell_exec($command);
                if ($rawOutput === null) {
                    throw new Exception('Chatbot engine did not respond');
                }

                // Debug: log raw output
                error_log('Chatbot raw output: ' . substr($rawOutput, 0, 500));

                $aiResponse = json_decode(trim($rawOutput), true);
                if (!$aiResponse || empty($aiResponse['success'])) {
                    error_log('Chatbot JSON decode failed. Raw: ' . substr($rawOutput, 0, 200));
                    throw new Exception($aiResponse['error'] ?? 'Invalid AI response');
                }

                $reply = trim($aiResponse['reply'] ?? '');
                if ($reply === '') {
                    throw new Exception('AI reply is empty');
                }

                if (!empty($aiResponse['warning'])) {
                    $visibleKeys = getenv('GEMINI_API_KEYS') ?: getenv('GEMINI_API_KEY') ?: getenv('GEMINI_KEY') ?: '';
                    $keyInfo = $visibleKeys === '' ? 'none' : ('len=' . strlen($visibleKeys));
                    error_log('Chatbot warning: ' . $aiResponse['warning'] . ' | envKeys=' . $keyInfo);
                }

                $database = new Database();
                $db = $database->getConnection();
                $stmt = $db->prepare('INSERT INTO chatbot_conversations (user_id, session_id, message, response, context, created_at) VALUES (:uid, :sid, :message, :reply, :context, NOW())');
                $stmt->execute([
                    ':uid' => $userId,
                    ':sid' => session_id(),
                    ':message' => $message,
                    ':reply' => $reply,
                    ':context' => json_encode($userContext, JSON_UNESCAPED_UNICODE),
                ]);

                echo json_encode(['success' => true, 'reply' => $reply], JSON_UNESCAPED_UNICODE);
            } catch (Exception $e) {
                error_log('Chatbot API error: ' . $e->getMessage());
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Không thể xử lý yêu cầu AI: ' . $e->getMessage()]);
            }
            break;

        // Auth endpoints
        case 'login':
            // Giả sử bạn có AuthController, nếu chưa thì viết logic inline hoặc tạo controller
            // Ở đây giữ nguyên logic cũ nếu bạn đã có AuthController
            if (class_exists('AuthController')) {
                $authController = new AuthController();
                $result = $authController->login();
                echo json_encode($result);
            } else {
                // Fallback nếu chưa có controller (Logic đăng nhập cơ bản)
                // ... (Bạn có thể thêm logic đăng nhập vào đây nếu cần)
                echo json_encode(['success' => false, 'message' => 'AuthController chưa được khởi tạo']);
            }
            break;

        case 'logout':
            requireLogin();
            session_destroy();
            echo json_encode(['success' => true, 'message' => 'Đã đăng xuất']);
            break;

        case 'generate-interview-questions':
            requireRole('recruiter');
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }

            $jobId = (int)($_POST['job_id'] ?? 0);
            if (!$jobId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Job ID không hợp lệ']);
                break;
            }

            try {
                $jobModel = new Job();
                $job = $jobModel->getJobById($jobId);
                
                if (!$job) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'message' => 'Không tìm thấy công việc']);
                    break;
                }

                if ($job['recruiter_id'] != $_SESSION['user_id']) {
                    http_response_code(403);
                    echo json_encode(['success' => false, 'message' => 'Bạn không có quyền thao tác công việc này']);
                    break;
                }

                $jobData = [
                    'title' => $job['title'],
                    'description' => $job['description'],
                    'requirements' => $job['requirements'],
                    'required_skills' => $job['required_skills'],
                ];

                $scriptPath = __DIR__ . '/utils/AI/interview_generator.py';
                if (!file_exists($scriptPath)) {
                    throw new Exception('Interview generator engine not found');
                }

                $pythonBinary = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN' ? 'python' : 'python3';
                $encodedJobData = base64_encode(json_encode($jobData, JSON_UNESCAPED_UNICODE));
                $command = escapeshellcmd($pythonBinary) . ' ' .
                    escapeshellarg($scriptPath) . ' ' .
                    escapeshellarg($encodedJobData) . ' 2>&1';

                $rawOutput = shell_exec($command);
                if ($rawOutput === null) {
                    throw new Exception('Interview generator did not respond');
                }

                $aiResponse = json_decode(trim($rawOutput), true);
                if (!$aiResponse || empty($aiResponse['success'])) {
                    throw new Exception($aiResponse['error'] ?? 'Invalid AI response');
                }

                $questions = $aiResponse['questions'] ?? [];
                if (empty($questions)) {
                    throw new Exception('AI did not generate any questions');
                }

                $saved = $jobModel->saveInterviewQuestions($jobId, $questions);
                if (!$saved) {
                    throw new Exception('Failed to save questions to database');
                }

                if (!empty($aiResponse['warning'])) {
                    error_log('Interview generator warning: ' . $aiResponse['warning']);
                }

                echo json_encode([
                    'success' => true, 
                    'message' => 'Đã tạo ' . count($questions) . ' câu hỏi phỏng vấn!',
                    'questions' => $questions
                ], JSON_UNESCAPED_UNICODE);
            } catch (Exception $e) {
                error_log('Generate interview questions error: ' . $e->getMessage());
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
            }
            break;

        case 'recommend-jobs':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }

            // Debug logging
            $isAuth = isLoggedIn();
            error_log('Recommend-jobs: isAuthenticated=' . ($isAuth ? 'true' : 'false'));
            error_log('Recommend-jobs: role=' . ($_SESSION['role'] ?? 'NONE'));
            error_log('Recommend-jobs: user_id=' . ($_SESSION['user_id'] ?? 'NONE'));

            if (!$isAuth) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'Bạn chưa đăng nhập']);
                break;
            }

            if ($_SESSION['role'] !== 'candidate') {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'Chỉ candidate mới dùng được (role hiện tại: ' . ($_SESSION['role'] ?? 'none') . ')']);
                break;
            }

            try {
                $candidateId = $_SESSION['user_id'];
                
                // Get candidate profile
                $candidateModel = new CandidateProfile();
                $profile = $candidateModel->getProfile($candidateId);
                
                if (!$profile) {
                    echo json_encode(['success' => false, 'message' => 'Không tìm thấy profile']);
                    break;
                }

                // Build CV data from profile fields (prioritize CV analysis, fallback to profile)
                $cvData = [];
                
                // Try CV analysis first
                if (!empty($profile['cv_analysis'])) {
                    $cvAnalysis = json_decode($profile['cv_analysis'], true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $cvData = $cvAnalysis;
                    }
                }
                
                // Fallback to profile data if CV analysis is empty
                if (empty($cvData['skills']) && !empty($profile['skills'])) {
                    $cvData['skills'] = $profile['skills'];
                }
                if (empty($cvData['experience_years']) && isset($profile['experience_years'])) {
                    $cvData['experience_years'] = $profile['experience_years'];
                }
                if (empty($cvData['education']) && !empty($profile['education_level'])) {
                    $eduLevels = [
                        'high_school' => 'THPT',
                        'associate' => 'Cao đẳng',
                        'bachelor' => 'Đại học',
                        'master' => 'Thạc sĩ',
                        'phd' => 'Tiến sĩ'
                    ];
                    $cvData['education'] = $eduLevels[$profile['education_level']] ?? $profile['education_level'];
                }
                if (empty($cvData['summary']) && !empty($profile['bio'])) {
                    $cvData['summary'] = $profile['bio'];
                }

                // Get all active jobs (fixed)
                $jobModel = new Job();
                $jobs = $jobModel->getActiveJobs(1000, 0); // Lấy tối đa 1000 jobs

                if (empty($jobs)) {
                    echo json_encode(['success' => false, 'message' => 'Không có công việc nào']);
                    break;
                }

                // Prepare data for Python
                $inputData = [
                    'cv_data' => $cvData,
                    'jobs' => $jobs
                ];

                // Call Python job recommender
                $pythonScript = __DIR__ . '/utils/AI/job_recommender.py';
                $inputJson = json_encode($inputData, JSON_UNESCAPED_UNICODE);
                
                $descriptorspec = [
                    0 => ['pipe', 'r'],
                    1 => ['pipe', 'w'],
                    2 => ['pipe', 'w']
                ];

                $process = proc_open(
                    "python \"$pythonScript\"",
                    $descriptorspec,
                    $pipes,
                    __DIR__
                );

                if (!is_resource($process)) {
                    throw new Exception('Không thể chạy Python script');
                }

                fwrite($pipes[0], $inputJson);
                fclose($pipes[0]);

                $output = stream_get_contents($pipes[1]);
                fclose($pipes[1]);

                $errors = stream_get_contents($pipes[2]);
                fclose($pipes[2]);

                $returnCode = proc_close($process);

                if ($returnCode !== 0) {
                    error_log('Python recommender error: ' . $errors);
                    throw new Exception('Python script failed: ' . $errors);
                }

                $aiResponse = json_decode($output, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    throw new Exception('Invalid JSON from Python: ' . $output);
                }

                if (!$aiResponse['success']) {
                    throw new Exception($aiResponse['message']);
                }

                echo json_encode([
                    'success' => true,
                    'recommendations' => $aiResponse['recommendations']
                ], JSON_UNESCAPED_UNICODE);

            } catch (Exception $e) {
                error_log('Job recommender error: ' . $e->getMessage());
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
            }
            break;

        // Job endpoints
        case 'search-jobs':
            if ($method !== 'GET') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            // Sử dụng JobController hoặc Model trực tiếp
            if (class_exists('JobController')) {
                $jobController = new JobController();
                $jobs = $jobController->searchJobs(); // Hàm này trong controller sẽ gọi $_GET và Model
                echo json_encode(['success' => true, 'data' => $jobs]);
            } else {
                // Fallback dùng Model trực tiếp
                $jobModel = new Job();
                $jobs = $jobModel->searchJobs($_GET['keyword'] ?? '', []);
                echo json_encode(['success' => true, 'data' => $jobs]);
            }
            break;

        case 'toggle-save-job':
            requireLogin();
            requireRole('candidate');
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            
            require_once 'utils/models/SavedJob.php';
            
            $input = json_decode(file_get_contents('php://input'), true);
            $jobId = (int)($input['job_id'] ?? $_POST['job_id'] ?? 0);
            $notes = $input['notes'] ?? $_POST['notes'] ?? null;
            
            if (!$jobId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Job ID không hợp lệ']);
                break;
            }
            
            $savedJobModel = new SavedJob();
            $userId = $_SESSION['user_id'];
            
            // Check if already saved
            if ($savedJobModel->isSaved($userId, $jobId)) {
                // Unsave
                if ($savedJobModel->unsaveJob($userId, $jobId)) {
                    echo json_encode(['success' => true, 'saved' => false, 'message' => 'Đã bỏ lưu tin']);
                } else {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => 'Có lỗi khi bỏ lưu tin']);
                }
            } else {
                // Save
                if ($savedJobModel->saveJob($userId, $jobId, $notes)) {
                    echo json_encode(['success' => true, 'saved' => true, 'message' => 'Đã lưu tin thành công']);
                } else {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => 'Có lỗi khi lưu tin']);
                }
            }
            break;

        case 'create-job':
            requireRole('recruiter');
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            if (class_exists('JobController')) {
                $jobController = new JobController();
                $result = $jobController->createJob();
                echo json_encode($result);
            }
            break;

        case 'update-job':
            requireRole('recruiter');
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            $jobId = (int)($_POST['job_id'] ?? 0);
            if (!$jobId) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Job ID không hợp lệ']);
                break;
            }
            if (class_exists('JobController')) {
                $jobController = new JobController();
                $result = $jobController->updateJob($jobId);
                echo json_encode($result);
            }
            break;

        // Application endpoints
        case 'apply-job':
            requireLogin();
            requireRole('candidate');
            if ($method !== 'POST') {
                ob_clean();
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                exit;
            }
            
            $jobId = (int)($_POST['job_id'] ?? 0);
            if (!$jobId) {
                ob_clean();
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Job ID không hợp lệ']);
                exit;
            }
            
            try {
                // Check if already applied (but not withdrawn)
                $appModel = new Application();
                $existingApp = $appModel->getApplicationByJobAndCandidate($jobId, $_SESSION['user_id']);
                
                if ($existingApp && $existingApp['status'] !== 'withdrawn') {
                    ob_clean();
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Bạn đã ứng tuyển vị trí này rồi']);
                    exit;
                }
                
                // Get candidate's main CV (ensure profile exists first)
                $candidateModel = new CandidateProfile();
                $profile = $candidateModel->getProfile($_SESSION['user_id']);
                
                // If profile doesn't exist, create it
                if (!$profile) {
                    $candidateModel->createProfile($_SESSION['user_id']);
                    $profile = $candidateModel->getProfile($_SESSION['user_id']);
                }
                
                $cvUrl = $profile['cv_file_url'] ?? '';
                
                if (empty($cvUrl)) {
                    ob_clean();
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Vui lòng tải CV trước khi ứng tuyển']);
                    exit;
                }
                
                // If user had withdrawn before, update the existing application instead of creating new one
                if ($existingApp && $existingApp['status'] === 'withdrawn') {
                    $updateResult = $appModel->updateApplication($existingApp['id'], [
                        'status' => 'pending',
                        'cover_letter' => $_POST['cover_letter'] ?? ''
                    ]);
                    
                    if ($updateResult) {
                        // Tăng lại applications_count
                        $jobModel = new Job();
                        $jobModel->incrementApplicationCount($jobId);
                        
                        ob_clean();
                        http_response_code(200);
                        echo json_encode(['success' => true, 'message' => 'Ứng tuyển thành công! 🎉']);
                    } else {
                        ob_clean();
                        http_response_code(500);
                        echo json_encode(['success' => false, 'message' => 'Lỗi hệ thống, vui lòng thử lại']);
                    }
                    exit;
                }
                
                // Create new application
                $result = $appModel->createApplication(
                    $jobId,
                    $_SESSION['user_id'],
                    ['cover_letter' => $_POST['cover_letter'] ?? '']
                );
                
                ob_clean();
                if ($result) {
                    http_response_code(200);
                    echo json_encode(['success' => true, 'message' => 'Ứng tuyển thành công! 🎉']);
                } else {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => 'Lỗi hệ thống, vui lòng thử lại']);
                }
                exit;
            } catch (Exception $e) {
                ob_clean();
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
                exit;
            }

        case 'withdraw-application':
            requireLogin();
            requireRole('candidate');
            if ($method !== 'POST') {
                ob_clean();
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                exit;
            }
            
            $appId = (int)($_POST['application_id'] ?? 0);
            if (!$appId) {
                ob_clean();
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Application ID không hợp lệ']);
                exit;
            }
            
            try {
                $appModel = new Application();
                $application = $appModel->getApplicationById($appId);
                
                // Verify ownership
                if (!$application || $application['candidate_id'] != $_SESSION['user_id']) {
                    ob_clean();
                    http_response_code(403);
                    echo json_encode(['success' => false, 'message' => 'Không có quyền thực hiện']);
                    exit;
                }
                
                // Check if already withdrawn or accepted
                if ($application['status'] === 'withdrawn') {
                    ob_clean();
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Đơn đã được rút trước đó']);
                    exit;
                }
                
                if ($application['status'] === 'accepted') {
                    ob_clean();
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Không thể rút đơn đã được chấp nhận']);
                    exit;
                }
                
                $result = $appModel->withdrawApplication($appId);
                
                ob_clean();
                if ($result) {
                    http_response_code(200);
                    echo json_encode(['success' => true, 'message' => 'Đã rút đơn ứng tuyển thành công']);
                } else {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => 'Lỗi khi rút đơn']);
                }
                exit;
            } catch (Exception $e) {
                ob_clean();
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
                exit;
            }

        case 'update-application':
            requireLogin(); // Cả admin và recruiter đều có thể update (tùy logic)
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            $appId = (int)($_POST['application_id'] ?? 0);
            $status = sanitize($_POST['status'] ?? '');
            
            // Kiểm tra dữ liệu
            if (!$appId || !$status) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Dữ liệu không hợp lệ']);
                break;
            }
            
            // Logic update status dùng Model
            $appModel = new Application();
            $app = $appModel->getApplicationById($appId);
            
            if (!$app) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Application không tồn tại']);
                break;
            }
            
            // Kiểm tra quyền - Recruiter chỉ có thể cập nhật ứng dụng của mình
            if ($_SESSION['role'] === 'recruiter') {
                $jobModel = new Job();
                $job = $jobModel->getJobById($app['job_id']);
                if (!$job || $job['recruiter_id'] != $_SESSION['user_id']) {
                    http_response_code(403);
                    echo json_encode(['success' => false, 'message' => 'Không có quyền cập nhật']);
                    break;
                }
            }
            
            $success = $appModel->updateApplication($appId, ['status' => $status]);
            
            if ($success) {
                echo json_encode(['success' => true, 'message' => 'Cập nhật trạng thái thành công']);
            } else {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi khi cập nhật']);
            }
            break;

        // Profile endpoints
        case 'upload-cv':
            requireRole('candidate');
            if ($method !== 'POST' || !isset($_FILES['cv'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Tệp CV không được tìm thấy']);
                break;
            }
            // Sử dụng FileHandler từ Helpers.php mới
            $result = FileHandler::uploadCV($_FILES['cv'], $_SESSION['user_id']);
            if ($result['success']) {
                // Lưu vào DB (nếu chưa set main CV thì set luôn)
                // $candidateModel = new CandidateProfile();
                // $candidateModel->addCV($_SESSION['user_id'], $result['path']);
            }
            echo json_encode($result);
            break;

        case 'upload-avatar':
            // Logic này đã được bao gồm trong 'update-profile' nhưng giữ lại để tương thích ngược nếu cần
            requireLogin();
            if ($method !== 'POST' || !isset($_FILES['avatar'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Tệp ảnh không được tìm thấy']);
                break;
            }
            $result = FileHandler::uploadImage($_FILES['avatar'], $_SESSION['user_id']);
            if ($result['success']) {
                $userModel = new User();
                $userModel->updateUser($_SESSION['user_id'], ['avatar_url' => BASE_URL . $result['path']]); // Thêm BASE_URL
            }
            echo json_encode($result);
            break;

        // --- TÍNH NĂNG CHỌN CV CHÍNH ---
        case 'set-main-cv':
            requireRole('candidate');
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            
            $filename = sanitize($_POST['filename'] ?? '');
            if (!$filename) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Tên file không hợp lệ']);
                break;
            }

            // Tạo đường dẫn tương đối để lưu vào DB (phải match với upload-cv.php)
            $relativePath = 'utils/uploads/cv/' . $filename;
            
            // Kiểm tra file có tồn tại thật không
            $fullPath = __DIR__ . '/' . $relativePath;
            if (!file_exists($fullPath)) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'File không tồn tại trên hệ thống: ' . $fullPath]);
                break;
            }

            // Cập nhật DB
            $db = new Database();
            $conn = $db->getConnection();
            
            // Ensure profile exists first
            $checkQuery = "SELECT id FROM candidate_profiles WHERE user_id = ? LIMIT 1";
            $checkStmt = $conn->prepare($checkQuery);
            $checkStmt->execute([$_SESSION['user_id']]);
            $profileExists = $checkStmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$profileExists) {
                $insertQuery = "INSERT INTO candidate_profiles (user_id, created_at) VALUES (?, NOW())";
                $insertStmt = $conn->prepare($insertQuery);
                $insertStmt->execute([$_SESSION['user_id']]);
            }
            
            // Update CV URL
            $stmt = $conn->prepare("UPDATE candidate_profiles SET cv_file_url = :url, updated_at = NOW() WHERE user_id = :uid");
            $stmt->bindParam(':url', $relativePath);
            $stmt->bindParam(':uid', $_SESSION['user_id']);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Đã đặt làm CV chính thành công!']);
            } else {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi cập nhật cơ sở dữ liệu']);
            }
            break;

        case 'update-candidate-profile':
            requireRole('candidate');
            // ... (Logic cũ của bạn giữ nguyên) ...
            $city = sanitize($_POST['city'] ?? '');
            $experience_years = (int)($_POST['experience_years'] ?? 0);
            $education_level = sanitize($_POST['education_level'] ?? '');
            
            if (!$city || $experience_years < 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Dữ liệu không hợp lệ']);
                break;
            }
            
            $candidateModel = new CandidateProfile();
            // Giả định model có hàm updateProfile
            // $result = $candidateModel->updateProfile(...)
            echo json_encode(['success' => true, 'message' => 'Hồ sơ đã được cập nhật (Demo)']);
            break;

        case 'update-recruiter-profile':
            // Cập nhật dùng Controller mới để xử lý cả ảnh và thông tin
            $controller = new RecruiterController();
            $response = $controller->updateProfile();
            echo json_encode($response);
            break;

        // Notification endpoints
        case 'get-notifications':
            requireLogin();
            if ($method !== 'GET') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            $notificationModel = new Notification();
            $notifications = $notificationModel->getNotifications($_SESSION['user_id'], 20);
            echo json_encode(['success' => true, 'data' => $notifications]);
            break;

        // AI Parse CV - Using Python Backend
        case 'parse-cv':
            requireLogin();
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }

            try {
                require_once 'utils/controllers/CVParserController.php';

                $cvPath = sanitize($_POST['cv_path'] ?? '');
                error_log('📍 parse-cv: Received cvPath = ' . $cvPath);
                
                if (empty($cvPath)) {
                    error_log('❌ parse-cv: CV path is empty');
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'CV path is required']);
                    break;
                }

                // Construct full path
                $fullPath = __DIR__ . '/' . $cvPath;
                error_log('📍 parse-cv: Full path = ' . $fullPath);

                // Use Python parser
                $controller = new CVParserController();
                $result = $controller->parseCVFile($fullPath);
                
                echo json_encode($result);
                
            } catch (Exception $e) {
                error_log('❌ parse-cv: Exception = ' . $e->getMessage());
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;

        // Chấm điểm CV bằng Gemini AI
        case 'analyze-cv':
            requireLogin();
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            try {
                // Lấy nội dung CV từ file
                $cvPath = sanitize($_POST['cv_path'] ?? '');
                $cvText = '';
                
                if (!empty($cvPath)) {
                    $fullPath = __DIR__ . '/' . $cvPath;
                    if (!file_exists($fullPath)) {
                        http_response_code(400);
                        echo json_encode(['success' => false, 'message' => 'CV file not found']);
                        break;
                    }
                    
                    // Extract text từ PDF/DOCX/TXT
                    require_once 'utils/AI/CVTextExtractor.php';
                    $extractor = new CVTextExtractor();
                    $cvText = $extractor->extractText($fullPath);
                    
                    if (empty($cvText) || strlen($cvText) < 50) {
                        http_response_code(400);
                        echo json_encode(['success' => false, 'message' => 'Không thể trích xuất nội dung từ CV. Vui lòng kiểm tra file.']);
                        break;
                    }
                    
                } else if (!empty($_POST['cv_text'])) {
                    $cvText = $_POST['cv_text'];
                } else {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'CV data is required']);
                    break;
                }
                
                require_once 'utils/AI/GeminiService.php';
                $gemini = new GeminiService();

                // Use public analyzeCV method to get structured analysis + score
                $analysis = $gemini->analyzeCV($cvText);

                if (!is_array($analysis)) {
                    throw new Exception('Invalid analysis format from AI');
                }

                // Persist analysis and score
                $candidateModel = new CandidateProfile();
                $userId = $_SESSION['user_id'];
                $score = intval($analysis['score'] ?? 0);
                $analysisJson = json_encode($analysis, JSON_UNESCAPED_UNICODE);

                $saved = $candidateModel->updateCVAnalysis($userId, $score, $analysisJson);

                if (!$saved) {
                    error_log('❌ analyze-cv: Failed to save analysis to DB for user ' . $userId);
                }

                echo json_encode([
                    'success' => true,
                    'message' => 'CV đã được chấm điểm thành công',
                    'data' => $analysis
                ]);
                
            } catch (Exception $e) {
                error_log('❌ analyze-cv: ' . $e->getMessage());
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;

        // --- MATCH JOB WITH CV ---
        case 'match-job':
            requireLogin();
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }

            try {
                $jobId = (int)($_POST['job_id'] ?? 0);
                $applicationId = (int)($_POST['application_id'] ?? 0);
                $candidateId = $_POST['candidate_id'] ?? null;

                if (!$jobId) {
                    throw new Exception('Job ID là bắt buộc');
                }

                // Nếu không có candidate_id nhưng có application_id, lấy từ Application
                if (!$candidateId && $applicationId) {
                    $appModel = new Application();
                    $app = $appModel->getApplicationById($applicationId);
                    if ($app) {
                        $candidateId = $app['candidate_id'];
                    }
                }

                // Fallback nếu vẫn không có candidate_id
                if (!$candidateId) {
                    $candidateId = $_SESSION['user_id'];
                }

                require_once 'utils/controllers/JobMatcherController.php';
                require_once 'utils/AI/CVTextExtractor.php';

                $jobModel = new Job();
                $candidateModel = new CandidateProfile();

                $job = $jobModel->getJobById($jobId);
                if (!$job) {
                    throw new Exception('Công việc không tồn tại');
                }

                // Get CV text from candidate profile
                $profile = $candidateModel->getProfile($candidateId);
                if (empty($profile['cv_file_url'])) {
                    throw new Exception('Ứng viên chưa tải CV');
                }

                $cvPath = __DIR__ . '/' . $profile['cv_file_url'];
                if (!file_exists($cvPath)) {
                    throw new Exception('File CV không tìm thấy');
                }

                $cvText = CVTextExtractor::extractText($cvPath);
                $jobDescription = $job['title'] . "\n\nMô tả: " . $job['description'] . "\n\nYêu cầu: " . $job['requirements'];

                $controller = new JobMatcherController();
                $result = $controller->matchJob($cvText, $jobDescription);

                if ($result['success'] ?? false) {
                    $data = $result['data'] ?? [];
                    $score = $data['score'] ?? 0;
                    
                    // Nếu có application_id, lưu vào DB
                    if ($applicationId) {
                        $appModel = new Application();
                        $updateResult = $appModel->updateMatchScore($applicationId, $score, $data);
                        error_log("Update match score result: " . ($updateResult ? 'success' : 'failed'));
                    }
                    
                    ob_clean();
                    http_response_code(200);
                    echo json_encode([
                        'success' => true,
                        'message' => 'Tính toán matching score thành công',
                        'data' => [
                            'score' => $score,
                            'analysis' => $data
                        ]
                    ]);
                    exit;
                } else {
                    $errorMsg = $result['message'] ?? $result['error'] ?? 'Unknown error';
                    error_log("Job matching failed: " . $errorMsg);
                    ob_clean();
                    http_response_code(500);
                    echo json_encode([
                        'success' => false,
                        'message' => 'Không thể tính điểm phù hợp: ' . $errorMsg,
                        'error' => $result
                    ]);
                    exit;
                }

            } catch (Exception $e) {
                error_log('❌ match-job: ' . $e->getMessage());
                ob_clean();
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
                exit;
            }
            break;

        // --- XÓA CV ---
        case 'delete-cv':
            requireLogin();
            requireRole('candidate');
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            
            $filename = sanitize($_POST['filename'] ?? '');
            if (!$filename) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Tên file không hợp lệ']);
                break;
            }

            // Kiểm tra file thuộc về user này
            if (stripos($filename, 'cv_' . $_SESSION['user_id']) !== 0) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'Bạn không có quyền xóa file này']);
                break;
            }

            $filePath = __DIR__ . '/utils/uploads/cv/' . $filename;
            
            // Kiểm tra file có tồn tại
            if (!file_exists($filePath)) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'File không tồn tại']);
                break;
            }

            // Xóa file
            if (unlink($filePath)) {
                // Nếu file bị xóa là CV chính, cập nhật DB
                $db = new Database();
                $conn = $db->getConnection();
                $relativePath = 'utils/uploads/cv/' . $filename;
                
                $stmt = $conn->prepare("SELECT cv_file_url FROM candidate_profiles WHERE user_id = ? LIMIT 1");
                $stmt->execute([$_SESSION['user_id']]);
                $profile = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($profile && $profile['cv_file_url'] === $relativePath) {
                    // Xóa CV chính nếu nó là file được xóa
                    $updateStmt = $conn->prepare("UPDATE candidate_profiles SET cv_file_url = NULL WHERE user_id = ?");
                    $updateStmt->execute([$_SESSION['user_id']]);
                }
                
                echo json_encode(['success' => true, 'message' => 'Đã xóa file CV thành công']);
            } else {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi khi xóa file']);
            }
            break;

        // --- BÁO CÁO VI PHẠM ---
        case 'submit-report':
            requireLogin();
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            
            try {
                $reportedType = sanitize($_POST['reported_type'] ?? '');
                $reportedId = (int)($_POST['job_id'] ?? $_POST['reported_id'] ?? 0);
                $reason = sanitize($_POST['reason'] ?? '');
                $description = sanitize($_POST['description'] ?? '');
                
                // Validate inputs
                if (!in_array($reportedType, ['job', 'candidate', 'recruiter'])) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Loại báo cáo không hợp lệ']);
                    break;
                }
                
                if (!$reportedId) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'ID để báo cáo không hợp lệ']);
                    break;
                }
                
                if (empty($reason)) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Vui lòng chọn lý do báo cáo']);
                    break;
                }
                
                if (empty($description) || strlen($description) < 10) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Vui lòng cung cấp chi tiết báo cáo (ít nhất 10 ký tự)']);
                    break;
                }
                
                // Check if reported object exists
                if ($reportedType === 'job') {
                    $jobModel = new Job();
                    $job = $jobModel->getJobById($reportedId);
                    if (!$job) {
                        http_response_code(404);
                        echo json_encode(['success' => false, 'message' => 'Bài đăng không tồn tại']);
                        break;
                    }
                }
                
                // Insert report into database
                $db = new Database();
                $conn = $db->getConnection();
                
                $stmt = $conn->prepare("
                    INSERT INTO reports (reporter_id, reported_type, reported_id, reason, description, status, created_at)
                    VALUES (?, ?, ?, ?, ?, 'pending', NOW())
                ");
                
                $result = $stmt->execute([
                    $_SESSION['user_id'],
                    $reportedType,
                    $reportedId,
                    $reason,
                    $description
                ]);
                
                if ($result) {
                    http_response_code(200);
                    echo json_encode([
                        'success' => true,
                        'message' => 'Cảm ơn bạn đã báo cáo. Chúng tôi sẽ xem xét sớm.'
                    ]);
                } else {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => 'Lỗi khi gửi báo cáo. Vui lòng thử lại.']);
                }
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
            }
            break;

        // --- ADMIN XÓA FILE CV ---
        case 'admin-delete-file':
            requireRole('admin');
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            
            try {
                $userId = (int)($_POST['user_id'] ?? 0);
                
                if (!$userId) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'User ID không hợp lệ']);
                    break;
                }
                
                // Lấy thông tin CV từ database
                $db = new Database();
                $conn = $db->getConnection();
                
                $stmt = $conn->prepare("SELECT cv_file_url FROM candidate_profiles WHERE user_id = ? LIMIT 1");
                $stmt->execute([$userId]);
                $profile = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$profile || empty($profile['cv_file_url'])) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'message' => 'Không tìm thấy file CV']);
                    break;
                }
                
                $cvFileUrl = $profile['cv_file_url'];
                // Xây dựng đường dẫn tuyệt đối từ dự án root
                $cvFilePath = __DIR__ . '/' . $cvFileUrl;
                
                // Xóa file khỏi ổ cứng nếu tồn tại
                if (file_exists($cvFilePath)) {
                    if (!unlink($cvFilePath)) {
                        http_response_code(500);
                        echo json_encode(['success' => false, 'message' => 'Không thể xóa file khỏi server']);
                        break;
                    }
                }
                
                // Cập nhật database - Set cv_file_url = NULL
                $updateStmt = $conn->prepare("UPDATE candidate_profiles SET cv_file_url = NULL WHERE user_id = ?");
                if ($updateStmt->execute([$userId])) {
                    http_response_code(200);
                    echo json_encode([
                        'success' => true,
                        'message' => 'Đã xóa file CV thành công'
                    ]);
                } else {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => 'Lỗi cập nhật database']);
                }
                
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
            }
            break;

        // Company Reviews
        case 'add-company-review':
            requireLogin();
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            
            try {
                require_once 'utils/models/CompanyReview.php';
                
                $companyId = (int)($_POST['company_id'] ?? 0);
                $rating = (int)($_POST['rating'] ?? 0);
                $title = trim($_POST['title'] ?? '');
                $comment = trim($_POST['comment'] ?? '');
                $jobPosition = trim($_POST['job_position'] ?? '');
                $employmentStatus = $_POST['employment_status'] ?? 'current_employee';
                
                if (!$companyId || $rating < 1 || $rating > 5 || empty($title) || empty($comment)) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Dữ liệu không hợp lệ']);
                    break;
                }
                
                $reviewModel = new CompanyReview();
                if ($reviewModel->addReview($companyId, $_SESSION['user_id'], $rating, $title, $comment, $jobPosition, $employmentStatus)) {
                    echo json_encode(['success' => true, 'message' => 'Đánh giá đã được thêm thành công']);
                } else {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => 'Lỗi khi thêm đánh giá']);
                }
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
            }
            break;

        case 'get-company-reviews':
            if ($method !== 'GET') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            
            try {
                require_once 'utils/models/CompanyReview.php';
                
                $companyId = (int)($_GET['company_id'] ?? 0);
                $limit = (int)($_GET['limit'] ?? 10);
                $offset = (int)($_GET['offset'] ?? 0);
                
                if (!$companyId) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Company ID không hợp lệ']);
                    break;
                }
                
                $reviewModel = new CompanyReview();
                $reviews = $reviewModel->getCompanyReviews($companyId, $limit, $offset);
                $stats = $reviewModel->getCompanyRatingStats($companyId);
                
                echo json_encode([
                    'success' => true,
                    'reviews' => $reviews,
                    'stats' => $stats
                ]);
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
            }
            break;

        case 'check-company-review':
            requireLogin();
            if ($method !== 'GET') {
                http_response_code(405);
                echo json_encode(['success' => false, 'message' => 'Method not allowed']);
                break;
            }
            
            try {
                require_once 'utils/models/CompanyReview.php';
                
                $companyId = (int)($_GET['company_id'] ?? 0);
                
                if (!$companyId) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Company ID không hợp lệ']);
                    break;
                }
                
                $reviewModel = new CompanyReview();
                $hasReviewed = $reviewModel->hasReviewed($companyId, $_SESSION['user_id']);
                
                echo json_encode([
                    'success' => true,
                    'has_reviewed' => $hasReviewed
                ]);
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
            }
            break;
        
        // ==================== CHAT SYSTEM ENDPOINTS ====================
        
        case 'start-conversation':
            // Khởi tạo conversation từ application
            if (!isLoggedIn()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            try {
                // Create MySQLi connection for chat
                $mysqli = new mysqli('localhost', 'root', '', 'ai_recruitment');
                if ($mysqli->connect_error) {
                    throw new Exception('Database connection failed: ' . $mysqli->connect_error);
                }
                $mysqli->set_charset("utf8mb4");
                
                $messageController = new MessageController($mysqli);
                $result = $messageController->startConversation($_SESSION['user_id'], $_SESSION['role']);
                echo json_encode($result);
                
                $mysqli->close();
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;
        
        case 'get-conversations':
            // Lấy danh sách conversations
            if (!isLoggedIn()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            try {
                $mysqli = new mysqli('localhost', 'root', '', 'ai_recruitment');
                if ($mysqli->connect_error) {
                    throw new Exception('Database connection failed: ' . $mysqli->connect_error);
                }
                $mysqli->set_charset("utf8mb4");
                
                $messageController = new MessageController($mysqli);
                $result = $messageController->getConversations($_SESSION['user_id'], $_SESSION['role']);
                echo json_encode($result);
                
                $mysqli->close();
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;
        
        case 'get-conversation':
            // Lấy chi tiết conversation và messages
            if (!isLoggedIn()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            $conversation_id = $_GET['id'] ?? null;
            if (!$conversation_id) {
                echo json_encode(['success' => false, 'message' => 'Missing conversation_id']);
                break;
            }
            
            try {
                $mysqli = new mysqli('localhost', 'root', '', 'ai_recruitment');
                if ($mysqli->connect_error) {
                    throw new Exception('Database connection failed: ' . $mysqli->connect_error);
                }
                $mysqli->set_charset("utf8mb4");
                
                $messageController = new MessageController($mysqli);
                $result = $messageController->getConversation($_SESSION['user_id'], $conversation_id);
                echo json_encode($result);
                
                $mysqli->close();
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;
        
        case 'send-message':
            // Gửi tin nhắn
            if (!isLoggedIn()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            try {
                $mysqli = new mysqli('localhost', 'root', '', 'ai_recruitment');
                if ($mysqli->connect_error) {
                    throw new Exception('Database connection failed: ' . $mysqli->connect_error);
                }
                $mysqli->set_charset("utf8mb4");
                
                $messageController = new MessageController($mysqli);
                $result = $messageController->sendMessage($_SESSION['user_id'], $_SESSION['role']);
                echo json_encode($result);
                
                $mysqli->close();
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;
        
        case 'poll-messages':
            // Lấy tin nhắn mới (AJAX polling)
            if (!isLoggedIn()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            $conversation_id = $_GET['conversation_id'] ?? null;
            $after_timestamp = $_GET['after'] ?? null;
            
            if (!$conversation_id || !$after_timestamp) {
                echo json_encode(['success' => false, 'message' => 'Missing parameters']);
                break;
            }
            
            try {
                $mysqli = new mysqli('localhost', 'root', '', 'ai_recruitment');
                if ($mysqli->connect_error) {
                    throw new Exception('Database connection failed: ' . $mysqli->connect_error);
                }
                $mysqli->set_charset("utf8mb4");
                
                $messageController = new MessageController($mysqli);
                $result = $messageController->pollMessages($_SESSION['user_id'], $conversation_id, $after_timestamp);
                echo json_encode($result);
                
                $mysqli->close();
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;
        
        case 'mark-conversation-read':
            // Đánh dấu đã đọc
            if (!isLoggedIn()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            try {
                $mysqli = new mysqli('localhost', 'root', '', 'ai_recruitment');
                if ($mysqli->connect_error) {
                    throw new Exception('Database connection failed: ' . $mysqli->connect_error);
                }
                $mysqli->set_charset("utf8mb4");
                
                $messageController = new MessageController($mysqli);
                $result = $messageController->markConversationRead($_SESSION['user_id'], $_SESSION['role']);
                echo json_encode($result);
                
                $mysqli->close();
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;
        
        case 'get-unread-count':
            // Lấy số tin nhắn chưa đọc
            if (!isLoggedIn()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            try {
                $mysqli = new mysqli('localhost', 'root', '', 'ai_recruitment');
                if ($mysqli->connect_error) {
                    throw new Exception('Database connection failed: ' . $mysqli->connect_error);
                }
                $mysqli->set_charset("utf8mb4");
                
                $messageController = new MessageController($mysqli);
                $result = $messageController->getUnreadCount($_SESSION['user_id'], $_SESSION['role']);
                echo json_encode($result);
                
                $mysqli->close();
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;
        
        case 'upload-chat-attachment':
            // Upload file đính kèm
            if (!isLoggedIn()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            try {
                $mysqli = new mysqli('localhost', 'root', '', 'ai_recruitment');
                if ($mysqli->connect_error) {
                    throw new Exception('Database connection failed: ' . $mysqli->connect_error);
                }
                $mysqli->set_charset("utf8mb4");
                
                $messageController = new MessageController($mysqli);
                $result = $messageController->uploadAttachment();
                echo json_encode($result);
                
                $mysqli->close();
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;

        case 'mark-notification-read':
            // Đánh dấu notification đã đọc
            if (!isLoggedIn()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            $notification_id = $_POST['notification_id'] ?? $_GET['notification_id'] ?? null;
            
            if (!$notification_id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Missing notification_id']);
                break;
            }
            
            try {
                $notificationModel = new Notification();
                $result = $notificationModel->markAsRead($notification_id);
                
                if ($result) {
                    echo json_encode(['success' => true, 'message' => 'Marked as read']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Failed to mark as read']);
                }
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            break;

        case 'load-widgets':
            // Lazy load chat widgets (không cần auth check vì chatbot public)
            ob_start();
            
            // Load chat widget nếu user đã login
            if (isLoggedIn()) {
                include __DIR__ . '/components/chat-widget.php';
            }
            
            // Load AI chatbot widget (public)
            include __DIR__ . '/views/components/chatbot-widget.php';
            
            $html = ob_get_clean();
            
            // Return HTML directly, not JSON
            header('Content-Type: text/html; charset=utf-8');
            echo $html;
            exit; // Important: exit để không chạy code phía dưới
            break;

        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Endpoint không tìm thấy (Action: ' . htmlspecialchars($action) . ')']);
            break;
    }
} catch (Exception $e) {
    ob_clean();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()]);
}
ob_end_flush();
?>