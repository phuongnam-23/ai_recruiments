<?php
require_once 'config/init.php';

echo "<h1>🧪 TEST KẾT NỐI DATABASE</h1>";

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($db) {
        echo "<p style='color: green; font-size: 20px;'>✅ KẾT NỐI DATABASE THÀNH CÔNG!</p>";
        
        $query = "SELECT COUNT(*) as total FROM users";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<p>📊 Số lượng users: <strong>" . $result['total'] . "</strong></p>";
        
        echo "<hr><h2>✅ HỆ THỐNG HOẠT ĐỘNG BÌNH THƯỜNG!</h2>";
        echo "<p><a href='login.php' style='padding: 10px 20px; background: #4F46E5; color: white; text-decoration: none; border-radius: 5px;'>→ Đăng nhập ngay</a></p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ LỖI: " . $e->getMessage() . "</p>";
}
?>