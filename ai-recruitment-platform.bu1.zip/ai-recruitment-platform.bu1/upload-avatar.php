<?php
/**
 * Avatar Upload Endpoint
 * Handles avatar image uploads for all user roles
 */

// Start output buffering first
ob_start();

// Set JSON header
header('Content-Type: application/json; charset=utf-8');

// Disable error display
ini_set('display_errors', 0);
error_reporting(E_ALL);

require_once 'config/init.php';
require_once 'utils/middleware/Auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Bạn cần đăng nhập để tải ảnh lên'
    ]);
    exit;
}

// Check if file was uploaded
if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Không nhận được file upload'
    ]);
    exit;
}

try {
    $file = $_FILES['avatar'];
    $userId = $_SESSION['user_id'];
    
    // Validate file type
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    $fileType = mime_content_type($file['tmp_name']);
    
    if (!in_array($fileType, $allowedTypes)) {
        throw new Exception('Chỉ chấp nhận file ảnh (JPG, PNG, GIF, WebP)');
    }
    
    // Validate file size (20MB)
    $maxSize = 20 * 1024 * 1024;
    if ($file['size'] > $maxSize) {
        throw new Exception('Kích thước file không được vượt quá 20MB');
    }
    
    // Get file extension
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
        $extension = 'jpg'; // Default
    }
    
    // Create upload directory if not exists
    $uploadDir = __DIR__ . '/uploads/avatars/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // Generate unique filename
    $filename = 'avatar_' . $userId . '_' . time() . '.' . $extension;
    $uploadPath = $uploadDir . $filename;
    
    // Delete old avatar if exists
    $userModel = new User();
    $user = $userModel->getUserById($userId);
    if (!empty($user['avatar_url'])) {
        $oldPath = __DIR__ . '/' . $user['avatar_url'];
        if (file_exists($oldPath) && strpos($user['avatar_url'], 'uploads/avatars/') !== false) {
            @unlink($oldPath);
        }
    }
    
    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        throw new Exception('Không thể lưu file. Vui lòng thử lại');
    }
    
    // Update database
    $relativePath = 'uploads/avatars/' . $filename;
    $result = $userModel->updateUser($userId, ['avatar_url' => $relativePath]);
    
    if (!$result) {
        // Delete uploaded file if DB update fails
        @unlink($uploadPath);
        throw new Exception('Không thể cập nhật cơ sở dữ liệu');
    }
    
    // Update session
    $_SESSION['avatar_url'] = $relativePath;
    
    // Clear output buffer and send JSON
    ob_clean();
    
    echo json_encode([
        'success' => true,
        'message' => 'Tải ảnh đại diện thành công!',
        'path' => $relativePath,
        'url' => BASE_URL . $relativePath
    ]);
    
} catch (Exception $e) {
    ob_clean();
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

ob_end_flush();
