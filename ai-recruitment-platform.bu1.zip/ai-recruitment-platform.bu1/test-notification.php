<?php
require_once 'config/init.php';

echo "=== TEST NOTIFICATION MODEL ===\n\n";

// Test với user_id = 1 (thường là candidate đầu tiên)
$notificationModel = new Notification();

echo "1. Testing getNotifications for user_id = 1:\n";
try {
    $notifications = $notificationModel->getNotifications(1, 10, 0);
    echo "Found " . count($notifications) . " notifications\n";
    print_r($notifications);
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

echo "\n2. Testing countUnread for user_id = 1:\n";
try {
    $unreadCount = $notificationModel->countUnread(1);
    echo "Unread count: " . $unreadCount . "\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

echo "\n3. Check if notifications table exists:\n";
try {
    $db = new Database();
    $conn = $db->getConnection();
    $stmt = $conn->query("SHOW TABLES LIKE 'notifications'");
    $result = $stmt->fetch();
    if ($result) {
        echo "Table 'notifications' exists\n";
        
        // Get table structure
        echo "\n4. Table structure:\n";
        $stmt = $conn->query("DESCRIBE notifications");
        $columns = $stmt->fetchAll();
        print_r($columns);
        
        // Count total rows
        echo "\n5. Total notifications in table:\n";
        $stmt = $conn->query("SELECT COUNT(*) as total FROM notifications");
        $count = $stmt->fetch();
        echo "Total: " . $count['total'] . "\n";
        
        // Show sample data
        echo "\n6. Sample notifications:\n";
        $stmt = $conn->query("SELECT * FROM notifications LIMIT 5");
        $samples = $stmt->fetchAll();
        print_r($samples);
    } else {
        echo "Table 'notifications' does NOT exist\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
