<?php
session_start();
require_once 'config/config.php';

// Login as candidate user 201 for testing
$_SESSION['user_id'] = 201;
$_SESSION['role'] = 'candidate';
$_SESSION['full_name'] = 'Nguyễn Văn An';
$_SESSION['email'] = 'an.nguyen@example.com';

echo "Logged in as: " . $_SESSION['full_name'] . " (ID: " . $_SESSION['user_id'] . ", Role: " . $_SESSION['role'] . ")<br>";
echo "You can now test the notification bell on <a href='index.php'>index.php</a>";
