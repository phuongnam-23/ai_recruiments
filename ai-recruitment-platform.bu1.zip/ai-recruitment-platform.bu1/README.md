# AI Recruitment Platform - Hướng dẫn

## 📋 Giới thiệu

AI Recruitment Platform là một nền tảng tuyển dụng trực tuyến được xây dựng bằng PHP, MySQL với tích hợp AI để hỗ trợ:
- Phân tích CV tự động
- Matching ứng viên và vị trí công việc
- Chatbot hỗ trợ tuyển dụng
- Quản lý ứng dụng toàn diện

## 🎯 Các vai trò người dùng

1. **Ứng viên (Candidate)**
   - Tạo hồ sơ chuyên nghiệp
   - Tải CV
   - Tìm kiếm và apply vị trí công việc
   - Theo dõi trạng thái đơn apply

2. **Nhà tuyển dụng (Recruiter)**
   - Đăng tin tuyển dụng
   - Quản lý hồ sơ công ty
   - Xem và quản lý đơn apply
   - Ghi chú và phỏng vấn ứng viên

3. **Quản trị viên (Admin)**
   - Quản lý người dùng
   - Xác thực công ty
   - Xử lý báo cáo vi phạm
   - Cấu hình hệ thống

## ⚙️ Yêu cầu hệ thống

- PHP 7.4+
- MySQL 5.7+
- Composer (tuỳ chọn)
- Node.js (tuỳ chọn, nếu dùng AI service)

## 📁 Cấu trúc thư mục

```
ai-recruitment-platform/
├── config/              # Cấu hình ứng dụng
│   ├── config.php      # Biến toàn cục
│   ├── database.php    # Kết nối database
│   └── init.php        # Khởi tạo ứng dụng
├── models/             # Lớp model (ORM)
│   ├── User.php
│   ├── Job.php
│   ├── Application.php
│   ├── CandidateProfile.php
│   ├── RecruiterProfile.php
│   ├── Message.php
│   └── Notification.php
├── controllers/        # Lớp controller (logic)
│   ├── AuthController.php
│   ├── JobController.php
│   └── ApplicationController.php
├── middleware/         # Middleware (xác thực, phân quyền)
│   └── Auth.php
├── views/              # Giao diện người dùng
│   ├── admin/
│   ├── recruiter/
│   └── candidate/
├── utils/              # Tiện ích hỗ trợ
│   └── Helpers.php
├── uploads/            # Thư mục lưu tệp tải lên
│   ├── cv/
│   └── images/
├── api.php             # API endpoints
├── login.php           # Trang đăng nhập
├── register.php        # Trang đăng ký
├── logout.php          # Thoát đăng nhập
├── index.php           # Trang chủ
└── README.md           # File hướng dẫn này
```

## 🚀 Hướng dẫn cài đặt

### Bước 1: Cải đặt cơ sở dữ liệu

1. Mở phpMyAdmin (http://localhost/phpmyadmin)
2. Tạo database mới: `ai_recruitment`
3. Chọn database vừa tạo
4. Vào tab "Import"
5. Chọn file SQL (code được cung cấp)
6. Click "Go"

### Bước 2: Cấu hình ứng dụng

1. Mở `config/config.php`
2. Cấu hình:
   - `BASE_URL`: Đường dẫn cơ sở (VD: http://localhost/ai-recruitment-platform/)
   - `UPLOAD_PATH`: Đường dẫn lưu tệp
   - `AI_SERVICE_URL`: URL của AI service (nếu có)

3. Mở `config/database.php`
4. Cập nhật thông tin kết nối database:
   ```php
   private $host = "localhost";
   private $db_name = "ai_recruitment";
   private $username = "root";
   private $password = "";
   ```

### Bước 3: Tạo thư mục uploads

```bash
mkdir -p uploads/cv
mkdir -p uploads/images
chmod 755 uploads/cv uploads/images
```

### Bước 4: Truy cập ứng dụng

- Mở trình duyệt: http://localhost/ai-recruitment-platform/

## 👤 Tài khoản test

| Vai trò | Email | Mật khẩu | Ghi chú |
|--------|-------|----------|--------|
| Admin | admin@airecruitment.com | admin123 | Quản trị viên hệ thống |
| Recruiter | recruiter@test.com | 123456 | Nhà tuyển dụng test |
| Candidate | candidate@test.com | 123456 | Ứng viên test |

## 🔑 Tính năng chính

### 1. Xác thực & Phân quyền
- Đăng ký tài khoản (candidate/recruiter)
- Xác minh email
- Phân quyền dựa trên vai trò
- Bảo mật CSRF token

### 2. Quản lý hồ sơ
- Cập nhật thông tin cá nhân
- Tải CV
- Liên kết mạng xã hội
- Mong muốn công việc

### 3. Tin tuyển dụng
- Tạo/chỉnh sửa/xóa tin
- Tìm kiếm nâng cao
- Lọc theo kỹ năng, địa điểm, ngành
- Full-text search

### 4. Ứng tuyển
- Apply vị trí công việc
- Theo dõi trạng thái
- Rút đơn
- AI matching score

### 5. Tin nhắn & Thông báo
- Gửi tin nhắn giữa recruiter/candidate
- Thông báo thời gian thực
- Đánh dấu đã đọc

### 6. Quản lý (Admin)
- Quản lý người dùng
- Xác thực công ty
- Xử lý báo cáo

## 🤖 Tích hợp AI

### Các tính năng AI

1. **CV Parsing**
   - Phân tích tự động CV
   - Trích xuất thông tin: kỹ năng, kinh nghiệm, giáo dục

2. **Candidate Matching**
   - So sánh ứng viên với yêu cầu công việc
   - Tính điểm tương thích (0-100%)

3. **Job Recommendations**
   - Gợi ý công việc dựa trên hồ sơ
   - Gợi ý ứng viên dựa trên tin tuyển dụng

4. **Interview Questions**
   - Tạo câu hỏi phỏng vấn tự động
   - Tùy chỉnh theo vị trí

### Cách tích hợp AI Service

Sửa `config/config.php`:
```php
define('AI_SERVICE_URL', 'http://localhost:8000/api/');
```

API endpoints:
- POST `/api/analyze-cv` - Phân tích CV
- POST `/api/match-score` - Tính điểm matching
- POST `/api/generate-questions` - Tạo câu hỏi

## 📊 Database Schema

### Các bảng chính:

1. **users** - Thông tin người dùng
2. **candidate_profiles** - Hồ sơ ứng viên
3. **recruiter_profiles** - Hồ sơ công ty
4. **jobs** - Tin tuyển dụng
5. **applications** - Đơn apply
6. **messages** - Tin nhắn
7. **notifications** - Thông báo
8. **ai_logs** - Ghi nhật ký AI
9. **system_logs** - Ghi nhật ký hệ thống

Xem file SQL để biết chi tiết.

## 🔒 Bảo mật

### Các biện pháp bảo mật đã áp dụng:

- ✅ Mã hóa mật khẩu (bcrypt)
- ✅ CSRF token protection
- ✅ SQL Injection prevention (prepared statements)
- ✅ XSS prevention (sanitization)
- ✅ Rate limiting
- ✅ Session security
- ✅ Security headers

## 📝 Hướng dẫn sử dụng API

### Ví dụ: Tạo tin tuyển dụng

```bash
POST /api.php?action=create-job HTTP/1.1
Content-Type: application/x-www-form-urlencoded

title=Senior Developer&job_type=full_time&city=Ha Noi&required_skills=PHP,MySQL
```

### Ví dụ: Apply vị trí công việc

```bash
POST /api.php?action=apply-job HTTP/1.1
Content-Type: application/x-www-form-urlencoded

job_id=1&cover_letter=Tôi quan tâm...
```

## 🛠️ Phát triển thêm

### Cài đặt dependencies (tuỳ chọn)

```bash
# Nếu sử dụng composer
composer install
```

### Các packages khuyến nghị:

- `PHPMailer` - Gửi email
- `AWS SDK` - Lưu trữ cloud
- `Stripe` - Thanh toán trực tuyến
- `Socket.io` - Realtime messaging

## 🐛 Troubleshooting

### Lỗi: "Database connection failed"
- Kiểm tra thông tin kết nối trong `config/database.php`
- Đảm bảo MySQL đang chạy
- Kiểm tra tên database

### Lỗi: "Permission denied" (uploads)
```bash
chmod -R 755 uploads/
```

### Lỗi: Session không hoạt động
- Kiểm tra folder `tmp` của PHP
- Cấp quyền ghi cho thư mục session

## 📞 Hỗ trợ

Nếu gặp vấn đề:
1. Kiểm tra console browser (F12)
2. Xem logs trong `system_logs` table
3. Kiểm tra Apache/PHP error logs

## 📄 License

MIT License - Tự do sử dụng cho mục đích thương mại và cá nhân.

## 👨‍💼 Tác giả

Tạo bởi AI Assistant - 2024

---

**Chúc bạn sử dụng ứng dụng vui vẻ! 🎉**
