<?php
require_once 'config/init.php';
require_once 'utils/middleware/Auth.php';

addSecurityHeaders();

if (isLoggedIn()) {
    redirect('index.php');
}

$authController = new AuthController();
$result = $authController->register();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký - AI Recruitment</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900">
    <div class="min-h-screen flex items-center justify-center p-4 py-8">
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border-2 border-slate-200 dark:border-slate-700 p-8 w-full max-w-md">
            <div class="text-center mb-8">
                <h1 class="text-4xl font-extrabold text-blue-600 dark:text-blue-400">AI Recruitment</h1>
                <p class="text-slate-600 dark:text-slate-300 mt-2 font-medium">Đăng ký tài khoản mới</p>
            </div>

            <?php if ($result && !$result['success']): ?>
                <div class="bg-red-100 dark:bg-red-900/40 border-2 border-red-400 dark:border-red-700 text-red-800 dark:text-red-300 px-4 py-3 rounded-lg mb-4 font-bold">
                    <?php echo htmlspecialchars($result['message']); ?>
                </div>
            <?php elseif ($result && $result['success']): ?>
                <div class="bg-green-100 dark:bg-green-900/40 border-2 border-green-400 dark:border-green-700 text-green-800 dark:text-green-300 px-4 py-3 rounded-lg mb-4 font-bold">
                    <?php echo htmlspecialchars($result['message']); ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="space-y-4">
                <div>
                    <label class="block text-slate-900 dark:text-white font-bold mb-2">Loại tài khoản</label>
                    <select name="role" id="role" required class="w-full border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2.5 focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 font-medium">
                        <option value="">-- Chọn loại tài khoản --</option>
                        <option value="candidate">Ứng viên tìm việc</option>
                        <option value="recruiter">Nhà tuyển dụng</option>
                    </select>
                </div>

                <div>
                    <label class="block text-slate-900 dark:text-white font-bold mb-2">Họ và tên</label>
                    <input type="text" name="full_name" required class="w-full border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2.5 focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 font-medium">
                </div>

                <div>
                    <label class="block text-slate-900 dark:text-white font-bold mb-2">Email</label>
                    <input type="email" name="email" required class="w-full border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2.5 focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 font-medium">
                </div>

                <div>
                    <label class="block text-slate-900 dark:text-white font-bold mb-2">Số điện thoại</label>
                    <input type="tel" name="phone" placeholder="0912345678" class="w-full border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2.5 focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 font-medium">
                </div>

                <!-- Recruiter fields -->
                <div id="recruiter-fields" class="hidden space-y-4">
                    <div>
                        <label class="block text-slate-900 dark:text-white font-bold mb-2">Tên công ty</label>
                        <input type="text" name="company_name" class="w-full border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2.5 focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 font-medium">
                    </div>
                    <div>
                        <label class="block text-slate-900 dark:text-white font-bold mb-2">Quy mô công ty</label>
                        <select name="company_size" class="w-full border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2.5 focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 font-medium">
                            <option value="">-- Chọn quy mô --</option>
                            <option value="1-10">1-10 người</option>
                            <option value="11-50">11-50 người</option>
                            <option value="51-200">51-200 người</option>
                            <option value="201-500">201-500 người</option>
                            <option value="501-1000">501-1000 người</option>
                            <option value="1000+">1000+ người</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-900 dark:text-white font-bold mb-2">Ngành công nghiệp</label>
                        <input type="text" name="industry" placeholder="VD: Công nghệ thông tin" class="w-full border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2.5 focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 font-medium">
                    </div>
                </div>

                <div>
                    <label class="block text-slate-900 dark:text-white font-bold mb-2">Mật khẩu</label>
                    <input type="password" name="password" required class="w-full border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2.5 focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 font-medium">
                </div>

                <div>
                    <label class="block text-slate-900 dark:text-white font-bold mb-2">Xác nhận mật khẩu</label>
                    <input type="password" name="confirm_password" required class="w-full border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-4 py-2.5 focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 font-medium">
                </div>

                <button type="submit" class="w-full bg-blue-600 dark:bg-blue-500 text-white font-bold py-3 rounded-lg hover:bg-blue-700 dark:hover:bg-blue-600 transition shadow-lg shadow-blue-500/30">
                    Đăng ký
                </button>
            </form>

            <div class="mt-6 text-center">
                <p class="text-slate-600 dark:text-slate-300 font-medium">Đã có tài khoản?</p>
                <a href="login.php" class="text-blue-600 dark:text-blue-400 font-bold hover:underline">Đăng nhập →</a>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('role').addEventListener('change', function(e) {
            const recruiterFields = document.getElementById('recruiter-fields');
            if (e.target.value === 'recruiter') {
                recruiterFields.classList.remove('hidden');
            } else {
                recruiterFields.classList.add('hidden');
            }
        });
    </script>
</body>
</html>
