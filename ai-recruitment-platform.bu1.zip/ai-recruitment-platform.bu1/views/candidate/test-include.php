<?php
echo "Views/candidate test\n";
echo "Config path: " . realpath('../../../config/init.php') . "\n";
echo "File exists: " . (file_exists('../../../config/init.php') ? 'YES' : 'NO') . "\n";
echo "Utils middleware path: " . realpath('../../../utils/middleware/Auth.php') . "\n";
echo "Utils middleware exists: " . (file_exists('../../../utils/middleware/Auth.php') ? 'YES' : 'NO') . "\n";
?>
