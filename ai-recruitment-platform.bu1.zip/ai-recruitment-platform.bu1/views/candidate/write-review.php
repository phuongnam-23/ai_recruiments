<?php
require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/CompanyReview.php';

addSecurityHeaders();
requireLogin();
requireRole('candidate');

$companyId = isset($_GET['company_id']) ? (int)$_GET['company_id'] : 0;
if (!$companyId) {
    redirect('../../index.php');
}

// Check if user has already reviewed
$reviewModel = new CompanyReview();
$hasReviewed = $reviewModel->hasReviewed($companyId, $_SESSION['user_id']);

// If already reviewed and trying to edit
$existingReview = null;
if ($hasReviewed) {
    // Get existing review to prefill form
    $db = (new Database())->getConnection();
    $stmt = $db->prepare("SELECT * FROM company_reviews WHERE company_id = ? AND reviewer_id = ? LIMIT 1");
    $stmt->execute([$companyId, $_SESSION['user_id']]);
    $existingReview = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Get company info - company_id là recruiter_profiles.id
$db = (new Database())->getConnection();
$stmt = $db->prepare("SELECT rp.* FROM recruiter_profiles rp WHERE rp.id = ? LIMIT 1");
$stmt->execute([$companyId]);
$company = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$company) {
    redirect('../../index.php');
}

$pageTitle = $existingReview ? 'Chỉnh sửa đánh giá' : 'Viết đánh giá';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - AI Recruitment</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900">
    <!-- Navigation -->
    <nav class="bg-white dark:bg-slate-800 shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center gap-8">
                <a href="<?php echo BASE_URL; ?>index.php" class="text-2xl font-bold tracking-tight text-blue-500">AI Recruitment</a>
                <div class="hidden md:flex gap-6">
                    <a href="<?php echo BASE_URL; ?>index.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500">Trang chủ</a>
                    <a href="<?php echo BASE_URL; ?>views/public/jobs-list.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500">Tìm việc</a>
                    <a href="<?php echo BASE_URL; ?>views/public/companies.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500">Công ty</a>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <span class="text-slate-700 dark:text-slate-300">👤 <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                <a href="../candidate/dashboard.php" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded hover:bg-blue-500">
                    Trang cá nhân
                </a>
                <a href="../../logout.php" class="text-red-400 hover:underline">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-2xl mx-auto px-4 py-8">
        <a href="javascript:history.back()" class="text-blue-500 hover:underline mb-6 inline-block">← Quay lại</a>

        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-8">
            <div class="mb-8">
                <h1 class="text-3xl font-bold text-slate-900 dark:text-white mb-2">
                    <?php echo $pageTitle; ?>
                </h1>
                <p class="text-slate-600 dark:text-slate-400">
                    <?php echo htmlspecialchars($company['company_name'] ?? 'Công ty'); ?>
                </p>
            </div>

            <form id="review-form" method="POST" class="space-y-6">
                <input type="hidden" name="company_id" value="<?php echo $companyId; ?>">
                <?php 
                if (empty($_SESSION['csrf_token'])) {
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                }
                ?>
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                <!-- Rating Stars -->
                <div>
                    <label class="block text-sm font-semibold mb-3 text-slate-700 dark:text-slate-300">
                        <span class="text-red-500">*</span> Đánh giá sao (1-5)
                    </label>
                    <div class="flex gap-3 mb-2">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <button type="button" class="rating-star text-5xl hover:scale-110 transition cursor-pointer" data-rating="<?php echo $i; ?>" onclick="selectRating(<?php echo $i; ?>)">
                                ⭐
                            </button>
                        <?php endfor; ?>
                    </div>
                    <input type="hidden" id="rating-input" name="rating" value="<?php echo $existingReview['rating'] ?? 0; ?>" required>
                    <p class="text-sm text-slate-500 dark:text-slate-400">Chọn từ 1 đến 5 sao</p>
                </div>

                <!-- Title -->
                <div>
                    <label for="title" class="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">
                        <span class="text-red-500">*</span> Tiêu đề đánh giá
                    </label>
                    <input 
                        type="text" 
                        name="title" 
                        id="title" 
                        required 
                        placeholder="VD: Môi trường tuyệt vời, đội ngũ chuyên nghiệp"
                        value="<?php echo htmlspecialchars($existingReview['title'] ?? ''); ?>"
                        class="w-full px-4 py-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                </div>

                <!-- Job Position -->
                <div>
                    <label for="job_position" class="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">
                        <span class="text-red-500">*</span> Vị trí công việc
                    </label>
                    <input 
                        type="text" 
                        name="job_position" 
                        id="job_position" 
                        required 
                        placeholder="VD: Senior Developer, UI/UX Designer"
                        value="<?php echo htmlspecialchars($existingReview['job_position'] ?? ''); ?>"
                        class="w-full px-4 py-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                </div>

                <!-- Employment Status -->
                <div>
                    <label for="employment_status" class="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">
                        <span class="text-red-500">*</span> Trạng thái công việc
                    </label>
                    <select 
                        name="employment_status" 
                        id="employment_status" 
                        class="w-full px-4 py-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                        <option value="current_employee" <?php echo ($existingReview['employment_status'] ?? '') === 'current_employee' ? 'selected' : ''; ?>>
                            👨‍💼 Hiện đang làm việc
                        </option>
                        <option value="former_employee" <?php echo ($existingReview['employment_status'] ?? '') === 'former_employee' ? 'selected' : ''; ?>>
                            👤 Đã từng làm việc
                        </option>
                    </select>
                </div>

                <!-- Comment -->
                <div>
                    <label for="comment" class="block text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">
                        <span class="text-red-500">*</span> Nhận xét chi tiết
                    </label>
                    <textarea 
                        name="comment" 
                        id="comment" 
                        required 
                        rows="6"
                        placeholder="Chia sẻ trải nghiệm làm việc tại công ty. Bạn có thể nói về:&#10;- Môi trường làm việc&#10;- Lương thưởng&#10;- Cơ hội phát triển&#10;- Quản lý và đội ngũ&#10;- Work-life balance&#10;- Những điểm tốt và cần cải thiện"
                        class="w-full px-4 py-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                    ><?php echo htmlspecialchars($existingReview['comment'] ?? ''); ?></textarea>
                    <p class="text-sm text-slate-500 dark:text-slate-400 mt-2">Tối thiểu 50 ký tự</p>
                </div>

                <!-- Submit Buttons -->
                <div class="flex gap-3 pt-6 border-t border-slate-200 dark:border-slate-700">
                    <button 
                        type="button" 
                        onclick="history.back()" 
                        class="flex-1 px-6 py-3 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-700 dark:text-slate-300 font-semibold hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                    >
                        ✕ Hủy
                    </button>
                    <button 
                        type="submit" 
                        class="flex-1 px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-lg font-semibold transition transform hover:-translate-y-0.5 shadow-lg shadow-blue-500/30"
                    >
                        📤 <?php echo $existingReview ? 'Cập nhật đánh giá' : 'Gửi đánh giá'; ?>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 py-8 mt-16">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <p>&copy; 2024 AI Recruitment. Tất cả các quyền được bảo lưu.</p>
        </div>
    </footer>

    <script>
        function selectRating(rating) {
            document.getElementById('rating-input').value = rating;
            const stars = document.querySelectorAll('.rating-star');
            stars.forEach((star, index) => {
                if (index < rating) {
                    star.style.opacity = '1';
                    star.style.transform = 'scale(1)';
                } else {
                    star.style.opacity = '0.3';
                    star.style.transform = 'scale(0.8)';
                }
            });
        }

        // Initialize stars if editing
        const initialRating = document.getElementById('rating-input').value;
        if (initialRating > 0) {
            selectRating(parseInt(initialRating));
        }

        // Form submission
        document.getElementById('review-form').addEventListener('submit', async (e) => {
            e.preventDefault();

            const rating = parseInt(document.getElementById('rating-input').value);
            if (rating === 0) {
                alert('❌ Vui lòng chọn đánh giá sao');
                return;
            }

            const comment = document.getElementById('comment').value.trim();
            if (comment.length < 50) {
                alert('❌ Nhận xét phải có ít nhất 50 ký tự');
                return;
            }

            const submitBtn = document.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.textContent = '⏳ Đang gửi...';

            try {
                const formData = new FormData(e.target);
                formData.append('action', 'add-company-review');
                formData.append('rating', rating);

                const response = await fetch('../../api.php', {
                    method: 'POST',
                    body: formData
                });

                const responseText = await response.text();
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (parseError) {
                    console.error('JSON Parse Error:', parseError);
                    throw new Error('Server returned invalid JSON');
                }

                if (data.success) {
                    alert('✅ ' + data.message);
                    // Redirect back with success flag
                    window.location.href = '<?php echo isset($_GET['redirect']) ? $_GET['redirect'] : '../../index.php'; ?>';
                } else {
                    alert('❌ ' + data.message);
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            } catch (error) {
                console.error('Review Error:', error);
                alert('❌ Lỗi: ' + error.message);
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        });
    </script>
</body>
</html>
