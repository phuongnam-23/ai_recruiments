<?php
session_start();
require_once '../../config/init.php';
require_once '../../utils/models/Application.php';

// Simulate logged in as user 7
$_SESSION['user_id'] = 7;
$_SESSION['role'] = 'candidate';

$appModel = new Application();
$apps = $appModel->getApplicationsByCandidate(7, 1000, 0);

echo "=== Applications Data ===\n";
echo "Total applications: " . count($apps) . "\n\n";

if (count($apps) > 0) {
    foreach ($apps as $i => $app) {
        echo "Application " . ($i + 1) . ":\n";
        echo "  Job ID: " . ($app['job_id'] ?? 'NULL') . "\n";
        echo "  Job Title: " . ($app['job_title'] ?? 'NULL') . "\n";
        echo "  Status: " . ($app['status'] ?? 'NULL') . "\n";
        echo "  Applied At: " . ($app['applied_at'] ?? 'NULL') . "\n";
        echo "\n";
    }
} else {
    echo "No applications found\n";
}
?>
