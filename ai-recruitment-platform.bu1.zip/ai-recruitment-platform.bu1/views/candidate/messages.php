<?php
require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';

requireLogin();
addSecurityHeaders();

$role = $_SESSION['role'];
$conversationModel = new Conversation($conn);
$conversations = $conversationModel->getUserConversations($_SESSION['user_id'], $role);
$totalUnread = $conversationModel->getTotalUnread($_SESSION['user_id'], $role);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tin nhắn - AI Recruitment</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .message-item.sent { text-align: right; }
        .message-bubble { display: inline-block; max-width: 70%; }
        .message-item:not(.sent) .message-bubble { text-align: left; }
        .conversation-active { background: #e0e7ff; border-left: 4px solid #667eea; }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-white shadow-sm sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="<?php echo BASE_URL; ?>index.php" class="text-2xl font-bold text-blue-600">AI Recruitment</a>
            <div class="flex items-center gap-4 text-sm">
                <a href="<?php echo $role === 'candidate' ? 'dashboard.php' : '../recruiter/dashboard.php'; ?>" class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition">Dashboard</a>
                <a href="<?php echo BASE_URL; ?>logout.php" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold text-gray-900 mb-2">Tin nhắn</h1>
        <p class="text-gray-600 mb-6">
            <?php echo $totalUnread > 0 ? "Bạn có $totalUnread tin nhắn chưa đọc" : "Tất cả tin nhắn đã được đọc"; ?>
        </p>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Conversations List -->
            <div class="md:col-span-1 bg-white rounded-xl shadow-lg overflow-hidden">
                <div class="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4">
                    <h2 class="font-semibold text-lg">Cuộc trò chuyện</h2>
                </div>
                
                <div class="divide-y max-h-[600px] overflow-y-auto" id="conversationsList">
                    <?php if (empty($conversations)): ?>
                        <div class="p-8 text-center text-gray-500">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-16 h-16 mx-auto mb-4 text-gray-300">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 01-.825-.242m9.345-8.334a2.126 2.126 0 00-.476-.095 48.64 48.64 0 00-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0011.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155" />
                            </svg>
                            <p>Chưa có cuộc trò chuyện nào</p>
                            <a href="<?php echo $role === 'candidate' ? 'search-jobs.php' : 'my-jobs.php'; ?>" class="text-blue-600 hover:underline mt-2 inline-block">
                                <?php echo $role === 'candidate' ? 'Tìm việc làm →' : 'Quản lý đơn ứng tuyển →'; ?>
                            </a>
                        </div>
                    <?php else: ?>
                        <?php foreach ($conversations as $conv): ?>
                            <?php
                            $partnerName = $role === 'candidate' ? $conv['recruiter_name'] : $conv['candidate_name'];
                            $partnerAvatar = $role === 'candidate' ? $conv['recruiter_avatar'] : $conv['candidate_avatar'];
                            $unreadCount = $role === 'candidate' ? $conv['candidate_unread_count'] : $conv['recruiter_unread_count'];
                            $initials = implode('', array_map(fn($n) => $n[0], explode(' ', $partnerName)));
                            ?>
                            <div class="conversation-item p-4 hover:bg-gray-50 cursor-pointer transition" 
                                 data-conversation-id="<?php echo $conv['id']; ?>"
                                 onclick="loadConversation(<?php echo $conv['id']; ?>)">
                                <div class="flex items-start gap-3">
                                    <div class="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold flex-shrink-0">
                                        <?php if ($partnerAvatar): ?>
                                            <img src="<?php echo $partnerAvatar; ?>" alt="<?php echo $partnerName; ?>" class="w-full h-full rounded-full object-cover">
                                        <?php else: ?>
                                            <?php echo strtoupper(substr($initials, 0, 2)); ?>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <div class="flex justify-between items-start">
                                            <h3 class="font-semibold text-gray-900 truncate"><?php echo htmlspecialchars($partnerName); ?></h3>
                                            <?php if ($unreadCount > 0): ?>
                                                <span class="bg-red-500 text-white text-xs px-2 py-1 rounded-full font-bold"><?php echo $unreadCount; ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="text-xs text-gray-500 truncate"><?php echo htmlspecialchars($conv['job_title']); ?></p>
                                        <p class="text-sm text-gray-600 truncate mt-1"><?php echo htmlspecialchars($conv['last_message'] ?: 'Chưa có tin nhắn'); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Messages Area -->
            <div class="md:col-span-2 bg-white rounded-xl shadow-lg overflow-hidden flex flex-col" style="height: 700px;">
                <div id="emptyState" class="flex-1 flex items-center justify-center text-gray-500">
                    <div class="text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-20 h-20 mx-auto mb-4 text-gray-300">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 01-2.555-.337A5.972 5.972 0 015.41 20.97a5.969 5.969 0 01-.474-.065 4.48 4.48 0 00.978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z" />
                        </svg>
                        <p>Chọn một cuộc trò chuyện để bắt đầu</p>
                    </div>
                </div>

                <div id="chatArea" class="hidden flex flex-col h-full">
                    <!-- Header -->
                    <div class="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 flex items-center gap-3">
                        <div class="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center" id="chatPartnerAvatar"></div>
                        <div>
                            <h3 class="font-semibold" id="chatPartnerName"></h3>
                            <p class="text-xs text-blue-100" id="chatJobTitle"></p>
                        </div>
                    </div>

                    <!-- Messages Container -->
                    <div class="flex-1 p-4 overflow-y-auto bg-gray-50" id="messagesContainer">
                        <!-- Messages will load here -->
                    </div>

                    <!-- Input Area -->
                    <div class="p-4 bg-white border-t">
                        <form onsubmit="sendMessage(event)" class="flex gap-2">
                            <input type="text" id="messageInput" placeholder="Nhập tin nhắn..." 
                                   class="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600" 
                                   autocomplete="off">
                            <button type="submit" class="px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:opacity-90 transition font-medium">
                                Gửi
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let currentConversationId = null;
        let pollingInterval = null;
        let lastMessageTime = null;
        const userId = <?php echo $_SESSION['user_id']; ?>;
        const userRole = '<?php echo $role; ?>';

        function loadConversation(conversationId) {
            currentConversationId = conversationId;
            
            // Highlight active conversation
            document.querySelectorAll('.conversation-item').forEach(el => {
                el.classList.remove('conversation-active');
            });
            document.querySelector(`[data-conversation-id="${conversationId}"]`).classList.add('conversation-active');
            
            fetch(`../../api.php?action=get-conversation&id=${conversationId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        renderMessages(data.conversation, data.messages);
                        markAsRead(conversationId);
                        startMessagePolling();
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        function renderMessages(conversation, messages) {
            const partnerName = userRole === 'candidate' ? conversation.recruiter_name : conversation.candidate_name;
            const partnerAvatar = userRole === 'candidate' ? conversation.recruiter_avatar : conversation.candidate_avatar;
            const initials = partnerName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
            
            // Update header
            document.getElementById('chatPartnerAvatar').innerHTML = partnerAvatar 
                ? `<img src="${partnerAvatar}" class="w-full h-full rounded-full object-cover">` 
                : initials;
            document.getElementById('chatPartnerName').textContent = partnerName;
            document.getElementById('chatJobTitle').textContent = `${conversation.job_title} - ${conversation.company_name}`;
            
            // Render messages
            const container = document.getElementById('messagesContainer');
            container.innerHTML = messages.map(msg => {
                const isSent = msg.sender_id == userId;
                const senderInitials = msg.sender_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
                
                return `
                    <div class="message-item mb-4 ${isSent ? 'sent' : ''}">
                        <div class="message-bubble ${isSent ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white' : 'bg-white'} p-3 rounded-lg shadow">
                            ${escapeHtml(msg.message)}
                        </div>
                        <div class="text-xs text-gray-500 mt-1">${formatTime(msg.created_at)}</div>
                    </div>
                `;
            }).join('');
            
            if (messages.length > 0) {
                lastMessageTime = messages[messages.length - 1].created_at;
            }
            
            // Show chat area
            document.getElementById('emptyState').classList.add('hidden');
            document.getElementById('chatArea').classList.remove('hidden');
            
            // Scroll to bottom
            container.scrollTop = container.scrollHeight;
        }

        function sendMessage(event) {
            event.preventDefault();
            
            const input = document.getElementById('messageInput');
            const message = input.value.trim();
            
            if (!message || !currentConversationId) return;
            
            fetch('../../api.php?action=send-message', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    conversation_id: currentConversationId,
                    message: message
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    input.value = '';
                    appendMessage(data.message);
                    lastMessageTime = data.message.created_at;
                }
            })
            .catch(error => console.error('Error:', error));
        }

        function appendMessage(message) {
            const container = document.getElementById('messagesContainer');
            const isSent = message.sender_id == userId;
            const senderInitials = message.sender_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
            
            const html = `
                <div class="message-item mb-4 ${isSent ? 'sent' : ''}">
                    <div class="message-bubble ${isSent ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white' : 'bg-white'} p-3 rounded-lg shadow">
                        ${escapeHtml(message.message)}
                    </div>
                    <div class="text-xs text-gray-500 mt-1">${formatTime(message.created_at)}</div>
                </div>
            `;
            
            container.insertAdjacentHTML('beforeend', html);
            container.scrollTop = container.scrollHeight;
        }

        function startMessagePolling() {
            if (pollingInterval) clearInterval(pollingInterval);
            
            pollingInterval = setInterval(() => {
                if (currentConversationId && lastMessageTime) {
                    fetch(`../../api.php?action=poll-messages&conversation_id=${currentConversationId}&after=${encodeURIComponent(lastMessageTime)}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success && data.messages.length > 0) {
                                data.messages.forEach(msg => appendMessage(msg));
                                lastMessageTime = data.messages[data.messages.length - 1].created_at;
                            }
                        })
                        .catch(error => console.error('Error:', error));
                }
            }, 3000);
        }

        function markAsRead(conversationId) {
            fetch('../../api.php?action=mark-conversation-read', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ conversation_id: conversationId })
            })
            .then(() => {
                // Remove unread badge
                const item = document.querySelector(`[data-conversation-id="${conversationId}"]`);
                const badge = item.querySelector('.bg-red-500');
                if (badge) badge.remove();
            });
        }

        function formatTime(timestamp) {
            const date = new Date(timestamp);
            const now = new Date();
            const diffMs = now - date;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMs / 3600000);
            const diffDays = Math.floor(diffMs / 86400000);
            
            if (diffMins < 1) return 'Vừa xong';
            if (diffMins < 60) return `${diffMins} phút trước`;
            if (diffHours < 24) return `${diffHours} giờ trước`;
            if (diffDays < 7) return `${diffDays} ngày trước`;
            
            return date.toLocaleDateString('vi-VN');
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    </script>
</body>
</html>
