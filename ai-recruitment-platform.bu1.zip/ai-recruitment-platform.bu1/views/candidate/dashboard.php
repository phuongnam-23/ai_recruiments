<?php
/**
 * CANDIDATE DASHBOARD - FULL DATABASE VERSION
 * Features: Full Profile Fields (DOB, Gender, Skills, Address), Multi-CV, Preview, Main CV
 */

require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';

requireLogin();
requireRole('candidate');
addSecurityHeaders();

$candidateModel = new CandidateProfile();
$userModel = new User();
$appModel = new Application();
$savedJobModel = new SavedJob();

$profile = $candidateModel->getProfile($_SESSION['user_id']);
$user = $userModel->getUserById($_SESSION['user_id']);
$allApps = $appModel->getApplicationsByCandidate($_SESSION['user_id'], 1000, 0);

// Lọc bỏ các đơn đã rút
$apps = array_filter($allApps, function($app) {
    return $app['status'] !== 'withdrawn';
});

$currentMainCV = $profile['cv_file_url'] ?? '';

// Dashboard stats
$stats = [
    'new_jobs' => 0,
    'active_applications' => 0,
    'shortlisted_applications' => 0,
    'unread_messages' => 0,
    'profile_completion' => 0,
    'saved_jobs' => 0
];

// Get saved jobs count
$stats['saved_jobs'] = $savedJobModel->countSavedJobs($_SESSION['user_id']);

// Application breakdown
foreach ($apps as $application) {
    $status = $application['status'] ?? 'pending';
    if (in_array($status, ['pending', 'reviewing'])) {
        $stats['active_applications']++;
    }
    if ($status === 'shortlisted') {
        $stats['shortlisted_applications']++;
    }
}

// Profile completion score
$profileFields = ['bio', 'skills', 'experience_years', 'education_level', 'city', 'cv_file_url'];
$filledFields = 0;
foreach ($profileFields as $field) {
    $value = $profile[$field] ?? null;
    if (is_string($value)) {
        $value = trim($value);
    }
    if (!empty($value)) {
        $filledFields++;
    }
}
if (count($profileFields) > 0) {
    $stats['profile_completion'] = (int)round(($filledFields / count($profileFields)) * 100);
}
$profileStatusLabel = 'Cần bổ sung thêm thông tin';
if ($stats['profile_completion'] >= 80) {
    $profileStatusLabel = 'Hồ sơ đã sẵn sàng phỏng vấn';
} elseif ($stats['profile_completion'] >= 50) {
    $profileStatusLabel = 'Đã khá đầy đủ, nên tối ưu thêm';
}

// Fetch new jobs (last 7 days) and unread messages
try {
    $db = new Database();
    $conn = $db->getConnection();

    $jobStmt = $conn->prepare("SELECT COUNT(*) FROM jobs WHERE status = 'active' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
    $jobStmt->execute();
    $stats['new_jobs'] = (int)$jobStmt->fetchColumn();

    $msgStmt = $conn->prepare("SELECT COALESCE(SUM(candidate_unread_count), 0) FROM conversations WHERE candidate_id = :uid AND status = 'active'");
    $msgStmt->execute([':uid' => $_SESSION['user_id']]);
    $stats['unread_messages'] = (int)$msgStmt->fetchColumn();
} catch (Exception $e) {
    // Leave stats at default values if query fails
}

// Quét file CV
$cvDir = __DIR__ . '/../../utils/uploads/cv/';
$cvFiles = [];
if (is_dir($cvDir)) {
    $files = scandir($cvDir);
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..' && stripos($file, 'cv_' . $_SESSION['user_id']) === 0) {
            $path = '../../utils/uploads/cv/' . $file;
            $cvFiles[] = [
                'name' => $file, 'path' => $path, 'db_path' => 'utils/uploads/cv/' . $file,
                'ext' => strtolower(pathinfo($file, PATHINFO_EXTENSION)),
                'size' => filesize($cvDir.$file), 'date' => filemtime($cvDir.$file)
            ];
        }
    }
    usort($cvFiles, fn($a, $b) => ($a['db_path']===$currentMainCV ? -1 : ($b['db_path']===$currentMainCV ? 1 : $b['date']-$a['date'])));
}

if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

// Debug session
error_log('Dashboard loaded - User ID: ' . $_SESSION['user_id'] . ', Role: ' . $_SESSION['role']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ sơ ứng viên</title>
    <script>
        // Debug session info
        console.log('Session info:', {
            role: '<?php echo $_SESSION['role'] ?? 'NONE'; ?>',
            user_id: '<?php echo $_SESSION['user_id'] ?? 'NONE'; ?>',
            csrf_token: '<?php echo substr($_SESSION['csrf_token'] ?? '', 0, 10); ?>...'
        });
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/jszip/dist/jszip.min.js"></script>
    <script src="https://unpkg.com/docx-preview@0.1.1/dist/docx-preview.min.js"></script>
    <style>
        .tab-btn { transition: all 0.2s; border-bottom: 2px solid transparent; color: #9ca3af; }
        .tab-btn.active { border-color: #3b82f6; color: #3b82f6; font-weight: 600; }
        .form-input { background-color: #374151; border-color: #4b5563; color: white; }
        .form-input:focus { border-color: #3b82f6; outline: none; }
        /* Scrollbar */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #1f2937; }
        ::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #6b7280; }
        .docx-wrapper { background: #f3f4f6 !important; padding: 20px !important; }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 min-h-screen">
    
    <nav class="bg-white/90 dark:bg-gray-900/80 backdrop-blur-md shadow-lg shadow-slate-900/5 border-b border-slate-200 dark:border-slate-700 sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 h-16 flex justify-between items-center">
            <div class="flex items-center gap-8">
                <a href="<?php echo BASE_URL; ?>index.php" class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition">AI Recruitment</a>
                <div class="hidden md:flex gap-6 text-sm">
                    <a href="<?php echo BASE_URL; ?>index.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 font-medium transition">Trang chủ</a>
                    <a href="<?php echo BASE_URL; ?>views/public/jobs-list.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 font-medium transition">Việc làm</a>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <?php include __DIR__ . '/../../components/notification-bell.php'; ?>
                <div class="relative group dropdown-group" style="padding-bottom: 8px;">
                    <button class="flex items-center gap-2 text-gray-700 hover:text-gray-900 font-medium transition dropdown-btn">
                        <img src="<?php 
                            if (!empty($user['avatar_url'])) {
                                // Nếu đã có http hoặc ui-avatars, dùng luôn
                                if (strpos($user['avatar_url'], 'http') === 0 || strpos($user['avatar_url'], 'ui-avatars') === 0) {
                                    echo $user['avatar_url'];
                                } else {
                                    // Nếu là path tương đối, thêm BASE_URL
                                    echo BASE_URL . $user['avatar_url'];
                                }
                            } else {
                                echo 'https://ui-avatars.com/api/?name=' . urlencode($user['full_name']);
                            }
                        ?>" class="w-8 h-8 rounded-full border border-slate-300/50 dark:border-slate-600/50 object-cover" id="nav-avatar" alt="avatar">
                        <span><?php echo htmlspecialchars($user['full_name']); ?></span>
                        <span class="text-slate-500 dark:text-slate-400">▼</span>
                    </button>
                    <div class="hidden group-hover:block absolute right-0 mt-0 bg-white shadow-xl rounded-xl min-w-[200px] z-10 border border-gray-200 overflow-hidden dropdown-menu">
                        <a href="<?php echo BASE_URL; ?>views/candidate/dashboard.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100 transition"><i class="fa-solid fa-chart-line w-6"></i> Dashboard</a>
                        <a href="<?php echo BASE_URL; ?>views/candidate/profile.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100 transition"><i class="fa-solid fa-user w-6"></i> Hồ sơ</a>
                        <a href="<?php echo BASE_URL; ?>views/candidate/applications.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100 transition"><i class="fa-solid fa-file w-6"></i> Đơn ứng tuyển</a>
                        <a href="<?php echo BASE_URL; ?>views/candidate/saved-jobs.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100 transition"><i class="fa-solid fa-bookmark w-6"></i> Tin đã lưu</a>
                        <a href="<?php echo BASE_URL; ?>views/candidate/upload-cv.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100 transition"><i class="fa-solid fa-file-pdf w-6"></i> Tải CV</a>
                        <div class="border-t border-gray-200"></div>
                        <a href="<?php echo BASE_URL; ?>logout.php" class="block px-4 py-3 text-red-600 hover:bg-red-50 transition"><i class="fa-solid fa-right-from-bracket w-6"></i> Đăng xuất</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow p-8 mb-10 flex flex-col gap-6 lg:flex-row lg:items-center">
            <div class="flex items-center gap-4 flex-1">
                <div>
                    <img src="<?php echo !empty($user['avatar_url']) ? (strpos($user['avatar_url'], 'http') === 0 ? $user['avatar_url'] : BASE_URL . $user['avatar_url']) : 'https://ui-avatars.com/api/?name=' . urlencode($user['full_name']); ?>" alt="avatar" class="w-20 h-20 object-cover">
                </div>
                <div>
                    <p class="text-gray-600 text-sm">Chào mừng trở lại</p>
                    <h1 class="text-3xl font-bold text-gray-900"><?php echo htmlspecialchars($user['full_name']); ?></h1>
                    <p class="text-gray-500 text-sm mt-1">Cập nhật ngày: <?php echo date('d/m/Y'); ?></p>
                </div>
            </div>
            <div class="flex gap-4 flex-wrap">
                <div class="px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">🔥 <?php echo $stats['new_jobs']; ?> job mới</div>
                <div class="px-4 py-2 bg-green-100 text-green-700 rounded-full text-sm font-medium">✉️ <?php echo $stats['unread_messages']; ?> tin nhắn</div>
                <div class="px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-medium">📄 <?php echo $stats['active_applications']; ?> đơn đang xử lý</div>
            </div>
        </div>
        
        <!-- Include Edit Profile Modal -->
        <?php include __DIR__ . '/edit-profile-section.php'; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-10">
            <div class="bg-white rounded-lg shadow p-6">
                <p class="text-xs uppercase tracking-widest text-gray-500">Job mới 7 ngày</p>
                <div class="flex items-end justify-between mt-3">
                    <span class="text-4xl font-bold text-gray-900"><?php echo $stats['new_jobs']; ?></span>
                    <span class="text-sm text-green-600">công việc</span>
                </div>
                <p class="text-sm text-gray-600 mt-4">Tăng cơ hội ứng tuyển sớm để được ưu tiên.</p>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <p class="text-xs uppercase tracking-widest text-gray-500">Đơn đang xử lý</p>
                <div class="flex items-end justify-between mt-3">
                    <span class="text-4xl font-bold text-gray-900"><?php echo $stats['active_applications']; ?></span>
                    <span class="text-sm text-green-600">+<?php echo $stats['shortlisted_applications']; ?> shortlisted</span>
                </div>
                <p class="text-sm text-gray-600 mt-4">Theo dõi tình trạng để phản hồi nhanh với nhà tuyển dụng.</p>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <p class="text-xs uppercase tracking-widest text-gray-500">Tin nhắn chưa đọc</p>
                <div class="flex items-end justify-between mt-3">
                    <span class="text-4xl font-bold text-gray-900"><?php echo $stats['unread_messages']; ?></span>
                    <span class="text-sm text-blue-600">cuộc trò chuyện</span>
                </div>
                <p class="text-sm text-gray-600 mt-4">Giữ liên lạc để không bỏ lỡ lịch phỏng vấn.</p>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center justify-between">
                    <p class="text-xs uppercase tracking-widest text-gray-500">Hồ sơ của bạn</p>
                    <span class="text-sm text-gray-700"><?php echo $stats['profile_completion']; ?>%</span>
                </div>
                <p class="text-xl font-semibold text-gray-900 mt-2"><?php echo $profileStatusLabel; ?></p>
                <div class="w-full h-2 rounded-full bg-gray-200 mt-4 overflow-hidden">
                    <div class="h-full bg-gradient-to-r from-green-400 to-blue-500" style="width: <?php echo min(100, $stats['profile_completion']); ?>%"></div>
                </div>
                <p class="text-xs text-gray-600 mt-3">Hoàn thiện thêm bio, kỹ năng hoặc CV để tăng điểm chất lượng.</p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <div class="lg:col-span-1 space-y-6">
            <!-- Profile Card -->
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-gray-500 text-xs uppercase tracking-wider font-semibold">Hồ sơ cá nhân</h3>
                    <a href="profile.php" class="text-xs text-blue-500 hover:underline font-semibold">
                        Xem đầy đủ →
                    </a>
                </div>
                
                <div class="space-y-3">
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-xl font-bold">
                            <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                        </div>
                        <div class="flex-1">
                            <p class="font-semibold text-gray-900"><?php echo htmlspecialchars($user['full_name']); ?></p>
                            <p class="text-xs text-gray-500"><?php echo htmlspecialchars($user['email']); ?></p>
                        </div>
                    </div>
                    
                    <div class="pt-3 border-t border-gray-200 space-y-2 text-sm">
                        <?php if (!empty($profile['city'])): ?>
                        <div class="flex items-center gap-2 text-gray-600">
                            <i class="fa-solid fa-location-dot w-4 text-blue-500"></i>
                            <span><?php echo htmlspecialchars($profile['city']); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($profile['experience_years'])): ?>
                        <div class="flex items-center gap-2 text-gray-600">
                            <i class="fa-solid fa-briefcase w-4 text-green-500"></i>
                            <span><?php echo $profile['experience_years']; ?> năm kinh nghiệm</span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($profile['education_level'])): ?>
                        <div class="flex items-center gap-2 text-gray-600">
                            <i class="fa-solid fa-graduation-cap w-4 text-purple-500"></i>
                            <span><?php echo htmlspecialchars($profile['education_level']); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <a href="profile.php" class="block w-full text-center bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-2.5 rounded-lg font-semibold transition shadow-md mt-4">
                        <i class="fa-solid fa-user-pen mr-2"></i>Chỉnh sửa hồ sơ
                    </a>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-gray-500 text-xs uppercase tracking-wider mb-4 font-semibold">Tổng quan</h3>
                <div class="grid grid-cols-2 gap-4">
                    <div class="bg-gray-100 p-4 rounded-xl cursor-pointer hover:bg-gray-200 transition" id="applicationsBtn">
                        <span class="text-2xl font-bold text-blue-600 block"><?php echo count($apps); ?></span>
                        <span class="text-xs text-gray-600">Đã ứng tuyển</span>
                    </div>
                    <a href="saved-jobs.php" class="bg-yellow-50 p-4 rounded-xl cursor-pointer hover:bg-yellow-100 transition border border-yellow-200">
                        <span class="text-2xl font-bold text-yellow-600 block"><?php echo $stats['saved_jobs']; ?></span>
                        <span class="text-xs text-gray-600">Tin đã lưu</span>
                    </a>
                    <div class="bg-gray-100 p-4 rounded-2xl flex flex-col justify-between h-full">
                        <div class="flex justify-between items-start">
                            <span class="text-xs text-gray-600 uppercase font-bold">Điểm hồ sơ</span>
                            <button id="btn-analyze-cv" class="text-xs bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-2 py-1 rounded-lg transition shadow-md shadow-purple-500/20 flex items-center gap-1">
                                <i class="fa-solid fa-wand-magic-sparkles"></i> Chấm điểm AI
                            </button>
                        </div>
                        <div class="mt-2 flex items-end gap-2">
                            <span id="score-display" class="text-3xl font-bold text-gray-900">
                                <?php echo $profile['cv_score'] > 0 ? $profile['cv_score'] : '--'; ?>
                            </span>
                            <span class="text-sm text-gray-600 mb-1">/ 100</span>
                        </div>
                        <?php if (!empty($profile['cv_analysis'])): ?>
                            <button onclick="document.getElementById('scoreDetailModal').classList.remove('hidden')" class="mt-2 text-xs text-blue-500 hover:underline text-left">
                                Xem chi tiết đánh giá →
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-gray-500 text-xs uppercase tracking-wider font-semibold">CV của bạn</h3>
                    <a href="upload-cv.php" class="text-xs px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">+ Thêm</a>
                </div>
                
                <?php if (empty($cvFiles)): ?>
                    <div class="text-center py-8 text-gray-600 text-sm border-2 border-dashed border-gray-300 rounded-xl">Chưa có CV nào</div>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php foreach (array_slice($cvFiles, 0, 3) as $cv): 
                            $isMain = ($cv['db_path'] === $currentMainCV);
                            $iconColor = $cv['ext'] === 'pdf' ? 'text-red-500' : 'text-blue-500';
                        ?>
                        <div class="group bg-gray-100 hover:bg-gray-200 p-3 rounded-xl border <?php echo $isMain?'border-green-500':'border-transparent'; ?> transition">
                            <div class="flex items-center gap-3">
                                <svg class="w-8 h-8 <?php echo $iconColor; ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center gap-2">
                                        <p class="text-sm font-medium text-gray-900 truncate" title="<?php echo $cv['name']; ?>"><?php echo $cv['name']; ?></p>
                                        <?php if($isMain): ?><span class="text-[10px] bg-green-100 text-green-700 px-1.5 rounded">Chính</span><?php endif; ?>
                                    </div>
                                    <p class="text-xs text-gray-600"><?php echo strtoupper($cv['ext']); ?> • <?php echo date('d/m', $cv['date']); ?></p>
                                </div>
                            </div>
                            <div class="flex gap-2 mt-3 pt-3 border-t border-gray-300 justify-end opacity-60 group-hover:opacity-100 transition">
                                <?php if(!$isMain): ?>
                                <button onclick="setMainCV('<?php echo addslashes($cv['name']); ?>')" class="text-xs text-gray-700 hover:text-yellow-600" title="Đặt làm chính">★ Chính</button>
                                <?php endif; ?>
                                <button onclick="previewFile('<?php echo addslashes($cv['path']); ?>', '<?php echo addslashes($cv['ext']); ?>', '<?php echo addslashes($cv['name']); ?>')" class="text-xs text-gray-700 hover:text-blue-600">Xem</button>
                                <button onclick="deleteCV('<?php echo addslashes($cv['name']); ?>')" class="text-xs text-gray-700 hover:text-red-600">Xóa</button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="lg:col-span-2">
            <div class="bg-white rounded-lg shadow overflow-hidden min-h-[600px]">
                <div class="flex border-b border-gray-200">
                    <button class="flex-1 py-4 text-center font-medium tab-btn active" onclick="openTab('view', this)">Thông tin hồ sơ</button>
                    <button class="flex-1 py-4 text-center font-medium tab-btn hover:bg-gray-100 transition" onclick="openTab('edit', this)">Chỉnh sửa</button>
                </div>

                <div id="tab-view" class="p-8 space-y-8" style="display: block;">
                    <!-- Avatar Section -->
                    <div class="mb-8 text-center pb-6 border-b border-gray-200">
                        <h3 class="text-lg font-bold text-gray-900 mb-4">Ảnh đại diện</h3>
                        <div class="flex justify-center">
                            <?php include __DIR__ . '/../../components/avatar-upload.php'; ?>
                        </div>
                    </div>

                    <div class="flex items-start gap-6 pb-8 border-b border-gray-200">
                        <div>
                            <h2 class="text-2xl font-bold text-gray-900"><?php echo htmlspecialchars($user['full_name']); ?></h2>
                            <p class="text-blue-600 mt-1"><?php echo htmlspecialchars($profile['city'] ?? 'Chưa cập nhật địa điểm'); ?></p>
                            <p class="text-gray-600 text-sm mt-2 leading-relaxed max-w-2xl">
                                <?php echo nl2br(htmlspecialchars($profile['bio'] ?? 'Chưa có thông tin giới thiệu. Hãy cập nhật để nhà tuyển dụng hiểu rõ hơn về bạn.')); ?>
                            </p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <h4 class="text-gray-500 text-xs uppercase font-semibold mb-4">Thông tin cá nhân</h4>
                            <ul class="space-y-4 text-sm">
                                <li class="flex justify-between border-b border-gray-200 pb-2">
                                    <span class="text-gray-600">Email</span>
                                    <span class="text-gray-900"><?php echo htmlspecialchars($user['email']); ?></span>
                                </li>
                                <li class="flex justify-between border-b border-gray-200 pb-2">
                                    <span class="text-gray-600">Số điện thoại</span>
                                    <span class="text-gray-900"><?php echo !empty($user['phone']) ? htmlspecialchars($user['phone']) : '--'; ?></span>
                                </li>
                                <li class="flex justify-between border-b border-gray-200 pb-2">
                                    <span class="text-gray-600">Ngày sinh</span>
                                    <span class="text-gray-900"><?php echo $profile['date_of_birth'] ? date('d/m/Y', strtotime($profile['date_of_birth'])) : '--'; ?></span>
                                </li>
                                <li class="flex justify-between border-b border-gray-200 pb-2">
                                    <span class="text-gray-600">Giới tính</span>
                                    <span class="text-gray-900"><?php echo $profile['gender'] === 'male' ? 'Nam' : ($profile['gender'] === 'female' ? 'Nữ' : 'Khác'); ?></span>
                                </li>
                                <li class="flex justify-between border-b border-gray-200 pb-2">
                                    <span class="text-gray-600">Địa chỉ</span>
                                    <span class="text-gray-900 truncate max-w-[200px]" title="<?php echo htmlspecialchars($profile['address']); ?>"><?php echo htmlspecialchars($profile['address'] ?? '--'); ?></span>
                                </li>
                            </ul>
                        </div>
                        
                        <div>
                            <h4 class="text-gray-500 text-xs uppercase font-semibold mb-4">Chuyên môn</h4>
                            <ul class="space-y-4 text-sm">
                                <li class="flex justify-between border-b border-gray-200 pb-2">
                                    <span class="text-gray-600">Kinh nghiệm</span>
                                    <span class="text-gray-900"><?php echo $profile['experience_years']; ?> năm</span>
                                </li>
                                <li class="flex justify-between border-b border-gray-200 pb-2">
                                    <span class="text-gray-600">Trình độ</span>
                                    <span class="text-gray-900">
                                        <?php 
                                            $edu = ['high_school'=>'THPT', 'associate'=>'Cao đẳng', 'bachelor'=>'Đại học', 'master'=>'Thạc sĩ', 'phd'=>'Tiến sĩ'];
                                            echo $edu[$profile['education_level']??''] ?? 'Chưa cập nhật';
                                        ?>
                                    </span>
                                </li>
                                <li>
                                    <span class="text-gray-600 block mb-2">Kỹ năng</span>
                                    <div class="flex flex-wrap gap-2">
                                        <?php 
                                        if(!empty($profile['skills'])): 
                                            // Loại bỏ tất cả ký tự đặc biệt thừa, chỉ giữ chữ, số, dấu ngoặc và khoảng trắng
                                            $cleanSkills = preg_replace('/[^\p{L}\p{N}\s,()]+/u', '', $profile['skills']);
                                            // Tách theo dấu phẩy
                                            $skills = explode(',', $cleanSkills);
                                            foreach($skills as $skill): 
                                                $cleanSkill = trim($skill);
                                                if(!empty($cleanSkill) && strlen($cleanSkill) > 1):
                                        ?>
                                            <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs border border-blue-300">
                                                <?php echo htmlspecialchars($cleanSkill); ?>
                                            </span>
                                        <?php endif; endforeach; else: ?>
                                            <span class="text-gray-600 italic">Chưa cập nhật kỹ năng</span>
                                        <?php endif; ?>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div id="tab-edit" class="p-8 space-y-6 hidden" style="display: none !important;">
                    <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start gap-3">
                        <span class="text-2xl">💡</span>
                        <div>
                            <p class="text-sm font-medium text-blue-700">AI Auto-fill</p>
                            <p class="text-xs text-blue-600 mt-1">Nhấn nút bên dưới để AI tự động phân tích CV của bạn và điền thông tin vào form</p>
                        </div>
                    </div>

                    <?php if (empty($currentMainCV)): ?>
                    <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-4 flex items-start gap-3">
                        <span class="text-2xl">⚠️</span>
                        <div>
                            <p class="text-sm font-medium text-yellow-700">Chưa có CV chính</p>
                            <p class="text-xs text-yellow-600 mt-1">Vui lòng <a href="upload-cv.php" class="text-yellow-700 hover:text-yellow-800 underline">tải CV</a> lên trước khi sử dụng tính năng AI Auto-fill</p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="flex gap-3">
                        <button id="btn-parse-cv" type="button" class="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold rounded-lg transition transform hover:scale-105" <?php echo empty($currentMainCV) ? 'disabled style="opacity:0.5; cursor:not-allowed;"' : ''; ?>>
                            <span>✨</span> Tự động điền thông tin từ CV
                        </button>
                        <button type="button" onclick="saveEditProfile()" class="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition">
                            💾 Lưu thay đổi
                        </button>
                    </div>

                    <form id="edit-form" class="space-y-6">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Họ tên đầy đủ</label>
                                <input type="text" name="full_name" id="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" class="form-input w-full px-4 py-2 rounded-lg" placeholder="Nhập họ tên">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Email</label>
                                <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" class="form-input w-full px-4 py-2 rounded-lg" placeholder="email@example.com">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Số điện thoại</label>
                                <input type="tel" name="phone" id="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" class="form-input w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500" placeholder="0912345678">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Ngày sinh</label>
                                <input type="date" name="date_of_birth" id="date_of_birth" value="<?php echo !empty($profile['date_of_birth']) ? date('Y-m-d', strtotime($profile['date_of_birth'])) : ''; ?>" class="form-input w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Giới tính</label>
                                <select name="gender" id="gender" class="form-input w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500">
                                    <option value="" <?php echo empty($profile['gender']) ? 'selected' : ''; ?>>-- Chọn giới tính --</option>
                                    <option value="male" <?php echo ($profile['gender'] ?? '') === 'male' ? 'selected' : ''; ?>>Nam</option>
                                    <option value="female" <?php echo ($profile['gender'] ?? '') === 'female' ? 'selected' : ''; ?>>Nữ</option>
                                    <option value="other" <?php echo ($profile['gender'] ?? '') === 'other' ? 'selected' : ''; ?>>Khác</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Thành phố</label>
                                <input type="text" name="city" id="city" value="<?php echo htmlspecialchars($profile['city'] ?? ''); ?>" class="form-input w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500" placeholder="Hà Nội, TP.HCM...">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Địa chỉ chi tiết</label>
                            <input type="text" name="address" id="address" value="<?php echo htmlspecialchars($profile['address'] ?? ''); ?>" class="form-input w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500" placeholder="Số nhà, đường, quận/huyện">
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Giới thiệu bản thân</label>
                            <textarea name="bio" id="bio" class="form-input w-full px-4 py-2 rounded-lg h-24" placeholder="Viết vài dòng về bạn..."><?php echo htmlspecialchars($profile['bio'] ?? ''); ?></textarea>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Trình độ</label>
                                <select name="education_level" id="education_level" class="form-input w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500">
                                    <option value="" <?php echo empty($profile['education_level']) ? 'selected' : ''; ?>>-- Chọn trình độ --</option>
                                    <option value="high_school" <?php echo ($profile['education_level'] ?? '') === 'high_school' ? 'selected' : ''; ?>>THPT</option>
                                    <option value="associate" <?php echo ($profile['education_level'] ?? '') === 'associate' ? 'selected' : ''; ?>>Cao đẳng</option>
                                    <option value="bachelor" <?php echo ($profile['education_level'] ?? '') === 'bachelor' ? 'selected' : ''; ?>>Đại học</option>
                                    <option value="master" <?php echo ($profile['education_level'] ?? '') === 'master' ? 'selected' : ''; ?>>Thạc sĩ</option>
                                    <option value="phd" <?php echo ($profile['education_level'] ?? '') === 'phd' ? 'selected' : ''; ?>>Tiến sĩ</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Kinh nghiệm (năm)</label>
                                <input type="number" name="experience_years" id="experience_years" value="<?php echo htmlspecialchars($profile['experience_years'] ?? 0); ?>" class="form-input w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500" placeholder="0" min="0" max="100">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Kỹ năng (ngăn cách bằng dấu phẩy)</label>
                            <input type="text" name="skills" id="skills" value="<?php echo htmlspecialchars($profile['skills'] ?? ''); ?>" class="form-input w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-blue-500" placeholder="PHP, MySQL, JavaScript, React...">
                            <p class="text-xs text-gray-500 mt-1">Ví dụ: PHP, MySQL, JavaScript, React, Node.js</p>
                        </div>

                        <div id="loading-spinner" class="hidden flex items-center gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                            <div class="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                            <span class="text-blue-700">Đang phân tích CV bằng AI...</span>
                        </div>

                        <div id="error-message" class="hidden p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm"></div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div id="preview-modal" class="fixed inset-0 bg-black/70 hidden z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-lg shadow-2xl w-full max-w-5xl h-[85vh] flex flex-col overflow-hidden">
            <div class="flex justify-between items-center p-4 bg-white border-b border-gray-200">
                <h3 class="font-bold text-gray-900 flex items-center gap-2">📄 <span id="preview-filename">File</span></h3>
                <button onclick="document.getElementById('preview-modal').classList.add('hidden')" class="text-3xl text-gray-500 hover:text-red-500">&times;</button>
            </div>
            <div class="flex-1 bg-gray-50 relative overflow-hidden">
                <div id="spinner" class="absolute inset-0 flex items-center justify-center bg-white z-10 hidden"><div class="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div></div>
                <div id="docx-container" class="w-full h-full overflow-auto hidden"></div>
                <iframe id="pdf-frame" class="w-full h-full hidden" src=""></iframe>
                <div id="preview-error" class="hidden flex items-center justify-center h-full text-gray-600">Không thể xem trước file này</div>
            </div>
        </div>
    </div>

    <script>
        // Define openTab globally BEFORE DOMContentLoaded
        function openTab(tabId, btn) {
            console.log('🟢 openTab called with tabId:', tabId);
            const tabView = document.getElementById('tab-view');
            const tabEdit = document.getElementById('tab-edit');
            
            console.log('tabView exists:', !!tabView);
            console.log('tabEdit exists:', !!tabEdit);
            
            if (tabId === 'view') {
                if (tabView) {
                    tabView.setAttribute('style', 'display: block !important;');
                    console.log('✅ Showing tab-view');
                }
                if (tabEdit) {
                    tabEdit.setAttribute('style', 'display: none !important;');
                    console.log('✅ Hiding tab-edit');
                }
            } else if (tabId === 'edit') {
                if (tabView) {
                    tabView.setAttribute('style', 'display: none !important;');
                    console.log('✅ Hiding tab-view');
                }
                if (tabEdit) {
                    tabEdit.setAttribute('style', 'display: block !important;');
                    console.log('✅ Showing tab-edit');
                }
            }
            
            // Update button active state
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            if (btn) btn.classList.add('active');
            console.log('✅ Tab buttons updated');
        }

        // ===== CV MANAGEMENT FUNCTIONS (Định nghĩa toàn cục) =====
        
        // Xem trước file CV
        window.previewFile = async function(filePath, fileExt, fileName) {
            console.log('📄 Preview file:', filePath, fileExt, fileName);
            const modal = document.getElementById('preview-modal');
            const spinner = document.getElementById('spinner');
            const docxContainer = document.getElementById('docx-container');
            const pdfFrame = document.getElementById('pdf-frame');
            const previewError = document.getElementById('preview-error');
            const previewFilename = document.getElementById('preview-filename');
            
            // Reset modal
            modal.classList.remove('hidden');
            docxContainer.classList.add('hidden');
            pdfFrame.classList.add('hidden');
            previewError.classList.add('hidden');
            spinner.classList.remove('hidden');
            previewFilename.textContent = fileName;
            
            // Xử lý đường dẫn tương đối: ../../utils/uploads/cv/file.pdf -> utils/uploads/cv/file.pdf
            let cleanPath = filePath.replace(/^\.\.\/\.\.\//, '');
            let fullPath = '<?php echo BASE_URL; ?>' + cleanPath;
            
            console.log('fullPath:', fullPath);
            
            try {
                if (fileExt.toLowerCase() === 'pdf') {
                    // PDF Preview
                    pdfFrame.src = fullPath;
                    pdfFrame.classList.remove('hidden');
                    spinner.classList.add('hidden');
                } else if (fileExt.toLowerCase() === 'docx') {
                    // DOCX Preview using docx-preview library
                    const response = await fetch(fullPath);
                    const arrayBuffer = await response.arrayBuffer();
                    docxContainer.innerHTML = ''; // Clear previous content
                    docxContainer.classList.remove('hidden');
                    await docx.renderAsync(arrayBuffer, docxContainer);
                    spinner.classList.add('hidden');
                } else {
                    previewError.classList.remove('hidden');
                    spinner.classList.add('hidden');
                }
            } catch (error) {
                console.error('Preview error:', error);
                previewError.classList.remove('hidden');
                spinner.classList.add('hidden');
            }
        }
        
        // Đặt CV làm chính
        window.setMainCV = async function(filename) {
            console.log('⭐ Set main CV:', filename);
            
            if (!confirm('Bạn có chắc muốn đặt CV này làm chính?')) {
                return;
            }
            
            try {
                const response = await fetch('<?php echo BASE_URL; ?>api.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        action: 'set-main-cv',
                        filename: filename,
                        csrf_token: document.querySelector('input[name="csrf_token"]').value
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('✅ ' + (data.message || 'Đã đặt CV chính thành công'));
                    location.reload();
                } else {
                    alert('❌ ' + (data.message || 'Lỗi cập nhật'));
                }
            } catch (error) {
                console.error('Error:', error);
                alert('❌ Lỗi: ' + error.message);
            }
        }
        
        // Xóa CV
        window.deleteCV = async function(filename) {
            console.log('🗑️ Delete CV:', filename);
            
            if (!confirm('Bạn có chắc muốn xóa CV này? Hành động này không thể hoàn tác.')) {
                return;
            }
            
            try {
                const response = await fetch('<?php echo BASE_URL; ?>api.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        action: 'delete-cv',
                        filename: filename,
                        csrf_token: document.querySelector('input[name="csrf_token"]').value
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('✅ ' + (data.message || 'Đã xóa CV thành công'));
                    location.reload();
                } else {
                    alert('❌ ' + (data.message || 'Lỗi xóa CV'));
                }
            } catch (error) {
                console.error('Error:', error);
                alert('❌ Lỗi: ' + error.message);
            }
        }

        document.addEventListener('DOMContentLoaded', function() {

            // ===== CV SCORING FUNCTIONS =====
            window.scoreCV = async function() {
                const btn = document.getElementById('btn-analyze-cv');
                const originalText = btn.innerHTML;
                
                const cvPath = '<?php echo htmlspecialchars($currentMainCV); ?>';
                
                if (!cvPath) {
                    alert('⚠️ Vui lòng tải CV lên trước khi chấm điểm');
                    return;
                }
                
                try {
                    btn.disabled = true;
                    btn.innerHTML = '⏳ Đang chấm điểm...';
                    
                    const response = await fetch('<?php echo BASE_URL; ?>api.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: new URLSearchParams({
                            action: 'analyze-cv',
                            cv_path: cvPath,
                            csrf_token: document.querySelector('input[name="csrf_token"]').value
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        alert('✅ ' + (data.message || 'CV đã được chấm điểm thành công'));
                        location.reload();
                    } else {
                        alert('❌ ' + (data.message || 'Lỗi khi chấm điểm CV'));
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('❌ Lỗi: ' + error.message);
                } finally {
                    btn.disabled = false;
                    btn.innerHTML = originalText;
                }
            }
            
            window.reScorecv = async function() {
                if (!confirm('Bạn có chắc muốn chấm điểm lại? Điểm cũ sẽ bị thay thế.')) return;
                
                const btn = document.getElementById('btn-rescore');
                const originalText = btn.innerHTML;
                
                const cvPath = '<?php echo htmlspecialchars($currentMainCV); ?>';
                
                if (!cvPath) {
                    alert('⚠️ Vui lòng tải CV lên trước khi chấm điểm');
                    return;
                }
                
                try {
                    btn.disabled = true;
                    btn.innerHTML = '⏳ Đang chấm điểm...';
                    
                    const response = await fetch('<?php echo BASE_URL; ?>api.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: new URLSearchParams({
                            action: 'analyze-cv',
                            cv_path: cvPath,
                            csrf_token: document.querySelector('input[name="csrf_token"]').value
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        location.reload();
                    } else {
                        alert('❌ ' + (data.message || 'Lỗi'));
                    }
                } catch (error) {
                    alert('❌ Lỗi: ' + error.message);
                } finally {
                    btn.disabled = false;
                    btn.innerHTML = originalText;
                }
            }
            
            window.downloadReport = function() {
                const analysis = <?php echo !empty($profile['cv_analysis']) ? json_encode(json_decode($profile['cv_analysis'], true)) : 'null'; ?>;
                if (!analysis) {
                    alert('Chưa có dữ liệu để xuất');
                    return;
                }
                const dataStr = JSON.stringify(analysis, null, 2);
                const dataBlob = new Blob([dataStr], { type: 'application/json' });
                const url = URL.createObjectURL(dataBlob);
                const link = document.createElement('a');
                link.href = url;
                link.download = 'cv-analysis-' + new Date().toISOString().split('T')[0] + '.json';
                link.click();
            }
            
            // Tab switching for analysis
            document.querySelectorAll('.tab-btn-analysis').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.tab-btn-analysis').forEach(b => {
                        b.classList.remove('active', 'bg-green-100', 'text-green-700');
                        b.classList.add('hover:bg-gray-100');
                    });
                    
                    this.classList.add('active', 'bg-green-100', 'text-green-700');
                    this.classList.remove('hover:bg-gray-100');
                    
                    document.querySelectorAll('.tab-content-analysis').forEach(content => {
                        content.classList.add('hidden');
                    });
                    
                    document.getElementById(this.dataset.tab).classList.remove('hidden');
                });
            });
            
            // Analyze CV Button
            const btnAnalyzeCV = document.getElementById('btn-analyze-cv');
            if (btnAnalyzeCV) {
                btnAnalyzeCV.addEventListener('click', scoreCV);
            }

            // Parse CV Button
            const btnParseCV = document.getElementById('btn-parse-cv');
            if (btnParseCV) {
                btnParseCV.addEventListener('click', async function() {
                    const cvPath = '<?php echo $currentMainCV; ?>';
                    console.log('🔍 Parse CV clicked, cvPath:', cvPath);
                    
                    if (!cvPath) {
                        console.log('❌ No CV path');
                        alert('⚠️ Vui lòng tải CV lên trước');
                        return;
                    }

                    console.log('✅ CV path valid, calling API...');
                    showLoading(true);
                    hideError();

                    try {
                        // Call parse CV API
                        console.log('📡 Fetching from api.php');
                        const response = await fetch('<?php echo BASE_URL; ?>api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: new URLSearchParams({
                                action: 'parse-cv',
                                cv_path: cvPath,
                                csrf_token: document.querySelector('input[name="csrf_token"]').value
                            })
                        });

                        console.log('📥 Response status:', response.status);
                        const text = await response.text();
                        console.log('📄 Response text:', text.substring(0, 500));
                        let data;
                        try {
                            data = JSON.parse(text);
                            console.log('✅ Parsed JSON:', data);
                        } catch (e) {
                            console.error('❌ Invalid JSON response:', text);
                            throw new Error('Server returned invalid response');
                        }

                        if (data.success && data.data) {
                            console.log('✅ Success, filling form...');
                            fillDataToForm(data.data);
                            alert('✅ Đã tự động điền thông tin từ CV');
                        } else {
                            console.log('❌ API error:', data.message);
                            showError(data.message || '❌ Lỗi khi phân tích CV');
                        }
                    } catch (error) {
                        console.error('❌ Error:', error);
                        showError('❌ Lỗi: ' + error.message);
                    } finally {
                        console.log('🏁 Hiding loading...');
                        showLoading(false);
                    }
                });
            }

            // Fill Data To Form
            function fillDataToForm(data) {
                // Map API response to form fields
                if (data.name) document.getElementById('full_name').value = data.name;
                if (data.email) document.getElementById('email').value = data.email;
                if (data.phone) document.getElementById('phone').value = data.phone;
                if (data.address) document.getElementById('address').value = data.address;
                if (data.summary) document.getElementById('bio').value = data.summary;
                
                // Skills: join array to comma-separated string
                if (data.skills && Array.isArray(data.skills)) {
                    document.getElementById('skills').value = data.skills.map(s => s.skill || s).join(', ');
                }
                
                // Experience years: only if it's a number
                if (data.experience_years && !isNaN(data.experience_years)) {
                    document.getElementById('experience_years').value = parseInt(data.experience_years);
                }
            }

            // Show/Hide Loading
            function showLoading(show) {
                const loader = document.getElementById('loading-spinner');
                if (loader) {
                    show ? loader.classList.remove('hidden') : loader.classList.add('hidden');
                }
            }

            // Show Error
            function showError(msg) {
                const errorEl = document.getElementById('error-message');
                if (errorEl) {
                    errorEl.textContent = msg;
                    errorEl.classList.remove('hidden');
                }
            }

            // Hide Error
            function hideError() {
                const errorEl = document.getElementById('error-message');
                if (errorEl) {
                    errorEl.classList.add('hidden');
                }
            }

            // Save Edit Profile
            window.saveEditProfile = function() {
                const form = document.getElementById('edit-form');
                const formData = new FormData(form);
                formData.append('action', 'update-candidate-profile');

                fetch('<?php echo BASE_URL; ?>api.php', {
                    method: 'POST',
                    body: formData
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        alert('✅ Cập nhật hồ sơ thành công');
                        setTimeout(() => location.reload(), 500);
                    } else {
                        alert('❌ ' + (data.message || 'Lỗi cập nhật'));
                    }
                })
                .catch(e => alert('❌ Lỗi: ' + e.message));
            }

            // Applications Modal
            const applicationsBtn = document.getElementById('applicationsBtn');
            const applicationsModal = document.getElementById('applicationsModal');
            const closeModalBtn = document.getElementById('closeModalBtn');
            
            if (applicationsBtn && applicationsModal && closeModalBtn) {
                applicationsBtn.addEventListener('click', () => {
                    applicationsModal.classList.remove('hidden');
                });
                
                closeModalBtn.addEventListener('click', () => {
                    applicationsModal.classList.add('hidden');
                });
                
                applicationsModal.addEventListener('click', (e) => {
                    if (e.target === applicationsModal) {
                        applicationsModal.classList.add('hidden');
                    }
                });
            }
        });
    </script>

    <!-- Score Detail Modal -->
    <div id="scoreDetailModal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-gray-200">
            <div class="sticky top-0 bg-white p-6 border-b border-gray-200 flex justify-between items-center">
                <h2 class="text-2xl font-bold text-gray-900">📊 Chi tiết đánh giá CV</h2>
                <button onclick="document.getElementById('scoreDetailModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
            </div>
            
            <div class="p-6 space-y-6">
                <?php 
                $cvScore = $profile['cv_score'] ?? 0;
                $analysis = !empty($profile['cv_analysis']) ? json_decode($profile['cv_analysis'], true) : [];
                
                if ($cvScore > 0 && !empty($analysis)): 
                ?>
                    <!-- Score Header -->
                    <div class="flex items-center gap-6 pb-6 border-b border-gray-200">
                        <div class="flex-shrink-0 text-center">
                            <div class="text-5xl font-bold <?php 
                                if ($cvScore >= 80) echo 'text-green-600';
                                elseif ($cvScore >= 60) echo 'text-yellow-600';
                                else echo 'text-red-600';
                            ?>">
                                <?php echo $cvScore; ?>
                            </div>
                            <div class="text-sm text-gray-600 mt-2">/ 100</div>
                            <div class="mt-3 px-3 py-1 rounded-full text-sm font-semibold <?php 
                                if ($cvScore >= 80) echo 'bg-green-100 text-green-700';
                                elseif ($cvScore >= 60) echo 'bg-yellow-100 text-yellow-700';
                                else echo 'bg-red-100 text-red-700';
                            ?>">
                                <?php echo $analysis['grade'] ?? 'N/A'; ?>
                            </div>
                        </div>
                        
                        <!-- Breakdown Criteria -->
                        <div class="flex-1 space-y-3">
                            <?php 
                            $criteria = [
                                'structure' => ['Structure & Format', 'text-blue-500', 20],
                                'content' => ['Content & Details', 'text-purple-500', 30],
                                'skills' => ['Technical Skills', 'text-pink-500', 30],
                                'clarity' => ['Clarity & Grammar', 'text-cyan-500', 20]
                            ];
                            
                            foreach ($criteria as $key => [$label, $color, $maxPoints]): 
                                $points = $analysis['breakdown'][$key] ?? 0;
                                $percentage = ($points / $maxPoints) * 100;
                            ?>
                            <div>
                                <div class="flex justify-between mb-1">
                                    <span class="text-xs font-semibold text-gray-700"><?php echo $label; ?></span>
                                    <span class="text-xs font-bold <?php echo $color; ?>"><?php echo $points; ?>/<?php echo $maxPoints; ?></span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="bg-gradient-to-r <?php echo match($key) {
                                        'structure' => 'from-blue-400 to-blue-600',
                                        'content' => 'from-purple-400 to-purple-600',
                                        'skills' => 'from-pink-400 to-pink-600',
                                        'clarity' => 'from-cyan-400 to-cyan-600'
                                    }; ?> h-2 rounded-full transition-all duration-500" 
                                         style="width: <?php echo $percentage; ?>%"></div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- 3-Column Grid Layout for Strengths, Weaknesses, Improvements -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        
                        <!-- Column 1: Điểm Mạnh (Strengths) -->
                        <div class="bg-gray-50 p-4 rounded-xl border border-gray-200">
                            <div class="flex items-center gap-2 mb-4">
                                <i class="fa-solid fa-check-circle text-green-600 text-lg"></i>
                                <h3 class="text-green-600 font-bold text-base">Điểm Mạnh</h3>
                            </div>
                            <div class="space-y-2">
                                <?php if (!empty($analysis['strengths']) && is_array($analysis['strengths'])): ?>
                                    <?php foreach ($analysis['strengths'] as $strength): ?>
                                    <div class="flex items-start gap-2 p-2 bg-white rounded-lg">
                                        <i class="fa-solid fa-check text-green-500 text-sm flex-shrink-0 mt-0.5"></i>
                                        <span class="text-sm text-gray-700"><?php echo htmlspecialchars($strength); ?></span>
                                    </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-sm text-gray-600 italic">Không có dữ liệu</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Column 2: Điểm Yếu (Weaknesses) -->
                        <div class="bg-slate-50 dark:bg-slate-700/50 p-4 rounded-xl border border-slate-200/50 dark:border-slate-700/50">
                            <div class="flex items-center gap-2 mb-4">
                                <i class="fa-solid fa-circle-exclamation text-red-600 dark:text-red-400 text-lg"></i>
                                <h3 class="text-red-600 dark:text-red-400 font-bold text-base">Điểm Yếu</h3>
                            </div>
                            <div class="space-y-2">
                                <?php if (!empty($analysis['weaknesses']) && is_array($analysis['weaknesses'])): ?>
                                    <?php foreach ($analysis['weaknesses'] as $weakness): ?>
                                    <div class="flex items-start gap-2 p-2 bg-white dark:bg-slate-800/50 rounded-lg">
                                        <i class="fa-solid fa-exclamation text-red-500 text-sm flex-shrink-0 mt-0.5"></i>
                                        <span class="text-sm text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($weakness); ?></span>
                                    </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-sm text-slate-600 dark:text-slate-400 italic">Không có dữ liệu</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Column 3: Gợi Ý Cải Thiện (Improvements) -->
                        <div class="bg-slate-50 dark:bg-slate-700/50 p-4 rounded-xl border border-slate-200/50 dark:border-slate-700/50">
                            <div class="flex items-center gap-2 mb-4">
                                <i class="fa-solid fa-lightbulb text-amber-600 dark:text-amber-400 text-lg"></i>
                                <h3 class="text-amber-600 dark:text-amber-400 font-bold text-base">Gợi Ý Cải Thiện</h3>
                            </div>
                            <div class="space-y-2">
                                <?php if (!empty($analysis['improvements']) && is_array($analysis['improvements'])): ?>
                                    <?php foreach ($analysis['improvements'] as $improvement): ?>
                                    <div class="flex items-start gap-2 p-2 bg-white dark:bg-slate-800/50 rounded-lg">
                                        <i class="fa-solid fa-star text-amber-500 text-sm flex-shrink-0 mt-0.5"></i>
                                        <span class="text-sm text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($improvement); ?></span>
                                    </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-sm text-slate-600 dark:text-slate-400 italic">Không có dữ liệu</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="flex gap-2 pt-4 border-t border-gray-200">
                        <button id="btn-rescore" onclick="reScorecv()" class="flex-1 px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-lg transition">
                            🔄 Chấm Điểm Lại
                        </button>
                        <button onclick="downloadReport()" class="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-900 rounded-lg transition">
                            📥 Xuất Báo Cáo
                        </button>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8">
                        <p class="text-gray-600">Chưa có dữ liệu chấm điểm</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Applications Modal -->
    <div id="applicationsModal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-lg max-w-2xl w-full max-h-96 overflow-y-auto shadow-2xl border border-gray-200">
            <div class="sticky top-0 bg-white p-6 border-b border-gray-200 flex justify-between items-center">
                <h2 class="text-2xl font-bold text-gray-900">📋 Danh sách ứng tuyển</h2>
                <button id="closeModalBtn" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
            </div>
            
            <div class="p-6 space-y-3">
                <?php if (count($apps) > 0): ?>
                    <?php foreach ($apps as $app): ?>
                        <div class="bg-gray-50 p-4 rounded-xl border border-gray-200 hover:bg-gray-100 transition">
                            <div class="flex items-start justify-between gap-4">
                                <div class="flex-1">
                                    <h3 class="font-semibold text-lg text-gray-900">
                                        <?php echo htmlspecialchars($app['job_title']); ?>
                                    </h3>
                                    <p class="text-sm text-gray-600 mt-1">
                                        📅 Ứng tuyển: <?php echo date('d/m/Y H:i', strtotime($app['applied_at'])); ?>
                                    </p>
                                    <div class="mt-3 flex items-center gap-2">
                                        <span class="inline-block px-3 py-1 rounded-full text-xs font-semibold
                                            <?php 
                                                if ($app['status'] === 'pending') {
                                                    echo 'bg-yellow-100 text-yellow-700';
                                                } elseif ($app['status'] === 'reviewing') {
                                                    echo 'bg-blue-100 text-blue-700';
                                                } elseif ($app['status'] === 'shortlisted') {
                                                    echo 'bg-green-100 text-green-700';
                                                } elseif ($app['status'] === 'approved' || $app['status'] === 'accepted') {
                                                    echo 'bg-green-100 text-green-700';
                                                } elseif ($app['status'] === 'rejected') {
                                                    echo 'bg-red-100 text-red-700';
                                                } elseif ($app['status'] === 'withdrawn') {
                                                    echo 'bg-gray-200 text-gray-700';
                                                }
                                            ?>
                                        ">
                                            <?php 
                                                if ($app['status'] === 'pending') {
                                                    echo '⏳ Đang chờ';
                                                } elseif ($app['status'] === 'reviewing') {
                                                    echo '🔍 Đang xem xét';
                                                } elseif ($app['status'] === 'shortlisted') {
                                                    echo '⭐ Được chọn';
                                                } elseif ($app['status'] === 'approved' || $app['status'] === 'accepted') {
                                                    echo '✅ Chấp nhận';
                                                } elseif ($app['status'] === 'rejected') {
                                                    echo '❌ Từ chối';
                                                } elseif ($app['status'] === 'withdrawn') {
                                                    echo '🚫 Đã rút';
                                                } else {
                                                    echo ucfirst($app['status']);
                                                }
                                            ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="flex flex-col gap-2">
                                    <a href="../../views/public/job-detail.php?id=<?php echo $app['job_id']; ?>" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition font-semibold whitespace-nowrap text-center">
                                        Xem chi tiết
                                    </a>
                                    <?php if (in_array($app['status'], ['pending', 'reviewing', 'shortlisted'])): ?>
                                        <button onclick="withdrawApplicationFromModal(<?php echo $app['id']; ?>)" class="bg-red-100 hover:bg-red-200 text-red-700 px-4 py-2 rounded-lg transition font-semibold whitespace-nowrap">
                                            ❌ Rút đơn
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center py-8">
                        <p class="text-gray-600 text-sm">Bạn chưa ứng tuyển công việc nào</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        </div><!-- Close grid -->

        <!-- AI Job Recommendations Section - Bottom -->
        <div id="recommended-jobs-section" class="mt-8 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border border-purple-200 shadow p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                        <i class="fa-solid fa-bullseye text-white text-xl"></i>
                    </div>
                    <div>
                        <h2 class="text-2xl font-bold text-gray-900">🎯 Jobs dành cho bạn</h2>
                        <p class="text-sm text-gray-600">AI phân tích hồ sơ của bạn và gợi ý công việc phù hợp</p>
                    </div>
                </div>
                <button id="btn-load-recommendations" onclick="loadRecommendations()" class="px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-xl font-semibold transition transform hover:scale-105">
                    <i class="fa-solid fa-wand-magic-sparkles"></i> Tìm việc phù hợp
                </button>
            </div>
            
            <div id="recommendations-loading" class="hidden text-center py-12">
                <i class="fa-solid fa-spinner fa-spin text-4xl text-purple-500 mb-4"></i>
                <p class="text-gray-700">AI đang phân tích hồ sơ và tính toán độ phù hợp...</p>
            </div>

            <div id="recommendations-empty" class="text-center py-12">
                <i class="fa-solid fa-inbox text-6xl text-gray-300 mb-4"></i>
                <p class="text-gray-600">Nhấn nút "Tìm việc phù hợp" để AI gợi ý công việc cho bạn</p>
                <p class="text-xs text-gray-500 mt-2">Dựa trên thông tin: Kỹ năng, Kinh nghiệm, Học vấn từ hồ sơ của bạn</p>
            </div>

            <div id="recommendations-list" class="hidden grid grid-cols-1 md:grid-cols-2 gap-4"></div>
        </div>

    </div><!-- Close max-w-7xl -->

    <script>
        // Applications Modal - Chạy ngay sau khi DOM load xong
        console.log('Applications Modal Script Started');
        
        const applicationsBtn = document.getElementById('applicationsBtn');
        const applicationsModal = document.getElementById('applicationsModal');
        const closeModalBtn = document.getElementById('closeModalBtn');
        
        console.log('applicationsBtn:', applicationsBtn);
        console.log('applicationsModal:', applicationsModal);
        console.log('closeModalBtn:', closeModalBtn);
        
        if (applicationsBtn && applicationsModal && closeModalBtn) {
            console.log('✅ All elements found! Attaching event listeners...');
            
            applicationsBtn.addEventListener('click', function(e) {
                console.log('✅ Click detected on applicationsBtn');
                e.preventDefault();
                applicationsModal.classList.remove('hidden');
                console.log('Modal classes after remove hidden:', applicationsModal.className);
            });
            
            closeModalBtn.addEventListener('click', function(e) {
                console.log('✅ Click detected on closeModalBtn');
                e.preventDefault();
                applicationsModal.classList.add('hidden');
            });
            
            applicationsModal.addEventListener('click', function(e) {
                if (e.target === applicationsModal) {
                    console.log('✅ Click on backdrop detected');
                    applicationsModal.classList.add('hidden');
                }
            });
            
            console.log('✅ All event listeners attached successfully!');
        } else {
            console.error('❌ Some elements not found!', {
                applicationsBtn: !!applicationsBtn,
                applicationsModal: !!applicationsModal,
                closeModalBtn: !!closeModalBtn
            });
        }

        // Withdraw Application from Modal
        function withdrawApplicationFromModal(applicationId) {
            if (!confirm('Bạn chắc chắn muốn rút đơn ứng tuyển này?\n\nHành động này không thể hoàn tác.')) {
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'withdraw-application');
            formData.append('application_id', applicationId);
            formData.append('csrf_token', '<?php echo $_SESSION['csrf_token'] ?? ''; ?>');
            
            fetch('../../api.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(text => {
                let data;
                try {
                    data = JSON.parse(text);
                } catch (e) {
                    console.error('Parse error:', e);
                    console.error('Response:', text);
                    alert('❌ Lỗi server');
                    return;
                }
                
                if (data.success) {
                    alert('✅ ' + data.message);
                    location.reload();
                } else {
                    alert('❌ ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('❌ Lỗi kết nối');
            });
        }
        
        // Make function global
        window.withdrawApplicationFromModal = withdrawApplicationFromModal;
    </script>

    <script>
    // AI Job Recommendations
    async function loadRecommendations() {
        const loadingEl = document.getElementById('recommendations-loading');
        const emptyEl = document.getElementById('recommendations-empty');
        const listEl = document.getElementById('recommendations-list');
        const btnEl = document.getElementById('btn-load-recommendations');

        // Show loading
        emptyEl.classList.add('hidden');
        listEl.classList.add('hidden');
        loadingEl.classList.remove('hidden');
        btnEl.disabled = true;

        try {
            console.log('Sending request to API...');
            const response = await fetch('../../api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'recommend-jobs',
                    csrf_token: '<?php echo $_SESSION['csrf_token'] ?? ''; ?>'
                })
            });

            console.log('Response status:', response.status);
            const data = await response.json();
            console.log('Response data:', data);
            
            if (data.success && data.recommendations.length > 0) {
                renderRecommendations(data.recommendations);
            } else {
                emptyEl.innerHTML = `
                    <i class="fa-solid fa-circle-exclamation text-6xl text-yellow-400 mb-4"></i>
                    <p class="text-slate-600 dark:text-slate-300">${data.message || 'Không tìm thấy công việc phù hợp'}</p>
                    <p class="text-sm text-slate-500 dark:text-slate-400 mt-2">Hãy cập nhật hồ sơ hoặc thử lại sau</p>
                `;
                emptyEl.classList.remove('hidden');
            }
        } catch (error) {
            console.error('Error:', error);
            emptyEl.innerHTML = `
                <i class="fa-solid fa-triangle-exclamation text-6xl text-red-400 mb-4"></i>
                <p class="text-red-600 dark:text-red-400">Lỗi kết nối: ${error.message}</p>
            `;
            emptyEl.classList.remove('hidden');
        } finally {
            loadingEl.classList.add('hidden');
            btnEl.disabled = false;
        }
    }

    function renderRecommendations(jobs) {
        const listEl = document.getElementById('recommendations-list');
        listEl.innerHTML = '';

        jobs.forEach((job, index) => {
            const scoreColor = job.score >= 80 ? 'text-green-400' : (job.score >= 60 ? 'text-yellow-400' : 'text-orange-400');
            const scoreBg = job.score >= 80 ? 'bg-green-900/30 border-green-500' : (job.score >= 60 ? 'bg-yellow-900/30 border-yellow-500' : 'bg-orange-900/30 border-orange-500');

            const card = document.createElement('div');
            card.className = 'bg-white rounded-lg shadow p-5 hover:shadow-xl transition transform hover:scale-[1.02]';
            card.innerHTML = `
                <div class="flex items-start justify-between mb-3">
                    <div class="flex-1">
                        <h3 class="font-bold text-lg text-gray-900 mb-1">${job.title}</h3>
                        <p class="text-sm text-gray-600">
                            <i class="fa-solid fa-building"></i> ${job.company}
                        </p>
                    </div>
                    <div class="flex flex-col items-end gap-1">
                        <div class="${scoreBg} border-2 rounded-lg px-3 py-1">
                            <span class="text-2xl font-bold ${scoreColor}">${job.score}%</span>
                        </div>
                        <span class="text-xs text-slate-500 dark:text-slate-400">Phù hợp</span>
                    </div>
                </div>

                <div class="flex items-center gap-4 text-xs text-gray-600 mb-4">
                    <span><i class="fa-solid fa-location-dot"></i> ${job.location}</span>
                    <span><i class="fa-solid fa-money-bill"></i> ${job.salary}</span>
                </div>

                <div class="space-y-2 mb-4">
                    <p class="text-xs font-semibold text-green-600">✓ Lý do phù hợp:</p>
                    <ul class="text-xs text-gray-700 space-y-1">
                        ${job.reasons.slice(0, 2).map(r => `<li class="flex items-start gap-2"><span class="text-green-500">•</span><span>${r}</span></li>`).join('')}
                    </ul>
                </div>

                ${job.missing.length > 0 ? `
                <div class="space-y-2 mb-4">
                    <p class="text-xs font-semibold text-orange-600">⚠ Cần cải thiện:</p>
                    <ul class="text-xs text-gray-700 space-y-1">
                        ${job.missing.slice(0, 2).map(m => `<li class="flex items-start gap-2"><span class="text-orange-500">•</span><span>${m}</span></li>`).join('')}
                    </ul>
                </div>
                ` : ''}

                <a href="../../views/public/job-detail.php?id=${job.job_id}" class="block w-full text-center py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold transition">
                    Xem chi tiết <i class="fa-solid fa-arrow-right"></i>
                </a>
            `;
            listEl.appendChild(card);
        });

        listEl.classList.remove('hidden');
    }
    </script>

    <!-- AI Chatbot Widget -->
    <?php include __DIR__ . '/../components/chatbot-widget.php'; ?>

    <!-- Chat Widget (Real-time messaging with recruiters) -->
    <?php include __DIR__ . '/../../components/chat-widget.php'; ?>

</body>
</html>