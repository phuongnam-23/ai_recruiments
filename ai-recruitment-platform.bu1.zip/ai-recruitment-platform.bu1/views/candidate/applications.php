<?php
// SỬA: Chỉ dùng 2 dấu '../' thay vì 3
require_once '../../config/init.php';
// SỬA: Chỉ dùng 2 dấu '../' và thêm 'utils/'
require_once '../../utils/middleware/Auth.php';

requireRole('candidate');
addSecurityHeaders();
// ... phần còn lại giữ nguyên

$applicationModel = new Application();
$applications = $applicationModel->getApplicationsByCandidate($_SESSION['user_id'], 100);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đơn ứng tuyển của tôi - AI Recruitment</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 min-h-screen font-sans">
    <!-- Navigation -->
    <nav class="bg-white dark:bg-slate-800 shadow-lg sticky top-0 z-50 border-b border-slate-200 dark:border-slate-700">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="<?php echo BASE_URL; ?>index.php" class="text-2xl font-bold tracking-tight text-blue-600 hover:text-blue-700 transition flex items-center gap-2">
                <i class="fa-solid fa-briefcase"></i> AI Recruitment
            </a>
            <div class="flex items-center gap-3 text-sm">
                <a href="dashboard.php" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition font-medium">
                    <i class="fa-solid fa-gauge mr-2"></i>Dashboard
                </a>
                <a href="<?php echo BASE_URL; ?>logout.php" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition font-medium">
                    <i class="fa-solid fa-right-from-bracket mr-2"></i>Đăng xuất
                </a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="flex items-center justify-between mb-8">
            <div>
                <h1 class="text-3xl font-bold tracking-tight text-slate-900 dark:text-white mb-2">Đơn ứng tuyển của tôi</h1>
                <p class="text-slate-600 dark:text-slate-400">Theo dõi và quản lý các đơn ứng tuyển của bạn</p>
            </div>
            <a href="search-jobs.php" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-medium">
                <i class="fa-solid fa-magnifying-glass mr-2"></i>Tìm việc mới
            </a>
        </div>

        <!-- Stats -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 p-6 border-l-4 border-blue-500 hover:shadow-xl transition">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-slate-500 dark:text-slate-400 text-sm font-medium uppercase tracking-wide">Tổng đơn</p>
                        <h3 class="text-3xl font-bold tracking-tight text-slate-900 dark:text-white mt-2"><?php echo count($applications); ?></h3>
                    </div>
                    <div class="p-3 bg-blue-100 dark:bg-blue-900/20 rounded-full text-blue-600 dark:text-blue-400">
                        <i class="fa-solid fa-file-lines text-xl"></i>
                    </div>
                </div>
            </div>
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 p-6 border-l-4 border-yellow-500 hover:shadow-xl transition">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-slate-500 dark:text-slate-400 text-sm font-medium uppercase tracking-wide">Chờ xử lý</p>
                        <h3 class="text-3xl font-bold tracking-tight text-slate-900 dark:text-white mt-2">
                            <?php echo count(array_filter($applications, fn($a) => $a['status'] === 'pending')); ?>
                        </h3>
                    </div>
                    <div class="p-3 bg-yellow-100 dark:bg-yellow-900/20 rounded-full text-yellow-600 dark:text-yellow-400">
                        <i class="fa-solid fa-clock text-xl"></i>
                    </div>
                </div>
            </div>
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 p-6 border-l-4 border-green-500 hover:shadow-xl transition">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-slate-500 dark:text-slate-400 text-sm font-medium uppercase tracking-wide">Shortlisted</p>
                        <h3 class="text-3xl font-bold tracking-tight text-slate-900 dark:text-white mt-2">
                            <?php echo count(array_filter($applications, fn($a) => $a['status'] === 'shortlisted')); ?>
                        </h3>
                    </div>
                    <div class="p-3 bg-green-100 dark:bg-green-900/20 rounded-full text-green-600 dark:text-green-400">
                        <i class="fa-solid fa-star text-xl"></i>
                    </div>
                </div>
            </div>
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 p-6 border-l-4 border-red-500 hover:shadow-xl transition">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-slate-500 dark:text-slate-400 text-sm font-medium uppercase tracking-wide">Bị từ chối</p>
                        <h3 class="text-3xl font-bold tracking-tight text-slate-900 dark:text-white mt-2">
                            <?php echo count(array_filter($applications, fn($a) => $a['status'] === 'rejected')); ?>
                        </h3>
                    </div>
                    <div class="p-3 bg-red-100 dark:bg-red-900/20 rounded-full text-red-600 dark:text-red-400">
                        <i class="fa-solid fa-xmark text-xl"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Applications List -->
        <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 overflow-hidden">
            <?php if (empty($applications)): ?>
                <div class="p-12 text-center">
                    <div class="mb-4 text-slate-400 dark:text-slate-600">
                        <i class="fa-solid fa-inbox text-6xl"></i>
                    </div>
                    <p class="text-slate-700 dark:text-slate-300 mb-4 text-lg font-medium">Bạn chưa ứng tuyển vị trí nào</p>
                    <a href="search-jobs.php" class="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-medium">
                        <i class="fa-solid fa-magnifying-glass"></i> Tìm việc làm ngay
                    </a>
                </div>
            <?php else: ?>
                <table class="w-full">
                    <thead class="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Vị trí</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Công ty</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Trạng thái</th>
                            <th class="px-6 py-4 text-center text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Điểm phù hợp</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Ngày nộp</th>
                            <th class="px-6 py-4 text-center text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $app): ?>
                            <tr class="border-b border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                                <td class="px-6 py-4">
                                    <a href="job-detail.php?id=<?php echo $app['job_id']; ?>" class="text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-2">
                                        <i class="fa-solid fa-briefcase text-sm"></i>
                                        <?php echo htmlspecialchars($app['job_title']); ?>
                                    </a>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($app['company_name'] ?? 'N/A'); ?></span>
                                </td>
                                <td class="px-6 py-4">
                                    <?php
                                    $statusIcons = [
                                        'pending' => 'fa-clock',
                                        'reviewing' => 'fa-eye',
                                        'shortlisted' => 'fa-star',
                                        'interviewed' => 'fa-comments',
                                        'offered' => 'fa-trophy',
                                        'rejected' => 'fa-xmark',
                                        'withdrawn' => 'fa-ban'
                                    ];
                                    $statusColors = [
                                        'pending' => 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
                                        'reviewing' => 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
                                        'shortlisted' => 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
                                        'interviewed' => 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400',
                                        'offered' => 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400',
                                        'rejected' => 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
                                        'withdrawn' => 'bg-slate-200 text-slate-800 dark:bg-slate-700 dark:text-slate-400'
                                    ];
                                    $statusLabels = [
                                        'pending' => 'Chờ xử lý',
                                        'reviewing' => 'Đang xem xét',
                                        'shortlisted' => 'Shortlisted',
                                        'interviewed' => 'Đã phỏng vấn',
                                        'offered' => 'Nhận đề xuất',
                                        'rejected' => 'Từ chối',
                                        'withdrawn' => 'Đã rút'
                                    ];
                                    $status = $app['status'];
                                    ?>
                                    <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold <?php echo $statusColors[$status] ?? 'bg-slate-200 text-slate-800'; ?>">
                                        <i class="fa-solid <?php echo $statusIcons[$status] ?? 'fa-circle'; ?>"></i>
                                        <?php echo $statusLabels[$status] ?? ucfirst($status); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <?php if ($app['matching_score']): ?>
                                        <?php 
                                        $score = $app['matching_score'];
                                        $scoreColor = $score >= 80 ? 'green' : ($score >= 60 ? 'yellow' : 'red');
                                        $colorClasses = [
                                            'green' => 'bg-green-500 dark:bg-green-400',
                                            'yellow' => 'bg-yellow-500 dark:bg-yellow-400',
                                            'red' => 'bg-red-500 dark:bg-red-400'
                                        ];
                                        $textColors = [
                                            'green' => 'text-green-700 dark:text-green-400',
                                            'yellow' => 'text-yellow-700 dark:text-yellow-400',
                                            'red' => 'text-red-700 dark:text-red-400'
                                        ];
                                        ?>
                                        <div class="flex items-center justify-center gap-3">
                                            <div class="w-20 bg-slate-200 dark:bg-slate-700 rounded-full h-2.5 overflow-hidden">
                                                <div class="<?php echo $colorClasses[$scoreColor]; ?> h-2.5 rounded-full transition-all" 
                                                     style="width: <?php echo $score; ?>%"></div>
                                            </div>
                                            <span class="font-bold text-sm <?php echo $textColors[$scoreColor]; ?>"><?php echo $score; ?>%</span>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-slate-400 dark:text-slate-600 text-sm">--</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="text-slate-700 dark:text-slate-300 text-sm">
                                        <i class="fa-regular fa-calendar text-slate-400 mr-1"></i>
                                        <?php echo DateHelper::formatDate($app['applied_at']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex items-center justify-center gap-2">
                                        <button onclick="viewDetails(<?php echo $app['id']; ?>)" 
                                                class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/40 transition" 
                                                title="Xem chi tiết">
                                            <i class="fa-solid fa-eye"></i>
                                        </button>
                                        
                                        <!-- Chat Button -->
                                        <button onclick="startChat(<?php echo $app['id']; ?>)" 
                                                class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-900/20 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-900/40 transition" 
                                                title="Nhắn tin">
                                            <i class="fa-solid fa-message"></i>
                                        </button>
                                        
                                        <?php if (in_array($app['status'], ['pending', 'reviewing', 'shortlisted'])): ?>
                                            <button onclick="withdrawApplication(<?php echo $app['id']; ?>)" 
                                                    class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/40 transition" 
                                                    title="Rút đơn">
                                                <i class="fa-solid fa-xmark"></i> Rút
                                            </button>
                                        <?php elseif ($app['status'] === 'withdrawn'): ?>
                                            <span class="text-slate-400 dark:text-slate-600 text-xs font-medium">Đã rút</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Include Chat Widget -->
    <?php include '../../components/lazy-load-widgets.php'; ?>

    <!-- AI Chatbot Widget -->
    <?php include __DIR__ . '/../components/chatbot-widget.php'; ?>

    <script>
        function viewDetails(applicationId) {
            // Có thể mở modal hoặc redirect tới trang chi tiết
            alert('Chi tiết đơn apply ID: ' + applicationId);
        }
        
        function startChat(applicationId) {
            // Mở chat widget và khởi tạo conversation
            fetch('../../api.php?action=start-conversation', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ application_id: applicationId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    ChatWidget.open();
                    ChatWidget.openConversation(data.conversation.id);
                } else {
                    alert('Lỗi: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Không thể khởi tạo cuộc trò chuyện');
            });
        }

        function withdrawApplication(applicationId) {
            if (!confirm('Bạn chắc chắn muốn rút đơn ứng tuyển này?\n\nHành động này không thể hoàn tác.')) {
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'withdraw-application');
            formData.append('application_id', applicationId);
            
            fetch('../../api.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(text => {
                let data;
                try {
                    data = JSON.parse(text);
                } catch (e) {
                    console.error('Parse error:', e);
                    console.error('Response:', text);
                    alert('❌ Lỗi server');
                    return;
                }
                
                if (data.success) {
                    alert('✅ ' + data.message);
                    location.reload();
                } else {
                    alert('❌ ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('❌ Lỗi kết nối');
            });
        }
    </script>
</body>
</html>
