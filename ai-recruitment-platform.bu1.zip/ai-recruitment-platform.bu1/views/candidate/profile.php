<?php
require_once __DIR__ . '/../../config/init.php';
require_once __DIR__ . '/../../utils/middleware/Auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'candidate') {
    header('Location: ' . BASE_URL . 'login.php');
    exit;
}

addSecurityHeaders();

$candidateModel = new CandidateProfile();
$profile = $candidateModel->getProfile($_SESSION['user_id']);
$userModel = new User();
$user = $userModel->getUserById($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ sơ của tôi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-white/90 dark:bg-gray-900/80 backdrop-blur-md shadow-lg shadow-slate-900/5 border-b border-slate-200 dark:border-slate-700 sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="<?php echo BASE_URL; ?>index.php" class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition">AI Recruitment</a>
            <div class="flex items-center gap-4 text-sm">
                <a href="dashboard.php" class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition">Dashboard</a>
                <a href="../../logout.php" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-3xl font-bold tracking-tight text-gray-900">Hồ sơ của tôi</h1>
                <div class="flex gap-3">
                    <button id="viewModeBtn" onclick="toggleMode('view')" class="px-6 py-2.5 bg-slate-200 text-slate-700 rounded-lg font-semibold transition hover:bg-slate-300">
                        <i class="fa-solid fa-eye"></i> Xem
                    </button>
                    <button id="editModeBtn" onclick="toggleMode('edit')" class="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold transition shadow-lg hover:from-blue-700 hover:to-purple-700">
                        <i class="fa-solid fa-pen-to-square"></i> Chỉnh sửa
                    </button>
                </div>
            </div>

            <!-- Avatar Section -->
            <div class="mb-8 text-center pb-6 border-b border-gray-200">
                <h2 class="text-xl font-bold text-gray-900 mb-4">Ảnh Đại Diện</h2>
                <div class="flex justify-center">
                    <?php include __DIR__ . '/../../components/avatar-upload.php'; ?>
                </div>
            </div>

            <form id="profile-form" class="space-y-6">
                <!-- Basic Info -->
                <div class="border-b border-gray-200 pb-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Thông tin cơ bản</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Họ và tên</label>
                            <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" 
                                   class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none profile-input" disabled>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Email</label>
                            <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" 
                                   class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none cursor-not-allowed" disabled>
                            <p class="text-xs text-gray-500 mt-1">Email không thể thay đổi</p>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Số điện thoại</label>
                            <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" 
                                   class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Ngày sinh</label>
                            <input type="date" name="date_of_birth" value="<?php echo $profile['date_of_birth'] ?? ''; ?>" 
                                   class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                        </div>
                    </div>
                </div>

                <!-- Professional Info -->
                <div class="border-b border-gray-200 pb-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Thông tin chuyên nghiệp</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Thành phố</label>
                            <input type="text" name="city" value="<?php echo htmlspecialchars($profile['city'] ?? ''); ?>" 
                                   placeholder="Hà Nội, TP Hồ Chí Minh..." class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Kinh nghiệm (năm)</label>
                            <input type="number" name="experience_years" value="<?php echo $profile['experience_years'] ?? 0; ?>" 
                                   min="0" max="60" class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Bằng cấp</label>
                            <select name="education_level" class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                                <option value="">-- Chọn bằng cấp --</option>
                                <option value="high_school" <?php echo $profile['education_level'] === 'high_school' ? 'selected' : ''; ?>>Cao đẳng/THPT</option>
                                <option value="bachelor" <?php echo $profile['education_level'] === 'bachelor' ? 'selected' : ''; ?>>Đại học</option>
                                <option value="master" <?php echo $profile['education_level'] === 'master' ? 'selected' : ''; ?>>Thạc sĩ</option>
                                <option value="phd" <?php echo $profile['education_level'] === 'phd' ? 'selected' : ''; ?>>Tiến sĩ</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Giới tính</label>
                            <select name="gender" class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                                <option value="">-- Chọn giới tính --</option>
                                <option value="male" <?php echo $profile['gender'] === 'male' ? 'selected' : ''; ?>>Nam</option>
                                <option value="female" <?php echo $profile['gender'] === 'female' ? 'selected' : ''; ?>>Nữ</option>
                                <option value="other" <?php echo $profile['gender'] === 'other' ? 'selected' : ''; ?>>Khác</option>
                            </select>
                        </div>
                    </div>

                    <div class="mt-4">
                        <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Về tôi</label>
                        <textarea name="bio" rows="4" placeholder="Nói về bản thân, kinh nghiệm, kỹ năng..." 
                                  class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition profile-input" disabled><?php echo htmlspecialchars($profile['bio'] ?? ''); ?></textarea>
                    </div>

                    <div class="mt-4">
                        <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Kỹ năng (cách nhau bằng dấu phẩy)</label>
                        <input type="text" name="skills" placeholder="JavaScript, React, Node.js, Python..." 
                               value="<?php echo is_array($profile['skills']) ? htmlspecialchars(implode(', ', json_decode($profile['skills']))) : htmlspecialchars($profile['skills'] ?? ''); ?>" 
                               class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                    </div>
                </div>

                <!-- Links -->
                <div class="border-b border-gray-200 pb-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Liên kết mạng xã hội</h2>
                    <div class="space-y-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">LinkedIn URL</label>
                            <input type="url" name="linkedin_url" placeholder="https://linkedin.com/in/..." 
                                   value="<?php echo htmlspecialchars($profile['linkedin_url'] ?? ''); ?>" 
                                   class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">GitHub URL</label>
                            <input type="url" name="github_url" placeholder="https://github.com/..." 
                                   value="<?php echo htmlspecialchars($profile['github_url'] ?? ''); ?>" 
                                   class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Portfolio URL</label>
                            <input type="url" name="portfolio_url" placeholder="https://..." 
                                   value="<?php echo htmlspecialchars($profile['portfolio_url'] ?? ''); ?>" 
                                   class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                        </div>
                    </div>
                </div>

                <!-- Salary Expectations -->
                <div class="pb-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Mong muốn công việc</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Lương tối thiểu (VND)</label>
                            <input type="number" name="desired_salary_min" value="<?php echo $profile['desired_salary_min'] ?? ''; ?>" 
                                   class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2 text-sm uppercase">Lương tối đa (VND)</label>
                            <input type="number" name="desired_salary_max" value="<?php echo $profile['desired_salary_max'] ?? ''; ?>" 
                                   class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none transition profile-input" disabled>
                        </div>
                    </div>
                </div>

                <!-- CV Upload -->
                <div class="border-t border-gray-200 pt-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Tải CV</h2>
                    <div class="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center cursor-pointer hover:border-blue-500 hover:bg-gray-100 transition" id="cv-upload-area">
                        <p class="text-gray-700">Kéo thả hoặc nhấp để tải CV (PDF, DOC, DOCX)</p>
                        <input type="file" id="cv-file" name="cv" accept=".pdf,.doc,.docx" class="hidden">
                        <?php if ($profile['cv_file_url']): ?>
                            <p class="text-green-400 mt-2">✅ CV hiện tại: <?php echo basename($profile['cv_file_url']); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <button type="submit" id="saveBtn" class="hidden w-full px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded font-bold py-3 rounded-xl shadow-lg mt-6 transition">
                    💾 Lưu thay đổi
                </button>
            </form>
        </div>
    </div>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script>
        let isEditMode = false;

        function toggleMode(mode) {
            isEditMode = (mode === 'edit');
            const inputs = document.querySelectorAll('.profile-input');
            const saveBtn = document.getElementById('saveBtn');
            const viewModeBtn = document.getElementById('viewModeBtn');
            const editModeBtn = document.getElementById('editModeBtn');
            
            inputs.forEach(input => {
                input.disabled = !isEditMode;
                if (isEditMode) {
                    input.classList.remove('cursor-not-allowed');
                    input.classList.add('hover:border-blue-500');
                } else {
                    input.classList.add('cursor-not-allowed');
                    input.classList.remove('hover:border-blue-500');
                }
            });

            if (isEditMode) {
                saveBtn.classList.remove('hidden');
                editModeBtn.classList.add('bg-gradient-to-r', 'from-blue-600', 'to-purple-600', 'text-white', 'shadow-lg');
                editModeBtn.classList.remove('bg-slate-200', 'text-slate-700');
                viewModeBtn.classList.add('bg-slate-200', 'text-slate-700');
                viewModeBtn.classList.remove('bg-gradient-to-r', 'from-blue-600', 'to-purple-600', 'text-white', 'shadow-lg');
            } else {
                saveBtn.classList.add('hidden');
                viewModeBtn.classList.add('bg-gradient-to-r', 'from-blue-600', 'to-purple-600', 'text-white', 'shadow-lg');
                viewModeBtn.classList.remove('bg-slate-200', 'text-slate-700');
                editModeBtn.classList.add('bg-slate-200', 'text-slate-700');
                editModeBtn.classList.remove('bg-gradient-to-r', 'from-blue-600', 'to-purple-600', 'text-white', 'shadow-lg');
            }
        }

        // Initialize in view mode
        toggleMode('view');
        // CV upload
        const cvUploadArea = document.getElementById('cv-upload-area');
        const cvFile = document.getElementById('cv-file');

        cvUploadArea.addEventListener('click', () => cvFile.click());
        cvUploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            cvUploadArea.classList.add('border-blue-500', 'bg-blue-900/20');
        });
        cvUploadArea.addEventListener('dragleave', () => {
            cvUploadArea.classList.remove('border-blue-500', 'bg-blue-900/20');
        });
        cvUploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            cvUploadArea.classList.remove('border-blue-500', 'bg-blue-900/20');
            if (e.dataTransfer.files.length > 0) {
                cvFile.files = e.dataTransfer.files;
            }
        });

        // Form submission
        document.getElementById('profile-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData();
            const inputs = document.querySelectorAll('#profile-form input, #profile-form textarea, #profile-form select');
            
            inputs.forEach(input => {
                if (input.name) {
                    formData.append(input.name, input.value);
                }
            });

            try {
                // Cập nhật profile
                // Có thể thêm AJAX call ở đây
                alert('Hồ sơ đã được cập nhật thành công!');
            } catch (error) {
                alert('Có lỗi xảy ra: ' + error.message);
            }
        });
    </script>
</body>
</html>
