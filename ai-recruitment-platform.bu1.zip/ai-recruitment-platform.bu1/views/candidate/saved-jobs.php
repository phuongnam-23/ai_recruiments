<?php
session_start();
require_once '../../config/init.php';
require_once '../../utils/models/SavedJob.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'candidate') {
    header('Location: ../../login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$savedJobModel = new SavedJob();

// Pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 12;
$offset = ($page - 1) * $perPage;

// Get saved jobs
$savedJobs = $savedJobModel->getSavedJobs($userId, $perPage, $offset);
$totalSaved = $savedJobModel->countSavedJobs($userId);
$totalPages = ceil($totalSaved / $perPage);

// Debug - show to user
if (!empty($savedJobs)) {
    error_log("DEBUG: Found " . count($savedJobs) . " saved jobs for user ID: $userId");
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tin đã lưu - AI Recruitment Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-sm sticky top-0 z-50">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <a href="../public/jobs-list.php" class="text-2xl font-bold text-blue-600">
                    <i class="fas fa-briefcase"></i> JobPortal
                </a>
                <div class="flex items-center gap-4">
                    <a href="search-jobs.php" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-search"></i> Tìm việc
                    </a>
                    <a href="saved-jobs.php" class="text-blue-600 font-semibold">
                        <i class="fas fa-bookmark"></i> Tin đã lưu
                    </a>
                    <a href="applications.php" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-file-alt"></i> Đơn ứng tuyển
                    </a>
                    <a href="dashboard.php" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-home"></i> Dashboard
                    </a>
                    <a href="../../logout.php" class="text-red-600 hover:text-red-700">
                        <i class="fas fa-sign-out-alt"></i> Đăng xuất
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800 mb-2">
                <i class="fas fa-bookmark text-blue-600"></i> Tin đã lưu
            </h1>
            <p class="text-gray-600">
                Bạn đã lưu <span class="font-semibold text-blue-600"><?php echo $totalSaved; ?></span> công việc
            </p>
            <!-- Debug info -->
            <p class="text-xs text-gray-400 mt-2">User ID: <?php echo $userId; ?> | Found jobs: <?php echo count($savedJobs); ?></p>
        </div>

        <?php if (empty($savedJobs)): ?>
            <!-- Empty State -->
            <div class="bg-white rounded-lg shadow-md p-12 text-center">
                <i class="fas fa-bookmark text-gray-300 text-6xl mb-4"></i>
                <h2 class="text-2xl font-semibold text-gray-700 mb-2">Chưa có tin đã lưu</h2>
                <p class="text-gray-500 mb-6">Hãy lưu các công việc mà bạn quan tâm để xem lại sau</p>
                <a href="search-jobs.php" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
                    <i class="fas fa-search mr-2"></i> Tìm việc làm
                </a>
            </div>
        <?php else: ?>
            <!-- Jobs Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($savedJobs as $job): ?>
                    <div class="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden relative">
                        <!-- Saved Badge -->
                        <div class="absolute top-3 right-3 z-10">
                            <button onclick="unsaveJob(<?php echo $job['id']; ?>)" 
                                    class="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition"
                                    title="Bỏ lưu tin">
                                <i class="fas fa-bookmark"></i>
                            </button>
                        </div>

                        <div class="p-6">
                            <!-- Company Logo -->
                            <div class="flex items-start mb-4">
                                <?php if (!empty($job['company_logo_url'])): ?>
                                    <img src="<?php echo BASE_URL . htmlspecialchars($job['company_logo_url']); ?>" 
                                         alt="Company Logo" 
                                         class="w-16 h-16 rounded-lg object-cover mr-4"
                                         onerror="this.onerror=null; this.parentElement.innerHTML='<div class=\'w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-xl\'><?php echo strtoupper(substr($job['company_name'] ?? 'C', 0, 1)); ?></div>';">
                                <?php else: ?>
                                    <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-xl mr-4">
                                        <?php echo strtoupper(substr($job['company_name'] ?? 'C', 0, 1)); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="flex-1">
                                    <h3 class="font-semibold text-lg text-gray-800 mb-1 line-clamp-2">
                                        <a href="../public/job-detail.php?id=<?php echo $job['id']; ?>" 
                                           class="hover:text-blue-600">
                                            <?php echo htmlspecialchars($job['title']); ?>
                                        </a>
                                    </h3>
                                    <p class="text-gray-600 text-sm">
                                        <?php echo htmlspecialchars($job['company_name'] ?? 'Công ty'); ?>
                                    </p>
                                </div>
                            </div>

                            <!-- Job Info -->
                            <div class="space-y-2 mb-4">
                                <div class="flex items-center text-sm text-gray-600">
                                    <i class="fas fa-map-marker-alt w-5"></i>
                                    <span><?php echo htmlspecialchars($job['location']); ?></span>
                                </div>
                                <div class="flex items-center text-sm text-gray-600">
                                    <i class="fas fa-money-bill-wave w-5"></i>
                                    <span><?php 
                                        if (!empty($job['salary_min']) && !empty($job['salary_max'])) {
                                            echo number_format($job['salary_min'], 0, '.', ',') . ' - ' . 
                                                 number_format($job['salary_max'], 0, '.', ',') . ' VND';
                                        } else {
                                            echo 'Thỏa thuận';
                                        }
                                    ?></span>
                                </div>
                                <div class="flex items-center text-sm text-gray-600">
                                    <i class="fas fa-clock w-5"></i>
                                    <span>Lưu <?php 
                                        $savedTime = strtotime($job['saved_at']);
                                        $diff = time() - $savedTime;
                                        if ($diff < 3600) {
                                            echo floor($diff / 60) . ' phút trước';
                                        } elseif ($diff < 86400) {
                                            echo floor($diff / 3600) . ' giờ trước';
                                        } else {
                                            echo floor($diff / 86400) . ' ngày trước';
                                        }
                                    ?></span>
                                </div>
                            </div>

                            <!-- Tags -->
                            <div class="flex flex-wrap gap-2 mb-4">
                                <span class="px-3 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                                    <?php echo htmlspecialchars($job['job_type']); ?>
                                </span>
                                <span class="px-3 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                                    <?php echo $job['total_applications']; ?> ứng tuyển
                                </span>
                            </div>

                            <!-- Actions -->
                            <div class="flex gap-2">
                                <a href="../public/job-detail.php?id=<?php echo $job['id']; ?>" 
                                   class="flex-1 bg-blue-600 text-white text-center py-2 rounded-lg hover:bg-blue-700 transition">
                                    <i class="fas fa-eye mr-2"></i> Xem chi tiết
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="mt-8 flex justify-center gap-2">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>" 
                           class="px-4 py-2 rounded-lg <?php echo $page == $i ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <script>
        function unsaveJob(jobId) {
            if (!confirm('Bạn có chắc muốn bỏ lưu tin này?')) {
                return;
            }

            const token = '<?php echo $_SESSION['csrf_token'] ?? ''; ?>';
            
            fetch('../../api.php?action=toggle-save-job', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    job_id: jobId,
                    csrf_token: token
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'Có lỗi xảy ra');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi xử lý yêu cầu');
            });
        }
    </script>
</body>
</html>
