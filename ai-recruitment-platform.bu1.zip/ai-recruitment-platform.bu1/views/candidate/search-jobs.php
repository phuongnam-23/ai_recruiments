<?php
// SỬA: Chỉ dùng 2 dấu '../' thay vì 3
require_once '../../config/init.php';
// SỬA: Chỉ dùng 2 dấu '../' và thêm 'utils/'
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/SavedJob.php';

requireRole('candidate');
addSecurityHeaders();

$jobModel = new Job();
$savedJobModel = new SavedJob();
$userId = $_SESSION['user_id'];

$keyword = sanitize($_GET['keyword'] ?? '');
$filters = [
    'category' => sanitize($_GET['category'] ?? ''),
    'job_type' => sanitize($_GET['job_type'] ?? ''),
    'city' => sanitize($_GET['city'] ?? ''),
    'salary_min' => (int)($_GET['salary_min'] ?? 0),
    'job_level' => sanitize($_GET['job_level'] ?? '')
];

// Loại bỏ các filter rỗng để tránh lỗi
$activeFilters = array_filter($filters, function($val) {
    return $val !== '' && $val !== 0;
});

// Pagination
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

// Thực hiện tìm kiếm với đầy đủ filters
$jobs = $jobModel->searchJobs($keyword, $filters, $limit, $offset);

// Lấy danh sách job IDs đã lưu
$savedJobIds = $savedJobModel->getSavedJobIds($userId);

// Tăng view count khi xem detail
if (isset($_GET['view_id'])) {
    $jobModel->incrementViewCount((int)$_GET['view_id']);
}

// Kiểm tra nếu có filter được áp dụng
$hasActiveSearch = !empty($keyword) || !empty($activeFilters);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tìm việc làm</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-white/90 dark:bg-gray-900/80 backdrop-blur-md shadow-lg shadow-slate-900/5 border-b border-slate-200 dark:border-slate-700 sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="dashboard.php" class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition">AI Recruitment</a>
            <div class="flex items-center gap-4 text-sm">
                <a href="saved-jobs.php" class="px-4 py-2 bg-yellow-100 text-yellow-700 rounded hover:bg-yellow-200 transition">🔖 Tin đã lưu</a>
                <a href="applications.php" class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition">📋 Đơn apply</a>
                <a href="profile.php" class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition">👤 Hồ sơ</a>
                <a href="../../logout.php" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <!-- Search Bar -->
        <div class="bg-white rounded-lg shadow p-6 mb-8">
            <h1 class="text-3xl font-bold tracking-tight text-gray-900 mb-6">🔍 Tìm việc làm</h1>
            
            <form method="GET" class="space-y-4">
                <!-- Main Search -->
                <div>
                    <input type="text" name="keyword" value="<?php echo htmlspecialchars($keyword); ?>" 
                           placeholder="Tên vị trí, kỹ năng, công ty..." 
                           class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-3 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition">
                </div>

                <!-- Filters -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-xs text-gray-700 mb-1 font-semibold">Vị trí / Kỹ năng</label>
                        <input type="text" name="keyword" value="<?php echo htmlspecialchars($keyword); ?>" 
                               placeholder="VD: PHP, Developer..." 
                               class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition">
                    </div>

                    <div>
                        <label class="block text-xs text-gray-700 mb-1 font-semibold">Thành phố</label>
                        <select name="city" class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none transition text-sm">
                            <option value="">-- Tất cả --</option>
                            <option value="Hà Nội" <?php echo $filters['city'] === 'Hà Nội' ? 'selected' : ''; ?>>Hà Nội</option>
                            <option value="TP Hồ Chí Minh" <?php echo $filters['city'] === 'TP Hồ Chí Minh' ? 'selected' : ''; ?>>TP Hồ Chí Minh</option>
                            <option value="Đà Nẵng" <?php echo $filters['city'] === 'Đà Nẵng' ? 'selected' : ''; ?>>Đà Nẵng</option>
                            <option value="Cần Thơ" <?php echo $filters['city'] === 'Cần Thơ' ? 'selected' : ''; ?>>Cần Thơ</option>
                            <option value="Remote" <?php echo $filters['city'] === 'Remote' ? 'selected' : ''; ?>>Remote</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-700 mb-1 font-semibold">Ngành</label>
                        <select name="category" class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none transition text-sm">
                            <option value="">-- Tất cả --</option>
                            <option value="Information Technology" <?php echo $filters['category'] === 'Information Technology' ? 'selected' : ''; ?>>CNTT</option>
                            <option value="Finance" <?php echo $filters['category'] === 'Finance' ? 'selected' : ''; ?>>Tài chính</option>
                            <option value="Marketing" <?php echo $filters['category'] === 'Marketing' ? 'selected' : ''; ?>>Marketing</option>
                            <option value="HR" <?php echo $filters['category'] === 'HR' ? 'selected' : ''; ?>>Nhân sự</option>
                            <option value="Sales" <?php echo $filters['category'] === 'Sales' ? 'selected' : ''; ?>>Bán hàng</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-700 mb-1 font-semibold">Loại công việc</label>
                        <select name="job_type" class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none transition text-sm">
                            <option value="">-- Tất cả --</option>
                            <option value="full_time" <?php echo $filters['job_type'] === 'full_time' ? 'selected' : ''; ?>>Toàn thời gian</option>
                            <option value="part_time" <?php echo $filters['job_type'] === 'part_time' ? 'selected' : ''; ?>>Bán thời gian</option>
                            <option value="contract" <?php echo $filters['job_type'] === 'contract' ? 'selected' : ''; ?>>Hợp đồng</option>
                            <option value="remote" <?php echo $filters['job_type'] === 'remote' ? 'selected' : ''; ?>>Remote</option>
                        </select>
                    </div>
                </div>

                <!-- Second Row Filters -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-xs text-gray-700 mb-1 font-semibold">Cấp độ</label>
                        <select name="job_level" class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:border-blue-500 focus:outline-none transition text-sm">
                            <option value="">-- Tất cả --</option>
                            <option value="junior" <?php echo $filters['job_level'] === 'junior' ? 'selected' : ''; ?>>Junior</option>
                            <option value="mid_level" <?php echo $filters['job_level'] === 'mid_level' ? 'selected' : ''; ?>>Mid-level</option>
                            <option value="senior" <?php echo $filters['job_level'] === 'senior' ? 'selected' : ''; ?>>Senior</option>
                            <option value="manager" <?php echo $filters['job_level'] === 'manager' ? 'selected' : ''; ?>>Quản lý</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-700 mb-1 font-semibold">Lương tối thiểu (VND)</label>
                        <input type="number" name="salary_min" value="<?php echo $filters['salary_min']; ?>" 
                               placeholder="VD: 15000000" 
                               class="w-full bg-gray-100 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none transition text-sm">
                    </div>

                    <div class="flex items-end">
                        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded-xl transition">
                            🔍 Tìm kiếm
                        </button>
                    </div>

                    <div class="flex items-end">
                        <a href="search-jobs.php" class="w-full text-center px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition font-bold py-2 rounded-xl">
                            ↻ Reset
                        </a>
                    </div>
                </div>

                <!-- Active Filters Display -->
                <?php if ($hasActiveSearch): ?>
                    <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 mt-4">
                        <p class="text-sm font-semibold text-blue-900 mb-2">🔎 Kết quả tìm kiếm:</p>
                        <div class="flex flex-wrap gap-2">
                            <?php if (!empty($keyword)): ?>
                                <span class="bg-blue-600 text-white text-xs px-3 py-1 rounded-full">📌 <?php echo htmlspecialchars($keyword); ?></span>
                            <?php endif; ?>
                            <?php if (!empty($filters['city'])): ?>
                                <span class="bg-indigo-600 text-white text-xs px-3 py-1 rounded-full">📍 <?php echo htmlspecialchars($filters['city']); ?></span>
                            <?php endif; ?>
                            <?php if (!empty($filters['category'])): ?>
                                <span class="bg-purple-600 text-white text-xs px-3 py-1 rounded-full">🏢 <?php echo htmlspecialchars($filters['category']); ?></span>
                            <?php endif; ?>
                            <?php if (!empty($filters['job_type'])): ?>
                                <span class="bg-pink-600 text-white text-xs px-3 py-1 rounded-full">⏰ <?php echo ucfirst(str_replace('_', ' ', $filters['job_type'])); ?></span>
                            <?php endif; ?>
                            <?php if (!empty($filters['job_level'])): ?>
                                <span class="bg-orange-600 text-white text-xs px-3 py-1 rounded-full">⭐ <?php echo ucfirst(str_replace('_', ' ', $filters['job_level'])); ?></span>
                            <?php endif; ?>
                            <?php if (!empty($filters['salary_min'])): ?>
                                <span class="bg-green-600 text-white text-xs px-3 py-1 rounded-full">💰 ≥<?php echo number_format($filters['salary_min']); ?> VND</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <p class="text-sm text-gray-600 mt-2"><strong><?php echo count($jobs); ?></strong> công việc tìm thấy</p>
                <?php else: ?>
                    <p class="text-sm text-gray-600 mt-4">💡 Nhập từ khóa hoặc chọn bộ lọc để tìm kiếm công việc</p>
                <?php endif; ?>

        <!-- Results -->
        <div class="space-y-4">
            <?php if (empty($jobs)): ?>
                <div class="bg-white rounded-lg shadow p-6 text-center">
                    <p class="text-gray-700 text-lg mb-4">😅 Không tìm thấy công việc phù hợp</p>
                    <a href="search-jobs.php" class="text-blue-400 hover:text-blue-300 transition">← Quay lại để thử tìm kiếm khác</a>
                </div>
            <?php else: ?>
                <div class="flex justify-between items-center mb-4">
                    <p class="text-gray-700">Tìm thấy <strong><?php echo count($jobs); ?></strong> công việc</p>
                </div>

                <?php foreach ($jobs as $job): ?>
                    <div class="bg-white rounded-lg shadow p-6 hover:border-blue-500 transition cursor-pointer"
                         onclick="window.location.href='job-detail.php?id=<?php echo $job['id']; ?>&view_id=<?php echo $job['id']; ?>'">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h2 class="text-2xl font-bold text-gray-900">
                                    <?php echo htmlspecialchars($job['title']); ?>
                                </h2>
                                <p class="text-gray-600 mt-1">
                                    📍 <?php echo htmlspecialchars($job['city']); ?> | 
                                    🏢 <?php echo htmlspecialchars($job['company_name']); ?>
                                </p>
                            <div class="text-right">
                                <button type="button" 
                                        class="text-3xl hover:scale-125 transition save-job-btn" 
                                        data-job-id="<?php echo $job['id']; ?>"
                                        onclick="toggleSaveJob(event, <?php echo $job['id']; ?>)">
                                    <?php echo in_array($job['id'], $savedJobIds) ? '🔖' : '📑'; ?>
                                </button>
                            </div>button>
                            </div>
                        </div>

                        <p class="text-gray-700 mb-4 line-clamp-2">
                            <?php echo htmlspecialchars(substr($job['description'], 0, 200)) . '...'; ?>
                        </p>

                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 pb-4 border-b border-gray-200">
                            <div>
                                <p class="text-xs text-gray-600 uppercase">Loại công việc</p>
                                <p class="font-semibold text-gray-800"><?php echo ucfirst(str_replace('_', ' ', $job['job_type'])); ?></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-600 uppercase">Cấp độ</p>
                                <p class="font-semibold text-gray-800"><?php echo ucfirst(str_replace('_', ' ', $job['job_level'])); ?></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-600 uppercase">Kinh nghiệm</p>
                                <p class="font-semibold text-gray-800"><?php echo $job['experience_required']; ?>+ năm</p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-600 uppercase">Lương</p>
                                <p class="font-semibold text-gray-800">
                                    <?php 
                                    if ($job['salary_min'] && $job['salary_max']) {
                                        echo number_format($job['salary_min']) . ' - ' . 
                                             number_format($job['salary_max']);
                                    } else {
                                        echo 'Thỏa thuận';
                                    }
                                    ?>
                                </p>
                            </div>
                        </div>

                        <?php if (!empty($job['required_skills'])): ?>
                            <div class="mb-4">
                                <p class="text-xs text-gray-600 uppercase mb-2">Kỹ năng yêu cầu</p>
                                <div class="flex flex-wrap gap-2">
                                    <?php 
                                    $skills = json_decode($job['required_skills'], true);
                                    if (is_array($skills)) {
                                        foreach (array_slice($skills, 0, 5) as $skill) {
                                            echo '<span class="bg-blue-900/40 text-blue-300 px-3 py-1 rounded-full text-sm border border-blue-700">' . 
                                                 htmlspecialchars($skill) . '</span>';
                                        }
                                        if (count($skills) > 5) {
                                            echo '<span class="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm border border-gray-300">' . 
                                                 (count($skills) - 5) . ' khác</span>';
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="flex justify-between items-center pt-4">
                            <div class="text-sm text-gray-600">
                                📅 <?php echo DateHelper::timeAgo($job['created_at']); ?>
                                | 👀 <?php echo $job['views_count']; ?> views
                                | 📄 <?php echo $job['applications_count']; ?> đơn apply
                            </div>
                            <a href="job-detail.php?id=<?php echo $job['id']; ?>&view_id=<?php echo $job['id']; ?>" 
                               class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition" 
                               onclick="event.stopPropagation()">
                                Xem chi tiết →
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if (!empty($jobs) && count($jobs) >= $limit): ?>
            <div class="mt-8 flex justify-center gap-2">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>&keyword=<?php echo urlencode($keyword); ?>" 
                       class="px-4 py-2 bg-white border border-gray-200 rounded-xl hover:border-blue-500 text-gray-700 transition">← Trang trước</a>
                <?php endif; ?>
                
                <span class="px-4 py-2 text-gray-600">Trang <?php echo $page; ?></span>
                
                <a href="?page=<?php echo $page + 1; ?>&keyword=<?php echo urlencode($keyword); ?>" 
                   class="px-4 py-2 bg-white border border-gray-200 rounded-xl hover:border-blue-500 text-gray-700 transition">Trang sau →</a>
            </div>
    <script>
        function toggleSaveJob(event, jobId) {
            event.stopPropagation();
            const btn = event.target;
            const isSaved = btn.textContent === '🔖';
            
            // Disable button during request
            btn.disabled = true;
            btn.style.opacity = '0.5';
            
            const token = '<?php echo $_SESSION['csrf_token'] ?? ''; ?>';
            
            fetch('../../api.php?action=toggle-save-job', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    job_id: jobId,
                    csrf_token: token
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    btn.textContent = data.saved ? '🔖' : '📑';
                    
                    // Show notification
                    const notification = document.createElement('div');
                    notification.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
                    notification.textContent = data.message;
                    document.body.appendChild(notification);
                    
                    setTimeout(() => {
                        notification.remove();
                    }, 3000);
                } else {
                    alert(data.message || 'Có lỗi xảy ra');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi xử lý yêu cầu');
            })
            .finally(() => {
                btn.disabled = false;
                btn.style.opacity = '1';
            });
        }
    </script>   // Gọi API để xóa job
            }
        }
    </script>

    <?php include __DIR__ . '/../../components/lazy-load-widgets.php'; ?>
    
    <!-- AI Chatbot Widget -->
    <?php include __DIR__ . '/../components/chatbot-widget.php'; ?>
</body>
</html>
