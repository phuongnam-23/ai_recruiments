<!-- EDIT PROFILE MODAL FOR CANDIDATE -->
<div id="editProfileModal" class="hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 overflow-y-auto">
    <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <!-- Header -->
        <div class="sticky top-0 bg-gradient-to-r from-blue-600 to-purple-600 p-6 flex justify-between items-center">
            <div>
                <h2 class="text-2xl font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-user-pen"></i> Chỉnh sửa hồ sơ cá nhân
                </h2>
                <p class="text-blue-100 text-sm mt-1">Cập nhật thông tin để tăng cơ hội được tuyển dụng</p>
            </div>
            <button onclick="document.getElementById('editProfileModal').classList.add('hidden')" class="text-white hover:text-gray-200 text-3xl">
                ×
            </button>
        </div>

        <!-- Form -->
        <form id="editProfileForm" method="POST" action="<?php echo BASE_URL; ?>api.php" class="p-6 space-y-6">
            <input type="hidden" name="action" value="update-candidate-profile">

            <!-- Thông tin cơ bản -->
            <div class="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-6">
                <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                    <i class="fa-solid fa-id-card text-blue-500"></i> Thông tin cơ bản
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Họ và tên -->
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Họ và tên <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               required>
                    </div>

                    <!-- Email -->
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Email <span class="text-red-500">*</span>
                        </label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white cursor-not-allowed" 
                               readonly disabled>
                        <p class="text-xs text-slate-500 mt-1">Email không thể thay đổi</p>
                    </div>

                    <!-- Số điện thoại -->
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Số điện thoại <span class="text-red-500">*</span>
                        </label>
                        <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               placeholder="0912345678" required>
                    </div>

                    <!-- Ngày sinh -->
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Ngày sinh
                        </label>
                        <input type="date" name="date_of_birth" value="<?php echo htmlspecialchars($profile['date_of_birth'] ?? ''); ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <!-- Giới tính -->
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Giới tính
                        </label>
                        <select name="gender" class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            <option value="">-- Chọn giới tính --</option>
                            <option value="male" <?php echo ($profile['gender'] ?? '') === 'male' ? 'selected' : ''; ?>>Nam</option>
                            <option value="female" <?php echo ($profile['gender'] ?? '') === 'female' ? 'selected' : ''; ?>>Nữ</option>
                            <option value="other" <?php echo ($profile['gender'] ?? '') === 'other' ? 'selected' : ''; ?>>Khác</option>
                        </select>
                    </div>

                    <!-- Thành phố -->
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Thành phố <span class="text-red-500">*</span>
                        </label>
                        <select name="city" class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                            <option value="">-- Chọn thành phố --</option>
                            <option value="Hà Nội" <?php echo ($profile['city'] ?? '') === 'Hà Nội' ? 'selected' : ''; ?>>Hà Nội</option>
                            <option value="TP Hồ Chí Minh" <?php echo ($profile['city'] ?? '') === 'TP Hồ Chí Minh' ? 'selected' : ''; ?>>TP Hồ Chí Minh</option>
                            <option value="Đà Nẵng" <?php echo ($profile['city'] ?? '') === 'Đà Nẵng' ? 'selected' : ''; ?>>Đà Nẵng</option>
                            <option value="Hải Phòng" <?php echo ($profile['city'] ?? '') === 'Hải Phòng' ? 'selected' : ''; ?>>Hải Phòng</option>
                            <option value="Cần Thơ" <?php echo ($profile['city'] ?? '') === 'Cần Thơ' ? 'selected' : ''; ?>>Cần Thơ</option>
                        </select>
                    </div>
                </div>

                <!-- Địa chỉ -->
                <div class="mt-4">
                    <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                        Địa chỉ chi tiết
                    </label>
                    <input type="text" name="address" value="<?php echo htmlspecialchars($profile['address'] ?? ''); ?>" 
                           class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                           placeholder="Số nhà, tên đường, quận/huyện...">
                </div>
            </div>

            <!-- Kinh nghiệm & Học vấn -->
            <div class="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-6">
                <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                    <i class="fa-solid fa-graduation-cap text-purple-500"></i> Kinh nghiệm & Học vấn
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Số năm kinh nghiệm -->
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Số năm kinh nghiệm <span class="text-red-500">*</span>
                        </label>
                        <input type="number" name="experience_years" value="<?php echo htmlspecialchars($profile['experience_years'] ?? '0'); ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               min="0" max="50" required>
                    </div>

                    <!-- Trình độ học vấn -->
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Trình độ học vấn <span class="text-red-500">*</span>
                        </label>
                        <select name="education_level" class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                            <option value="">-- Chọn trình độ --</option>
                            <option value="Trung học" <?php echo ($profile['education_level'] ?? '') === 'Trung học' ? 'selected' : ''; ?>>Trung học</option>
                            <option value="Cao đẳng" <?php echo ($profile['education_level'] ?? '') === 'Cao đẳng' ? 'selected' : ''; ?>>Cao đẳng</option>
                            <option value="Đại học" <?php echo ($profile['education_level'] ?? '') === 'Đại học' ? 'selected' : ''; ?>>Đại học</option>
                            <option value="Thạc sĩ" <?php echo ($profile['education_level'] ?? '') === 'Thạc sĩ' ? 'selected' : ''; ?>>Thạc sĩ</option>
                            <option value="Tiến sĩ" <?php echo ($profile['education_level'] ?? '') === 'Tiến sĩ' ? 'selected' : ''; ?>>Tiến sĩ</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Kỹ năng & Giới thiệu -->
            <div class="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-6">
                <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                    <i class="fa-solid fa-lightbulb text-yellow-500"></i> Kỹ năng & Giới thiệu bản thân
                </h3>
                
                <!-- Kỹ năng -->
                <div class="mb-4">
                    <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                        Kỹ năng chuyên môn <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="skills" value="<?php echo htmlspecialchars($profile['skills'] ?? ''); ?>" 
                           class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                           placeholder="VD: JavaScript, React, Node.js, Python..." required>
                    <p class="text-xs text-slate-500 mt-1">Ngăn cách bằng dấu phẩy (,)</p>
                </div>

                <!-- Bio -->
                <div>
                    <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                        Giới thiệu bản thân <span class="text-red-500">*</span>
                    </label>
                    <textarea name="bio" rows="5" 
                              class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                              placeholder="Giới thiệu ngắn gọn về bản thân, kinh nghiệm làm việc và mục tiêu nghề nghiệp của bạn..." 
                              required><?php echo htmlspecialchars($profile['bio'] ?? ''); ?></textarea>
                    <p class="text-xs text-slate-500 mt-1">Tối thiểu 50 ký tự, tối đa 1000 ký tự</p>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="flex gap-4 justify-end pt-4 border-t border-slate-200 dark:border-slate-700">
                <button type="button" onclick="document.getElementById('editProfileModal').classList.add('hidden')" 
                        class="px-6 py-3 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 font-semibold transition">
                    Hủy
                </button>
                <button type="submit" 
                        class="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-lg font-semibold transition shadow-lg flex items-center gap-2">
                    <i class="fa-solid fa-save"></i> Lưu thay đổi
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Handle form submission
document.getElementById('editProfileForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    try {
        const response = await fetch('<?php echo BASE_URL; ?>api.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('✅ Cập nhật hồ sơ thành công!');
            location.reload();
        } else {
            alert('❌ Lỗi: ' + (data.message || 'Không thể cập nhật hồ sơ'));
        }
    } catch (error) {
        alert('❌ Lỗi: ' + error.message);
    }
});
</script>
