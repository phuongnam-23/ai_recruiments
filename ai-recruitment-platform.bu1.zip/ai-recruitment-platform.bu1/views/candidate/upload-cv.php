<?php
/**
 * UPLOAD CV - FIXED PATH VERSION
 * File: views/candidate/upload-cv.php
 */

// Turn off all error display
ini_set('display_errors', 0);
error_reporting(0);

// Start output buffering FIRST
ob_start();

// ============================================
// HANDLE AJAX UPLOAD REQUEST FIRST
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['cv'])) {
    // Clear any previous output
    ob_clean();
    
    // Set JSON header immediately
    header('Content-Type: application/json; charset=utf-8');
    
    // Start session if not started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Check authentication
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'candidate') {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Bạn cần đăng nhập với tài khoản ứng viên'
        ]);
        exit;
    }
    
    try {
        // Validate file exists
        if (!isset($_FILES['cv']) || $_FILES['cv']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Không nhận được file upload');
        }
        
        $file = $_FILES['cv'];
        
        // Validate file extension
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowedExtensions = ['doc', 'docx', 'pdf', 'jpg', 'jpeg', 'png'];
        
        if (!in_array($extension, $allowedExtensions)) {
            throw new Exception('Chỉ chấp nhận file DOC, DOCX, PDF, JPG, PNG');
        }
        
        // Validate file size (5MB)
        $maxSize = 5 * 1024 * 1024;
        if ($file['size'] > $maxSize) {
            throw new Exception('File không được vượt quá 5MB');
        }
        
        // --- [SỬA ĐƯỜNG DẪN] ---
        // Trỏ đúng vào utils/uploads/cv/
        $uploadDir = __DIR__ . '/../../utils/uploads/cv/';
        
        // Tạo thư mục nếu chưa có
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // Generate unique filename
        $newFilename = 'cv_' . $_SESSION['user_id'] . '_' . time() . '.' . $extension;
        $uploadPath = $uploadDir . $newFilename;
        
        // Move uploaded file
        if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
            throw new Exception('Không thể lưu file. Kiểm tra quyền thư mục utils/uploads/');
        }
        
        // --- [SỬA ĐƯỜNG DẪN DB] ---
        // Lưu đường dẫn tương đối bao gồm cả utils
        $relativePath = 'utils/uploads/cv/' . $newFilename;
        
        // Connect to database
        require_once __DIR__ . '/../../config/database.php';
        $database = new Database();
        $db = $database->getConnection();
        
        // First check if profile exists, if not create it
        $checkQuery = "SELECT id FROM candidate_profiles WHERE user_id = :user_id LIMIT 1";
        $checkStmt = $db->prepare($checkQuery);
        $checkStmt->bindParam(':user_id', $_SESSION['user_id']);
        $checkStmt->execute();
        $profileExists = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$profileExists) {
            // Create profile if it doesn't exist
            $insertQuery = "INSERT INTO candidate_profiles (user_id, created_at) VALUES (:user_id, NOW())";
            $insertStmt = $db->prepare($insertQuery);
            $insertStmt->bindParam(':user_id', $_SESSION['user_id']);
            if (!$insertStmt->execute()) {
                throw new Exception('Không thể tạo hồ sơ ứng viên. Vui lòng thử lại sau');
            }
        }
        
        // Update candidate profile with CV URL
        $query = "UPDATE candidate_profiles 
                  SET cv_file_url = :cv_url, 
                      updated_at = NOW() 
                  WHERE user_id = :user_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':cv_url', $relativePath);
        $stmt->bindParam(':user_id', $_SESSION['user_id']);
        
        if (!$stmt->execute()) {
            throw new Exception('Không thể lưu thông tin CV vào cơ sở dữ liệu');
        }
        
        // Return success
        http_response_code(200);
        echo json_encode([
            'success' => true,
            'message' => 'Tải CV lên thành công!',
            'filename' => $newFilename,
            'path' => $relativePath
        ]);
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
    
    exit; // IMPORTANT: Stop here for AJAX requests
}

// ============================================
// NORMAL PAGE LOAD (HTML RENDERING)
// ============================================

// Now load all required files
require_once __DIR__ . '/../../config/init.php';

// Check authentication for page view
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'candidate') {
    header('Location: ' . BASE_URL . 'login.php');
    exit;
}

// Get user info
require_once __DIR__ . '/../../utils/models/User.php';
require_once __DIR__ . '/../../utils/models/CandidateProfile.php';

$userModel = new User();
$candidateModel = new CandidateProfile();

$user = $userModel->getUserById($_SESSION['user_id']);
$profile = $candidateModel->getProfile($_SESSION['user_id']);

// --- [SỬA ĐƯỜNG DẪN ĐỌC FILE] ---
$cvDir = __DIR__ . '/../../utils/uploads/cv/';
$cvFiles = [];

if (is_dir($cvDir)) {
    $files = scandir($cvDir);
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..' && 
            stripos($file, 'cv_' . $_SESSION['user_id']) === 0) {
            $filePath = $cvDir . $file;
            $cvFiles[] = [
                'name' => $file,
                // Đường dẫn hiển thị cho HTML
                'path' => 'utils/uploads/cv/' . $file,
                'size' => filesize($filePath),
                'date' => filemtime($filePath)
            ];
        }
    }
    
    // Sort by date (newest first)
    usort($cvFiles, function($a, $b) {
        return $b['date'] - $a['date'];
    });
}

// Generate CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Clear output buffer and start HTML
ob_end_clean();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý CV - AI Recruitment</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 min-h-screen">
    <nav class="bg-white shadow-sm sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 py-4 flex flex-wrap items-center justify-between gap-4">
            <a href="<?php echo BASE_URL; ?>index.php" class="text-2xl font-bold text-blue-600">AI Recruitment</a>
            <div class="flex items-center gap-3 text-sm">
                <span class="hidden md:inline text-gray-700">Xin chào, <strong class="text-gray-900"><?php echo htmlspecialchars($user['full_name']); ?></strong></span>
                <a href="<?php echo BASE_URL; ?>views/candidate/dashboard.php" class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition">Dashboard</a>
                <a href="<?php echo BASE_URL; ?>logout.php" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-5xl mx-auto px-4 py-10 space-y-6">
        <div class="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg shadow p-6 text-white">
            <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <p class="text-sm uppercase tracking-[0.3em] text-white opacity-80">Trung tâm CV</p>
                    <h1 class="text-3xl font-bold mt-2">📄 Quản lý CV</h1>
                    <p class="text-white opacity-90 mt-3">Kéo thả để tải lên CV mới, quản lý phiên bản trước và tăng điểm chuyên nghiệp của bạn.</p>
                </div>
                <div class="flex gap-8 text-white opacity-90">ity-90">
                    <div>
                        <p class="text-xs uppercase tracking-widest text-white opacity-70">CV mới nhất</p>
                        <p class="text-2xl font-semibold mt-1">
                            <?php echo $profile && !empty($profile['cv_file_url']) ? date('d/m/Y', strtotime($profile['updated_at'])) : 'Chưa có'; ?>
                        </p>
                    </div>
                    <div>
                        <p class="text-xs uppercase tracking-widest text-white opacity-70">Phiên bản lưu</p>
                        <p class="text-2xl font-semibold mt-1"><?php echo count($cvFiles); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6 space-y-8">
            <div class="flex flex-col gap-2">
                <h2 class="text-xl font-semibold tracking-tight text-gray-900">Tải lên và quản lý các file CV của bạn</h2>
                <p class="text-gray-600">Hệ thống tự động lưu trữ lịch sử để bạn có thể quay lại phiên bản cũ bất cứ lúc nào.</p>
            </div>

            <div id="upload-section" class="mb-8">
                <div class="border-2 border-dashed border-gray-300 rounded-2xl p-8 text-center hover:border-blue-500 transition cursor-pointer bg-gray-50" id="upload-area">
                    <div class="mb-4">
                        <svg class="w-16 h-16 mx-auto text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-2">Kéo thả file CV ở đây</h3>
                    <p class="text-gray-600 mb-4">hoặc nhấp để chọn file từ máy tính</p>
                    <p class="text-sm text-gray-500">
                        📎 Hỗ trợ: DOCX, DOC, PDF, JPG, PNG<br>
                        📊 Kích thước tối đa: 5MB
                    </p>
                </div>
                
                <input type="file" id="cv-file-input" accept=".doc,.docx,.pdf,.jpg,.jpeg,.png,image/*" class="hidden">
                
                <button type="button" id="upload-btn" class="w-full px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition justify-center hidden mt-4">
                    ⬆️ Tải lên CV
                </button>
            </div>

            <?php if ($profile && !empty($profile['cv_file_url'])): ?>
                <div class="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 mb-8">
                    <h2 class="text-lg font-bold mb-4 text-emerald-700 flex items-center gap-2">
                        <span class="text-2xl">✅</span> CV Hiện Tại
                    </h2>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="bg-white p-3 rounded-xl">
                                <svg class="w-6 h-6 text-emerald-600" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"/>
                                </svg>
                            </div>
                            <div>
                                <p class="font-semibold text-gray-900"><?php echo basename($profile['cv_file_url']); ?></p>
                                <p class="text-sm text-gray-600">
                                    Cập nhật: <?php echo date('d/m/Y H:i', strtotime($profile['updated_at'])); ?>
                                </p>
                            </div>
                        </div>
                        <a href="../../<?php echo htmlspecialchars($profile['cv_file_url']); ?>" 
                           target="_blank" 
                           class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition">
                            📥 Tải xuống
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <div class="bg-amber-100 border border-amber-200 rounded-2xl p-6 mb-8">
                    <p class="text-amber-700 flex items-center gap-2">
                        <span class="text-2xl">⚠️</span>
                        Bạn chưa tải CV nào. Hãy tải CV để tăng cơ hội được recruiter chú ý!
                    </p>
                </div>
            <?php endif; ?>

            <?php if (!empty($cvFiles)): ?>
                <div class="bg-gray-100 rounded-2xl p-6 mb-8 border border-gray-200">
                    <h2 class="text-lg font-bold mb-4 text-gray-900">📋 Lịch Sử Tải</h2>
                    <div class="space-y-3">
                        <?php foreach ($cvFiles as $file): ?>
                            <div class="flex items-center justify-between bg-white rounded-xl p-4 border border-gray-200">
                                <div class="flex items-center gap-3">
                                    <div class="bg-gray-100 p-2 rounded-xl text-2xl">📄</div>
                                    <div>
                                        <p class="font-semibold text-gray-900"><?php echo htmlspecialchars($file['name']); ?></p>
                                        <p class="text-sm text-gray-600">
                                            📅 <?php echo date('d/m/Y H:i', $file['date']); ?> | 
                                            📊 <?php echo number_format($file['size'] / 1024, 2); ?> KB
                                        </p>
                                    </div>
                                </div>
                                <div class="flex gap-3">
                                    <a href="../../<?php echo htmlspecialchars($file['path']); ?>" 
                                       target="_blank"
                                       class="text-blue-500 hover:text-blue-700 text-xl" 
                                       title="Xem">👁️</a>
                                    <a href="../../<?php echo htmlspecialchars($file['path']); ?>" 
                                       download
                                       class="text-emerald-500 hover:text-emerald-700 text-xl" 
                                       title="Tải">⬇️</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="bg-sky-50 border border-sky-200 p-6 rounded-2xl">
                <h3 class="font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <span class="text-2xl">💡</span> Mẹo Làm CV Tốt
                </h3>
                <ul class="text-sm text-gray-700 space-y-2">
                    <li class="flex items-start gap-2">
                        <span>✓</span>
                        <span>Giữ CV ngắn gọn (1-2 trang)</span>
                    </li>
                    <li class="flex items-start gap-2">
                        <span>✓</span>
                        <span>Liệt kê kỹ năng liên quan đến công việc</span>
                    </li>
                    <li class="flex items-start gap-2">
                        <span>✓</span>
                        <span>Sử dụng định dạng chuyên nghiệp, dễ đọc</span>
                    </li>
                    <li class="flex items-start gap-2">
                        <span>✓</span>
                        <span>Kèm thông tin liên hệ rõ ràng</span>
                    </li>
                    <li class="flex items-start gap-2">
                        <span>✓</span>
                        <span>Cập nhật thường xuyên khi có kinh nghiệm mới</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <script>
    (function() {
        'use strict';
        
        const uploadArea = document.getElementById('upload-area');
        const fileInput = document.getElementById('cv-file-input');
        const uploadBtn = document.getElementById('upload-btn');
        
        let selectedFile = null;
        
        // Click to select file
        uploadArea.addEventListener('click', () => {
            fileInput.click();
        });
        
        // Drag and drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('border-blue-600', 'bg-blue-900/20');
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('border-blue-600', 'bg-blue-900/20');
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('border-blue-600', 'bg-blue-900/20');
            
            if (e.dataTransfer.files.length > 0) {
                handleFileSelect(e.dataTransfer.files[0]);
            }
        });
        
        // File input change
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                handleFileSelect(e.target.files[0]);
            }
        });
        
        // Handle file selection
        function handleFileSelect(file) {
            // Check Extension
            const extension = file.name.split('.').pop().toLowerCase();
            const allowedExtensions = ['doc', 'docx', 'pdf', 'jpg', 'jpeg', 'png'];
            
            if (!allowedExtensions.includes(extension)) {
                alert('❌ Chỉ chấp nhận file DOC, DOCX, PDF, JPG, PNG');
                return;
            }
            
            // Validate file size (5MB)
            const maxSize = 5 * 1024 * 1024;
            if (file.size > maxSize) {
                alert('❌ Kích thước file không được vượt quá 5MB');
                return;
            }
            
            selectedFile = file;
            
            // Update UI
            uploadArea.innerHTML = `
                <div class="mb-4">
                    <svg class="w-16 h-16 mx-auto text-green-500" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                    </svg>
                </div>
                <p class="text-lg font-semibold text-green-400">✅ ${file.name}</p>
                <p class="text-sm text-gray-700">${(file.size / 1024).toFixed(2)} KB</p>
                <button type="button" class="mt-4 text-blue-500 hover:text-blue-700 text-sm" onclick="location.reload()">
                    ← Chọn file khác
                </button>
            `;
            
            // Show upload button
            uploadBtn.classList.remove('hidden');
        }
        
        // Upload button click
        uploadBtn.addEventListener('click', function() {
            if (!selectedFile) {
                alert('Vui lòng chọn file CV');
                return;
            }
            
            // Create FormData
            const formData = new FormData();
            formData.append('cv', selectedFile);
            formData.append('csrf_token', '<?php echo $_SESSION['csrf_token']; ?>');
            
            // Disable button
            uploadBtn.disabled = true;
            uploadBtn.textContent = '⏳ Đang tải lên...';
            
            // Send AJAX request
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => {
                const contentType = response.headers.get('content-type');
                if (!contentType || !contentType.includes('application/json')) {
                    throw new Error('Server không trả về JSON. Có lỗi xảy ra.');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    alert('✅ ' + data.message);
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                } else {
                    alert('❌ ' + data.message);
                    uploadBtn.disabled = false;
                    uploadBtn.textContent = '⬆️ Tải lên CV';
                }
            })
            .catch(error => {
                console.error('Upload error:', error);
                alert('❌ Lỗi tải lên: ' + error.message);
                uploadBtn.disabled = false;
                uploadBtn.textContent = '⬆️ Tải lên CV';
            });
        });
    })();
    </script>

</body>
</html>