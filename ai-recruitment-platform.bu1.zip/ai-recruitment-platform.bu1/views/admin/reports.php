<?php
// views/admin/reports.php

// 1. Load các file cấu hình
require_once '../../config/init.php';

// Kiểm tra file Auth có tồn tại không trước khi require
if (file_exists('../../utils/middleware/Auth.php')) {
    require_once '../../utils/middleware/Auth.php';
} else {
    die("Lỗi: Không tìm thấy file Auth.php");
}

// Kiểm tra file Helpers
if (file_exists('../../utils/Helpers.php')) {
    require_once '../../utils/Helpers.php';
}

requireRole('admin');
addSecurityHeaders();

// 2. Kết nối Database an toàn
if (class_exists('Database')) {
    $db = (new Database())->getConnection();
} else {
    die("Lỗi: Class Database chưa được định nghĩa.");
}

// --- XỬ LÝ HÀNH ĐỘNG (Giải quyết báo cáo) ---
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $reportId = (int)($_POST['report_id'] ?? 0);
    
    if ($reportId) {
        $newStatus = '';
        $msgText = '';
        
        if ($action === 'resolve') {
            $newStatus = 'resolved';
            $msgText = '✅ Đã đánh dấu báo cáo là "Đã giải quyết".';
        } elseif ($action === 'dismiss') {
            $newStatus = 'dismissed';
            $msgText = '🚫 Đã bỏ qua báo cáo này.';
        }

        if ($newStatus) {
            try {
                // Cập nhật trạng thái báo cáo
                $stmt = $db->prepare("UPDATE reports SET status = :status, resolved_at = NOW() WHERE id = :id");
                $stmt->bindParam(':status', $newStatus);
                $stmt->bindParam(':id', $reportId);
                
                if ($stmt->execute()) {
                    $message = ['type' => 'success', 'text' => $msgText];
                } else {
                    $message = ['type' => 'error', 'text' => 'Lỗi cập nhật CSDL.'];
                }
            } catch (PDOException $e) {
                $message = ['type' => 'error', 'text' => 'Lỗi hệ thống: ' . $e->getMessage()];
            }
        }
    }
}

// --- LẤY DỮ LIỆU ---
$statusFilter = $_GET['status'] ?? 'pending';
$page = (int)($_GET['page'] ?? 1);
$limit = 10;
$offset = ($page - 1) * $limit;

// --- SỬA LỖI TẠI ĐÂY: Dùng r.reporter_id thay vì r.user_id ---
$query = "SELECT r.*, u.full_name as reporter_name, u.email as reporter_email
          FROM reports r
          LEFT JOIN users u ON r.reporter_id = u.id  
          WHERE 1=1";

$params = [];

if ($statusFilter !== 'all') {
    $query .= " AND r.status = :status";
    $params[':status'] = $statusFilter;
}

try {
    // Đếm tổng
    $countSql = str_replace("r.*, u.full_name as reporter_name, u.email as reporter_email", "COUNT(*)", $query);
    $countStmt = $db->prepare($countSql);
    foreach ($params as $key => $value) $countStmt->bindValue($key, $value);
    $countStmt->execute();
    $totalRecords = $countStmt->fetchColumn();
    $totalPages = ceil($totalRecords / $limit);

    // Lấy dữ liệu
    $query .= " ORDER BY r.created_at DESC LIMIT :limit OFFSET :offset";
    $stmt = $db->prepare($query);
    foreach ($params as $key => $value) $stmt->bindValue($key, $value);
    $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
    $stmt->execute();
    $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Lỗi truy vấn: " . $e->getMessage()); // Hiện lỗi SQL chi tiết để debug
}

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Báo cáo vi phạm - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 font-sans">
    <!-- Navigation -->
    <nav class="bg-white dark:bg-slate-800 shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="dashboard.php" class="text-2xl font-bold tracking-tight text-blue-500 hover:text-blue-700 flex items-center gap-2">
                <i class="fa-solid fa-user-shield"></i> AI Recruitment Admin
            </a>
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:text-white transition"><i class="fa-solid fa-arrow-left"></i> Dashboard</a>
                <a href="../../logout.php" class="text-red-400 hover:text-red-800 font-medium transition">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mb-6">
            <!-- Header -->
            <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4 border-b pb-6">
                <div>
                    <h1 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white"><i class="fa-solid fa-triangle-exclamation text-red-500 mr-2"></i> Báo cáo vi phạm</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Tổng số: <strong><?php echo number_format($totalRecords); ?></strong> báo cáo</p>
                </div>
                
                <form class="flex items-center gap-3" method="GET">
                    <label class="text-sm font-semibold text-slate-700 dark:text-slate-300">Trạng thái:</label>
                    <select name="status" class="border rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-blue-500 bg-white dark:bg-slate-800" onchange="this.form.submit()">
                        <option value="pending" <?php echo $statusFilter === 'pending' ? 'selected' : ''; ?>>⏳ Chờ xử lý</option>
                        <option value="resolved" <?php echo $statusFilter === 'resolved' ? 'selected' : ''; ?>>✅ Đã giải quyết</option>
                        <option value="dismissed" <?php echo $statusFilter === 'dismissed' ? 'selected' : ''; ?>>🚫 Đã bỏ qua</option>
                        <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>Tất cả</option>
                    </select>
                </form>
            </div>

            <!-- Alerts -->
            <?php if (!empty($message)): ?>
                <div class="bg-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-6 text-sm flex items-center shadow-sm">
                    <i class="fa-solid <?php echo $message['type'] === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i> 
                    <?php echo $message['text']; ?>
                </div>
            <?php endif; ?>

            <!-- Reports Table -->
            <div class="overflow-x-auto rounded-xl border border-slate-200/50 dark:border-slate-700/50">
                <table class="w-full text-sm text-left text-slate-500 dark:text-slate-400">
                    <thead class="text-xs text-slate-700 dark:text-slate-300 uppercase bg-slate-50 dark:bg-slate-900">
                        <tr>
                            <th class="px-6 py-3">Người báo cáo</th>
                            <th class="px-6 py-3">Đối tượng bị báo cáo</th>
                            <th class="px-6 py-3">Lý do / Nội dung</th>
                            <th class="px-6 py-3 text-center">Trạng thái</th>
                            <th class="px-6 py-3 text-center">Ngày gửi</th>
                            <th class="px-6 py-3 text-center">Xử lý</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php if (empty($reports)): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-12 text-center text-slate-500 dark:text-slate-400 italic bg-slate-50 dark:bg-slate-900">
                                    <?php if ($statusFilter === 'pending'): ?>
                                        <i class="fa-solid fa-shield-halved text-4xl text-green-200 mb-3 block"></i>
                                        Tuyệt vời! Hệ thống trong sạch, không có báo cáo nào mới.
                                    <?php else: ?>
                                        Không tìm thấy dữ liệu.
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($reports as $report): ?>
                                <tr class="bg-white dark:bg-slate-800 hover:bg-red-900/20/20 transition">
                                    <!-- Cột 1: Người báo cáo -->
                                    <td class="px-6 py-4">
                                        <div class="font-medium text-slate-900 dark:text-white"><?php echo htmlspecialchars($report['reporter_name'] ?? 'Ẩn danh'); ?></div>
                                        <div class="text-xs text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($report['reporter_email'] ?? ''); ?></div>
                                    </td>

                                    <!-- Cột 2: Đối tượng -->
                                    <td class="px-6 py-4">
                                        <?php 
                                        $typeLabels = [
                                            'job' => ['text' => 'Tin tuyển dụng', 'icon' => 'fa-briefcase', 'color' => 'text-purple-600', 'link' => 'jobs.php?highlight='],
                                            'user' => ['text' => 'Người dùng', 'icon' => 'fa-user', 'color' => 'text-blue-500', 'link' => 'users.php?search='], 
                                            'review' => ['text' => 'Đánh giá', 'icon' => 'fa-star', 'color' => 'text-orange-600', 'link' => '#']
                                        ];
                                        $targetType = $report['reported_type'] ?? 'unknown'; // Sửa reported_type nếu cần
                                        $target = $typeLabels[$targetType] ?? ['text' => $targetType, 'icon' => 'fa-question', 'color' => 'text-slate-700 dark:text-slate-300', 'link' => '#'];
                                        ?>
                                        <div class="flex items-center gap-2">
                                            <i class="fa-solid <?php echo $target['icon']; ?> <?php echo $target['color']; ?>"></i>
                                            <span class="font-medium"><?php echo $target['text']; ?></span>
                                            <span class="text-xs text-slate-500 dark:text-slate-400">#<?php echo $report['reported_id'] ?? 0; ?></span> <!-- Sửa reported_id -->
                                        </div>
                                        <a href="<?php echo $target['link'] . ($report['reported_id'] ?? ''); ?>" class="text-xs text-blue-500 hover:underline mt-1 inline-block">
                                            Xem đối tượng <i class="fa-solid fa-external-link-alt ml-0.5"></i>
                                        </a>
                                    </td>

                                    <!-- Cột 3: Lý do -->
                                    <td class="px-6 py-4 max-w-xs">
                                        <div class="text-slate-900 dark:text-white italic">"<?php echo htmlspecialchars($report['reason'] ?? ''); ?>"</div>
                                        <?php if(!empty($report['description'])): ?>
                                            <div class="text-xs text-slate-500 dark:text-slate-400 mt-1"><?php echo htmlspecialchars($report['description']); ?></div>
                                        <?php endif; ?>
                                    </td>

                                    <!-- Cột 4: Trạng thái -->
                                    <td class="px-6 py-4 text-center">
                                        <?php
                                        $statusConfig = [
                                            'pending' => ['bg' => 'bg-yellow-100', 'text' => 'text-yellow-700', 'label' => 'Chờ xử lý', 'icon' => 'fa-clock'],
                                            'resolved' => ['bg' => 'bg-green-100', 'text' => 'text-green-700', 'label' => 'Đã xử lý', 'icon' => 'fa-check'],
                                            'dismissed' => ['bg' => 'bg-white dark:bg-slate-800', 'text' => 'text-slate-700 dark:text-slate-300', 'label' => 'Bỏ qua', 'icon' => 'fa-xmark']
                                        ];
                                        $currentStatus = $report['status'] ?? 'pending';
                                        $conf = $statusConfig[$currentStatus] ?? $statusConfig['pending'];
                                        ?>
                                        <span class="px-2.5 py-1 rounded-full text-xs font-semibold <?php echo $conf['bg'] . ' ' . $conf['text']; ?> inline-flex items-center gap-1">
                                            <i class="fa-solid <?php echo $conf['icon']; ?>"></i> <?php echo $conf['label']; ?>
                                        </span>
                                    </td>

                                    <!-- Cột 5: Ngày gửi -->
                                    <td class="px-6 py-4 text-center text-xs text-slate-500 dark:text-slate-400">
                                        <?php 
                                        $createdAt = $report['created_at'] ?? 'now';
                                        if (class_exists('DateHelper')) {
                                            echo DateHelper::formatDateTime($createdAt);
                                        } else {
                                            echo date('d/m/Y H:i', strtotime($createdAt));
                                        }
                                        ?>
                                    </td>

                                    <!-- Cột 6: Hành động -->
                                    <td class="px-6 py-4 text-center">
                                        <?php if ($currentStatus === 'pending'): ?>
                                            <div class="flex justify-center gap-2">
                                                <!-- Nút Resolve (Đã xử lý xong) -->
                                                <form method="POST" onsubmit="return confirm('Xác nhận đã giải quyết báo cáo này?');" style="display:inline;">
                                                    <input type="hidden" name="action" value="resolve">
                                                    <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                    <button type="submit" class="p-2 text-green-400 bg-green-900/20 hover:bg-green-100 rounded-xl transition border border-green-200" title="Đánh dấu đã giải quyết">
                                                        <i class="fa-solid fa-check-double"></i>
                                                    </button>
                                                </form>
                                                
                                                <!-- Nút Dismiss (Bỏ qua) -->
                                                <form method="POST" onsubmit="return confirm('Bỏ qua báo cáo này (không vi phạm)?');" style="display:inline;">
                                                    <input type="hidden" name="action" value="dismiss">
                                                    <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                    <button type="submit" class="p-2 text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:bg-slate-700 rounded-xl transition border border-slate-200/50 dark:border-slate-700/50" title="Bỏ qua">
                                                        <i class="fa-solid fa-eye-slash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-xs text-slate-500 dark:text-slate-400">Đã xong</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="flex justify-center mt-8 gap-2">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&status=<?php echo $statusFilter; ?>" class="px-3 py-1 rounded border bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800"><i class="fa-solid fa-chevron-left"></i></a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&status=<?php echo $statusFilter; ?>" class="px-3 py-1 rounded border font-medium <?php echo $i === $page ? 'bg-blue-600 text-slate-900 dark:text-white border-blue-600' : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800'; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&status=<?php echo $statusFilter; ?>" class="px-3 py-1 rounded border bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800"><i class="fa-solid fa-chevron-right"></i></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>