<?php
// views/admin/dashboard.php

require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/User.php';
require_once '../../utils/models/Job.php';

requireRole('admin');
addSecurityHeaders();

$userModel = new User();
$jobModel = new Job();
$db = (new Database())->getConnection();

$user = $userModel->getUserById($_SESSION['user_id']);
// Avatar: Ưu tiên DB > Session > Mặc định - thêm BASE_URL nếu path tương đối
$avatarUrl = '';
if (!empty($user['avatar_url'])) {
    // Nếu đã có BASE_URL hoặc http, dùng luôn
    if (strpos($user['avatar_url'], 'http') === 0 || strpos($user['avatar_url'], 'ui-avatars') === 0) {
        $avatarUrl = $user['avatar_url'];
    } else {
        // Nếu là path tương đối, thêm BASE_URL
        $avatarUrl = BASE_URL . $user['avatar_url'];
    }
} else {
    $avatarUrl = 'https://ui-avatars.com/api/?name=Admin&background=random';
}

// Stats
$candidateCount = $userModel->countUsersByRole('candidate');
$recruiterCount = $userModel->countUsersByRole('recruiter');
$activeJobs = $db->query("SELECT COUNT(*) FROM jobs WHERE status = 'active'")->fetchColumn();
$pendingApps = $db->query("SELECT COUNT(*) FROM applications WHERE status = 'pending'")->fetchColumn();

// ===== GROWTH DATA FOR LAST 7 DAYS =====
$growthData = [
    'dates' => [],
    'new_candidates' => [],
    'new_recruiters' => [],
    'new_jobs' => [],
    'new_applications' => []
];

// Generate dates for last 7 days
$today = new DateTime();
$dates = [];
for ($i = 6; $i >= 0; $i--) {
    $date = clone $today;
    $date->modify("-$i days");
    $dates[$date->format('Y-m-d')] = $date->format('d/m');
}

// Query 1: New candidates by date
$sql1 = "SELECT DATE(created_at) as date, COUNT(*) as count 
         FROM users 
         WHERE role = 'candidate' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
         GROUP BY DATE(created_at)";
$result1 = $db->query($sql1)->fetchAll(PDO::FETCH_ASSOC);
$candidates_by_date = [];
foreach ($result1 as $row) {
    $candidates_by_date[$row['date']] = (int)$row['count'];
}

// Query 2: New recruiters by date
$sql2 = "SELECT DATE(created_at) as date, COUNT(*) as count 
         FROM users 
         WHERE role = 'recruiter' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
         GROUP BY DATE(created_at)";
$result2 = $db->query($sql2)->fetchAll(PDO::FETCH_ASSOC);
$recruiters_by_date = [];
foreach ($result2 as $row) {
    $recruiters_by_date[$row['date']] = (int)$row['count'];
}

// Query 3: New jobs by date
$sql3 = "SELECT DATE(created_at) as date, COUNT(*) as count 
         FROM jobs 
         WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
         GROUP BY DATE(created_at)";
$result3 = $db->query($sql3)->fetchAll(PDO::FETCH_ASSOC);
$jobs_by_date = [];
foreach ($result3 as $row) {
    $jobs_by_date[$row['date']] = (int)$row['count'];
}

// Query 4: New applications by date
$sql4 = "SELECT DATE(applied_at) as date, COUNT(*) as count 
         FROM applications 
         WHERE applied_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
         GROUP BY DATE(applied_at)";
$result4 = $db->query($sql4)->fetchAll(PDO::FETCH_ASSOC);
$applications_by_date = [];
foreach ($result4 as $row) {
    $applications_by_date[$row['date']] = (int)$row['count'];
}

// Build growth data array with 0 for missing dates
foreach ($dates as $dateStr => $dateLabel) {
    $growthData['dates'][] = $dateLabel;
    $growthData['new_candidates'][] = $candidates_by_date[$dateStr] ?? 0;
    $growthData['new_recruiters'][] = $recruiters_by_date[$dateStr] ?? 0;
    $growthData['new_jobs'][] = $jobs_by_date[$dateStr] ?? 0;
    $growthData['new_applications'][] = $applications_by_date[$dateStr] ?? 0;
}

// Convert to JSON for JavaScript
$growthDataJson = json_encode($growthData);

if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 text-slate-900 dark:text-white font-sans min-h-screen transition-colors duration-300">
    <!-- Navigation -->
    <nav class="backdrop-blur-md bg-white/80 dark:bg-slate-900/80 border-b border-slate-200/50 dark:border-slate-700/50 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
            <div class="flex items-center gap-3">
                <a href="../../index.php" class="flex items-center gap-2 hover:opacity-80 transition">
                    <i class="fa-solid fa-user-shield text-blue-500 text-2xl"></i>
                    <span class="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">AI Recruitment Admin</span>
                </a>
            </div>
            <div class="flex items-center gap-4">
                <div class="relative group dropdown-group" style="padding-bottom: 8px;">
                    <button class="flex items-center gap-2 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:text-white font-medium transition dropdown-btn">
                        <img src="<?php echo $avatarUrl; ?>" class="w-8 h-8 rounded-full border border-slate-300/50 dark:border-slate-600/50 object-cover" id="nav-avatar">
                        <?php echo htmlspecialchars($_SESSION['full_name']); ?> ▼
                    </button>
                    <div class="hidden group-hover:block absolute right-0 mt-0 bg-white dark:bg-slate-800 shadow-xl rounded-xl min-w-[200px] z-10 border border-slate-200/50 dark:border-slate-700/50 overflow-hidden dropdown-menu">
                        <a href="dashboard.php" class="block px-4 py-3 hover:bg-slate-100 dark:bg-slate-700 transition"><i class="fa-solid fa-chart-line w-6"></i> Dashboard</a>
                        <div class="border-t border-slate-200/50 dark:border-slate-700/50"></div>
                        <a href="../../logout.php" class="block px-4 py-3 hover:bg-red-900/30 text-red-400 transition"><i class="fa-solid fa-right-from-bracket w-6"></i> Đăng xuất</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <!-- 1. Stats Overview -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 p-6 border border-slate-200/50 dark:border-slate-700/50 hover:border-blue-500 transition group relative overflow-hidden">
                <div class="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition"><i class="fa-solid fa-users text-6xl text-blue-500"></i></div>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider">Ứng viên</p>
                <h3 class="text-3xl font-bold tracking-tight tracking-tight text-blue-400 mt-2"><?php echo number_format($candidateCount); ?></h3>
            </div>
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 p-6 border border-slate-200/50 dark:border-slate-700/50 hover:border-green-500 transition group relative overflow-hidden">
                <div class="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition"><i class="fa-solid fa-building text-6xl text-green-500"></i></div>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider">Nhà tuyển dụng</p>
                <h3 class="text-3xl font-bold tracking-tight tracking-tight text-green-400 mt-2"><?php echo number_format($recruiterCount); ?></h3>
            </div>
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 p-6 border border-slate-200/50 dark:border-slate-700/50 hover:border-purple-500 transition group relative overflow-hidden">
                <div class="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition"><i class="fa-solid fa-briefcase text-6xl text-purple-500"></i></div>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider">Tin tuyển dụng</p>
                <h3 class="text-3xl font-bold tracking-tight tracking-tight text-purple-400 mt-2"><?php echo number_format($activeJobs); ?></h3>
            </div>
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 p-6 border border-slate-200/50 dark:border-slate-700/50 hover:border-orange-500 transition group relative overflow-hidden">
                <div class="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition"><i class="fa-solid fa-file-contract text-6xl text-orange-500"></i></div>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider">Đơn chờ xử lý</p>
                <h3 class="text-3xl font-bold tracking-tight tracking-tight text-orange-400 mt-2"><?php echo number_format($pendingApps); ?></h3>
            </div>
        </div>

        <!-- BIỂU ĐỒ TĂNG TRƯỞNG 7 NGÀY -->
        <div class="mb-8">
            <h2 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                <i class="fa-solid fa-chart-line text-blue-500"></i> Biểu Đồ Tăng Trưởng 7 Ngày
            </h2>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Chart 1: Line Chart - Ứng viên vs NTD -->
                <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 border border-slate-200/50 dark:border-slate-700/50 p-6 shadow-lg">
                    <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                        <i class="fa-solid fa-users text-blue-400"></i> Ứng Viên vs Nhà Tuyển Dụng
                    </h3>
                    <div class="relative w-full h-80">
                        <canvas id="lineChart"></canvas>
                    </div>
                </div>

                <!-- Chart 2: Bar Chart - Tin Tuyển dụng vs Lượt Ứng Tuyển -->
                <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 border border-slate-200/50 dark:border-slate-700/50 p-6 shadow-lg">
                    <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                        <i class="fa-solid fa-briefcase text-purple-400"></i> Tin Tuyển Dụng vs Lượt Ứng Tuyển
                    </h3>
                    <div class="relative w-full h-80">
                        <canvas id="barChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- 2. CỘT TRÁI: HỒ SƠ ADMIN & UPLOAD ẢNH -->
            <div class="lg:col-span-1">
                <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 border border-slate-200/50 dark:border-slate-700/50 p-6 shadow-lg">
                    <h2 class="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2"><i class="fa-solid fa-id-card text-blue-500"></i> Hồ sơ Admin</h2>
                    
                    <form id="profile-form" class="space-y-4" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="update-profile">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                        <!-- Avatar Upload Component -->
                        <div class="text-center mb-6">
                            <?php include __DIR__ . '/../../components/avatar-upload.php'; ?>
                        </div>

                        <!-- Thông tin cá nhân -->
                        <div>
                            <label class="block text-xs text-slate-500 dark:text-slate-400 mb-1 font-bold uppercase">Họ và tên</label>
                            <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" class="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300/50 dark:border-slate-600/50 rounded px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-blue-500">
                        </div>
                        <div>
                            <label class="block text-xs text-slate-500 dark:text-slate-400 mb-1 font-bold uppercase">Số điện thoại</label>
                            <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" class="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300/50 dark:border-slate-600/50 rounded px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-blue-500">
                        </div>
                        <div>
                            <label class="block text-xs text-slate-500 dark:text-slate-400 mb-1 font-bold uppercase">Email (Không đổi)</label>
                            <input type="text" value="<?php echo htmlspecialchars($user['email']); ?>" disabled class="w-full bg-slate-100 dark:bg-slate-700/50 border border-slate-200/50 dark:border-slate-700/50 rounded px-3 py-2 text-slate-500 dark:text-slate-400 cursor-not-allowed">
                        </div>

                        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-900/200 text-slate-900 dark:text-white font-bold py-2 rounded transition flex justify-center items-center gap-2">
                            <i class="fa-solid fa-save"></i> Cập nhật hồ sơ
                        </button>
                    </form>
                </div>
            </div>

            <!-- 3. CỘT PHẢI: MENU CHỨC NĂNG (7 MỤC - Đã khôi phục đầy đủ) -->
            <div class="lg:col-span-2">
                <h2 class="text-xl font-bold tracking-tight text-slate-900 dark:text-white mb-4 flex items-center gap-2"><i class="fa-solid fa-layer-group text-blue-500"></i> Chức năng quản lý</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    <a href="users.php" class="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200/50 dark:border-slate-700/50 hover:bg-gray-750 hover:border-blue-500 transition group flex items-start gap-4">
                        <div class="w-10 h-10 bg-blue-900/30 rounded-xl flex items-center justify-center text-blue-400 group-hover:bg-blue-600 group-hover:text-slate-900 dark:text-white transition">
                            <i class="fa-solid fa-users-gear"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-bold text-gray-800 dark:text-gray-200 group-hover:text-blue-400 transition">Quản lý người dùng</h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Danh sách, phân quyền, khóa tài khoản.</p>
                        </div>
                    </a>

                    <a href="jobs.php" class="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200/50 dark:border-slate-700/50 hover:bg-gray-750 hover:border-purple-500 transition group flex items-start gap-4">
                        <div class="w-10 h-10 bg-purple-900/30 rounded-xl flex items-center justify-center text-purple-400 group-hover:bg-purple-600 group-hover:text-slate-900 dark:text-white transition">
                            <i class="fa-solid fa-briefcase"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-bold text-gray-800 dark:text-gray-200 group-hover:text-purple-400 transition">Quản lý tin tuyển dụng</h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Duyệt tin, xóa tin vi phạm.</p>
                        </div>
                    </a>

                    <a href="applications.php" class="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200/50 dark:border-slate-700/50 hover:bg-gray-750 hover:border-orange-500 transition group flex items-start gap-4">
                        <div class="w-10 h-10 bg-orange-900/30 rounded-xl flex items-center justify-center text-orange-400 group-hover:bg-orange-600 group-hover:text-slate-900 dark:text-white transition">
                            <i class="fa-solid fa-file-contract"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-bold text-gray-800 dark:text-gray-200 group-hover:text-orange-400 transition">Quản lý đơn apply</h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Theo dõi, thống kê đơn ứng tuyển.</p>
                        </div>
                    </a>

                    <a href="verification.php" class="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200/50 dark:border-slate-700/50 hover:bg-gray-750 hover:border-green-500 transition group flex items-start gap-4">
                        <div class="w-10 h-10 bg-green-900/30 rounded-xl flex items-center justify-center text-green-400 group-hover:bg-green-600 group-hover:text-slate-900 dark:text-white transition">
                            <i class="fa-solid fa-certificate"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-bold text-gray-800 dark:text-gray-200 group-hover:text-green-400 transition">Xác thực công ty</h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Kiểm tra giấy phép KD của Recruiter.</p>
                        </div>
                    </a>

                    <a href="reports.php" class="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200/50 dark:border-slate-700/50 hover:bg-gray-750 hover:border-red-500 transition group flex items-start gap-4">
                        <div class="w-10 h-10 bg-red-900/30 rounded-xl flex items-center justify-center text-red-400 group-hover:bg-red-600 group-hover:text-slate-900 dark:text-white transition">
                            <i class="fa-solid fa-triangle-exclamation"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-bold text-gray-800 dark:text-gray-200 group-hover:text-red-400 transition">Báo cáo vi phạm</h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Xử lý khiếu nại, báo cáo xấu.</p>
                        </div>
                    </a>

                    <a href="settings.php" class="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200/50 dark:border-slate-700/50 hover:bg-gray-750 hover:border-slate-300/50 dark:border-slate-600/50 transition group flex items-start gap-4">
                        <div class="w-10 h-10 bg-slate-100 dark:bg-slate-700 rounded-xl flex items-center justify-center text-slate-700 dark:text-slate-300 group-hover:bg-slate-50 dark:bg-slate-9000 group-hover:text-slate-900 dark:text-white transition">
                            <i class="fa-solid fa-sliders"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-bold text-gray-800 dark:text-gray-200 group-hover:text-slate-700 dark:text-slate-300 transition">Cài đặt hệ thống</h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Cấu hình chung, SEO, email...</p>
                        </div>
                    </a>

                    <a href="uploads.php" class="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200/50 dark:border-slate-700/50 hover:bg-gray-750 hover:border-yellow-500 transition group flex items-start gap-4">
                        <div class="w-10 h-10 bg-yellow-900/30 rounded-xl flex items-center justify-center text-yellow-400 group-hover:bg-yellow-600 group-hover:text-slate-900 dark:text-white transition">
                            <i class="fa-solid fa-folder-open"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-bold text-gray-800 dark:text-gray-200 group-hover:text-yellow-400 transition">Quản lý Upload</h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Quản lý file CV, hình ảnh.</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function previewImage(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('preview-avatar').src = e.target.result;
                    document.getElementById('view-avatar-link').href = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        document.getElementById('profile-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const btn = this.querySelector('button[type="submit"]');
            const formData = new FormData(this);

            btn.disabled = true;
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Đang lưu...';

            fetch('../../api.php', {
                method: 'POST',
                body: formData
            })
            .then(async res => {
                const text = await res.text();
                try { return JSON.parse(text); } catch { throw new Error('Lỗi Server (Trả về không phải JSON): ' + text); }
            })
            .then(data => {
                if(data.success) {
                    alert('✅ ' + data.message);
                    if (data.avatar_url) {
                        // Thêm timestamp để ép trình duyệt tải lại ảnh mới (Fix lỗi cache)
                        const newSrc = data.avatar_url + '?t=' + new Date().getTime();
                        document.getElementById('nav-avatar').src = newSrc;
                        document.getElementById('preview-avatar').src = newSrc;
                        document.getElementById('view-avatar-link').href = data.avatar_url;
                    }
                } else {
                    alert('❌ ' + data.message);
                }
            })
            .catch(err => {
                console.error(err);
                alert('❌ ' + err.message); 
            })
            .finally(() => {
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-save"></i> Cập nhật hồ sơ';
            });
        });

        // Fix dropdown menu
        document.querySelectorAll('.dropdown-group').forEach(group => {
            const btn = group.querySelector('.dropdown-btn');
            const menu = group.querySelector('.dropdown-menu');
            
            if (btn && menu) {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    menu.classList.toggle('!block');
                    menu.classList.toggle('!opacity-100');
                });
                
                group.addEventListener('mouseleave', () => {
                    menu.classList.remove('!block');
                    menu.classList.remove('!opacity-100');
                });
            }
        });
        
        document.addEventListener('click', (e) => {
            document.querySelectorAll('.dropdown-menu').forEach(menu => {
                if (!menu.closest('.dropdown-group')?.contains(e.target)) {
                    menu.classList.remove('!block');
                    menu.classList.remove('!opacity-100');
                }
            });
        });

        // ===== CHART.JS INITIALIZATION =====
        // Dummy data for testing (PRODUCTION: DISABLE THIS)
        const dummyData = {
            dates: ['26/11', '27/11', '28/11', '29/11', '30/11', '01/12', '02/12'],
            new_candidates: [5, 8, 3, 12, 6, 9, 7],
            new_recruiters: [2, 4, 1, 5, 3, 6, 4],
            new_jobs: [3, 6, 2, 8, 4, 7, 5],
            new_applications: [8, 12, 5, 15, 10, 14, 11]
        };

        // PRODUCTION: Use real data from PHP database
        const growthData = <?php echo $growthDataJson; ?>;

        // Line Chart: Ứng viên vs NTD
        const lineCtx = document.getElementById('lineChart');
        if (lineCtx) {
            const lineChart = new Chart(lineCtx, {
                type: 'line',
                data: {
                    labels: growthData.dates,
                    datasets: [
                        {
                            label: 'Ứng viên mới',
                            data: growthData.new_candidates,
                            borderColor: '#3B82F6',
                            backgroundColor: 'rgba(59, 130, 246, 0.1)',
                            borderWidth: 2,
                            tension: 0.4,
                            fill: true,
                            pointRadius: 5,
                            pointBackgroundColor: '#3B82F6',
                            pointBorderColor: '#1E3A8A',
                            pointBorderWidth: 2,
                            pointHoverRadius: 7
                        },
                        {
                            label: 'NTD mới',
                            data: growthData.new_recruiters,
                            borderColor: '#10B981',
                            backgroundColor: 'rgba(16, 185, 129, 0.1)',
                            borderWidth: 2,
                            tension: 0.4,
                            fill: true,
                            pointRadius: 5,
                            pointBackgroundColor: '#10B981',
                            pointBorderColor: '#065F46',
                            pointBorderWidth: 2,
                            pointHoverRadius: 7
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            labels: {
                                color: '#E5E7EB',
                                font: { size: 12, weight: 'bold' },
                                usePointStyle: true,
                                padding: 15
                            },
                            position: 'top'
                        },
                        tooltip: {
                            backgroundColor: '#1F2937',
                            titleColor: '#F3F4F6',
                            bodyColor: '#E5E7EB',
                            borderColor: '#4B5563',
                            borderWidth: 1,
                            padding: 12,
                            titleFont: { size: 13, weight: 'bold' },
                            bodyFont: { size: 12 }
                        }
                    },
                    scales: {
                        x: {
                            grid: { color: 'rgba(75, 85, 99, 0.2)' },
                            ticks: { color: '#9CA3AF', font: { size: 11 } }
                        },
                        y: {
                            grid: { color: 'rgba(75, 85, 99, 0.2)' },
                            ticks: { color: '#9CA3AF', font: { size: 11 }, beginAtZero: true },
                            min: 0
                        }
                    }
                }
            });
        }

        // Bar Chart: Tin Tuyển dụng vs Lượt Ứng Tuyển
        const barCtx = document.getElementById('barChart');
        if (barCtx) {
            const barChart = new Chart(barCtx, {
                type: 'bar',
                data: {
                    labels: growthData.dates,
                    datasets: [
                        {
                            label: 'Tin tuyển dụng mới',
                            data: growthData.new_jobs,
                            backgroundColor: '#A855F7',
                            borderColor: '#7E22CE',
                            borderWidth: 1,
                            borderRadius: 5,
                            hoverBackgroundColor: '#D946EF'
                        },
                        {
                            label: 'Lượt ứng tuyển mới',
                            data: growthData.new_applications,
                            backgroundColor: '#F97316',
                            borderColor: '#EA580C',
                            borderWidth: 1,
                            borderRadius: 5,
                            hoverBackgroundColor: '#FB923C'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            labels: {
                                color: '#E5E7EB',
                                font: { size: 12, weight: 'bold' },
                                usePointStyle: true,
                                padding: 15
                            },
                            position: 'top'
                        },
                        tooltip: {
                            backgroundColor: '#1F2937',
                            titleColor: '#F3F4F6',
                            bodyColor: '#E5E7EB',
                            borderColor: '#4B5563',
                            borderWidth: 1,
                            padding: 12,
                            titleFont: { size: 13, weight: 'bold' },
                            bodyFont: { size: 12 }
                        }
                    },
                    scales: {
                        x: {
                            grid: { drawBorder: false },
                            ticks: { color: '#9CA3AF', font: { size: 11 } }
                        },
                        y: {
                            grid: { color: 'rgba(75, 85, 99, 0.2)' },
                            ticks: { color: '#9CA3AF', font: { size: 11 }, beginAtZero: true },
                            min: 0
                        }
                    }
                }
            });
        }
    </script>
</body>
</html>