<?php
// views/admin/settings.php

require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/Helpers.php'; 

requireRole('admin');
addSecurityHeaders();

$db = (new Database())->getConnection();

// --- XỬ LÝ LƯU CẤU HÌNH ---
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings = $_POST['settings'] ?? [];
    
    try {
        $db->beginTransaction();
        
        // Chuẩn bị câu lệnh Insert hoặc Update (Upsert)
        // Giả sử bảng system_settings có cột: setting_key (Primary), setting_value
        $stmt = $db->prepare("INSERT INTO system_settings (setting_key, setting_value) 
                              VALUES (:key, :value) 
                              ON DUPLICATE KEY UPDATE setting_value = :value");
        
        foreach ($settings as $key => $value) {
            $stmt->bindValue(':key', $key);
            $stmt->bindValue(':value', $value);
            $stmt->execute();
        }
        
        $db->commit();
        $message = ['type' => 'success', 'text' => '✅ Đã lưu cấu hình hệ thống thành công.'];
    } catch (Exception $e) {
        $db->rollBack();
        $message = ['type' => 'error', 'text' => '❌ Lỗi khi lưu: ' . $e->getMessage()];
    }
}

// --- LẤY CẤU HÌNH HIỆN TẠI ---
// Lấy tất cả settings đưa vào mảng $config
$config = [];
$stmt = $db->query("SELECT setting_key, setting_value FROM system_settings");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $config[$row['setting_key']] = $row['setting_value'];
}

// Helper để lấy giá trị config an toàn
function getConf($key, $default = '') {
    global $config;
    return isset($config[$key]) ? htmlspecialchars($config[$key]) : $default;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cài đặt hệ thống - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 font-sans">
    <!-- Navigation -->
    <nav class="bg-white dark:bg-slate-800 shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="dashboard.php" class="text-2xl font-bold tracking-tight text-blue-500 hover:text-blue-700 flex items-center gap-2">
                <i class="fa-solid fa-user-shield"></i> AI Recruitment Admin
            </a>
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:text-white transition"><i class="fa-solid fa-arrow-left"></i> Dashboard</a>
                <a href="../../logout.php" class="text-red-400 hover:text-red-800 font-medium transition">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-4 py-8">
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mb-6">
            <h1 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white mb-6 pb-4 border-b"><i class="fa-solid fa-sliders text-slate-700 dark:text-slate-300 mr-2"></i> Cài đặt hệ thống</h1>

            <!-- Alerts -->
            <?php if (!empty($message)): ?>
                <div class="bg-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-6 text-sm flex items-center shadow-sm">
                    <i class="fa-solid <?php echo $message['type'] === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i> 
                    <?php echo $message['text']; ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="space-y-8">
                
                <!-- 1. Thông tin chung -->
                <div>
                    <h2 class="text-lg font-bold text-blue-700 mb-4 flex items-center"><i class="fa-solid fa-globe mr-2"></i> Thông tin chung</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Tên Website</label>
                            <input type="text" name="settings[site_name]" value="<?php echo getConf('site_name', 'AI Recruitment Platform'); ?>" class="w-full border rounded-xl px-3 py-2 focus:border-blue-500 focus:outline-none">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Email liên hệ (Admin)</label>
                            <input type="email" name="settings[admin_email]" value="<?php echo getConf('admin_email', 'admin@example.com'); ?>" class="w-full border rounded-xl px-3 py-2 focus:border-blue-500 focus:outline-none">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Mô tả trang (SEO Meta Description)</label>
                            <textarea name="settings[site_description]" rows="2" class="w-full border rounded-xl px-3 py-2 focus:border-blue-500 focus:outline-none"><?php echo getConf('site_description'); ?></textarea>
                        </div>
                    </div>
                </div>

                <hr class="border-gray-100">

                <!-- 2. Cấu hình vận hành -->
                <div>
                    <h2 class="text-lg font-bold text-orange-600 mb-4 flex items-center"><i class="fa-solid fa-gears mr-2"></i> Vận hành</h2>
                    <div class="space-y-4">
                        <div class="flex items-center justify-between bg-slate-50 dark:bg-slate-900 p-4 rounded-xl border">
                            <div>
                                <label class="block font-semibold text-slate-900 dark:text-white">Chế độ bảo trì</label>
                                <p class="text-xs text-slate-500 dark:text-slate-400">Khi bật, chỉ Admin mới có thể truy cập hệ thống.</p>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="hidden" name="settings[maintenance_mode]" value="0">
                                <input type="checkbox" name="settings[maintenance_mode]" value="1" class="sr-only peer" <?php echo getConf('maintenance_mode') == '1' ? 'checked' : ''; ?>>
                                <div class="w-11 h-6 bg-slate-100 dark:bg-slate-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-slate-200/50 dark:border-slate-700/50 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                            </label>
                        </div>

                        <div class="flex items-center justify-between bg-slate-50 dark:bg-slate-900 p-4 rounded-xl border">
                            <div>
                                <label class="block font-semibold text-slate-900 dark:text-white">Cho phép đăng ký mới</label>
                                <p class="text-xs text-slate-500 dark:text-slate-400">Tắt chức năng này để chặn người dùng mới tạo tài khoản.</p>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="hidden" name="settings[allow_registration]" value="0">
                                <input type="checkbox" name="settings[allow_registration]" value="1" class="sr-only peer" <?php echo getConf('allow_registration', '1') == '1' ? 'checked' : ''; ?>>
                                <div class="w-11 h-6 bg-slate-100 dark:bg-slate-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-slate-200/50 dark:border-slate-700/50 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                            </label>
                        </div>
                    </div>
                </div>

                <hr class="border-gray-100">

                <!-- 3. Liên kết Mạng xã hội -->
                <div>
                    <h2 class="text-lg font-bold text-purple-600 mb-4 flex items-center"><i class="fa-solid fa-share-nodes mr-2"></i> Liên kết Footer</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1"><i class="fa-brands fa-facebook text-blue-500"></i> Facebook URL</label>
                            <input type="text" name="settings[social_facebook]" value="<?php echo getConf('social_facebook'); ?>" class="w-full border rounded-xl px-3 py-2 focus:border-blue-500 focus:outline-none">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1"><i class="fa-brands fa-linkedin text-blue-800"></i> LinkedIn URL</label>
                            <input type="text" name="settings[social_linkedin]" value="<?php echo getConf('social_linkedin'); ?>" class="w-full border rounded-xl px-3 py-2 focus:border-blue-500 focus:outline-none">
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="pt-6 border-t flex justify-end gap-3">
                    <button type="reset" class="px-6 py-2 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold rounded-xl hover:bg-slate-100 dark:bg-slate-700 transition">
                        Khôi phục
                    </button>
                    <button type="submit" class="px-6 py-2 bg-blue-600 text-slate-900 dark:text-white font-bold rounded-xl hover:bg-blue-500 transition shadow-lg">
                        <i class="fa-solid fa-save mr-2"></i> Lưu cấu hình
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>