<?php
// views/admin/verification.php

require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/RecruiterProfile.php';
require_once '../../utils/Helpers.php'; 

requireRole('admin');
addSecurityHeaders();

// Kết nối DB trực tiếp để xử lý nhanh gọn
$db = (new Database())->getConnection();

// --- XỬ LÝ HÀNH ĐỘNG (Duyệt/Từ chối) ---
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $userId = (int)($_POST['user_id'] ?? 0);
    
    if ($userId) {
        $newStatus = '';
        if ($action === 'verify') {
            $newStatus = 'verified';
            $msgText = '✅ Đã xác thực công ty thành công.';
        } elseif ($action === 'reject') {
            $newStatus = 'rejected';
            $msgText = '❌ Đã từ chối xác thực công ty.';
        } elseif ($action === 'reset') {
            $newStatus = 'pending';
            $msgText = '↺ Đã chuyển về trạng thái chờ duyệt.';
        }

        if ($newStatus) {
            $stmt = $db->prepare("UPDATE recruiter_profiles SET verification_status = :status WHERE user_id = :id");
            $stmt->bindParam(':status', $newStatus);
            $stmt->bindParam(':id', $userId);
            
            if ($stmt->execute()) {
                $message = ['type' => 'success', 'text' => $msgText];
            } else {
                $message = ['type' => 'error', 'text' => 'Lỗi cập nhật cơ sở dữ liệu.'];
            }
        }
    }
}

// --- LẤY DỮ LIỆU & BỘ LỌC ---
$statusFilter = $_GET['status'] ?? 'pending'; // Mặc định hiện danh sách CHỜ DUYỆT
$searchKeyword = $_GET['search'] ?? '';
$page = (int)($_GET['page'] ?? 1);
$limit = 10;
$offset = ($page - 1) * $limit;

// Query lấy thông tin Công ty + User
$query = "SELECT rp.*, u.full_name, u.email, u.phone 
          FROM recruiter_profiles rp 
          JOIN users u ON rp.user_id = u.id 
          WHERE 1=1";

$params = [];

if ($statusFilter !== 'all') {
    $query .= " AND rp.verification_status = :status";
    $params[':status'] = $statusFilter;
}

if ($searchKeyword) {
    $query .= " AND (rp.company_name LIKE :search OR u.email LIKE :search OR u.full_name LIKE :search)";
    $params[':search'] = "%$searchKeyword%";
}

// Đếm tổng
$countStmt = $db->prepare(str_replace("rp.*, u.full_name, u.email, u.phone", "COUNT(*)", $query));
foreach ($params as $key => $value) $countStmt->bindValue($key, $value);
$countStmt->execute();
$totalRecords = $countStmt->fetchColumn();
$totalPages = ceil($totalRecords / $limit);

// Lấy dữ liệu
$query .= " ORDER BY rp.updated_at DESC LIMIT :limit OFFSET :offset";
$stmt = $db->prepare($query);
foreach ($params as $key => $value) $stmt->bindValue($key, $value);
$stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
$stmt->execute();
$companies = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Thống kê nhanh
$statsQuery = "SELECT 
                SUM(CASE WHEN verification_status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN verification_status = 'verified' THEN 1 ELSE 0 END) as verified
               FROM recruiter_profiles";
$stats = $db->query($statsQuery)->fetch(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xác thực công ty - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 font-sans">
    <!-- Navigation -->
    <nav class="bg-white dark:bg-slate-800 shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="dashboard.php" class="text-2xl font-bold tracking-tight text-blue-500 hover:text-blue-700 flex items-center gap-2">
                <i class="fa-solid fa-user-shield"></i> AI Recruitment Admin
            </a>
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:text-white transition"><i class="fa-solid fa-arrow-left"></i> Dashboard</a>
                <a href="../../logout.php" class="text-red-400 hover:text-red-800 font-medium transition">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mb-6">
            <!-- Header & Stats -->
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4 border-b pb-6">
                <div>
                    <h1 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white"><i class="fa-solid fa-certificate text-green-500 mr-2"></i> Xác thực Công ty</h1>
                    <div class="flex gap-4 mt-2 text-sm">
                        <span class="text-yellow-600 bg-yellow-50 px-2 py-1 rounded"><i class="fa-solid fa-clock"></i> Chờ duyệt: <strong><?php echo $stats['pending']; ?></strong></span>
                        <span class="text-green-400 bg-green-900/20 px-2 py-1 rounded"><i class="fa-solid fa-check-circle"></i> Đã duyệt: <strong><?php echo $stats['verified']; ?></strong></span>
                    </div>
                </div>
                
                <form class="flex flex-col md:flex-row gap-3 w-full md:w-auto" method="GET">
                    <select name="status" class="border rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-blue-500 bg-white dark:bg-slate-800" onchange="this.form.submit()">
                        <option value="pending" <?php echo $statusFilter === 'pending' ? 'selected' : ''; ?>>⏳ Chờ duyệt (Pending)</option>
                        <option value="verified" <?php echo $statusFilter === 'verified' ? 'selected' : ''; ?>>✅ Đã xác thực</option>
                        <option value="rejected" <?php echo $statusFilter === 'rejected' ? 'selected' : ''; ?>>❌ Đã từ chối</option>
                        <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>Tất cả</option>
                    </select>
                    <div class="relative">
                        <input type="text" name="search" value="<?php echo htmlspecialchars($searchKeyword); ?>" placeholder="Tên công ty, email..." class="border rounded-xl pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-blue-500 w-full md:w-64">
                        <i class="fa-solid fa-search absolute left-3 top-2.5 text-slate-500 dark:text-slate-400"></i>
                    </div>
                    <button type="submit" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded-xl hover:bg-blue-500 text-sm font-medium transition">
                        Lọc
                    </button>
                </form>
            </div>

            <!-- Alerts -->
            <?php if (!empty($message)): ?>
                <div class="bg-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-6 text-sm flex items-center shadow-sm">
                    <i class="fa-solid <?php echo $message['type'] === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i> 
                    <?php echo $message['text']; ?>
                </div>
            <?php endif; ?>

            <!-- Table -->
            <div class="overflow-x-auto rounded-xl border border-slate-200/50 dark:border-slate-700/50">
                <table class="w-full text-sm text-left text-slate-500 dark:text-slate-400">
                    <thead class="text-xs text-slate-700 dark:text-slate-300 uppercase bg-slate-50 dark:bg-slate-900">
                        <tr>
                            <th class="px-6 py-3">Công ty</th>
                            <th class="px-6 py-3">Người đại diện</th>
                            <th class="px-6 py-3">Thông tin pháp lý</th>
                            <th class="px-6 py-3">Giấy tờ xác thực</th>
                            <th class="px-6 py-3 text-center">Trạng thái</th>
                            <th class="px-6 py-3 text-center">Hành động</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php if (empty($companies)): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-12 text-center text-slate-500 dark:text-slate-400 italic bg-slate-50 dark:bg-slate-900">
                                    <?php if ($statusFilter === 'pending'): ?>
                                        <i class="fa-solid fa-check-double text-4xl text-green-200 mb-3 block"></i>
                                        Tuyệt vời! Không có yêu cầu nào đang chờ duyệt.
                                    <?php else: ?>
                                        Không tìm thấy dữ liệu phù hợp.
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($companies as $comp): ?>
                                <tr class="bg-white dark:bg-slate-800 hover:bg-slate-50 dark:bg-slate-900 transition">
                                    <!-- Cột 1: Công ty -->
                                    <td class="px-6 py-4">
                                        <div class="flex items-center gap-3">
                                            <?php
                                            // Tối ưu Server-side: Kiểm tra từ phía Backend
                                            $logoUrl = '';
                                            $fallbackUrl = 'https://ui-avatars.com/api/?name=' . urlencode($comp['company_name'] ?? 'Company') . '&background=random&bold=true&size=128';
                                            
                                            if (!empty($comp['company_logo_url'])) {
                                                // Nếu đã là full URL, dùng luôn
                                                if (strpos($comp['company_logo_url'], 'http') === 0) {
                                                    $logoUrl = $comp['company_logo_url'];
                                                } else {
                                                    // Nếu là relative path, thêm BASE_URL
                                                    $logoUrl = BASE_URL . $comp['company_logo_url'];
                                                }
                                            } else {
                                                // Nếu logo rỗng, dùng fallback từ phía server luôn
                                                $logoUrl = $fallbackUrl;
                                            }
                                            ?>
                                            <img src="<?php echo htmlspecialchars($logoUrl); ?>" 
                                                 class="w-12 h-12 rounded-xl border-2 border-slate-200/50 dark:border-slate-700/50 object-cover bg-white dark:bg-slate-800 shadow-sm" 
                                                 alt="<?php echo htmlspecialchars($comp['company_name'] ?? 'Company'); ?>"
                                                 onerror="this.onerror=null; this.src='<?php echo htmlspecialchars($fallbackUrl); ?>'">
                                            <div>
                                                <div class="font-bold text-slate-900 dark:text-white text-base"><?php echo htmlspecialchars($comp['company_name'] ?? 'Chưa cập nhật tên'); ?></div>
                                                <div class="text-xs text-slate-500 dark:text-slate-400"><i class="fa-solid fa-map-pin mr-1"></i> <?php echo htmlspecialchars($comp['company_city'] ?? '--'); ?></div>
                                            </div>
                                        </div>
                                    </td>

                                    <!-- Cột 2: Người đại diện -->
                                    <td class="px-6 py-4">
                                        <div class="font-medium text-slate-900 dark:text-white"><?php echo htmlspecialchars($comp['full_name']); ?></div>
                                        <div class="text-xs text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($comp['email']); ?></div>
                                        <?php if(!empty($comp['phone'])): ?>
                                            <div class="text-xs text-slate-500 dark:text-slate-400"><i class="fa-solid fa-phone mr-1"></i> <?php echo htmlspecialchars($comp['phone']); ?></div>
                                        <?php endif; ?>
                                    </td>

                                    <!-- Cột 3: Pháp lý -->
                                    <td class="px-6 py-4">
                                        <div class="text-xs space-y-1">
                                            <div><span class="text-slate-500 dark:text-slate-400">MST:</span> <strong class="text-slate-900 dark:text-white"><?php echo htmlspecialchars($comp['tax_code'] ?? 'Chưa có'); ?></strong></div>
                                            <div><span class="text-slate-500 dark:text-slate-400">Website:</span> 
                                                <?php if (!empty($comp['company_website'])): ?>
                                                    <a href="<?php echo htmlspecialchars($comp['company_website']); ?>" target="_blank" class="text-blue-500 hover:underline font-medium"><i class="fa-solid fa-link mr-1"></i>Xem</a>
                                                <?php else: ?>
                                                    <span class="text-slate-500 dark:text-slate-400">--</span>
                                                <?php endif; ?>
                                            </div>
                                            <div><span class="text-slate-500 dark:text-slate-400">Quy mô:</span> <?php echo htmlspecialchars($comp['company_size'] ?? '--'); ?></div>
                                        </div>
                                    </td>

                                    <!-- Cột 4: Giấy tờ -->
                                    <td class="px-6 py-4">
                                        <?php if (!empty($comp['verification_documents'])): ?>
                                            <a href="<?php echo htmlspecialchars($comp['verification_documents']); ?>" target="_blank" 
                                               class="inline-flex items-center px-3 py-1.5 bg-blue-900/20 text-blue-700 rounded-xl hover:bg-blue-100 transition border border-blue-200 text-xs font-semibold">
                                                <i class="fa-solid fa-file-pdf mr-2"></i> Tài liệu
                                            </a>
                                        <?php else: ?>
                                            <span class="text-slate-500 dark:text-slate-400 italic text-xs">Chưa có</span>
                                        <?php endif; ?>
                                    </td>

                                    <!-- Cột 5: Trạng thái -->
                                    <td class="px-6 py-4 text-center">
                                        <?php
                                        $s = $comp['verification_status'];
                                        $badge = [
                                            'verified' => ['bg'=>'bg-green-100', 'text'=>'text-green-700', 'icon'=>'fa-check-circle', 'label'=>'Đã xác thực'],
                                            'rejected' => ['bg'=>'bg-red-100', 'text'=>'text-red-700', 'icon'=>'fa-times-circle', 'label'=>'Từ chối'],
                                            'pending' => ['bg'=>'bg-yellow-100', 'text'=>'text-yellow-700', 'icon'=>'fa-clock', 'label'=>'Chờ duyệt']
                                        ];
                                        $b = $badge[$s] ?? $badge['pending'];
                                        ?>
                                        <span class="px-2.5 py-1 rounded-full text-xs font-semibold <?php echo $b['bg'].' '.$b['text']; ?> inline-flex items-center gap-1">
                                            <i class="fa-solid <?php echo $b['icon']; ?>"></i> <?php echo $b['label']; ?>
                                        </span>
                                    </td>

                                    <!-- Cột 6: Hành động -->
                                    <td class="px-6 py-4 text-center">
                                        <div class="flex justify-center gap-2">
                                            <!-- Nút Xem chi tiết (xanh dương) - với data attributes -->
                                            <button type="button" 
                                                    class="btn-view-details inline-flex items-center gap-1.5 px-3 py-2 text-blue-500 bg-blue-900/20 hover:bg-blue-100 rounded-xl transition border border-blue-200 hover:shadow-sm font-medium text-xs"
                                                    title="Xem chi tiết"
                                                    data-company-name="<?php echo htmlspecialchars($comp['company_name'] ?? 'Chưa cập nhật'); ?>"
                                                    data-full-name="<?php echo htmlspecialchars($comp['full_name']); ?>"
                                                    data-email="<?php echo htmlspecialchars($comp['email']); ?>"
                                                    data-phone="<?php echo htmlspecialchars($comp['phone'] ?? 'N/A'); ?>"
                                                    data-company-website="<?php echo htmlspecialchars($comp['company_website'] ?? 'Chưa cập nhật'); ?>"
                                                    data-tax-code="<?php echo htmlspecialchars($comp['tax_code'] ?? 'Chưa có'); ?>"
                                                    data-company-size="<?php echo htmlspecialchars($comp['company_size'] ?? 'Chưa cập nhật'); ?>"
                                                    data-company-city="<?php echo htmlspecialchars($comp['company_city'] ?? '--'); ?>"
                                                    data-company-address="<?php echo htmlspecialchars($comp['company_address'] ?? '--'); ?>"
                                                    data-company-logo-url="<?php echo htmlspecialchars($comp['company_logo_url'] ?? ''); ?>"
                                                    data-company-description="<?php echo htmlspecialchars($comp['company_description'] ?? 'Chưa có mô tả'); ?>">
                                                <i class="fa-solid fa-eye"></i> Xem
                                            </button>

                                            <?php if ($s === 'pending'): ?>
                                                <!-- Nút Duyệt (xanh lá) -->
                                                <form method="POST" style="display:inline;" onsubmit="return confirm('Xác thực công ty này?');">
                                                    <input type="hidden" name="action" value="verify">
                                                    <input type="hidden" name="user_id" value="<?php echo $comp['user_id']; ?>">
                                                    <button type="submit" class="inline-flex items-center gap-1.5 px-3 py-2 text-green-400 bg-green-900/20 hover:bg-green-100 rounded-xl transition border border-green-200 hover:shadow-sm font-medium text-xs" title="Duyệt">
                                                        <i class="fa-solid fa-check"></i> Duyệt
                                                    </button>
                                                </form>
                                                
                                                <!-- Nút Từ chối (đỏ) -->
                                                <form method="POST" onsubmit="return confirm('Bạn chắc chắn muốn từ chối hồ sơ này?');" style="display:inline;">
                                                    <input type="hidden" name="action" value="reject">
                                                    <input type="hidden" name="user_id" value="<?php echo $comp['user_id']; ?>">
                                                    <button type="submit" class="inline-flex items-center gap-1.5 px-3 py-2 text-red-400 bg-red-900/20 hover:bg-red-100 rounded-xl transition border border-red-200 hover:shadow-sm font-medium text-xs" title="Từ chối">
                                                        <i class="fa-solid fa-xmark"></i> Từ chối
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <!-- Nút Reset (xám - xét duyệt lại) -->
                                                <form method="POST" onsubmit="return confirm('Xét duyệt lại công ty này?');" style="display:inline;">
                                                    <input type="hidden" name="action" value="reset">
                                                    <input type="hidden" name="user_id" value="<?php echo $comp['user_id']; ?>">
                                                    <button type="submit" class="inline-flex items-center gap-1.5 px-3 py-2 text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-900 hover:bg-white dark:bg-slate-800 rounded-xl transition border border-slate-200/50 dark:border-slate-700/50 hover:shadow-sm font-medium text-xs" title="Xét duyệt lại">
                                                        <i class="fa-solid fa-rotate-left"></i> Xét lại
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="flex justify-center mt-8 gap-2">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&status=<?php echo $statusFilter; ?>" class="px-3 py-1 rounded border bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800"><i class="fa-solid fa-chevron-left"></i></a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&status=<?php echo $statusFilter; ?>" class="px-3 py-1 rounded border font-medium <?php echo $i === $page ? 'bg-blue-600 text-slate-900 dark:text-white border-blue-600' : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800'; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&status=<?php echo $statusFilter; ?>" class="px-3 py-1 rounded border bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800"><i class="fa-solid fa-chevron-right"></i></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal: Chi tiết công ty (2 cột) -->
    <div id="detailsModal" class="fixed inset-0 bg-black/50 hidden flex items-center justify-center z-50 p-4 backdrop-blur-sm">
        <div class="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-slate-200/50 dark:border-slate-700/50">
            <!-- Header -->
            <div class="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 text-slate-900 dark:text-white px-6 py-4 flex justify-between items-center border-b border-slate-200/50 dark:border-slate-700/50">
                <h2 class="text-2xl font-bold tracking-tight flex items-center gap-3">
                    <i class="fa-solid fa-building text-2xl"></i> Chi Tiết Công Ty
                </h2>
                <button onclick="closeDetailsModal()" class="text-slate-900 dark:text-white hover:text-gray-800 dark:text-gray-200 text-3xl leading-none font-light">&times;</button>
            </div>

            <!-- Content: 2 Columns -->
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- CỘT TRÁI: Ảnh & Thông tin cơ bản -->
                    <div class="space-y-6">
                        <!-- Logo -->
                        <div class="text-center">
                            <img id="modalLogo" src="" class="w-32 h-32 rounded-xl border-4 border-blue-500 object-cover bg-slate-100 dark:bg-slate-700 shadow-lg mx-auto" onerror="this.src='https://ui-avatars.com/api/?name=Company&background=random&bold=true&size=256'">
                        </div>

                        <!-- Tên công ty -->
                        <div class="bg-blue-600/20 border border-blue-600 rounded-xl p-4 text-center">
                            <h3 id="modalCompanyName" class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white mb-2"></h3>
                            <p id="modalCompanyCity" class="text-slate-700 dark:text-slate-300 text-sm flex items-center justify-center gap-1">
                                <i class="fa-solid fa-map-pin"></i> <span id="modalCityText">--</span>
                            </p>
                        </div>

                        <!-- Quy mô -->
                        <div class="bg-purple-600/20 border border-purple-600 rounded-xl p-4">
                            <p class="text-slate-500 dark:text-slate-400 text-xs uppercase font-semibold mb-2">Quy Mô Công Ty</p>
                            <p id="modalCompanySize" class="text-lg font-bold text-purple-300">--</p>
                        </div>

                        <!-- Địa chỉ -->
                        <div class="bg-green-600/20 border border-green-600 rounded-xl p-4">
                            <p class="text-slate-500 dark:text-slate-400 text-xs uppercase font-semibold mb-2"><i class="fa-solid fa-location-dot mr-1"></i>Địa Chỉ</p>
                            <p id="modalCompanyAddress" class="text-sm text-green-300">--</p>
                        </div>
                    </div>

                    <!-- CỘT PHẢI: Thông tin chi tiết -->
                    <div class="space-y-4">
                        <!-- Người đại diện -->
                        <div class="bg-blue-600/20 border border-blue-500 rounded-xl p-4">
                            <h4 class="text-sm uppercase font-semibold text-blue-400 mb-3 flex items-center gap-2">
                                <i class="fa-solid fa-user-tie"></i> Người Đại Diện
                            </h4>
                            <div class="space-y-2">
                                <p class="text-sm text-slate-500 dark:text-slate-400">
                                    <strong class="text-slate-700 dark:text-slate-300">Tên:</strong>
                                    <span id="modalFullName" class="text-slate-900 dark:text-white ml-2">--</span>
                                </p>
                                <p class="text-sm text-slate-500 dark:text-slate-400">
                                    <strong class="text-slate-700 dark:text-slate-300">Email:</strong>
                                    <span id="modalEmail" class="text-blue-400 ml-2 break-all">--</span>
                                </p>
                                <p class="text-sm text-slate-500 dark:text-slate-400">
                                    <strong class="text-slate-700 dark:text-slate-300">SĐT:</strong>
                                    <span id="modalPhone" class="text-slate-900 dark:text-white ml-2">--</span>
                                </p>
                            </div>
                        </div>

                        <!-- Thông tin pháp lý -->
                        <div class="bg-green-600/20 border border-green-500 rounded-xl p-4">
                            <h4 class="text-sm uppercase font-semibold text-green-400 mb-3 flex items-center gap-2">
                                <i class="fa-solid fa-file-contract"></i> Thông Tin Pháp Lý
                            </h4>
                            <div class="space-y-2">
                                <p class="text-sm text-slate-500 dark:text-slate-400">
                                    <strong class="text-slate-700 dark:text-slate-300">MST:</strong>
                                    <span id="modalTaxCode" class="text-slate-900 dark:text-white font-mono ml-2">--</span>
                                </p>
                                <p class="text-sm text-slate-500 dark:text-slate-400">
                                    <strong class="text-slate-700 dark:text-slate-300">Website:</strong>
                                    <a id="modalWebsiteLink" href="#" target="_blank" class="text-blue-400 hover:text-blue-300 ml-2 break-all">
                                        <span id="modalWebsite">--</span>
                                    </a>
                                </p>
                            </div>
                        </div>

                        <!-- Mô tả -->
                        <div class="bg-yellow-600/20 border border-yellow-600 rounded-xl p-4">
                            <h4 class="text-sm uppercase font-semibold text-yellow-400 mb-2 flex items-center gap-2">
                                <i class="fa-solid fa-align-left"></i> Mô Tả Công Ty
                            </h4>
                            <p id="modalDescription" class="text-sm text-slate-700 dark:text-slate-300 italic line-clamp-3">--</p>
                        </div>

                        <!-- Trạng thái -->
                        <div class="bg-slate-100 dark:bg-slate-700 border border-slate-300/50 dark:border-slate-600/50 rounded-xl p-4">
                            <p class="text-xs text-slate-500 dark:text-slate-400 uppercase font-semibold mb-2">Trạng Thái Xác Thực</p>
                            <p id="modalStatus" class="inline-block px-3 py-1 rounded-full text-sm font-semibold">--</p>
                        </div>
                    </div>
                </div>

                <!-- Tài liệu xác thực (Full width) -->
                <div class="mt-6 pt-6 border-t border-slate-200/50 dark:border-slate-700/50">
                    <h4 class="text-sm uppercase font-semibold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                        <i class="fa-solid fa-file-pdf"></i> Tài Liệu Xác Thực
                    </h4>
                    <div id="modalDocLink" class="hidden">
                        <a id="docLink" href="#" target="_blank" class="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-slate-900 dark:text-white rounded-xl transition font-semibold">
                            <i class="fa-solid fa-download"></i> Tải PDF
                        </a>
                    </div>
                    <div id="modalNoDoc" class="text-slate-500 dark:text-slate-400 italic text-sm">Chưa tải lên tài liệu xác thực</div>
                </div>
            </div>

            <!-- Footer -->
            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-900 border-t border-slate-200/50 dark:border-slate-700/50 flex justify-end">
                <button onclick="closeDetailsModal()" class="px-6 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-gray-600 text-slate-900 dark:text-white rounded-xl transition font-semibold">
                    Đóng
                </button>
            </div>
        </div>
    </div>

    <!-- JavaScript: Xử lý Modal -->
    <script>
        // Bắt sự kiện click tất cả các nút "Xem"
        document.querySelectorAll('.btn-view-details').forEach(button => {
            button.addEventListener('click', function() {
                // Lấy dữ liệu từ data attributes
                const companyName = this.getAttribute('data-company-name');
                const fullName = this.getAttribute('data-full-name');
                const email = this.getAttribute('data-email');
                const phone = this.getAttribute('data-phone');
                const website = this.getAttribute('data-company-website');
                const taxCode = this.getAttribute('data-tax-code');
                const companySize = this.getAttribute('data-company-size');
                const city = this.getAttribute('data-company-city');
                const address = this.getAttribute('data-company-address');
                const logoUrl = this.getAttribute('data-company-logo-url');
                const description = this.getAttribute('data-company-description');

                // Xử lý URL logo
                let finalLogoUrl = '';
                if (logoUrl && logoUrl.trim() !== '') {
                    if (logoUrl.startsWith('http')) {
                        finalLogoUrl = logoUrl;
                    } else {
                        finalLogoUrl = '<?php echo BASE_URL; ?>' + logoUrl;
                    }
                } else {
                    finalLogoUrl = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(companyName) + '&background=random&bold=true&size=256';
                }

                // Điền dữ liệu vào Modal - Cột Trái
                const imgElement = document.getElementById('modalLogo');
                imgElement.src = finalLogoUrl;
                imgElement.onerror = function() {
                    if (!this.dataset.retried) {
                        this.dataset.retried = true;
                        this.src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(companyName) + '&background=random&bold=true&size=256';
                        this.onerror = null;
                    }
                };

                document.getElementById('modalCompanyName').textContent = companyName || 'Chưa cập nhật';
                document.getElementById('modalCityText').textContent = city || '--';
                document.getElementById('modalCompanySize').textContent = companySize || 'Chưa xác định';
                document.getElementById('modalCompanyAddress').textContent = address || '--';

                // Điền dữ liệu vào Modal - Cột Phải
                document.getElementById('modalFullName').textContent = fullName || '--';
                document.getElementById('modalEmail').textContent = email || '--';
                document.getElementById('modalPhone').textContent = phone || '--';
                document.getElementById('modalTaxCode').textContent = taxCode || '--';
                document.getElementById('modalDescription').textContent = description || 'Chưa có mô tả';

                // Website link
                if (website && website !== 'Chưa cập nhật') {
                    document.getElementById('modalWebsiteLink').href = website;
                    document.getElementById('modalWebsiteLink').style.display = 'inline';
                    try {
                        document.getElementById('modalWebsite').textContent = new URL(website).hostname;
                    } catch(e) {
                        document.getElementById('modalWebsite').textContent = website;
                    }
                } else {
                    document.getElementById('modalWebsiteLink').href = '#';
                    document.getElementById('modalWebsite').textContent = 'Chưa cập nhật';
                }

                // Tài liệu (mặc định ẩn)
                document.getElementById('modalDocLink').classList.add('hidden');
                document.getElementById('modalNoDoc').classList.remove('hidden');

                // Trạng thái (mặc định pending)
                const statusEl = document.getElementById('modalStatus');
                statusEl.textContent = '⏳ Chờ duyệt';
                statusEl.className = 'inline-block px-3 py-1 rounded-full text-sm font-semibold bg-yellow-600/30 text-yellow-300 border border-yellow-600';

                // Hiện Modal
                document.getElementById('detailsModal').classList.remove('hidden');
            });
        });

        // Đóng Modal
        function closeDetailsModal() {
            document.getElementById('detailsModal').classList.add('hidden');
        }

        // Đóng khi click outside
        document.getElementById('detailsModal').addEventListener('click', function(e) {
            if (e.target === this) closeDetailsModal();
        });

        // Đóng khi press ESC
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && !document.getElementById('detailsModal').classList.contains('hidden')) {
                closeDetailsModal();
            }
        });
    </script>
</body>
</html>