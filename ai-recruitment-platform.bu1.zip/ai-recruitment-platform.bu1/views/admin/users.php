<?php
// views/admin/users.php - User Management with Complete MVC Implementation

require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/User.php';

requireRole('admin');
addSecurityHeaders();

$userModel = new User();
$success_message = '';
$error_message = '';

// Handle Actions (Ban/Unban/Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $userId = (int)($_POST['user_id'] ?? 0);
    
    // Prevent self-action
    if ($userId === $_SESSION['user_id']) {
        $error_message = "Không thể thao tác trên tài khoản của chính bạn.";
    } elseif ($userId > 0) {
        switch ($action) {
            case 'ban':
                if ($userModel->updateStatus($userId, 'suspended')) {
                    $success_message = "Đã khóa tài khoản thành công.";
                } else {
                    $error_message = "Lỗi khi khóa tài khoản.";
                }
                break;
            case 'unban':
                if ($userModel->updateStatus($userId, 'active')) {
                    $success_message = "Đã mở khóa tài khoản thành công.";
                } else {
                    $error_message = "Lỗi khi mở khóa tài khoản.";
                }
                break;
            case 'delete':
                if ($userModel->deleteUser($userId)) {
                    $success_message = "Đã xóa tài khoản thành công.";
                } else {
                    $error_message = "Lỗi khi xóa tài khoản.";
                }
                break;
        }
    }
}

// Get filters and pagination params
$roleFilter = $_GET['role'] ?? 'all';
$searchKeyword = trim($_GET['search'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 15;
$offset = ($page - 1) * $limit;

// Get users based on filters
$users = [];
$totalCount = 0;

if ($roleFilter !== 'all') {
    $totalCount = $userModel->countUsersByRole($roleFilter);
    $users = $userModel->getUsersByRole($roleFilter, $limit, $offset);
} else {
    // Get all users
    $allUsers = $userModel->getAllUsers(PHP_INT_MAX, 0);
    $totalCount = count($allUsers);
    
    // Filter by search keyword if provided
    if (!empty($searchKeyword)) {
        $users = array_filter($allUsers, function($u) use ($searchKeyword) {
            $kw = strtolower($searchKeyword);
            return strpos(strtolower($u['full_name']), $kw) !== false || 
                   strpos(strtolower($u['email']), $kw) !== false ||
                   strpos(strtolower($u['role']), $kw) !== false;
        });
        $totalCount = count($users);
        $users = array_slice($users, $offset, $limit);
    } else {
        $users = $userModel->getAllUsers($limit, $offset);
    }
}

$totalPages = ceil($totalCount / $limit);

// Helper function for avatar URL
function getAvatarUrl($avatarUrl, $fullName) {
    if (empty($avatarUrl)) {
        return 'https://ui-avatars.com/api/?name=' . urlencode($fullName) . '&background=random';
    }
    // If already full URL, use as is
    if (strpos($avatarUrl, 'http') === 0) {
        return $avatarUrl;
    }
    // If relative path, add BASE_URL
    return BASE_URL . $avatarUrl;
}

// Role labels and colors
$roleLabels = ['candidate' => 'Ứng viên', 'recruiter' => 'Nhà tuyển dụng', 'admin' => 'Quản trị viên'];
$roleColors = ['candidate' => 'blue', 'recruiter' => 'green', 'admin' => 'red'];

$statusLabels = ['active' => 'Hoạt động', 'suspended' => 'Bị khóa', 'banned' => 'Cấm', 'deleted' => 'Đã xóa'];
$statusColors = ['active' => 'green', 'suspended' => 'yellow', 'banned' => 'red', 'deleted' => 'gray'];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Người Dùng - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 font-sans">
    <!-- Navigation -->
    <nav class="bg-white dark:bg-slate-800 shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="<?php echo BASE_URL; ?>" class="text-2xl font-bold tracking-tight text-blue-500 hover:text-blue-700 flex items-center gap-2">
                <i class="fa-solid fa-briefcase"></i> AI Recruitment
            </a>
            <div class="flex items-center gap-4">
                <div class="relative group dropdown-group" style="padding-bottom: 8px;">
                    <button class="flex items-center gap-2 text-slate-700 dark:text-slate-300 hover:text-blue-500 font-medium transition dropdown-btn">
                        <img src="<?php echo getAvatarUrl($_SESSION['avatar_url'] ?? '', $_SESSION['full_name']); ?>" class="w-8 h-8 rounded-full border">
                        <?php echo htmlspecialchars($_SESSION['full_name']); ?> ▼
                    </button>
                    <div class="hidden group-hover:block absolute right-0 mt-0 bg-white dark:bg-slate-800 shadow-xl rounded-xl min-w-[200px] z-10 border overflow-hidden dropdown-menu">
                        <a href="dashboard.php" class="block px-4 py-3 hover:bg-slate-50 dark:bg-slate-900 transition"><i class="fa-solid fa-chart-line w-6"></i> Tổng quan</a>
                        <a href="users.php" class="block px-4 py-3 hover:bg-slate-50 dark:bg-slate-900 transition"><i class="fa-solid fa-users w-6"></i> Quản lý người dùng</a>
                        <div class="border-t"></div>
                        <a href="../../logout.php" class="block px-4 py-3 hover:bg-red-900/20 text-red-400 transition"><i class="fa-solid fa-right-from-bracket w-6"></i> Đăng xuất</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Notifications -->
    <?php if ($success_message): ?>
        <div class="bg-green-100 border-t-4 border-green-500 text-green-700 px-4 py-3 sticky top-16 z-40">
            <div class="max-w-7xl mx-auto flex justify-between items-center">
                <span><i class="fa-solid fa-check-circle mr-2"></i><?php echo htmlspecialchars($success_message); ?></span>
                <button onclick="this.parentElement.parentElement.style.display='none'" class="text-green-700 hover:text-green-900">&times;</button>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($error_message): ?>
        <div class="bg-red-100 border-t-4 border-red-500 text-red-700 px-4 py-3 sticky top-16 z-40">
            <div class="max-w-7xl mx-auto flex justify-between items-center">
                <span><i class="fa-solid fa-exclamation-circle mr-2"></i><?php echo htmlspecialchars($error_message); ?></span>
                <button onclick="this.parentElement.parentElement.style.display='none'" class="text-red-700 hover:text-red-900">&times;</button>
            </div>
        </div>
    <?php endif; ?>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 py-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-4xl font-bold text-slate-900 dark:text-white mb-2">Quản Lý Người Dùng</h1>
            <p class="text-slate-700 dark:text-slate-300">Tổng cộng: <span class="font-semibold text-blue-500"><?php echo $totalCount; ?></span> người dùng</p>
        </div>

        <!-- Filter Section -->
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mb-6">
            <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <!-- Search -->
                <div>
                    <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Tìm kiếm</label>
                    <input type="text" name="search" value="<?php echo htmlspecialchars($searchKeyword); ?>" placeholder="Tên hoặc Email..." class="w-full border rounded-xl px-3 py-2 focus:outline-none focus:border-blue-500">
                </div>

                <!-- Role Filter -->
                <div>
                    <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Loại tài khoản</label>
                    <select name="role" class="w-full border rounded-xl px-3 py-2 focus:outline-none focus:border-blue-500">
                        <option value="all">Tất cả</option>
                        <option value="candidate" <?php echo $roleFilter === 'candidate' ? 'selected' : ''; ?>>Ứng viên</option>
                        <option value="recruiter" <?php echo $roleFilter === 'recruiter' ? 'selected' : ''; ?>>Nhà tuyển dụng</option>
                        <option value="admin" <?php echo $roleFilter === 'admin' ? 'selected' : ''; ?>>Quản trị viên</option>
                    </select>
                </div>

                <!-- Buttons -->
                <div class="flex items-end gap-2">
                    <button type="submit" class="flex-1 bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded-xl hover:bg-blue-500 transition font-semibold">
                        <i class="fa-solid fa-search mr-2"></i> Tìm kiếm
                    </button>
                    <a href="users.php" class="flex-1 bg-gray-300 text-slate-700 dark:text-slate-300 px-4 py-2 rounded-xl hover:bg-gray-400 transition font-semibold text-center">
                        <i class="fa-solid fa-redo mr-2"></i> Đặt lại
                    </a>
                </div>
            </form>
        </div>

        <!-- Users Table -->
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl overflow-hidden">
            <?php if (empty($users)): ?>
                <div class="p-12 text-center text-slate-500 dark:text-slate-400">
                    <i class="fa-solid fa-inbox text-4xl mb-4"></i>
                    <p>Không tìm thấy người dùng nào</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead class="bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 uppercase text-xs font-semibold border-b">
                            <tr>
                                <th class="px-6 py-4 text-left">Người Dùng</th>
                                <th class="px-6 py-4 text-left">Email</th>
                                <th class="px-6 py-4 text-left">Loại TK</th>
                                <th class="px-6 py-4 text-left">Trạng Thái</th>
                                <th class="px-6 py-4 text-left">Ngày Tạo</th>
                                <th class="px-6 py-4 text-center">Hành Động</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php foreach ($users as $user): ?>
                                <?php 
                                    $role = $user['role'] ?? 'candidate';
                                    $status = $user['status'] ?? 'active';
                                    $roleColor = $roleColors[$role] ?? 'gray';
                                    $statusColor = $statusColors[$status] ?? 'gray';
                                ?>
                                <tr class="hover:bg-blue-900/20/50 transition duration-150">
                                    <td class="px-6 py-4">
                                        <div class="flex items-center gap-3">
                                            <img src="<?php echo getAvatarUrl($user['avatar_url'] ?? '', $user['full_name']); ?>" 
                                                 class="w-10 h-10 rounded-full border-2 border-slate-200/50 dark:border-slate-700/50 object-cover" 
                                                 alt="<?php echo htmlspecialchars($user['full_name']); ?>">
                                            <div>
                                                <p class="font-semibold text-slate-900 dark:text-white"><?php echo htmlspecialchars($user['full_name']); ?></p>
                                                <p class="text-xs text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($user['phone'] ?? 'N/A'); ?></p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td class="px-6 py-4">
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-<?php echo $roleColor; ?>-100 text-<?php echo $roleColor; ?>-700">
                                            <?php echo $roleLabels[$role] ?? ucfirst($role); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-<?php echo $statusColor; ?>-100 text-<?php echo $statusColor; ?>-700">
                                            <?php echo $statusLabels[$status] ?? ucfirst($status); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-slate-700 dark:text-slate-300 text-xs">
                                        <?php echo date('d/m/Y', strtotime($user['created_at'])); ?>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <div class="flex items-center justify-center gap-2">
                                            <!-- View Details Button -->
                                            <button onclick="openModal(<?php echo htmlspecialchars(json_encode($user)); ?>)" 
                                                    class="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-900/20 text-blue-500 rounded-xl hover:bg-blue-100 transition text-xs font-semibold" 
                                                    title="Xem chi tiết">
                                                <i class="fa-solid fa-eye text-sm"></i> Xem
                                            </button>

                                            <!-- Ban/Unban Button -->
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <input type="hidden" name="action" value="<?php echo $status === 'active' ? 'ban' : 'unban'; ?>">
                                                <button type="submit" 
                                                        class="inline-flex items-center gap-1 px-3 py-1.5 <?php echo $status === 'active' ? 'bg-yellow-50 text-yellow-600 hover:bg-yellow-100' : 'bg-green-900/20 text-green-400 hover:bg-green-100'; ?> rounded-xl transition text-xs font-semibold" 
                                                        onclick="return confirm('Bạn chắc chắn?')"
                                                        title="<?php echo $status === 'active' ? 'Khóa' : 'Mở khóa'; ?>">
                                                    <i class="fa-solid <?php echo $status === 'active' ? 'fa-lock' : 'fa-lock-open'; ?> text-sm"></i> <?php echo $status === 'active' ? 'Khóa' : 'Mở khóa'; ?>
                                                </button>
                                            </form>

                                            <!-- Delete Button -->
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <button type="submit" 
                                                        class="inline-flex items-center gap-1 px-3 py-1.5 bg-red-900/20 text-red-400 rounded-xl hover:bg-red-100 transition text-xs font-semibold" 
                                                        onclick="return confirm('Xóa người dùng này? Hành động này không thể hoàn tác!')"
                                                        title="Xóa">
                                                    <i class="fa-solid fa-trash text-sm"></i> Xóa
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <div class="bg-slate-50 dark:bg-slate-900 px-6 py-4 border-t flex items-center justify-between">
                        <p class="text-sm text-slate-700 dark:text-slate-300">Trang <span class="font-semibold"><?php echo $page; ?></span> / <span class="font-semibold"><?php echo $totalPages; ?></span></p>
                        <div class="flex gap-2">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo $page - 1; ?>&role=<?php echo urlencode($roleFilter); ?>&search=<?php echo urlencode($searchKeyword); ?>" 
                                   class="px-3 py-2 bg-white dark:bg-slate-800 border rounded-xl hover:bg-white dark:bg-slate-800 transition text-sm font-semibold">
                                    <i class="fa-solid fa-chevron-left"></i> Trước
                                </a>
                            <?php endif; ?>

                            <?php if ($page < $totalPages): ?>
                                <a href="?page=<?php echo $page + 1; ?>&role=<?php echo urlencode($roleFilter); ?>&search=<?php echo urlencode($searchKeyword); ?>" 
                                   class="px-3 py-2 bg-blue-600 text-slate-900 dark:text-white rounded-xl hover:bg-blue-500 transition text-sm font-semibold">
                                    Sau <i class="fa-solid fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal: User Details -->
    <div id="userModal" class="fixed inset-0 bg-black/50 hidden flex items-center justify-center z-50 p-4">
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl max-w-md w-full max-h-96 overflow-y-auto">
            <div class="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 text-slate-900 dark:text-white px-6 py-4 flex justify-between items-center">
                <h2 class="text-xl font-bold tracking-tight">Chi Tiết Người Dùng</h2>
                <button onclick="closeModal()" class="text-slate-900 dark:text-white hover:text-gray-800 dark:text-gray-200 text-2xl">&times;</button>
            </div>

            <div class="p-6 space-y-4">
                <div class="text-center mb-4">
                    <img id="modalAvatar" src="" class="w-16 h-16 rounded-full border-4 border-blue-200 mx-auto object-cover">
                </div>

                <div>
                    <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Họ và tên</label>
                    <p id="modalFullName" class="text-slate-900 dark:text-white font-medium"></p>
                </div>

                <div>
                    <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Email</label>
                    <p id="modalEmail" class="text-slate-900 dark:text-white"></p>
                </div>

                <div>
                    <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Số điện thoại</label>
                    <p id="modalPhone" class="text-slate-900 dark:text-white"></p>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Loại TK</label>
                        <p id="modalRole" class="text-slate-900 dark:text-white"></p>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Trạng thái</label>
                        <p id="modalStatus" class="text-slate-900 dark:text-white"></p>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Ngày tạo</label>
                    <p id="modalCreatedAt" class="text-slate-900 dark:text-white"></p>
                </div>
            </div>

            <div class="px-6 py-4 bg-slate-50 dark:bg-slate-900 border-t text-right">
                <button onclick="closeModal()" class="px-4 py-2 bg-gray-300 text-slate-700 dark:text-slate-300 rounded-xl hover:bg-gray-400 transition font-semibold">
                    Đóng
                </button>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script>
        function openModal(user) {
            document.getElementById('modalAvatar').src = user.avatar_url && user.avatar_url.startsWith('http') 
                ? user.avatar_url 
                : (user.avatar_url ? '<?php echo BASE_URL; ?>' + user.avatar_url : 'https://ui-avatars.com/api/?name=' + encodeURIComponent(user.full_name) + '&background=random');
            
            document.getElementById('modalFullName').textContent = user.full_name;
            document.getElementById('modalEmail').textContent = user.email;
            document.getElementById('modalPhone').textContent = user.phone || 'N/A';
            
            const roleLabels = {'candidate': 'Ứng viên', 'recruiter': 'Nhà tuyển dụng', 'admin': 'Quản trị viên'};
            const statusLabels = {'active': 'Hoạt động', 'suspended': 'Bị khóa', 'banned': 'Cấm', 'deleted': 'Đã xóa'};
            
            document.getElementById('modalRole').textContent = roleLabels[user.role] || user.role;
            document.getElementById('modalStatus').textContent = statusLabels[user.status] || user.status;
            document.getElementById('modalCreatedAt').textContent = new Date(user.created_at).toLocaleDateString('vi-VN');
            
            document.getElementById('userModal').classList.remove('hidden');
        }

        function closeModal() {
            document.getElementById('userModal').classList.add('hidden');
        }

        // Close modal on outside click
        document.getElementById('userModal').addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });

        // Dropdown menu fix
        document.querySelectorAll('.dropdown-group').forEach(group => {
            const btn = group.querySelector('.dropdown-btn');
            const menu = group.querySelector('.dropdown-menu');
            
            if (!btn || !menu) return;
            
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                menu.classList.toggle('hidden');
            });

            group.addEventListener('mouseleave', () => {
                menu.classList.add('hidden');
            });
        });

        document.addEventListener('click', (e) => {
            document.querySelectorAll('.dropdown-menu').forEach(menu => {
                if (!menu.parentElement.contains(e.target)) {
                    menu.classList.add('hidden');
                }
            });
        });
    </script>
</body>
</html>
