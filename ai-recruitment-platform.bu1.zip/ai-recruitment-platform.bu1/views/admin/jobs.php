<?php
// views/admin/jobs.php

require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/Job.php';
require_once '../../utils/Helpers.php'; 

requireRole('admin');
addSecurityHeaders();

$jobModel = new Job();

// --- XỬ LÝ HÀNH ĐỘNG (POST) ---
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $jobId = (int)($_POST['job_id'] ?? 0);
    
    if ($jobId) {
        if ($action === 'approve') {
            // Duyệt tin: Chuyển sang active
            if ($jobModel->updateStatus($jobId, 'active')) {
                $message = ['type' => 'success', 'text' => '✅ Đã duyệt tin tuyển dụng thành công.'];
            } else {
                $message = ['type' => 'error', 'text' => '❌ Lỗi khi duyệt tin.'];
            }
        } elseif ($action === 'close') {
            // Đóng tin: Chuyển sang closed
            if ($jobModel->updateStatus($jobId, 'closed')) {
                $message = ['type' => 'success', 'text' => '🔒 Đã đóng/khóa tin tuyển dụng.'];
            }
        } elseif ($action === 'delete') {
            // Xóa tin
            if ($jobModel->deleteJob($jobId)) {
                $message = ['type' => 'success', 'text' => '🗑️ Đã xóa tin tuyển dụng.'];
            }
        }
    }
}

// --- LẤY DỮ LIỆU & PHÂN TRANG (GET) ---
$statusFilter = $_GET['status'] ?? 'all';
$searchKeyword = $_GET['search'] ?? '';
$page = (int)($_GET['page'] ?? 1);
$limit = 10;
$offset = ($page - 1) * $limit;

$filters = [
    'status' => $statusFilter,
    'search' => $searchKeyword
];

// Gọi hàm dành riêng cho Admin (lấy tất cả tin)
$jobs = $jobModel->getAllJobsAdmin($filters, $limit, $offset);
$totalJobs = $jobModel->countAllJobsAdmin($filters);
$totalPages = ceil($totalJobs / $limit);

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Tin tuyển dụng - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 font-sans">
    <!-- Navigation -->
    <nav class="bg-white dark:bg-slate-800 shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="dashboard.php" class="text-2xl font-bold tracking-tight text-blue-500 hover:text-blue-700 flex items-center gap-2">
                <i class="fa-solid fa-user-shield"></i> AI Recruitment Admin
            </a>
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:text-white transition"><i class="fa-solid fa-arrow-left"></i> Dashboard</a>
                <a href="../../logout.php" class="text-red-400 hover:text-red-800 font-medium transition">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mb-6">
            <!-- Header & Filter -->
            <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4 border-b pb-6">
                <div>
                    <h1 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white"><i class="fa-solid fa-briefcase text-purple-500 mr-2"></i> Quản lý Tin đăng</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Tổng số: <strong><?php echo number_format($totalJobs); ?></strong> tin tuyển dụng</p>
                </div>
                
                <form class="flex flex-col md:flex-row gap-3 w-full md:w-auto" method="GET">
                    <select name="status" class="border rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-blue-500 bg-white dark:bg-slate-800" onchange="this.form.submit()">
                        <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>Tất cả trạng thái</option>
                        <option value="pending" <?php echo $statusFilter === 'pending' ? 'selected' : ''; ?>>⏳ Chờ duyệt</option>
                        <option value="active" <?php echo $statusFilter === 'active' ? 'selected' : ''; ?>>✅ Đang hoạt động</option>
                        <option value="closed" <?php echo $statusFilter === 'closed' ? 'selected' : ''; ?>>🔒 Đã đóng</option>
                        <option value="draft" <?php echo $statusFilter === 'draft' ? 'selected' : ''; ?>>📝 Nháp</option>
                    </select>
                    <div class="relative">
                        <input type="text" name="search" value="<?php echo htmlspecialchars($searchKeyword); ?>" placeholder="Tìm tiêu đề, công ty..." class="border rounded-xl pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-blue-500 w-full md:w-64">
                        <i class="fa-solid fa-search absolute left-3 top-2.5 text-slate-500 dark:text-slate-400"></i>
                    </div>
                    <button type="submit" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded-xl hover:bg-blue-500 text-sm font-medium transition">
                        Tìm kiếm
                    </button>
                </form>
            </div>

            <!-- Alerts -->
            <?php if (!empty($message)): ?>
                <div class="bg-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-6 text-sm flex items-center shadow-sm">
                    <i class="fa-solid <?php echo $message['type'] === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i> 
                    <?php echo $message['text']; ?>
                </div>
            <?php endif; ?>

            <!-- Jobs Table -->
            <div class="overflow-x-auto rounded-xl border border-slate-200/50 dark:border-slate-700/50">
                <table class="w-full text-sm text-left text-slate-500 dark:text-slate-400">
                    <thead class="text-xs text-slate-700 dark:text-slate-300 uppercase bg-slate-50 dark:bg-slate-900">
                        <tr>
                            <th class="px-6 py-3">Thông tin tin tuyển dụng</th>
                            <th class="px-6 py-3">Công ty / Người đăng</th>
                            <th class="px-6 py-3 text-center">Thống kê</th>
                            <th class="px-6 py-3 text-center">Trạng thái</th>
                            <th class="px-6 py-3 text-center">Hành động</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php if (empty($jobs)): ?>
                            <tr>
                                <td colspan="5" class="px-6 py-12 text-center text-slate-500 dark:text-slate-400 italic bg-slate-50 dark:bg-slate-900">
                                    <i class="fa-solid fa-inbox text-4xl text-slate-700 dark:text-slate-300 mb-3 block"></i>
                                    Không tìm thấy tin tuyển dụng nào phù hợp.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($jobs as $job): ?>
                                <tr class="bg-white dark:bg-slate-800 hover:bg-blue-900/20/30 transition duration-150" data-job-id="<?php echo $job['id']; ?>">
                                    <!-- Cột 1: Thông tin Job -->
                                    <td class="px-6 py-4 max-w-xs">
                                        <div class="font-bold text-slate-900 dark:text-white text-base mb-1 line-clamp-2">
                                            <a href="../../views/public/job-detail.php?id=<?php echo $job['id']; ?>" target="_blank" class="hover:text-blue-500 hover:underline" title="Xem chi tiết ngoài trang chủ">
                                                <?php echo htmlspecialchars($job['title']); ?> <i class="fa-solid fa-arrow-up-right-from-square text-xs text-slate-500 dark:text-slate-400 ml-1"></i>
                                            </a>
                                        </div>
                                        <div class="text-xs text-slate-500 dark:text-slate-400 space-y-1">
                                            <div class="flex items-center gap-2">
                                                <span class="bg-white dark:bg-slate-800 px-2 py-0.5 rounded border border-slate-200/50 dark:border-slate-700/50">
                                                    <?php 
                                                    $types = ['full_time' => 'Full-time', 'part_time' => 'Part-time', 'contract' => 'Hợp đồng', 'internship' => 'Thực tập', 'remote' => 'Remote'];
                                                    echo $types[$job['job_type']] ?? $job['job_type']; 
                                                    ?>
                                                </span>
                                                <span><i class="fa-solid fa-location-dot text-slate-500 dark:text-slate-400"></i> <?php echo htmlspecialchars($job['city']); ?></span>
                                            </div>
                                            <div><i class="fa-regular fa-clock text-slate-500 dark:text-slate-400"></i> Đăng: <?php echo date('d/m/Y', strtotime($job['created_at'])); ?></div>
                                        </div>
                                    </td>

                                    <!-- Cột 2: Thông tin Công ty -->
                                    <td class="px-6 py-4">
                                        <div class="flex items-center gap-3">
                                            <?php 
                                            $logo = !empty($job['company_logo_url']) ? $job['company_logo_url'] : 'https://ui-avatars.com/api/?name='.urlencode($job['company_name'] ?? 'C').'&background=random&size=64';
                                            ?>
                                            <img src="<?php echo htmlspecialchars($logo); ?>" class="w-10 h-10 rounded border object-contain bg-white dark:bg-slate-800 p-0.5">
                                            <div>
                                                <div class="font-semibold text-slate-900 dark:text-white line-clamp-1" title="<?php echo htmlspecialchars($job['company_name']); ?>">
                                                    <?php echo htmlspecialchars($job['company_name'] ?? 'Chưa cập nhật tên cty'); ?>
                                                </div>
                                                <div class="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1">
                                                    <i class="fa-solid fa-user text-slate-500 dark:text-slate-400"></i> <?php echo htmlspecialchars($job['recruiter_name']); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                    <!-- Cột 3: Thống kê -->
                                    <td class="px-6 py-4 text-center">
                                        <div class="flex justify-center gap-3 text-xs">
                                            <div class="text-center">
                                                <div class="font-bold text-slate-700 dark:text-slate-300"><?php echo number_format($job['views_count']); ?></div>
                                                <div class="text-slate-500 dark:text-slate-400">Views</div>
                                            </div>
                                            <div class="w-px bg-slate-100 dark:bg-slate-700 h-8"></div>
                                            <div class="text-center">
                                                <div class="font-bold text-blue-500"><?php echo number_format($job['applications_count']); ?></div>
                                                <div class="text-slate-500 dark:text-slate-400">Apply</div>
                                            </div>
                                        </div>
                                    </td>

                                    <!-- Cột 4: Trạng thái -->
                                    <td class="px-6 py-4 text-center">
                                        <?php
                                        $statusConfig = [
                                            'active' => ['bg' => 'bg-green-100', 'text' => 'text-green-700', 'label' => 'Đang chạy', 'icon' => 'fa-circle-check'],
                                            'pending' => ['bg' => 'bg-yellow-100', 'text' => 'text-yellow-700', 'label' => 'Chờ duyệt', 'icon' => 'fa-clock'],
                                            'closed' => ['bg' => 'bg-red-100', 'text' => 'text-red-700', 'label' => 'Đã đóng', 'icon' => 'fa-ban'],
                                            'draft' => ['bg' => 'bg-white dark:bg-slate-800', 'text' => 'text-slate-700 dark:text-slate-300', 'label' => 'Nháp', 'icon' => 'fa-pencil']
                                        ];
                                        $conf = $statusConfig[$job['status']] ?? $statusConfig['draft'];
                                        ?>
                                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold <?php echo $conf['bg'] . ' ' . $conf['text']; ?>">
                                            <i class="fa-solid <?php echo $conf['icon']; ?> text-[10px]"></i>
                                            <?php echo $conf['label']; ?>
                                        </span>
                                    </td>

                                    <!-- Cột 5: Hành động -->
                                    <td class="px-6 py-4 text-center">
                                        <div class="flex justify-center gap-2">
                                            <!-- Logic nút Duyệt -->
                                            <?php if ($job['status'] === 'pending'): ?>
                                                <form method="POST" style="display:inline;">
                                                    <input type="hidden" name="action" value="approve">
                                                    <input type="hidden" name="job_id" value="<?php echo $job['id']; ?>">
                                                    <button type="submit" class="w-8 h-8 flex items-center justify-center text-green-400 bg-green-900/20 hover:bg-green-100 rounded-xl transition" title="Duyệt đăng tin">
                                                        <i class="fa-solid fa-check"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>

                                            <!-- Logic nút Đóng/Khóa -->
                                            <?php if ($job['status'] === 'active'): ?>
                                                <form method="POST" onsubmit="return confirm('Bạn chắc chắn muốn đóng tin này? Nó sẽ không còn hiển thị với ứng viên.');" style="display:inline;">
                                                    <input type="hidden" name="action" value="close">
                                                    <input type="hidden" name="job_id" value="<?php echo $job['id']; ?>">
                                                    <button type="submit" class="w-8 h-8 flex items-center justify-center text-yellow-600 bg-yellow-50 hover:bg-yellow-100 rounded-xl transition" title="Đóng tin">
                                                        <i class="fa-solid fa-lock"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>

                                            <!-- Nút Xóa -->
                                            <form method="POST" onsubmit="return confirm('CẢNH BÁO NGUY HIỂM:\nHành động này sẽ xóa vĩnh viễn tin tuyển dụng và toàn bộ đơn ứng tuyển liên quan.\n\nBạn có chắc chắn muốn xóa?');" style="display:inline;">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="job_id" value="<?php echo $job['id']; ?>">
                                                <button type="submit" class="w-8 h-8 flex items-center justify-center text-red-400 bg-red-900/20 hover:bg-red-100 rounded-xl transition" title="Xóa vĩnh viễn">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="flex justify-center mt-8 gap-2">
                    <!-- Nút Previous -->
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&status=<?php echo $statusFilter; ?>&search=<?php echo urlencode($searchKeyword); ?>" 
                           class="px-3 py-1 rounded border bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800">
                           <i class="fa-solid fa-chevron-left"></i>
                        </a>
                    <?php endif; ?>

                    <!-- Các trang số -->
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&status=<?php echo $statusFilter; ?>&search=<?php echo urlencode($searchKeyword); ?>" 
                           class="px-3 py-1 rounded border font-medium <?php echo $i === $page ? 'bg-blue-600 text-slate-900 dark:text-white border-blue-600' : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800'; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>

                    <!-- Nút Next -->
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&status=<?php echo $statusFilter; ?>&search=<?php echo urlencode($searchKeyword); ?>" 
                           class="px-3 py-1 rounded border bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800">
                           <i class="fa-solid fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Highlight job row if coming from reports page
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            const highlightJobId = urlParams.get('highlight');
            
            if (highlightJobId) {
                // Find the job row with data-job-id attribute
                const jobRow = document.querySelector(`tr[data-job-id="${highlightJobId}"]`);
                
                if (jobRow) {
                    // Add red highlight class
                    jobRow.classList.add('bg-red-100/50', 'dark:bg-red-900/30', 'border-l-4', 'border-red-500');
                    
                    // Scroll to the element
                    setTimeout(() => {
                        jobRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }, 100);
                    
                    // Optional: Animate the highlight to fade out after 5 seconds
                    setTimeout(() => {
                        jobRow.classList.remove('bg-red-100/50', 'dark:bg-red-900/30', 'border-l-4', 'border-red-500');
                    }, 5000);
                }
            }
        });
    </script>
</body>
</html>