<?php
// views/admin/applications.php

require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/Application.php'; // Đảm bảo file này tồn tại
require_once '../../utils/models/Job.php';         // Để lấy thông tin job nếu cần
require_once '../../utils/Helpers.php'; 

requireRole('admin');
addSecurityHeaders();

// Khởi tạo Model (Nếu bạn chưa có hàm getAllApplicationsAdmin trong Model, mình sẽ giả lập query ở dưới)
// Tốt nhất bạn nên bổ sung hàm này vào utils/models/Application.php sau này.
$db = (new Database())->getConnection();

// --- XỬ LÝ HÀNH ĐỘNG (Xóa đơn spam) ---
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $appId = (int)($_POST['application_id'] ?? 0);
    
    if ($appId && $action === 'delete') {
        // Xóa đơn (Cần quyền Admin)
        $stmt = $db->prepare("DELETE FROM applications WHERE id = :id");
        $stmt->bindParam(':id', $appId);
        if ($stmt->execute()) {
            $message = ['type' => 'success', 'text' => '🗑️ Đã xóa đơn ứng tuyển.'];
        } else {
            $message = ['type' => 'error', 'text' => '❌ Lỗi khi xóa.'];
        }
    }
}

// --- LẤY DỮ LIỆU & PHÂN TRANG ---
$statusFilter = $_GET['status'] ?? 'all';
$searchKeyword = $_GET['search'] ?? '';
$page = (int)($_GET['page'] ?? 1);
$limit = 10;
$offset = ($page - 1) * $limit;

// Xây dựng Query (Lấy thông tin Ứng viên + Job + Recruiter + CV)
$query = "SELECT a.*, 
                 u.full_name as candidate_name, u.email as candidate_email, u.avatar_url,
                 j.title as job_title, 
                 rp.company_name,
                 cp.cv_file_url
          FROM applications a
          JOIN users u ON a.candidate_id = u.id
          JOIN jobs j ON a.job_id = j.id
          LEFT JOIN recruiter_profiles rp ON j.recruiter_id = rp.user_id
          LEFT JOIN candidate_profiles cp ON a.candidate_id = cp.user_id
          WHERE 1=1";

$params = [];

if ($statusFilter !== 'all') {
    $query .= " AND a.status = :status";
    $params[':status'] = $statusFilter;
}

if ($searchKeyword) {
    $query .= " AND (u.full_name LIKE :search OR j.title LIKE :search OR u.email LIKE :search)";
    $params[':search'] = "%$searchKeyword%";
}

// Đếm tổng số để phân trang
$countStmt = $db->prepare(str_replace("a.*, \n                 u.full_name as candidate_name, u.email as candidate_email, u.avatar_url,\n                 j.title as job_title, \n                 rp.company_name", "COUNT(*)", $query));
foreach ($params as $key => $value) $countStmt->bindValue($key, $value);
$countStmt->execute();
$totalApps = $countStmt->fetchColumn();
$totalPages = ceil($totalApps / $limit);

// Lấy dữ liệu chi tiết
$query .= " ORDER BY a.applied_at DESC LIMIT :limit OFFSET :offset";
$stmt = $db->prepare($query);
foreach ($params as $key => $value) $stmt->bindValue($key, $value);
$stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
$stmt->execute();
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Đơn ứng tuyển - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 font-sans">
    <!-- Navigation -->
    <nav class="bg-white dark:bg-slate-800 shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="dashboard.php" class="text-2xl font-bold tracking-tight text-blue-500 hover:text-blue-700 flex items-center gap-2">
                <i class="fa-solid fa-user-shield"></i> AI Recruitment Admin
            </a>
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:text-white transition"><i class="fa-solid fa-arrow-left"></i> Dashboard</a>
                <a href="../../logout.php" class="text-red-400 hover:text-red-800 font-medium transition">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-4 mb-6">
            <!-- Header & Filter -->
            <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4 border-b pb-6">
                <div>
                    <h1 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white"><i class="fa-solid fa-file-contract text-orange-500 mr-2"></i> Quản lý Đơn ứng tuyển</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Tổng cộng: <strong><?php echo number_format($totalApps); ?></strong> đơn</p>
                </div>
                
                <form class="flex flex-col md:flex-row gap-3 w-full md:w-auto" method="GET">
                    <select name="status" class="border rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-blue-500 bg-white dark:bg-slate-800" onchange="this.form.submit()">
                        <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>Tất cả trạng thái</option>
                        <option value="pending" <?php echo $statusFilter === 'pending' ? 'selected' : ''; ?>>⏳ Chờ xử lý</option>
                        <option value="reviewing" <?php echo $statusFilter === 'reviewing' ? 'selected' : ''; ?>>👀 Đang xem xét</option>
                        <option value="interviewed" <?php echo $statusFilter === 'interviewed' ? 'selected' : ''; ?>>🗣️ Phỏng vấn</option>
                        <option value="offered" <?php echo $statusFilter === 'offered' ? 'selected' : ''; ?>>🎉 Đã tuyển</option>
                        <option value="rejected" <?php echo $statusFilter === 'rejected' ? 'selected' : ''; ?>>❌ Từ chối</option>
                    </select>
                    <div class="relative">
                        <input type="text" name="search" value="<?php echo htmlspecialchars($searchKeyword); ?>" placeholder="Tìm tên ứng viên, job..." class="border rounded-xl pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-blue-500 w-full md:w-64">
                        <i class="fa-solid fa-search absolute left-3 top-2.5 text-slate-500 dark:text-slate-400"></i>
                    </div>
                    <button type="submit" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded-xl hover:bg-blue-500 text-sm font-medium transition">
                        Tìm kiếm
                    </button>
                </form>
            </div>

            <!-- Alerts -->
            <?php if (!empty($message)): ?>
                <div class="bg-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-100 border border-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $message['type'] === 'success' ? 'green' : 'red'; ?>-700 px-4 py-3 rounded mb-6 text-sm flex items-center shadow-sm">
                    <i class="fa-solid <?php echo $message['type'] === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i> 
                    <?php echo $message['text']; ?>
                </div>
            <?php endif; ?>

            <!-- Applications Table -->
            <div class="overflow-x-auto rounded-xl border border-slate-200/50 dark:border-slate-700/50">
                <table class="w-full text-sm text-left text-slate-500 dark:text-slate-400">
                    <thead class="text-xs text-slate-700 dark:text-slate-300 uppercase bg-slate-50 dark:bg-slate-900">
                        <tr>
                            <th class="px-6 py-3">Ứng viên</th>
                            <th class="px-6 py-3">Vị trí ứng tuyển</th>
                            <th class="px-6 py-3 text-center">AI Score</th>
                            <th class="px-6 py-3 text-center">Trạng thái</th>
                            <th class="px-6 py-3 text-center">Ngày nộp</th>
                            <th class="px-6 py-3 text-center">Hành động</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php if (empty($applications)): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-12 text-center text-slate-500 dark:text-slate-400 italic bg-slate-50 dark:bg-slate-900">
                                    Không tìm thấy đơn ứng tuyển nào.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($applications as $app): ?>
                                <tr class="bg-white dark:bg-slate-800 hover:bg-orange-50/30 transition duration-150">
                                    <!-- Cột 1: Ứng viên -->
                                    <td class="px-6 py-4">
                                        <div class="flex items-center gap-3">
                                            <img src="<?php echo !empty($app['avatar_url']) ? htmlspecialchars($app['avatar_url']) : 'https://ui-avatars.com/api/?name='.urlencode($app['candidate_name']).'&background=random'; ?>" class="w-9 h-9 rounded-full border">
                                            <div>
                                                <div class="font-semibold text-slate-900 dark:text-white"><?php echo htmlspecialchars($app['candidate_name']); ?></div>
                                                <div class="text-xs text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($app['candidate_email']); ?></div>
                                            </div>
                                        </div>
                                    </td>

                                    <!-- Cột 2: Vị trí & Công ty -->
                                    <td class="px-6 py-4 max-w-xs">
                                        <div class="font-bold text-slate-900 dark:text-white line-clamp-1" title="<?php echo htmlspecialchars($app['job_title']); ?>">
                                            <?php echo htmlspecialchars($app['job_title']); ?>
                                        </div>
                                        <div class="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1">
                                            <i class="fa-solid fa-building text-slate-500 dark:text-slate-400"></i> <?php echo htmlspecialchars($app['company_name'] ?? 'N/A'); ?>
                                        </div>
                                    </td>

                                    <!-- Cột 3: AI Score -->
                                    <td class="px-6 py-4 text-center">
                                        <?php if (!empty($app['matching_score'])): ?>
                                            <div class="inline-flex items-center justify-center w-10 h-10 rounded-full border-2 
                                                <?php echo $app['matching_score'] >= 75 ? 'border-green-500 text-green-400 bg-green-900/20' : ($app['matching_score'] >= 50 ? 'border-yellow-500 text-yellow-600 bg-yellow-50' : 'border-red-500 text-red-400 bg-red-900/20'); ?> 
                                                font-bold text-xs shadow-sm">
                                                <?php echo $app['matching_score']; ?>%
                                            </div>
                                        <?php else: ?>
                                            <span class="text-slate-500 dark:text-slate-400 text-xs italic">--</span>
                                        <?php endif; ?>
                                    </td>

                                    <!-- Cột 4: Trạng thái -->
                                    <td class="px-6 py-4 text-center">
                                        <?php
                                        $statusConfig = [
                                            'pending' => ['bg' => 'bg-yellow-100', 'text' => 'text-yellow-700', 'label' => 'Chờ xử lý'],
                                            'reviewing' => ['bg' => 'bg-blue-100', 'text' => 'text-blue-700', 'label' => 'Đang xem'],
                                            'interviewed' => ['bg' => 'bg-purple-100', 'text' => 'text-purple-700', 'label' => 'Phỏng vấn'],
                                            'offered' => ['bg' => 'bg-green-100', 'text' => 'text-green-700', 'label' => 'Đã tuyển'],
                                            'rejected' => ['bg' => 'bg-red-100', 'text' => 'text-red-700', 'label' => 'Từ chối']
                                        ];
                                        $conf = $statusConfig[$app['status']] ?? ['bg' => 'bg-white dark:bg-slate-800', 'text' => 'text-slate-700 dark:text-slate-300', 'label' => ucfirst($app['status'])];
                                        ?>
                                        <span class="px-2.5 py-0.5 rounded text-xs font-semibold <?php echo $conf['bg'] . ' ' . $conf['text']; ?>">
                                            <?php echo $conf['label']; ?>
                                        </span>
                                    </td>

                                    <!-- Cột 5: Ngày nộp -->
                                    <td class="px-6 py-4 text-center text-xs text-slate-500 dark:text-slate-400">
                                        <?php 
                                        if (class_exists('DateHelper')) {
                                            echo DateHelper::formatDateTime($app['applied_at']);
                                        } else {
                                            echo date('d/m/Y H:i', strtotime($app['applied_at']));
                                        }
                                        ?>
                                    </td>

                                    <!-- Cột 6: Hành động -->
                                    <td class="px-6 py-4 text-center">
                                        <div class="flex justify-center gap-2">
                                            <!-- Xem chi tiết (CV) -->
                                        <?php if (!empty($app['cv_file_url'])): ?>
                                            <a href="<?php echo BASE_URL . htmlspecialchars($app['cv_file_url']); ?>" target="_blank" class="w-8 h-8 flex items-center justify-center text-blue-500 bg-blue-900/20 hover:bg-blue-100 rounded-xl transition" title="Xem CV">
                                                <i class="fa-solid fa-eye"></i>
                                            </a>
                                        <?php else: ?>
                                            <span class="w-8 h-8 flex items-center justify-center text-gray-400" title="Không có CV">
                                                <i class="fa-solid fa-ban"></i>
                                            </span>
                                        <?php endif; ?>

                                            <!-- Xóa (Chỉ Admin mới có quyền này để dọn rác) -->
                                            <form method="POST" onsubmit="return confirm('Bạn chắc chắn muốn xóa đơn ứng tuyển này?');" style="display:inline;">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                                <button type="submit" class="w-8 h-8 flex items-center justify-center text-red-400 bg-red-900/20 hover:bg-red-100 rounded-xl transition" title="Xóa đơn">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="flex justify-center mt-8 gap-2">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&status=<?php echo $statusFilter; ?>&search=<?php echo urlencode($searchKeyword); ?>" 
                           class="px-3 py-1 rounded border bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800"><i class="fa-solid fa-chevron-left"></i></a>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&status=<?php echo $statusFilter; ?>&search=<?php echo urlencode($searchKeyword); ?>" 
                           class="px-3 py-1 rounded border font-medium <?php echo $i === $page ? 'bg-blue-600 text-slate-900 dark:text-white border-blue-600' : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800'; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&status=<?php echo $statusFilter; ?>&search=<?php echo urlencode($searchKeyword); ?>" 
                           class="px-3 py-1 rounded border bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-white dark:bg-slate-800"><i class="fa-solid fa-chevron-right"></i></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>