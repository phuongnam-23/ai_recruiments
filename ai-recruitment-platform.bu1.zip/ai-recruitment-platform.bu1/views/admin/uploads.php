<?php
// views/admin/uploads.php

require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/CandidateProfile.php';

requireRole('admin');
addSecurityHeaders();

// Lấy dữ liệu CV từ database với user_id để xóa file sau này
$db = (new Database())->getConnection();
$query = "SELECT cp.cv_file_url, cp.user_id, u.full_name, u.email, cp.updated_at, cp.created_at
          FROM candidate_profiles cp
          LEFT JOIN users u ON cp.user_id = u.id
          WHERE cp.cv_file_url IS NOT NULL AND cp.cv_file_url != ''
          ORDER BY cp.updated_at DESC";

$stmt = $db->prepare($query);
$stmt->execute();
$allFiles = $stmt->fetchAll(PDO::FETCH_ASSOC);

// --- BẮT ĐẦU PHẦN SỬA LỖI TÍNH DUNG LƯỢNG ---
// 1. Lấy đường dẫn gốc tuyệt đối của dự án (Project Root)
// Đi lùi 2 cấp từ views/admin để về root
$projectRoot = realpath(__DIR__ . '/../../');

$totalSize = 0;

foreach ($allFiles as &$file) {
    $dbPath = $file['cv_file_url']; // VD: utils/uploads/cv/file.pdf
    
    // 2. Tạo đường dẫn vật lý (Physical Path) chuẩn theo Hệ điều hành
    // Nối Project Root + Đường dẫn trong DB (thay thế / thành \ nếu là Windows)
    $physicalPath = $projectRoot . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $dbPath);
    
    // 3. Kiểm tra file có tồn tại trên ổ cứng không
    if (file_exists($physicalPath) && is_file($physicalPath)) {
        $fileSize = filesize($physicalPath);
        $file['size'] = $fileSize;
        $totalSize += $fileSize;
    } else {
        // Fallback: Nếu đường dẫn trong DB chỉ lưu tên file hoặc sai path
        // Thử tìm trực tiếp trong folder utils/uploads/cv/
        $alternativePath = $projectRoot . '/utils/uploads/cv/' . basename($dbPath);
        $alternativePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $alternativePath);

        if (file_exists($alternativePath)) {
            $file['size'] = filesize($alternativePath);
            $totalSize += $file['size'];
        } else {
            $file['size'] = 0; // Không tìm thấy file
        }
    }
}
unset($file); // Hủy tham chiếu biến
// --- KẾT THÚC PHẦN SỬA ---
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Upload</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900">
    <nav class="bg-white dark:bg-slate-800 shadow">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <h1 class="text-2xl font-bold tracking-tight text-blue-500">AI Recruitment Admin</h1>
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:text-white">← Dashboard</a>
                <a href="../../logout.php" class="text-red-400 hover:underline">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mb-8">
            <h1 class="text-3xl font-bold tracking-tight mb-6 text-slate-900 dark:text-white">📁 Quản lý Upload</h1>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div class="bg-blue-900/20 rounded p-4">
                    <h3 class="text-slate-700 dark:text-slate-300 text-sm">Tổng file</h3>
                    <p class="text-3xl font-bold tracking-tight text-blue-500"><?php echo count($allFiles); ?></p>
                </div>
                <div class="bg-green-900/20 rounded p-4">
                    <h3 class="text-slate-700 dark:text-slate-300 text-sm">File CV</h3>
                    <p class="text-3xl font-bold tracking-tight text-green-400">
                        <?php echo count($allFiles); ?>
                    </p>
                </div>
                <div class="bg-purple-50 rounded p-4">
                    <h3 class="text-slate-700 text-sm">Dung lượng tổng</h3>
                    <p class="text-2xl font-bold tracking-tight text-purple-600">
                        <?php echo number_format($totalSize / 1024 / 1024, 2); ?> MB
                    </p>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-slate-500 dark:text-slate-400">
                    <thead class="bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        <tr>
                            <th class="px-6 py-3 text-left">Tên Ứng Viên</th>
                            <th class="px-6 py-3 text-left">Email</th>
                            <th class="px-6 py-3 text-left">Dung lượng</th>
                            <th class="px-6 py-3 text-left">Ngày Cập Nhật</th>
                            <th class="px-6 py-3 text-center">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($allFiles)): ?>
                            <tr>
                                <td colspan="5" class="px-6 py-8 text-center text-slate-700 dark:text-slate-300">
                                    Không có file nào
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($allFiles as $file): ?>
                                <tr class="border-b dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                    <td class="px-6 py-4 font-semibold text-slate-900 dark:text-white">
                                        <?php echo htmlspecialchars($file['full_name'] ?? 'N/A'); ?>
                                    </td>
                                    <td class="px-6 py-4">
                                        <?php echo htmlspecialchars($file['email'] ?? 'N/A'); ?>
                                    </td>
                                    <td class="px-6 py-4">
                                        <?php 
                                        if ($file['size'] > 0) {
                                            echo ($file['size'] < 1024 * 1024) 
                                                ? number_format($file['size'] / 1024, 2) . ' KB' 
                                                : number_format($file['size'] / 1024 / 1024, 2) . ' MB';
                                        } else {
                                            echo '<span class="text-red-400 italic">0 KB (Lỗi path)</span>';
                                        }
                                        ?>
                                    </td>
                                    <td class="px-6 py-4 text-sm">
                                        <?php echo date('d/m/Y H:i', strtotime($file['updated_at'])); ?>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <div class="flex justify-center gap-2">
                                            <a href="<?php echo BASE_URL . htmlspecialchars($file['cv_file_url']); ?>" target="_blank" 
                                               class="inline-flex items-center gap-1 text-blue-500 hover:text-blue-700 dark:hover:text-blue-400 font-semibold mr-3" title="Xem">
                                                <span>👁️</span> Xem
                                            </a>
                                            <a href="<?php echo BASE_URL . htmlspecialchars($file['cv_file_url']); ?>" download 
                                               class="inline-flex items-center gap-1 text-green-400 hover:text-green-300 font-semibold mr-3" title="Tải">
                                                <span>⬇️</span> Tải
                                            </a>
                                            <button onclick="if(confirm('Chắc chắn xóa file CV này? Mọi dữ liệu liên quan sẽ mất.')) { xoaFileCv(<?php echo $file['user_id']; ?>, '<?php echo htmlspecialchars($file['cv_file_url']); ?>'); }" 
                                                    class="inline-flex items-center gap-1 text-red-500 hover:text-red-700 dark:hover:text-red-400 font-semibold" title="Xóa">
                                                <span>🗑️</span> Xóa
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-8 bg-yellow-50 border border-yellow-200 rounded p-4">
                <h3 class="font-bold text-yellow-900 mb-2">⚠️ Ghi chú:</h3>
                <ul class="text-sm text-yellow-800 space-y-1">
                    <li>• File tự động được đặt tên với user ID để tránh trùng lặp</li>
                    <li>• Các file có thể được xóa thủ công từ thư mục uploads/</li>
                    <li>• Kiểm tra dung lượng để tránh đầy ổ cứng</li>
                    <li>• Các file được bảo vệ bằng .htaccess (không thể thực thi PHP)</li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        // Hàm xóa file CV
        async function xoaFileCv(userId, cvFileUrl) {
            try {
                console.log('Deleting CV for user:', userId, 'file:', cvFileUrl);
                
                const formData = new FormData();
                formData.append('action', 'admin-delete-file');
                formData.append('user_id', userId);
                
                const response = await fetch('../../api.php', {
                    method: 'POST',
                    body: formData
                });
                
                console.log('Response status:', response.status);
                const responseText = await response.text();
                console.log('Response text:', responseText);
                
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (e) {
                    console.error('JSON parse error:', e);
                    alert('❌ Lỗi: ' + responseText);
                    return;
                }
                
                if (data.success) {
                    alert('✅ ' + data.message);
                    location.reload();
                } else {
                    alert('❌ ' + data.message);
                }
            } catch (error) {
                alert('❌ Lỗi: ' + error.message);
                console.error('Delete error:', error);
            }
        }
    </script>
</body>
</html>