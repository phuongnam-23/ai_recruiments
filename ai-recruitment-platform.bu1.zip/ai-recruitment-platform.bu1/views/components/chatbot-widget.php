<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token']) && function_exists('generateToken')) {
    $_SESSION['csrf_token'] = generateToken();
} elseif (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$isAuthenticated = function_exists('isLoggedIn') ? isLoggedIn() : !empty($_SESSION['user_id']);
$apiEndpoint = BASE_URL . 'api.php?action=chat-bot';
$csrfToken = $_SESSION['csrf_token'];
?>
<div id="ai-chatbot-widget"
     data-api="<?php echo htmlspecialchars($apiEndpoint, ENT_QUOTES, 'UTF-8'); ?>"
     data-token="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>"
     data-auth="<?php echo $isAuthenticated ? '1' : '0'; ?>"
     class="fixed bottom-24 right-6 text-slate-900 dark:text-white"
     style="z-index: 9999;">
    <button type="button"
            data-chatbot-toggle
            class="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg flex items-center justify-center text-2xl hover:scale-110 focus:outline-none focus:ring-2 focus:ring-blue-400 transition-all duration-200">
        🤖
    </button>

    <div id="ai-chatbot-window" class="hidden absolute bottom-16 right-0 w-80 sm:w-96">
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200/70 dark:border-slate-700/70 flex flex-col">
            <div class="px-4 py-3 border-b border-slate-200/70 dark:border-slate-700/70 flex items-center justify-between">
                <div>
                    <p class="text-sm font-semibold">AI Career Advisor</p>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Hỗ trợ 24/7</p>
                </div>
                <button type="button" data-chatbot-toggle class="text-slate-400 hover:text-slate-600 dark:hover:text-white">✕</button>
            </div>

            <div id="ai-chatbot-messages" class="px-4 py-4 h-72 overflow-y-auto space-y-3 text-sm">
                <div class="flex justify-start">
                    <div class="bg-slate-100 dark:bg-slate-700/70 border border-slate-200/60 dark:border-slate-600/60 rounded-2xl px-3 py-2 max-w-[80%]">
                        <?php if ($isAuthenticated): ?>
                            👋 Xin chào! Mình là trợ lý nghề nghiệp AI, hãy cho mình biết điều bạn đang băn khoăn nhé.
                        <?php else: ?>
                            🔒 Vui lòng <a href="<?php echo BASE_URL; ?>login.php" class="text-blue-500 underline">đăng nhập</a> để trò chuyện cùng AI Advisor.
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if ($isAuthenticated): ?>
                <form id="ai-chatbot-form" class="px-4 py-3 border-t border-slate-200/70 dark:border-slate-700/70 flex gap-2">
                    <input type="text"
                           id="ai-chatbot-input"
                           name="message"
                           autocomplete="off"
                           placeholder="Nhập câu hỏi..."
                           class="flex-1 rounded-xl border border-slate-200/60 dark:border-slate-600/60 bg-slate-50 dark:bg-slate-900/50 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <button type="submit"
                            class="bg-blue-600 hover:bg-blue-500 text-white rounded-xl px-4 text-sm font-semibold">
                        Gửi
                    </button>
                </form>
            <?php else: ?>
                <div class="px-4 py-3 border-t border-slate-200/70 dark:border-slate-700/70 text-xs text-center text-slate-500 dark:text-slate-400">
                    Bạn cần đăng nhập để sử dụng trợ lý AI.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
(function () {
    if (window.__AI_CAREER_CHATBOT_INITIALIZED__) {
        return;
    }
    window.__AI_CAREER_CHATBOT_INITIALIZED__ = true;

    const widget = document.getElementById('ai-chatbot-widget');
    if (!widget) {
        return;
    }

    const panel = document.getElementById('ai-chatbot-window');
    const toggleButtons = widget.querySelectorAll('[data-chatbot-toggle]');

    toggleButtons.forEach((btn) => {
        btn.addEventListener('click', () => {
            panel.classList.toggle('hidden');
        });
    });

    if (widget.dataset.auth !== '1') {
        return;
    }

    const form = document.getElementById('ai-chatbot-form');
    const input = document.getElementById('ai-chatbot-input');
    const messageList = document.getElementById('ai-chatbot-messages');
    const endpoint = widget.dataset.api;
    const csrfToken = widget.dataset.token;
    let isSending = false;

    const scrollToBottom = () => {
        messageList.scrollTop = messageList.scrollHeight;
    };

    const sanitize = (text) => {
        return text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    };

    const renderMarkdownLite = (text) => {
        return sanitize(text)
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`([^`]+)`/g, '<code class="bg-slate-800/10 px-1 rounded">$1</code>')
            .replace(/\n/g, '<br>');
    };

    const appendMessage = (content, sender) => {
        const row = document.createElement('div');
        row.className = sender === 'user' ? 'flex justify-end' : 'flex justify-start';

        const bubble = document.createElement('div');
        bubble.className = sender === 'user'
            ? 'bg-blue-600 text-white rounded-2xl px-3 py-2 max-w-[80%]'
            : 'bg-slate-100 dark:bg-slate-700/70 border border-slate-200/60 dark:border-slate-600/60 rounded-2xl px-3 py-2 max-w-[80%]';
        bubble.innerHTML = renderMarkdownLite(content);

        row.appendChild(bubble);
        messageList.appendChild(row);
        scrollToBottom();
        return row;
    };

    const showTyping = () => {
        const typing = document.createElement('div');
        typing.id = 'ai-chatbot-typing';
        typing.className = 'flex justify-start text-xs text-slate-500';
        typing.innerHTML = '<div class="bg-slate-100 dark:bg-slate-700/70 border border-slate-200/60 dark:border-slate-600/60 rounded-2xl px-3 py-2">AI đang nhập...</div>';
        messageList.appendChild(typing);
        scrollToBottom();
    };

    const hideTyping = () => {
        const typing = document.getElementById('ai-chatbot-typing');
        if (typing) {
            typing.remove();
        }
    };

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (isSending) {
            return;
        }

        const text = input.value.trim();
        if (!text) {
            return;
        }

        appendMessage(text, 'user');
        input.value = '';
        showTyping();
        isSending = true;

        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    message: text,
                    csrf_token: csrfToken,
                }),
            });

            const data = await response.json();
            hideTyping();

            if (data.success && data.reply) {
                appendMessage(data.reply, 'ai');
            } else {
                appendMessage('❌ ' + (data.message || 'Hệ thống bận, vui lòng thử lại sau.'), 'ai');
            }
        } catch (error) {
            hideTyping();
            appendMessage('❌ Lỗi kết nối: ' + error.message, 'ai');
        } finally {
            isSending = false;
        }
    });
})();
</script>
