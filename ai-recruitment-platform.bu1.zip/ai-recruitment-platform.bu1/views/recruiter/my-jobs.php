<?php
require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';

// Require login and recruiter role
requireLogin('recruiter');

// Redirect to dashboard which shows all jobs
header('Location: dashboard.php');
exit;
?>
