<!-- EDIT PROFILE SECTION FOR RECRUITER (Already in dashboard tab) -->
<div id="content-edit" class="p-6 hidden">
    <form id="updateRecruiterProfileForm" method="POST" class="space-y-6">
        <input type="hidden" name="action" value="update-recruiter-profile">

        <!-- Thông tin cá nhân -->
        <div class="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-5">
            <h3 class="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                <i class="fa-solid fa-user text-blue-500"></i> Thông tin cá nhân
            </h3>
            
            <!-- Họ tên -->
            <div class="mb-4">
                <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Họ và tên <span class="text-red-500">*</span>
                </label>
                <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" 
                       class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm" 
                       required>
            </div>

            <!-- Email (readonly) -->
            <div class="mb-4">
                <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Email
                </label>
                <input type="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" 
                       class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-400 text-sm cursor-not-allowed" 
                       readonly disabled>
                <p class="text-xs text-slate-500 mt-1">Email không thể thay đổi</p>
            </div>

            <!-- Số điện thoại -->
            <div>
                <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Số điện thoại <span class="text-red-500">*</span>
                </label>
                <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" 
                       class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm" 
                       placeholder="0912345678" required>
            </div>
        </div>

        <!-- Thông tin công ty -->
        <div class="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-5">
            <h3 class="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                <i class="fa-solid fa-building text-purple-500"></i> Thông tin công ty
            </h3>
            
            <!-- Tên công ty -->
            <div class="mb-4">
                <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Tên công ty <span class="text-red-500">*</span>
                </label>
                <input type="text" name="company_name" value="<?php echo htmlspecialchars($profile['company_name'] ?? ''); ?>" 
                       class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm" 
                       placeholder="VD: FPT Software" required>
            </div>

            <!-- Grid 2 columns -->
            <div class="grid grid-cols-2 gap-4 mb-4">
                <!-- Quy mô -->
                <div>
                    <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                        Quy mô <span class="text-red-500">*</span>
                    </label>
                    <select name="company_size" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm" required>
                        <option value="">-- Chọn --</option>
                        <option value="1-50" <?php echo ($profile['company_size'] ?? '') === '1-50' ? 'selected' : ''; ?>>1-50 nhân viên</option>
                        <option value="51-200" <?php echo ($profile['company_size'] ?? '') === '51-200' ? 'selected' : ''; ?>>51-200 nhân viên</option>
                        <option value="201-500" <?php echo ($profile['company_size'] ?? '') === '201-500' ? 'selected' : ''; ?>>201-500 nhân viên</option>
                        <option value="501-1000" <?php echo ($profile['company_size'] ?? '') === '501-1000' ? 'selected' : ''; ?>>501-1000 nhân viên</option>
                        <option value="1000+" <?php echo ($profile['company_size'] ?? '') === '1000+' ? 'selected' : ''; ?>>1000+ nhân viên</option>
                    </select>
                </div>

                <!-- Ngành nghề -->
                <div>
                    <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                        Ngành nghề <span class="text-red-500">*</span>
                    </label>
                    <select name="industry" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm" required>
                        <option value="">-- Chọn --</option>
                        <option value="Information Technology" <?php echo ($profile['industry'] ?? '') === 'Information Technology' ? 'selected' : ''; ?>>Công nghệ thông tin</option>
                        <option value="IT Outsourcing" <?php echo ($profile['industry'] ?? '') === 'IT Outsourcing' ? 'selected' : ''; ?>>IT Outsourcing</option>
                        <option value="Finance" <?php echo ($profile['industry'] ?? '') === 'Finance' ? 'selected' : ''; ?>>Tài chính - Ngân hàng</option>
                        <option value="E-commerce" <?php echo ($profile['industry'] ?? '') === 'E-commerce' ? 'selected' : ''; ?>>Thương mại điện tử</option>
                        <option value="Telecommunications" <?php echo ($profile['industry'] ?? '') === 'Telecommunications' ? 'selected' : ''; ?>>Viễn thông</option>
                        <option value="Marketing" <?php echo ($profile['industry'] ?? '') === 'Marketing' ? 'selected' : ''; ?>>Marketing - Quảng cáo</option>
                        <option value="Education" <?php echo ($profile['industry'] ?? '') === 'Education' ? 'selected' : ''; ?>>Giáo dục - Đào tạo</option>
                        <option value="Healthcare" <?php echo ($profile['industry'] ?? '') === 'Healthcare' ? 'selected' : ''; ?>>Y tế - Sức khỏe</option>
                    </select>
                </div>
            </div>

            <!-- Website -->
            <div class="mb-4">
                <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Website công ty
                </label>
                <input type="url" name="company_website" value="<?php echo htmlspecialchars($profile['company_website'] ?? ''); ?>" 
                       class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm" 
                       placeholder="https://example.com">
            </div>

            <!-- Thành phố -->
            <div class="mb-4">
                <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Thành phố <span class="text-red-500">*</span>
                </label>
                <select name="company_city" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm" required>
                    <option value="">-- Chọn --</option>
                    <option value="Hà Nội" <?php echo ($profile['company_city'] ?? '') === 'Hà Nội' ? 'selected' : ''; ?>>Hà Nội</option>
                    <option value="TP Hồ Chí Minh" <?php echo ($profile['company_city'] ?? '') === 'TP Hồ Chí Minh' ? 'selected' : ''; ?>>TP Hồ Chí Minh</option>
                    <option value="Đà Nẵng" <?php echo ($profile['company_city'] ?? '') === 'Đà Nẵng' ? 'selected' : ''; ?>>Đà Nẵng</option>
                    <option value="Hải Phòng" <?php echo ($profile['company_city'] ?? '') === 'Hải Phòng' ? 'selected' : ''; ?>>Hải Phòng</option>
                    <option value="Cần Thơ" <?php echo ($profile['company_city'] ?? '') === 'Cần Thơ' ? 'selected' : ''; ?>>Cần Thơ</option>
                </select>
            </div>

            <!-- Địa chỉ chi tiết -->
            <div class="mb-4">
                <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Địa chỉ chi tiết <span class="text-red-500">*</span>
                </label>
                <input type="text" name="company_address" value="<?php echo htmlspecialchars($profile['company_address'] ?? ''); ?>" 
                       class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm" 
                       placeholder="Tòa nhà, số nhà, tên đường, quận/huyện..." required>
            </div>

            <!-- Mô tả công ty -->
            <div>
                <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Mô tả về công ty <span class="text-red-500">*</span>
                </label>
                <textarea name="company_description" rows="4" 
                          class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm" 
                          placeholder="Giới thiệu về công ty, lĩnh vực hoạt động, văn hóa doanh nghiệp..." 
                          required><?php echo htmlspecialchars($profile['company_description'] ?? ''); ?></textarea>
                <p class="text-xs text-slate-500 mt-1">Tối thiểu 100 ký tự</p>
            </div>
        </div>

        <!-- Thông tin pháp lý -->
        <div class="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-5">
            <h3 class="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                <i class="fa-solid fa-file-contract text-green-500"></i> Thông tin pháp lý
            </h3>
            
            <!-- Mã số thuế -->
            <div>
                <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Mã số thuế
                </label>
                <input type="text" name="tax_code" value="<?php echo htmlspecialchars($profile['tax_code'] ?? ''); ?>" 
                       class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm" 
                       placeholder="VD: 0123456789">
                <p class="text-xs text-slate-500 mt-1">Mã số thuế giúp xác minh tính hợp pháp của công ty</p>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex gap-3 justify-end pt-4 border-t border-slate-200 dark:border-slate-700">
            <button type="button" onclick="switchTab('view')" 
                    class="px-5 py-2.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 font-semibold transition text-sm">
                Hủy
            </button>
            <button type="submit" 
                    class="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-lg font-semibold transition shadow-lg flex items-center gap-2 text-sm">
                <i class="fa-solid fa-save"></i> Lưu thay đổi
            </button>
        </div>
    </form>
</div>

<script>
// Tab switching for recruiter dashboard
function switchTab(tab) {
    const viewBtn = document.getElementById('tab-view');
    const editBtn = document.getElementById('tab-edit');
    const viewContent = document.getElementById('content-view');
    const editContent = document.getElementById('content-edit');
    
    if (tab === 'view') {
        viewBtn.classList.add('border-blue-600', 'text-blue-500', 'bg-blue-900/20');
        viewBtn.classList.remove('border-transparent', 'text-slate-500');
        editBtn.classList.remove('border-blue-600', 'text-blue-500', 'bg-blue-900/20');
        editBtn.classList.add('border-transparent', 'text-slate-500');
        viewContent.classList.remove('hidden');
        editContent.classList.add('hidden');
    } else {
        editBtn.classList.add('border-blue-600', 'text-blue-500', 'bg-blue-900/20');
        editBtn.classList.remove('border-transparent', 'text-slate-500');
        viewBtn.classList.remove('border-blue-600', 'text-blue-500', 'bg-blue-900/20');
        viewBtn.classList.add('border-transparent', 'text-slate-500');
        editContent.classList.remove('hidden');
        viewContent.classList.add('hidden');
    }
}

// Setup tab buttons
document.getElementById('tab-view')?.addEventListener('click', () => switchTab('view'));
document.getElementById('tab-edit')?.addEventListener('click', () => switchTab('edit'));

// Handle form submission
document.getElementById('updateRecruiterProfileForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    try {
        const response = await fetch('<?php echo BASE_URL; ?>api.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('✅ Cập nhật hồ sơ công ty thành công!');
            location.reload();
        } else {
            alert('❌ Lỗi: ' + (data.message || 'Không thể cập nhật hồ sơ'));
        }
    } catch (error) {
        alert('❌ Lỗi: ' + error.message);
    }
});
</script>
