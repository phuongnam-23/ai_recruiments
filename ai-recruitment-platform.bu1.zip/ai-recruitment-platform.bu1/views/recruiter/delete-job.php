<?php
// views/recruiter/delete-job.php

require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/Job.php';

requireRole('recruiter');

// Lấy ID từ URL
$jobId = (int)($_GET['id'] ?? 0);

if (!$jobId) {
    redirect('dashboard.php');
}

// Kiểm tra quyền sở hữu job
$jobModel = new Job();
$job = $jobModel->getJobById($jobId);

if (!$job || $job['recruiter_id'] != $_SESSION['user_id']) {
    redirect('dashboard.php');
}

// Xóa job
if ($jobModel->deleteJob($jobId)) {
    // Xóa thành công, redirect về dashboard với thông báo
    $_SESSION['success_message'] = 'Tin đăng đã được xóa thành công!';
    header('Location: dashboard.php');
    exit;
} else {
    // Xóa thất bại
    $_SESSION['error_message'] = 'Không thể xóa tin đăng. Vui lòng thử lại!';
    header('Location: dashboard.php');
    exit;
}
?>
