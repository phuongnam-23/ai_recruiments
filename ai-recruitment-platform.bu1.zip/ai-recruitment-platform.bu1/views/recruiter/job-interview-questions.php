<?php
require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';

requireRole('recruiter');
addSecurityHeaders();

$jobId = (int)($_GET['id'] ?? 0);
if (!$jobId) redirect('dashboard.php');

$jobModel = new Job();
$job = $jobModel->getJobById($jobId);

if (!$job || $job['recruiter_id'] != $_SESSION['user_id']) {
    redirect('dashboard.php');
}

$questions = [];
if (!empty($job['ai_generated_questions'])) {
    $decoded = json_decode($job['ai_generated_questions'], true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
        $questions = $decoded;
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Câu hỏi phỏng vấn - <?php echo htmlspecialchars($job['title']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900">
    <nav class="bg-white dark:bg-slate-800 shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="dashboard.php" class="text-2xl font-bold text-blue-600">AI Recruitment</a>
            <div class="flex items-center gap-4">
                <span class="text-slate-600 dark:text-slate-300"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                <a href="../../logout.php" class="text-red-500 hover:text-red-700">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-5xl mx-auto px-4 py-8">
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 p-6 mb-6">
            <div class="flex justify-between items-start">
                <div>
                    <h1 class="text-2xl font-bold text-slate-900 dark:text-white mb-2"><?php echo htmlspecialchars($job['title']); ?></h1>
                    <p class="text-slate-500 dark:text-slate-400"><i class="fa-solid fa-wand-magic-sparkles"></i> Câu hỏi phỏng vấn AI</p>
                </div>
                <div class="flex gap-2">
                    <button onclick="generateInterviewQuestions(<?php echo $jobId; ?>)" class="px-4 py-2 bg-purple-600 text-white rounded-xl hover:bg-purple-500 transition">
                        <i class="fa-solid fa-rotate"></i> Tạo lại
                    </button>
                    <a href="dashboard.php" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl hover:bg-slate-200 transition">
                        ← Quay lại
                    </a>
                </div>
            </div>
        </div>

        <?php if (empty($questions)): ?>
            <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 p-12 text-center">
                <i class="fa-solid fa-clipboard-question text-6xl text-slate-300 dark:text-slate-600 mb-4"></i>
                <h2 class="text-xl font-bold text-slate-900 dark:text-white mb-2">Chưa có câu hỏi phỏng vấn</h2>
                <p class="text-slate-500 dark:text-slate-400 mb-6">AI sẽ tạo 10 câu hỏi (5 technical, 3 behavioral, 2 situational) dựa trên job description.</p>
                <button onclick="generateInterviewQuestions(<?php echo $jobId; ?>)" class="px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-500 transition font-semibold">
                    <i class="fa-solid fa-wand-magic-sparkles"></i> Tạo câu hỏi bằng AI
                </button>
            </div>
        <?php else: ?>
            <div class="grid gap-4">
                <?php
                $typeLabels = [
                    'technical' => ['label' => 'Kỹ thuật', 'color' => 'bg-blue-100 text-blue-700 border-blue-500', 'icon' => 'fa-code'],
                    'behavioral' => ['label' => 'Hành vi', 'color' => 'bg-green-100 text-green-700 border-green-500', 'icon' => 'fa-users'],
                    'situational' => ['label' => 'Tình huống', 'color' => 'bg-orange-100 text-orange-700 border-orange-500', 'icon' => 'fa-lightbulb']
                ];
                
                foreach ($questions as $index => $q):
                    $type = $q['type'] ?? 'technical';
                    $typeInfo = $typeLabels[$type] ?? $typeLabels['technical'];
                ?>
                    <div class="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-5 hover:shadow-md transition">
                        <div class="flex items-start gap-4">
                            <div class="flex-shrink-0 w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-600 dark:text-slate-300">
                                <?php echo $index + 1; ?>
                            </div>
                            <div class="flex-1">
                                <div class="flex items-center gap-2 mb-3">
                                    <span class="px-3 py-1 rounded-full text-xs font-semibold border-2 <?php echo $typeInfo['color']; ?>">
                                        <i class="fa-solid <?php echo $typeInfo['icon']; ?>"></i> <?php echo $typeInfo['label']; ?>
                                    </span>
                                    <?php if (!empty($q['category'])): ?>
                                        <span class="px-2 py-1 rounded-full text-xs bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                                            <?php echo htmlspecialchars($q['category']); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <p class="text-slate-900 dark:text-white leading-relaxed"><?php echo htmlspecialchars($q['question'] ?? ''); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="mt-6 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-xl p-4">
                <p class="text-sm text-blue-900 dark:text-blue-300">
                    <i class="fa-solid fa-info-circle"></i> <strong>Gợi ý:</strong> Sử dụng các câu hỏi này làm tài liệu tham khảo trong buổi phỏng vấn. Bạn có thể tùy chỉnh hoặc tạo lại bất cứ lúc nào.
                </p>
            </div>
        <?php endif; ?>
    </div>

    <script>
        async function generateInterviewQuestions(jobId) {
            if (!confirm('Tạo/cập nhật câu hỏi phỏng vấn AI cho công việc này?')) return;
            
            const btn = event.target;
            const originalHTML = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Đang tạo...';

            try {
                const response = await fetch('../../api.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'generate-interview-questions',
                        job_id: jobId,
                        csrf_token: '<?php echo $_SESSION['csrf_token'] ?? ''; ?>'
                    })
                });

                const data = await response.json();
                if (data.success) {
                    alert('✅ ' + data.message);
                    location.reload();
                } else {
                    alert('❌ Lỗi: ' + data.message);
                }
            } catch (error) {
                alert('❌ Lỗi kết nối: ' + error.message);
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalHTML;
            }
        }
    </script>
</body>
</html>
