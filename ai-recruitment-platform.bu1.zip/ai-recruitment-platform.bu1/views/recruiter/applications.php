<?php
// views/recruiter/applications.php

require_once '../../config/init.php';

// 1. Load Middleware
require_once '../../utils/middleware/Auth.php';

// 2. Load Models & Helpers
require_once '../../utils/models/Job.php';
require_once '../../utils/models/Application.php';
require_once '../../utils/models/User.php';
require_once '../../utils/Helpers.php'; 

requireRole('recruiter');
addSecurityHeaders();

// Lấy Job ID từ URL
$jobId = (int)($_GET['job_id'] ?? 0);

// Nếu không có ID, quay về dashboard (tránh lỗi)
if (!$jobId) {
    redirect('dashboard.php');
}

// 3. Khởi tạo đối tượng
$jobModel = new Job();
$applicationModel = new Application();

// Lấy thông tin Job
$job = $jobModel->getJobById($jobId);

// Kiểm tra quyền sở hữu
if (!$job || $job['recruiter_id'] != $_SESSION['user_id']) {
    redirect('dashboard.php');
}

// Lấy danh sách đơn ứng tuyển
$allApplications = $applicationModel->getApplicationsByJob($jobId);

// Lọc bỏ các đơn đã rút
$applications = array_filter($allApplications, function($app) {
    return $app['status'] !== 'withdrawn';
});

// Lọc theo trạng thái nếu có
$statusFilter = $_GET['status'] ?? 'all';
if ($statusFilter !== 'all') {
    $applications = array_filter($applications, function($app) use ($statusFilter) {
        return $app['status'] === $statusFilter;
    });
}

// Sắp xếp mặc định: độ phù hợp giảm dần
$sortType = $_GET['sort'] ?? 'match_desc';

// Sắp xếp danh sách dựa trên loại sắp xếp
usort($applications, function($a, $b) use ($sortType) {
    switch ($sortType) {
        case 'match_desc': // Độ phù hợp giảm dần (mặc định)
            $scoreA = $a['match_score'] ?? 0;
            $scoreB = $b['match_score'] ?? 0;
            return $scoreB <=> $scoreA;
        case 'newest': // Mới nhất
            return strtotime($b['applied_at']) <=> strtotime($a['applied_at']);
        case 'oldest': // Cũ nhất
            return strtotime($a['applied_at']) <=> strtotime($b['applied_at']);
        default:
            return 0;
    }
});
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đơn apply - <?php echo htmlspecialchars($job['title']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 min-h-screen text-slate-900 dark:text-white transition-colors duration-300">
    <nav class="bg-white/90 dark:bg-gray-900/80 backdrop-blur-md border-b border-slate-200 dark:border-gray-700 sticky top-0 z-50 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="dashboard.php" class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition">AI Recruitment</a>
            <div class="flex items-center gap-4">
                <div class="relative group">
                    <button class="flex items-center gap-2 text-slate-700 dark:text-slate-300 hover:text-blue-500">
                        ▼ <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Recruiter'); ?>
                    </button>
                    <div class="hidden group-hover:block absolute right-0 bg-white dark:bg-slate-800 shadow-lg rounded min-w-[150px] z-10">
                        <a href="dashboard.php" class="block px-4 py-2 hover:bg-white dark:bg-slate-800">📊 Trang cá nhân</a>
                        <a href="dashboard.php" class="block px-4 py-2 hover:bg-white dark:bg-slate-800">📋 Quản lý tin đăng</a>
                        <a href="../../logout.php" class="block px-4 py-2 hover:bg-red-100 text-red-400">🚪 Đăng xuất</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mb-6">
            <div class="flex justify-between items-center">
                <div>
                    <h1 class="text-2xl font-bold tracking-tight"><?php echo htmlspecialchars($job['title']); ?></h1>
                    <p class="text-slate-700 dark:text-slate-300 mt-2">Tổng: <strong><?php echo count($applications); ?></strong> đơn apply</p>
                </div>
                <a href="dashboard.php" class="text-blue-500 hover:underline">← Quay lại danh sách</a>
            </div>
        </div>

        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-4 mb-6">
            <div class="flex justify-between items-center gap-4">
                <div class="flex gap-4">
                    <button onclick="locTheoTrangThai('all')" class="px-4 py-2 rounded hover:bg-slate-50 dark:hover:bg-slate-700 transition <?php echo $statusFilter === 'all' ? 'bg-blue-600 text-white' : 'bg-white dark:bg-slate-800 border'; ?>">
                        Tất cả
                    </button>
                    <button onclick="locTheoTrangThai('pending')" class="px-4 py-2 rounded hover:bg-slate-50 dark:hover:bg-slate-700 transition <?php echo $statusFilter === 'pending' ? 'bg-yellow-600 text-white' : 'bg-white dark:bg-slate-800 border'; ?>">
                        Chờ xử lý
                    </button>
                    <button onclick="locTheoTrangThai('shortlisted')" class="px-4 py-2 rounded hover:bg-slate-50 dark:hover:bg-slate-700 transition <?php echo $statusFilter === 'shortlisted' ? 'bg-purple-600 text-white' : 'bg-white dark:bg-slate-800 border'; ?>">
                        Được rút ngắn
                    </button>
                    <button onclick="locTheoTrangThai('rejected')" class="px-4 py-2 rounded hover:bg-slate-50 dark:hover:bg-slate-700 transition <?php echo $statusFilter === 'rejected' ? 'bg-red-600 text-white' : 'bg-white dark:bg-slate-800 border'; ?>">
                        Bị từ chối
                    </button>
                </div>
                <div class="flex items-center gap-2">
                    <label for="sortDropdown" class="text-slate-700 dark:text-slate-300 font-medium">Sắp xếp theo:</label>
                    <select id="sortDropdown" onchange="xuLySapXep(this.value)" 
                            class="border rounded px-3 py-2 bg-white dark:bg-slate-800 dark:text-white cursor-pointer focus:outline-none focus:border-blue-500">
                        <option value="match_desc">Độ phù hợp giảm dần (Mặc định)</option>
                        <option value="newest">Mới nhất</option>
                        <option value="oldest">Cũ nhất</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl overflow-hidden">
            <table class="w-full">
                <thead class="bg-white dark:bg-slate-800">
                    <tr>
                        <th class="px-6 py-3 text-left">Ứng viên</th>
                        <th class="px-6 py-3 text-left">Email</th>
                        <th class="px-6 py-3 text-center">📄 CV</th>
                        <th class="px-6 py-3 text-center">🤖 Match Score</th>
                        <th class="px-6 py-3 text-left">Trạng thái</th>
                        <th class="px-6 py-3 text-left">Ngày apply</th>
                        <th class="px-6 py-3 text-center">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($applications)): ?>
                        <tr>
                            <td colspan="7" class="px-6 py-8 text-center text-slate-500 dark:text-slate-400">
                                Chưa có ứng viên nào ứng tuyển vị trí này.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($applications as $app): ?>
                            <tr class="border-b hover:bg-slate-50 dark:bg-slate-900">
                                <td class="px-6 py-4 font-semibold">
                                    <a href="candidate-profile.php?id=<?php echo $app['candidate_id']; ?>" class="text-blue-500 hover:text-blue-400">
                                        <?php echo htmlspecialchars($app['full_name']); ?>
                                    </a>
                                </td>
                                <td class="px-6 py-4">
                                    <a href="mailto:<?php echo htmlspecialchars($app['email']); ?>" class="text-blue-500 hover:underline">
                                        <?php echo htmlspecialchars($app['email']); ?>
                                    </a>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <?php 
                                    // Lấy CV từ candidate profile
                                    $candidateModel = new CandidateProfile();
                                    $candidateProfile = $candidateModel->getProfile($app['candidate_id']);
                                    $cvUrl = $candidateProfile['cv_file_url'] ?? null;
                                    
                                    if ($cvUrl && file_exists(__DIR__ . '/../../' . $cvUrl)): ?>
                                        <a href="<?php echo BASE_URL . $cvUrl; ?>" target="_blank" 
                                           class="inline-flex items-center gap-1 text-blue-500 hover:text-blue-700 font-medium">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
                                            </svg>
                                            Xem CV
                                        </a>
                                    <?php else: ?>
                                        <span class="text-slate-400 text-sm">Chưa có</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 text-center score-cell">
                                    <?php if ($app['matching_score'] ?? 0): ?>
                                        <?php 
                                            $analysisData = null;
                                            if (!empty($app['ai_analysis'])) {
                                                $analysisData = json_decode($app['ai_analysis'], true);
                                            }
                                        ?>
                                        <button onclick='hienThiPhanTichDiem(<?php echo json_encode($analysisData, JSON_HEX_APOS | JSON_HEX_QUOT); ?>, "<?php echo $app['matching_score']; ?>", "<?php echo addslashes($app['full_name'] ?? 'Ứng viên'); ?>")'
                                                class="font-semibold text-lg cursor-pointer hover:underline <?php 
                                                    $score = $app['matching_score'];
                                                    echo $score >= 80 ? 'text-green-500' : ($score >= 60 ? 'text-yellow-500' : 'text-red-500');
                                                ?>">
                                            <?php echo $app['matching_score']; ?>%
                                        </button>
                                    <?php else: ?>
                                        <button data-app-id="<?php echo $app['id']; ?>" data-job-id="<?php echo $jobId; ?>" data-candidate-name="<?php echo htmlspecialchars($app['full_name'] ?? 'Ứng viên'); ?>"
                                                onclick="tinhDiem(<?php echo $app['id']; ?>, <?php echo $jobId; ?>)" 
                                                class="text-xs bg-purple-600 hover:bg-purple-700 text-white px-2 py-1 rounded transition">
                                            ⚡ Phân tích
                                        </button>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4">
                                    <select onchange="capNhatTrangThaiUngTuyen(<?php echo $app['id']; ?>, this.value)" 
                                            class="border rounded px-3 py-1 bg-white dark:bg-slate-800 cursor-pointer focus:outline-none focus:border-blue-500">
                                        <option value="pending" <?php echo $app['status'] === 'pending' ? 'selected' : ''; ?>>Chờ xử lý</option>
                                        <option value="reviewing" <?php echo $app['status'] === 'reviewing' ? 'selected' : ''; ?>>Đang xem xét</option>
                                        <option value="shortlisted" <?php echo $app['status'] === 'shortlisted' ? 'selected' : ''; ?>>Rút ngắn</option>
                                        <option value="interviewed" <?php echo $app['status'] === 'interviewed' ? 'selected' : ''; ?>>Phỏng vấn</option>
                                        <option value="offered" <?php echo $app['status'] === 'offered' ? 'selected' : ''; ?>>Đề nghị</option>
                                        <option value="rejected" <?php echo $app['status'] === 'rejected' ? 'selected' : ''; ?>>Từ chối</option>
                                    </select>
                                </td>
                                <td class="px-6 py-4">
                                    <?php 
                                    if (class_exists('DateHelper')) {
                                        echo DateHelper::formatDate($app['applied_at']);
                                    } else {
                                        echo date('d/m/Y', strtotime($app['applied_at']));
                                    }
                                    ?>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <button onclick="xemChiTietUngVien(<?php echo $app['id']; ?>)" 
                                            class="text-blue-500 hover:underline font-medium mr-3" title="Xem chi tiết">👁️</button>
                                    
                                    <!-- Chat Button -->
                                    <button onclick="startChat(<?php echo $app['id']; ?>)" 
                                            class="text-purple-500 hover:underline font-medium" title="Nhắn tin">💬</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Tự động tính điểm khi trang tải
        window.addEventListener('DOMContentLoaded', function() {
            tinhDiemTuDong();
            // Đặt giá trị sắp xếp hiện tại
            const loaiSapXep = new URLSearchParams(window.location.search).get('sort') || 'match_desc';
            document.getElementById('sortDropdown').value = loaiSapXep;
        });

        // Tự động tính toán tất cả các điểm còn thiếu
        async function tinhDiemTuDong() {
            const buttons = document.querySelectorAll('button[data-app-id]');
            if (buttons.length === 0) return;

            console.log('🔄 Bắt đầu tính toán điểm phù hợp...');
            
            for (let btn of buttons) {
                await tinhDiemTuDongMotUngVien(btn);
                // Chờ giữa các yêu cầu để tránh quá tải server
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
            console.log('✅ Hoàn tất tính toán tất cả điểm phù hợp');
        }

        // Tính điểm phù hợp cho một đơn ứng tuyển
        window.tinhDiemTuDongMotUngVien = async function(btn) {
            const applicationId = btn.getAttribute('data-app-id');
            const jobId = btn.getAttribute('data-job-id');
            
            try {
                const response = await fetch('../../api.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        action: 'match-job',
                        job_id: jobId,
                        application_id: applicationId,
                        csrf_token: '<?php echo $_SESSION['csrf_token'] ?? ''; ?>'
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    const score = data.data.score;
                    const analysis = data.data.analysis || null;
                    console.log('✅ Điểm tính được: ' + score + '% (ID ứng viên: ' + applicationId + ')');
                    console.log('📊 Analysis data:', analysis);
                    
                    // Cập nhật giao diện mà không tải lại trang
                    const scoreCell = btn.closest('tr').querySelector('.score-cell');
                    if (scoreCell) {
                        const candidateName = btn.getAttribute('data-candidate-name') || 'Ứng viên';
                        const scoreColor = score >= 80 ? 'text-green-500' : (score >= 60 ? 'text-yellow-500' : 'text-red-500');
                        
                        // Escape quotes in candidateName
                        const escapedName = candidateName.replace(/"/g, '\\"').replace(/'/g, "\\'");
                        
                        scoreCell.innerHTML = `<button onclick='hienThiPhanTichDiem(${JSON.stringify(analysis)}, "${score}", "${escapedName}")'
                                                class="font-semibold text-lg cursor-pointer hover:underline ${scoreColor}">
                                                ${score}%
                                            </button>`;
                    }
                } else {
                    console.error('❌ Lỗi: ' + (data.message || 'Không thể tính điểm phù hợp'));
                }
            } catch (error) {
                console.error('❌ Lỗi: ' + error.message);
            }
        };

        // Tính điểm phù hợp (bấm nút thủ công)
        window.tinhDiem = async function(applicationId, jobId) {
            const btn = event.target;
            const textGoc = btn.innerHTML;
            
            try {
                btn.disabled = true;
                btn.innerHTML = '⏳ Đang tính...';
                
                const response = await fetch('../../api.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        action: 'match-job',
                        job_id: jobId,
                        application_id: applicationId,
                        csrf_token: '<?php echo $_SESSION['csrf_token'] ?? ''; ?>'
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('✅ Tính điểm phù hợp thành công!\nĐiểm: ' + data.data.score + '%');
                    location.reload();
                } else {
                    alert('❌ Lỗi: ' + (data.message || 'Không thể tính điểm phù hợp'));
                }
            } catch (error) {
                alert('❌ Lỗi: ' + error.message);
            } finally {
                btn.disabled = false;
                btn.innerHTML = textGoc;
            }
        }

        // Xử lý thay đổi dropdown sắp xếp
        function xuLySapXep(loaiSapXep) {
            const url = new URL(window.location);
            url.searchParams.set('sort', loaiSapXep);
            window.location.href = url.toString();
        }

        // Xử lý lọc theo trạng thái
        function locTheoTrangThai(trangThai) {
            const url = new URL(window.location);
            url.searchParams.set('status', trangThai);
            url.searchParams.set('sort', '<?php echo $sortType; ?>'); // Giữ lại sort type hiện tại
            window.location.href = url.toString();
        }

        function capNhatTrangThaiUngTuyen(applicationId, trangThai) {
            if(!confirm('Bạn có chắc muốn đổi trạng thái thành ' + trangThai + '?')) return;

            // Lấy CSRF token từ meta tag hoặc session
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '<?php echo $_SESSION['csrf_token'] ?? ''; ?>';

            fetch('../../api.php?action=update-application', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'application_id=' + applicationId + '&status=' + trangThai + '&csrf_token=' + encodeURIComponent(csrfToken)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('✅ Cập nhật trạng thái thành công');
                    location.reload();
                } else {
                    alert('❌ Lỗi: ' + (data.message || 'Không thể cập nhật trạng thái'));
                }
            })
            .catch(err => {
                console.error(err);
                alert('❌ Lỗi kết nối server');
            });
        }

        function xemChiTietUngVien(applicationId) {
            alert('Xem chi tiết CV của ứng viên ID: ' + applicationId);
        }

        window.hienThiPhanTichDiem = function(data, diem, candidateName = 'Ứng viên') {
            console.log('🔍 hienThiPhanTichDiem called with:', { data, diem, candidateName });
            
            // Kiểm tra nếu data không hợp lệ
            if (!data || typeof data !== 'object') {
                console.warn('⚠️ Invalid data:', data);
                alert('Không có dữ liệu phân tích. Vui lòng tính điểm lại.');
                return;
            }
            
            // Xác định màu sắc dựa trên điểm số
            const getScoreColor = (score) => {
                if (score >= 80) return { bg: 'bg-green-50', text: 'text-green-600', border: 'border-green-500', dark: 'dark:bg-green-900/20' };
                if (score >= 60) return { bg: 'bg-amber-50', text: 'text-amber-600', border: 'border-amber-500', dark: 'dark:bg-amber-900/20' };
                return { bg: 'bg-red-50', text: 'text-red-600', border: 'border-red-500', dark: 'dark:bg-red-900/20' };
            };
            
            const colors = getScoreColor(diem);
            
            // Tách dữ liệu
            const pros = data?.pros || [];
            const cons = data?.cons || [];
            const missingSkills = data?.missing_skills || [];
            const recommendation = data?.recommendation || 'CHƯA CÓ ĐÁNH GIÁ';
            const reason = data?.reason || 'Không có lý do được cung cấp';
            
            console.log('📊 Parsed data:', { pros, cons, missingSkills, recommendation, reason });
            
            const modalHTML = `
                <div class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onclick="this.parentElement.removeChild(this)">
                    <div class="bg-white dark:bg-slate-800 rounded-xl max-w-3xl w-full max-h-[85vh] shadow-2xl border border-slate-200/50 dark:border-slate-700/50 flex flex-col overflow-hidden" onclick="event.stopPropagation()">
                        
                        <!-- HEADER -->
                        <div class="bg-gradient-to-r from-blue-600 to-blue-700 p-4 text-white flex-shrink-0">
                            <div class="flex justify-between items-center">
                                <div>
                                    <h2 class="text-lg font-bold">🏅 ${candidateName}</h2>
                                    <p class="text-blue-100 text-xs">Phân tích AI</p>
                                </div>
                                <button onclick="this.closest('.fixed').parentElement.removeChild(this.closest('.fixed'))" class="text-2xl hover:bg-white/20 w-8 h-8 rounded-full transition">×</button>
                            </div>
                        </div>
                        
                        <!-- BODY -->
                        <div class="overflow-y-auto flex-1 p-5 space-y-4">
                            
                            <!-- MATCHING SCORE -->
                            <div class="flex items-center justify-between p-3 rounded-lg ${colors.bg} border-l-4 ${colors.border}">
                                <div>
                                    <p class="text-xs text-slate-600">📊 Điểm Phù Hợp</p>
                                    <p class="text-2xl font-bold ${colors.text}">${diem}%</p>
                                </div>
                                <div class="text-4xl font-bold ${colors.text} opacity-20">${diem}%</div>
                            </div>
                            
                            <!-- Kỹ Năng Đạt -->
                            ${pros.length > 0 ? `
                            <div>
                                <p class="text-sm font-semibold text-emerald-600 mb-2">✓ Kỹ Năng Đạt</p>
                                <ul class="space-y-1 text-sm">
                                    ${pros.slice(0, 3).map(p => `<li class="flex gap-2"><span class="text-emerald-500">•</span><span>${p}</span></li>`).join('')}
                                </ul>
                            </div>
                            ` : ''}
                            
                            <!-- Kỹ Năng Thiếu -->
                            ${missingSkills.length > 0 ? `
                            <div>
                                <p class="text-sm font-semibold text-amber-600 mb-2">⚠ Kỹ Năng Thiếu</p>
                                <div class="flex flex-wrap gap-2">
                                    ${missingSkills.slice(0, 6).map(m => `<span class="text-xs bg-amber-100 text-amber-700 px-2 py-1 rounded">${m}</span>`).join('')}
                                </div>
                            </div>
                            ` : ''}
                            
                            <!-- Điểm Yếu -->
                            ${cons.length > 0 ? `
                            <div>
                                <p class="text-sm font-semibold text-red-600 mb-2">✗ Điểm Yếu</p>
                                <ul class="space-y-1 text-sm">
                                    ${cons.slice(0, 2).map(c => `<li class="flex gap-2"><span class="text-red-500">•</span><span>${c}</span></li>`).join('')}
                                </ul>
                            </div>
                            ` : ''}
                            
                            <!-- AI Đề Xuất -->
                            <div class="bg-slate-100 dark:bg-slate-700/50 p-3 rounded-lg border-l-4 ${colors.border}">
                                <p class="font-bold text-sm ${colors.text} mb-1">💡 AI ĐỀ XUẤT: ${recommendation}</p>
                                <p class="text-sm text-slate-600 dark:text-slate-300">${reason}</p>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            const temp = document.createElement('div');
            temp.innerHTML = modalHTML;
            document.body.appendChild(temp.firstElementChild);
        }
        
        // Start chat with candidate
        function startChat(applicationId) {
            console.log('startChat called with application_id:', applicationId);
            
            const url = '../../api.php?action=start-conversation';
            console.log('Fetching:', url);
            
            fetch(url, {
                method: 'POST',
                credentials: 'include', // ✅ Include cookies/session
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ application_id: applicationId })
            })
            .then(response => {
                console.log('Response status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('Response data:', data);
                if (data.success) {
                    if (typeof ChatWidget !== 'undefined') {
                        ChatWidget.open();
                        ChatWidget.openConversation(data.conversation.id);
                    } else {
                        alert('Chat widget chưa được tải. Vui lòng refresh trang.');
                    }
                } else {
                    alert('Lỗi: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Không thể khởi tạo cuộc trò chuyện: ' + error.message);
            });
        }
    </script>

    <!-- Include Chat Widget -->
    <?php include '../../components/lazy-load-widgets.php'; ?>
    
    <!-- Chat Widget (Real-time messaging with candidates) -->
    <?php include __DIR__ . '/../../components/chat-widget.php'; ?>
</body>
</html>