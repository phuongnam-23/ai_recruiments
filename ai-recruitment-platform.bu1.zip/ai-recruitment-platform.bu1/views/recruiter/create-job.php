<?php
require_once '../../config/init.php';

// 1. Load Middleware
require_once '../../utils/middleware/Auth.php';

// 2. Load Models & Controller
require_once '../../utils/models/Job.php';
require_once '../../utils/controllers/JobController.php';

requireRole('recruiter');
addSecurityHeaders();

$jobController = new JobController();
$error_message = ''; 
$validation_errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = $jobController->createJob();
    
    if (isset($result['success']) && $result['success']) {
        // Chuyển hướng chính xác để ngăn việc gửi lại form khi F5 (Post/Redirect/Get)
        redirect('views/recruiter/dashboard.php'); 
    } else {
        $error_message = $result['message'] ?? 'Có lỗi không xác định xảy ra';
        $validation_errors = $result['errors'] ?? [];
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tạo tin tuyển dụng</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900">
    <!-- Navigation -->
    <nav class="bg-white dark:bg-slate-800 shadow">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="dashboard.php" class="text-2xl font-bold tracking-tight text-blue-500 hover:text-blue-700">AI Recruitment</a>
            <div class="flex items-center gap-4">
                <div class="relative group">
                    <button class="flex items-center gap-2 text-slate-700 dark:text-slate-300 hover:text-blue-500">
                        ▼ <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Recruiter'); ?>
                    </button>
                    <!-- Menu thả xuống -->
                    <div class="hidden group-hover:block absolute right-0 bg-white dark:bg-slate-800 shadow-lg rounded min-w-[150px] z-10">
                        <a href="dashboard.php" class="block px-4 py-2 hover:bg-white dark:bg-slate-800">📊 Trang cá nhân</a>
                        <a href="dashboard.php" class="block px-4 py-2 hover:bg-white dark:bg-slate-800">📋 Quản lý tin đăng</a>
                        <a href="../../logout.php" class="block px-4 py-2 hover:bg-red-100 text-red-400">🚪 Đăng xuất</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-4 py-8">
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-8">
            <h1 class="text-3xl font-bold tracking-tight tracking-tight mb-6">Tạo tin tuyển dụng</h1>

            <!-- KHU VỰC HIỂN THỊ LỖI -->
            <?php if (!empty($error_message)): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p class="font-bold">⚠️ Lỗi:</p>
                    <p><?php echo htmlspecialchars($error_message); ?></p>
                </div>
            <?php endif; ?>

            <!-- HIỂN THỊ CHI TIẾT LỖI VALIDATION -->
            <?php if (!empty($validation_errors)): ?>
                <div class="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-6">
                    <p class="font-bold">Vui lòng kiểm tra lại các mục sau:</p>
                    <ul class="list-disc list-inside mt-2">
                        <?php foreach ($validation_errors as $field => $error): ?>
                            <li>
                                <strong><?php echo ucfirst($field); ?>:</strong> 
                                <?php echo htmlspecialchars($error); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- THÊM ONSUBMIT ĐỂ CHẶN GỬI NHIỀU LẦN -->
            <form method="POST" class="space-y-6" onsubmit="disableSubmitButton()">
                <!-- Basic Info -->
                <div>
                    <h2 class="text-xl font-bold tracking-tight mb-4">Thông tin cơ bản</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <div class="col-span-2">
                            <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Tiêu đề vị trí *</label>
                            <input type="text" name="title" required value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>" class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Ngành *</label>
                            <input type="text" name="category" required value="<?php echo htmlspecialchars($_POST['category'] ?? ''); ?>" placeholder="VD: IT, Marketing..." class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Thành phố *</label>
                            <input type="text" name="city" required value="<?php echo htmlspecialchars($_POST['city'] ?? ''); ?>" placeholder="VD: Hà Nội" class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                        </div>
                        <!-- Thêm input Location -->
                        <div>
                            <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Địa điểm cụ thể</label>
                            <input type="text" name="location" value="<?php echo htmlspecialchars($_POST['location'] ?? ''); ?>" placeholder="VD: Tòa nhà A, Quận 1..." class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                        </div>
                    </div>
                </div>

                <!-- Job Details -->
                <div>
                    <h2 class="text-xl font-bold tracking-tight mb-4">Chi tiết công việc</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Loại công việc *</label>
                            <select name="job_type" required class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                                <option value="full_time" <?php echo (isset($_POST['job_type']) && $_POST['job_type'] === 'full_time') ? 'selected' : ''; ?>>Toàn thời gian</option>
                                <option value="part_time" <?php echo (isset($_POST['job_type']) && $_POST['job_type'] === 'part_time') ? 'selected' : ''; ?>>Bán thời gian</option>
                                <option value="contract" <?php echo (isset($_POST['job_type']) && $_POST['job_type'] === 'contract') ? 'selected' : ''; ?>>Theo hợp đồng</option>
                                <option value="internship" <?php echo (isset($_POST['job_type']) && $_POST['job_type'] === 'internship') ? 'selected' : ''; ?>>Thực tập sinh</option>
                                <option value="remote" <?php echo (isset($_POST['job_type']) && $_POST['job_type'] === 'remote') ? 'selected' : ''; ?>>Remote</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Cấp độ *</label>
                            <select name="job_level" required class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                                <option value="intern" <?php echo (isset($_POST['job_level']) && $_POST['job_level'] === 'intern') ? 'selected' : ''; ?>>Thực tập sinh</option>
                                <option value="junior" <?php echo (isset($_POST['job_level']) && $_POST['job_level'] === 'junior') ? 'selected' : ''; ?>>Junior</option>
                                <option value="middle" <?php echo (isset($_POST['job_level']) && $_POST['job_level'] === 'middle') ? 'selected' : ''; ?>>Middle</option>
                                <option value="senior" <?php echo (isset($_POST['job_level']) && $_POST['job_level'] === 'senior') ? 'selected' : ''; ?>>Senior</option>
                                <option value="lead" <?php echo (isset($_POST['job_level']) && $_POST['job_level'] === 'lead') ? 'selected' : ''; ?>>Lead</option>
                                <option value="manager" <?php echo (isset($_POST['job_level']) && $_POST['job_level'] === 'manager') ? 'selected' : ''; ?>>Quản lý</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Số vị trí *</label>
                            <input type="number" name="num_positions" value="<?php echo htmlspecialchars($_POST['num_positions'] ?? '1'); ?>" min="1" required class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Kinh nghiệm yêu cầu (năm)</label>
                            <input type="number" name="experience_required" value="<?php echo htmlspecialchars($_POST['experience_required'] ?? '0'); ?>" min="0" class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                        </div>
                    </div>
                </div>

                <!-- Salary -->
                <div>
                    <h2 class="text-xl font-bold tracking-tight mb-4">Lương và phúc lợi</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Lương tối thiểu (VND)</label>
                            <input type="number" name="salary_min" value="<?php echo htmlspecialchars($_POST['salary_min'] ?? ''); ?>" class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Lương tối đa (VND)</label>
                            <input type="number" name="salary_max" value="<?php echo htmlspecialchars($_POST['salary_max'] ?? ''); ?>" class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                        </div>
                    </div>
                    <div class="mt-4">
                        <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Phúc lợi</label>
                        <textarea name="benefits" rows="3" placeholder="VD: Bảo hiểm, Du lịch, Học tập..." class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500"><?php echo htmlspecialchars($_POST['benefits'] ?? ''); ?></textarea>
                    </div>
                </div>

                <!-- Description -->
                <div>
                    <h2 class="text-xl font-bold tracking-tight mb-4">Mô tả công việc</h2>
                    <div>
                        <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Mô tả *</label>
                        <textarea name="description" rows="5" required placeholder="Mô tả chi tiết về công việc..." class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                    </div>
                    <div class="mt-4">
                        <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Yêu cầu *</label>
                        <textarea name="requirements" rows="5" required placeholder="Yêu cầu của vị trí..." class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500"><?php echo htmlspecialchars($_POST['requirements'] ?? ''); ?></textarea>
                    </div>
                </div>

                <!-- Skills -->
                <div>
                    <h2 class="text-xl font-bold tracking-tight mb-4">Kỹ năng yêu cầu</h2>
                    <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Kỹ năng (cách nhau bằng dấu phẩy)</label>
                    <input type="text" name="required_skills" value="<?php echo htmlspecialchars($_POST['required_skills'] ?? ''); ?>" placeholder="JavaScript, React, Node.js..." class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                </div>

                <!-- Deadline -->
                <div>
                    <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Hạn chót nhận hồ sơ</label>
                    <input type="date" name="application_deadline" value="<?php echo htmlspecialchars($_POST['application_deadline'] ?? ''); ?>" class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                </div>

                <!-- Status -->
                <div>
                    <label class="block text-slate-700 dark:text-slate-300 font-semibold mb-2">Trạng thái *</label>
                    <select name="status" required class="w-full border rounded px-4 py-2 focus:outline-none focus:border-blue-500">
                        <option value="draft" <?php echo (isset($_POST['status']) && $_POST['status'] === 'draft') ? 'selected' : ''; ?>>Nháp</option>
                        <option value="pending" <?php echo (isset($_POST['status']) && $_POST['status'] === 'pending') ? 'selected' : ''; ?>>Chờ duyệt</option>
                        <option value="active" <?php echo (isset($_POST['status']) && $_POST['status'] === 'active') ? 'selected' : ''; ?>>Kích hoạt</option>
                    </select>
                </div>

                <!-- Buttons -->
                <div class="flex gap-4">
                    <button id="submitBtn" type="submit" class="flex-1 bg-blue-600 text-slate-900 dark:text-white font-semibold py-2 rounded hover:bg-blue-500 transition duration-200">
                        💾 Tạo tin tuyển dụng
                    </button>
                    <a href="dashboard.php" class="flex-1 bg-gray-300 text-slate-900 dark:text-white font-semibold py-2 rounded hover:bg-gray-400 text-center transition duration-200">
                        ❌ Hủy
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Script chặn gửi 2 lần -->
    <script>
        function disableSubmitButton() {
            const btn = document.getElementById('submitBtn');
            btn.disabled = true;
            btn.innerHTML = '⏳ Đang xử lý...';
            btn.classList.add('opacity-50', 'cursor-not-allowed');
        }
    </script>
</body>
</html>