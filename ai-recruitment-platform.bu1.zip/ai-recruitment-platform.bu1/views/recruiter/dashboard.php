<?php
// views/recruiter/dashboard.php

require_once __DIR__ . '/../../config/init.php';
require_once __DIR__ . '/../../utils/middleware/Auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'recruiter') {
    header('Location: ' . BASE_URL . 'login.php');
    exit;
}

addSecurityHeaders();

$jobController = new JobController();
$jobs = $jobController->getMyJobs();

$recruiterModel = new RecruiterProfile();
$profile = $recruiterModel->getProfile($_SESSION['user_id']);

$userModel = new User();
$user = $userModel->getUserById($_SESSION['user_id']);

// Helper để lấy avatar/logo hoặc ảnh mặc định
function getAvatarUrl($url, $name = 'Recruiter') {
    if (empty($url)) {
        return 'https://ui-avatars.com/api/?name=' . urlencode($name) . '&background=random';
    }
    // Nếu đã có http hoặc ui-avatars, dùng luôn
    if (strpos($url, 'http') === 0 || strpos($url, 'ui-avatars') === 0) {
        return $url;
    }
    // Nếu là path tương đối, thêm BASE_URL và loại bỏ slash đầu nếu có
    return BASE_URL . ltrim($url, '/');
}
function getCompanyLogoUrl($url) {
    return !empty($url) ? $url : 'https://ui-avatars.com/api/?name=Company&background=0D8ABC&color=fff&size=128';
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Nhà Tuyển Dụng</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 font-sans text-slate-900 dark:text-white transition-colors duration-300">
    <!-- Navigation -->
    <nav class="bg-white/90 dark:bg-gray-900/80 backdrop-blur-md border-b border-slate-200 dark:border-gray-700 sticky top-0 z-50 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="<?php echo BASE_URL; ?>" class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition flex items-center gap-2">
                <i class="fa-solid fa-briefcase bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"></i> AI Recruitment
            </a>
            <div class="flex items-center gap-4">
                <div class="relative group dropdown-group" style="padding-bottom: 8px;">
                    <button class="flex items-center gap-2 text-slate-700 dark:text-slate-300 hover:text-blue-500 font-medium transition dropdown-btn">
                        <img src="<?php echo getAvatarUrl($user['avatar_url'] ?? '', $user['full_name'] ?? 'User'); ?>" class="w-8 h-8 rounded-full border object-cover" id="nav-avatar">
                        <?php echo htmlspecialchars($_SESSION['full_name']); ?> ▼
                    </button>
                    <div class="hidden group-hover:block absolute right-0 mt-0 bg-white dark:bg-slate-800 shadow-xl rounded-xl min-w-[200px] z-10 border overflow-hidden dropdown-menu">
                        <a href="../../logout.php" class="block px-4 py-3 hover:bg-red-900/20 text-red-400 transition"><i class="fa-solid fa-right-from-bracket w-6"></i> Đăng xuất</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Notifications -->
    <?php if (!empty($_SESSION['success_message'])): ?>
        <div class="bg-green-100 border-t-4 border-green-500 text-green-700 px-4 py-3 sticky top-16 z-40">
            <div class="max-w-7xl mx-auto flex justify-between items-center">
                <span><i class="fa-solid fa-check-circle mr-2"></i><?php echo htmlspecialchars($_SESSION['success_message']); ?></span>
                <button onclick="this.parentElement.parentElement.style.display='none'" class="text-green-700 hover:text-green-900">&times;</button>
            </div>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <?php if (!empty($_SESSION['error_message'])): ?>
        <div class="bg-red-100 border-t-4 border-red-500 text-red-700 px-4 py-3 sticky top-16 z-40">
            <div class="max-w-7xl mx-auto flex justify-between items-center">
                <span><i class="fa-solid fa-exclamation-circle mr-2"></i><?php echo htmlspecialchars($_SESSION['error_message']); ?></span>
                <button onclick="this.parentElement.parentElement.style.display='none'" class="text-red-700 hover:text-red-900">&times;</button>
            </div>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <!-- Stats Section -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 shadow-sm p-6 border-l-4 border-blue-500 hover:shadow-lg hover:shadow-blue-500/10 transition">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-slate-500 dark:text-slate-400 text-sm font-medium uppercase">Tổng tin đăng</p>
                        <h3 class="text-3xl font-bold tracking-tight tracking-tight text-slate-900 dark:text-white mt-2"><?php echo count($jobs); ?></h3>
                    </div>
                    <div class="p-3 bg-blue-900/20 rounded-full text-blue-500">
                        <i class="fa-solid fa-newspaper text-xl"></i>
                    </div>
                </div>
            </div>
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 shadow-sm p-6 border-l-4 border-green-500 hover:shadow-lg hover:shadow-blue-500/10 transition">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-slate-500 dark:text-slate-400 text-sm font-medium uppercase">Đang hoạt động</p>
                        <h3 class="text-3xl font-bold tracking-tight tracking-tight text-slate-900 dark:text-white mt-2">
                            <?php echo count(array_filter($jobs, fn($j) => $j['status'] === 'active')); ?>
                        </h3>
                    </div>
                    <div class="p-3 bg-green-900/20 rounded-full text-green-400">
                        <i class="fa-solid fa-check-circle text-xl"></i>
                    </div>
                </div>
            </div>
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 shadow-sm p-6 border-l-4 border-purple-500 hover:shadow-lg hover:shadow-blue-500/10 transition">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-slate-500 dark:text-slate-400 text-sm font-medium uppercase">Lượt xem</p>
                        <h3 class="text-3xl font-bold tracking-tight tracking-tight text-slate-900 dark:text-white mt-2">
                            <?php echo number_format(array_sum(array_column($jobs, 'views_count'))); ?>
                        </h3>
                    </div>
                    <div class="p-3 bg-purple-50 rounded-full text-purple-600">
                        <i class="fa-solid fa-eye text-xl"></i>
                    </div>
                </div>
            </div>
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 shadow-sm p-6 border-l-4 border-orange-500 hover:shadow-lg hover:shadow-blue-500/10 transition">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-slate-500 dark:text-slate-400 text-sm font-medium uppercase">Lượt ứng tuyển</p>
                        <h3 class="text-3xl font-bold tracking-tight tracking-tight text-slate-900 dark:text-white mt-2">
                            <?php echo number_format(array_sum(array_column($jobs, 'applications_count'))); ?>
                        </h3>
                    </div>
                    <div class="p-3 bg-orange-50 rounded-full text-orange-600">
                        <i class="fa-solid fa-users text-xl"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Left Column: Profile Card -->
            <div class="lg:col-span-1">
                <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 shadow-sm overflow-hidden sticky top-24">
                    <!-- Tabs -->
                    <div class="flex border-b">
                        <button class="flex-1 py-4 text-center font-semibold border-b-2 border-blue-600 text-blue-500 bg-blue-900/20/50" id="tab-view">
                            <i class="fa-solid fa-id-card mr-2"></i> Hồ sơ
                        </button>
                        <button class="flex-1 py-4 text-center font-semibold border-b-2 border-transparent text-slate-500 dark:text-slate-400 hover:text-blue-500 hover:bg-slate-50 dark:bg-slate-900" id="tab-edit">
                            <i class="fa-solid fa-pen-to-square mr-2"></i> Cập nhật
                        </button>
                    </div>

                    <!-- VIEW MODE -->
                    <div id="content-view" class="p-6">
                        <!-- Avatar Section -->
                        <div class="mb-6 text-center pb-6 border-b border-slate-200 dark:border-slate-700">
                            <h3 class="text-sm font-bold text-slate-900 dark:text-white mb-4 uppercase tracking-wider">Ảnh đại diện</h3>
                            <div class="flex justify-center">
                                <?php include __DIR__ . '/../../components/avatar-upload.php'; ?>
                            </div>
                        </div>

                        <!-- Personal Info -->
                        <div class="text-center mb-4 pb-4 border-b border-slate-200 dark:border-slate-700">
                            <h2 class="text-lg font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($user['full_name']); ?></h2>
                            <p class="text-blue-500 text-xs font-semibold uppercase tracking-wide mt-1">Nhà Tuyển Dụng</p>
                        </div>

                        <div class="space-y-3 text-sm mb-5 pb-5 border-b border-slate-200 dark:border-slate-700">
                            <div class="flex items-start gap-3">
                                <i class="fa-solid fa-envelope text-blue-500 w-5 mt-0.5 flex-shrink-0"></i>
                                <div>
                                    <p class="text-slate-500 dark:text-slate-400 text-xs mb-1">Email</p>
                                    <span class="text-slate-700 dark:text-slate-300 break-all"><?php echo htmlspecialchars($user['email']); ?></span>
                                </div>
                            </div>
                            <?php if (!empty($user['phone'])): ?>
                            <div class="flex items-start gap-3">
                                <i class="fa-solid fa-phone text-green-500 w-5 mt-0.5 flex-shrink-0"></i>
                                <div>
                                    <p class="text-slate-500 dark:text-slate-400 text-xs mb-1">Số điện thoại</p>
                                    <span class="text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($user['phone']); ?></span>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="flex items-start gap-3">
                                <i class="fa-solid fa-calendar-days text-slate-500 w-5 mt-0.5 flex-shrink-0"></i>
                                <div>
                                    <p class="text-slate-500 dark:text-slate-400 text-xs mb-1">Ngày tham gia</p>
                                    <span class="text-slate-700 dark:text-slate-300"><?php echo date('d/m/Y', strtotime($user['created_at'] ?? 'now')); ?></span>
                                </div>
                            </div>
                        </div>

                        <!-- Company Info -->
                        <div>
                            <!-- Company Header -->
                            <div class="flex items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-200 dark:border-slate-700">
                                <h3 class="font-bold text-slate-900 dark:text-white uppercase text-sm tracking-wider">Thông Tin Công Ty</h3>
                                <?php 
                                $status = $profile['verification_status'] ?? 'pending';
                                $statusClass = $status === 'verified' ? 'bg-green-100 text-green-700' : ($status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700');
                                $statusIcon = $status === 'verified' ? 'fa-check-circle' : ($status === 'rejected' ? 'fa-xmark-circle' : 'fa-clock');
                                $statusText = $status === 'verified' ? 'Đã xác thực' : ($status === 'rejected' ? 'Bị từ chối' : 'Chờ xác thực');
                                ?>
                                <span class="px-2 py-1 rounded text-xs font-semibold <?php echo $statusClass; ?>" title="<?php echo $statusText; ?>">
                                    <i class="fa-solid <?php echo $statusIcon; ?> mr-1"></i><?php echo $statusText; ?>
                                </span>
                            </div>

                            <!-- Company Name & Website -->
                            <div class="flex items-start gap-4 mb-4 pb-4 border-b border-slate-200 dark:border-slate-700">
                                <img src="<?php echo getAvatarUrl($user['avatar_url'] ?? '', $user['full_name'] ?? 'User'); ?>" class="w-16 h-16 rounded-full border-4 border-blue-100 dark:border-blue-900 object-cover flex-shrink-0">
                                <div class="flex-1 min-w-0">
                                    <h4 class="font-bold text-slate-900 dark:text-white text-sm mb-1">
                                        <?php echo htmlspecialchars($profile['company_name'] ?? 'Chưa cập nhật'); ?>
                                    </h4>
                                    <?php if (!empty($profile['company_website'])): ?>
                                        <a href="<?php echo htmlspecialchars($profile['company_website']); ?>" target="_blank" class="text-blue-500 text-xs hover:underline truncate block mb-2">
                                            <i class="fa-solid fa-link"></i> <?php echo parse_url($profile['company_website'], PHP_URL_HOST); ?>
                                        </a>
                                    <?php endif; ?>
                                    <span class="inline-block bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">
                                        <i class="fa-solid fa-users mr-1"></i><?php echo htmlspecialchars($profile['company_size'] ?? '--'); ?>
                                    </span>
                                </div>
                            </div>

                            <!-- Company Details -->
                            <div class="space-y-3 text-sm">
                                <?php if (!empty($profile['industry'])): ?>
                                <div class="flex items-start gap-2">
                                    <i class="fa-solid fa-industry text-purple-500 w-4 mt-0.5 flex-shrink-0"></i>
                                    <div>
                                        <p class="text-slate-500 dark:text-slate-400 text-xs">Lĩnh vực</p>
                                        <p class="text-slate-900 dark:text-white font-medium"><?php echo htmlspecialchars($profile['industry']); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($profile['company_city'])): ?>
                                <div class="flex items-start gap-2">
                                    <i class="fa-solid fa-location-dot text-red-500 w-4 mt-0.5 flex-shrink-0"></i>
                                    <div>
                                        <p class="text-slate-500 dark:text-slate-400 text-xs">Thành phố</p>
                                        <p class="text-slate-900 dark:text-white font-medium"><?php echo htmlspecialchars($profile['company_city']); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($profile['company_address'])): ?>
                                <div class="flex items-start gap-2">
                                    <i class="fa-solid fa-map-pin text-orange-500 w-4 mt-0.5 flex-shrink-0"></i>
                                    <div>
                                        <p class="text-slate-500 dark:text-slate-400 text-xs">Địa chỉ</p>
                                        <p class="text-slate-900 dark:text-white text-sm"><?php echo htmlspecialchars($profile['company_address']); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($profile['tax_code'])): ?>
                                <div class="flex items-start gap-2">
                                    <i class="fa-solid fa-file-invoice text-cyan-500 w-4 mt-0.5 flex-shrink-0"></i>
                                    <div>
                                        <p class="text-slate-500 dark:text-slate-400 text-xs">Mã số thuế</p>
                                        <p class="text-slate-900 dark:text-white font-mono text-sm"><?php echo htmlspecialchars($profile['tax_code']); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($profile['company_description'])): ?>
                                <div class="flex items-start gap-2 mt-3 pt-3 border-t">
                                    <i class="fa-solid fa-info-circle text-slate-500 dark:text-slate-400 w-4 mt-0.5 flex-shrink-0"></i>
                                    <div>
                                        <p class="text-slate-500 dark:text-slate-400 text-xs">Giới thiệu</p>
                                        <p class="text-slate-700 dark:text-slate-300 text-sm italic"><?php echo htmlspecialchars(substr($profile['company_description'], 0, 200)); ?><?php echo strlen($profile['company_description']) > 200 ? '...' : ''; ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- EDIT MODE - Include full edit profile section -->
                    <?php include __DIR__ . '/edit-profile-section.php'; ?>
                </div>
            </div>

            <!-- Right Column: Jobs List -->
            <div class="lg:col-span-2">
                <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 shadow-sm p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-xl font-bold tracking-tight text-slate-900 dark:text-white"><i class="fa-solid fa-list-ul mr-2 text-blue-500"></i> Tin tuyển dụng của tôi</h2>
                        <a href="create-job.php" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded-xl hover:bg-blue-500 transition font-medium shadow-lg text-sm">
                            <i class="fa-solid fa-plus mr-1"></i> Tạo tin mới
                        </a>
                    </div>

                    <?php if (empty($jobs)): ?>
                        <div class="text-center py-16 bg-slate-50 dark:bg-slate-900 rounded-xl border border-dashed border-slate-200/50 dark:border-slate-700/50">
                            <i class="fa-solid fa-clipboard-list text-4xl text-slate-700 dark:text-slate-300 mb-3"></i>
                            <p class="text-slate-500 dark:text-slate-400 mb-4">Bạn chưa tạo tin tuyển dụng nào</p>
                            <a href="create-job.php" class="text-blue-500 hover:underline font-medium">Tạo tin tuyển dụng đầu tiên →</a>
                        </div>
                    <?php else: ?>
                        <div class="overflow-x-auto">
                            <table class="w-full text-sm">
                                <thead class="bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 uppercase text-xs">
                                    <tr>
                                        <th class="px-4 py-3 text-left rounded-tl-lg">Tên vị trí</th>
                                        <th class="px-4 py-3 text-left">Trạng thái</th>
                                        <th class="px-4 py-3 text-center">Views</th>
                                        <th class="px-4 py-3 text-center">Đơn apply</th>
                                        <th class="px-4 py-3 text-center rounded-tr-lg">Hành động</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100">
                                    <?php foreach ($jobs as $job): ?>
                                        <tr class="hover:bg-blue-900/20/50 transition duration-150">
                                            <td class="px-4 py-4 font-medium">
                                                <a href="../../views/public/job-detail.php?id=<?php echo $job['id']; ?>" class="text-slate-900 dark:text-white hover:text-blue-500 hover:underline">
                                                    <?php echo htmlspecialchars($job['title']); ?>
                                                </a>
                                                <div class="text-xs text-slate-500 dark:text-slate-400 mt-1">
                                                    <i class="fa-regular fa-clock mr-1"></i> <?php echo date('d/m/Y', strtotime($job['created_at'])); ?>
                                                </div>
                                            </td>
                                            <td class="px-4 py-4">
                                                <?php 
                                                $statusColors = [
                                                    'active' => 'bg-green-100 text-green-700',
                                                    'pending' => 'bg-yellow-100 text-yellow-700',
                                                    'closed' => 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300',
                                                    'draft' => 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400'
                                                ];
                                                $statusLabels = [
                                                    'active' => 'Đang tuyển',
                                                    'pending' => 'Chờ duyệt',
                                                    'closed' => 'Đã đóng',
                                                    'draft' => 'Nháp'
                                                ];
                                                $s = $job['status'];
                                                ?>
                                                <span class="px-2 py-1 rounded-full text-xs font-semibold <?php echo $statusColors[$s] ?? 'bg-white dark:bg-slate-800'; ?>">
                                                    <?php echo $statusLabels[$s] ?? ucfirst($s); ?>
                                                </span>
                                            </td>
                                            <td class="px-4 py-4 text-center font-semibold text-slate-700 dark:text-slate-300">
                                                <?php echo number_format($job['views_count']); ?>
                                            </td>
                                            <td class="px-4 py-4 text-center">
                                                <a href="applications.php?job_id=<?php echo $job['id']; ?>" class="inline-flex items-center justify-center px-3 py-1 bg-blue-900/20 text-blue-500 rounded-full text-xs font-bold hover:bg-blue-100 transition">
                                                    <?php echo $job['applications_count']; ?>
                                                </a>
                                            </td>
                                            <td class="px-4 py-4 text-center">
                                                <div class="flex items-center justify-center gap-2">
                                                    <a href="edit-job.php?id=<?php echo $job['id']; ?>" class="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-900/20 text-blue-500 rounded-xl hover:bg-blue-100 transition text-xs font-semibold" title="Chỉnh sửa">
                                                        <i class="fa-solid fa-pen text-sm"></i> Sửa
                                                    </a>
                                                    <a href="job-interview-questions.php?id=<?php echo $job['id']; ?>" class="inline-flex items-center gap-1 px-3 py-1.5 bg-purple-900/20 text-purple-500 rounded-xl hover:bg-purple-100 transition text-xs font-semibold" title="Câu hỏi phỏng vấn AI">
                                                        <i class="fa-solid fa-clipboard-question text-sm"></i> Câu hỏi AI
                                                    </a>
                                                    <a href="delete-job.php?id=<?php echo $job['id']; ?>" class="inline-flex items-center gap-1 px-3 py-1.5 bg-red-900/20 text-red-400 rounded-xl hover:bg-red-100 transition text-xs font-semibold" onclick="return confirm('Bạn chắc chắn muốn xóa tin này?')" title="Xóa">
                                                        <i class="fa-solid fa-trash text-sm"></i> Xóa
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Tab switching logic
        const tabView = document.getElementById('tab-view');
        const tabEdit = document.getElementById('tab-edit');
        const contentView = document.getElementById('content-view');
        const contentEdit = document.getElementById('content-edit');

        function switchTab(mode) {
            if (mode === 'view') {
                contentView.classList.remove('hidden');
                contentEdit.classList.add('hidden');
                tabView.classList.add('border-blue-600', 'text-blue-500', 'bg-blue-900/20/50');
                tabView.classList.remove('border-transparent', 'text-slate-500 dark:text-slate-400');
                tabEdit.classList.remove('border-blue-600', 'text-blue-500', 'bg-blue-900/20/50');
                tabEdit.classList.add('border-transparent', 'text-slate-500 dark:text-slate-400');
            } else {
                contentView.classList.add('hidden');
                contentEdit.classList.remove('hidden');
                tabEdit.classList.add('border-blue-600', 'text-blue-500', 'bg-blue-900/20/50');
                tabEdit.classList.remove('border-transparent', 'text-slate-500 dark:text-slate-400');
                tabView.classList.remove('border-blue-600', 'text-blue-500', 'bg-blue-900/20/50');
                tabView.classList.add('border-transparent', 'text-slate-500 dark:text-slate-400');
            }
        }

        tabView.addEventListener('click', () => switchTab('view'));
        tabEdit.addEventListener('click', () => switchTab('edit'));

        // Profile update via AJAX
        document.getElementById('profile-edit-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const messageDiv = document.getElementById('form-message');
            const btn = this.querySelector('button[type="submit"]');
            
            // Disable button
            btn.disabled = true;
            btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Đang lưu...';

            fetch('../../api.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then(text => {
                console.log('Response:', text);
                try {
                    return JSON.parse(text);
                } catch (e) {
                    throw new Error('Invalid JSON response: ' + text.substring(0, 100));
                }
            })
            .then(data => {
                messageDiv.classList.remove('hidden');
                if (data.success) {
                    messageDiv.className = 'p-3 rounded text-sm bg-green-100 text-green-700 border border-green-200 mb-4';
                    messageDiv.innerHTML = '<i class="fa-solid fa-check-circle"></i> ' + data.message;
                    btn.disabled = false;
                    btn.innerHTML = '💾 Lưu thay đổi';
                    // Cập nhật session avatar nếu có
                    if (data.avatar_url) {
                        document.getElementById('nav-avatar').src = data.avatar_url;
                    }
                    // Tự động ẩn message sau 3 giây
                    setTimeout(() => {
                        messageDiv.classList.add('hidden');
                    }, 3000);
                } else {
                    messageDiv.className = 'p-3 rounded text-sm bg-red-100 text-red-700 border border-red-200 mb-4';
                    messageDiv.innerHTML = '<i class="fa-solid fa-exclamation-circle"></i> ' + (data.message || 'Lỗi cập nhật');
                    btn.disabled = false;
                    btn.innerHTML = '💾 Lưu thay đổi';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                messageDiv.classList.remove('hidden');
                messageDiv.className = 'p-3 rounded text-sm bg-red-100 text-red-700 border border-red-200 mb-4';
                messageDiv.textContent = '❌ ' + error.message;
                btn.disabled = false;
                btn.innerHTML = '💾 Lưu thay đổi';
            });
        });

        // Fix dropdown menu
        document.querySelectorAll('.dropdown-group').forEach(group => {
            const btn = group.querySelector('.dropdown-btn');
            const menu = group.querySelector('.dropdown-menu');
            
            if (btn && menu) {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    menu.classList.toggle('!block');
                    menu.classList.toggle('!opacity-100');
                });
                
                group.addEventListener('mouseleave', () => {
                    menu.classList.remove('!block');
                    menu.classList.remove('!opacity-100');
                });
            }
        });
        
        document.addEventListener('click', (e) => {
            document.querySelectorAll('.dropdown-menu').forEach(menu => {
                if (!menu.closest('.dropdown-group')?.contains(e.target)) {
                    menu.classList.remove('!block');
                    menu.classList.remove('!opacity-100');
                }
            });
        });

        // Tab switching
        document.getElementById('tab-view')?.addEventListener('click', () => {
            document.getElementById('content-view').classList.remove('hidden');
            document.getElementById('content-edit').classList.add('hidden');
            document.getElementById('tab-view').classList.add('border-blue-600', 'text-blue-500', 'bg-blue-900/20/50');
            document.getElementById('tab-view').classList.remove('border-transparent', 'text-slate-500 dark:text-slate-400');
            document.getElementById('tab-edit').classList.add('border-transparent', 'text-slate-500 dark:text-slate-400');
            document.getElementById('tab-edit').classList.remove('border-blue-600', 'text-blue-500', 'bg-blue-900/20/50');
        });

        document.getElementById('tab-edit')?.addEventListener('click', () => {
            document.getElementById('content-edit').classList.remove('hidden');
            document.getElementById('content-view').classList.add('hidden');
            document.getElementById('tab-edit').classList.add('border-blue-600', 'text-blue-500', 'bg-blue-900/20/50');
            document.getElementById('tab-edit').classList.remove('border-transparent', 'text-slate-500 dark:text-slate-400');
            document.getElementById('tab-view').classList.add('border-transparent', 'text-slate-500 dark:text-slate-400');
            document.getElementById('tab-view').classList.remove('border-blue-600', 'text-blue-500', 'bg-blue-900/20/50');
        });
    </script>

    <!-- Chat Widget (Real-time messaging with candidates) -->
    <?php include __DIR__ . '/../../components/chat-widget.php'; ?>
</body>
</html>