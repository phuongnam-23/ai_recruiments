<?php
/**
 * RECRUITER VIEW - CANDIDATE PROFILE (Headhunting Enabled)
 * File: views/recruiter/candidate-profile.php
 * 
 * Authorization Rules:
 * - Admin: Full access to all candidate profiles
 * - Recruiter: Access if candidate applied to their job OR profile is public (is_public=1)
 * - Others: Denied
 */

require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';

addSecurityHeaders();

// Get candidate ID from URL
$candidateId = (int)($_GET['id'] ?? 0);

if (!$candidateId) {
    redirect('../../index.php');
}

// Load models
require_once '../../utils/models/User.php';
require_once '../../utils/models/CandidateProfile.php';

$userModel = new User();
$candidateModel = new CandidateProfile();

// Get candidate info
$candidate = $userModel->getUserById($candidateId);
$profile = $candidateModel->getProfile($candidateId);

// Check if candidate exists and is actually a candidate
if (!$candidate || $candidate['role'] !== 'candidate') {
    http_response_code(404);
    die('Ứng viên không tồn tại.');
}

// ============================================
// AUTHORIZATION LOGIC
// ============================================

$hasPermission = false;
$accessReason = '';

// Rule 1: ADMIN - Full Access
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    $hasPermission = true;
    $accessReason = 'admin_access';
}
// Rule 2: RECRUITER - Conditional Access
elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'recruiter') {
    // Condition A: Check if candidate applied to recruiter's job
    require_once '../../utils/models/Application.php';
    require_once '../../utils/models/Job.php';
    
    $appModel = new Application();
    $jobModel = new Job();
    
    $applications = $appModel->getApplicationsByCandidate($candidateId, 1000, 0);
    $recruiterJobs = $jobModel->getJobsByRecruiter($_SESSION['user_id']);
    $recruiterJobIds = array_column($recruiterJobs, 'id');
    
    if (!empty($applications) && !empty($recruiterJobIds)) {
        foreach ($applications as $app) {
            if (in_array($app['job_id'], $recruiterJobIds)) {
                $hasPermission = true;
                $accessReason = 'applied_to_job';
                break;
            }
        }
    }
    
    // Condition B: Check if profile is public (is_public = 1)
    if (!$hasPermission && !empty($profile['is_public'])) {
        $hasPermission = true;
        $accessReason = 'profile_public';
    }
}

// Deny access if no permission
if (!$hasPermission) {
    http_response_code(403);
    die('❌ Bạn không có quyền xem hồ sơ ứng viên này.<br>
         Lý do: Ứng viên này không công khai hồ sơ và không ứng tuyển vào vị trí của bạn.');
}

// Parse JSON fields if they exist
$skills = !empty($profile['skills']) ? (is_array($profile['skills']) ? $profile['skills'] : json_decode($profile['skills'], true)) : [];
$desiredPositions = !empty($profile['desired_positions']) ? (is_array($profile['desired_positions']) ? $profile['desired_positions'] : json_decode($profile['desired_positions'], true)) : [];
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ sơ ứng viên - <?php echo htmlspecialchars($candidate['full_name']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 text-slate-900 dark:text-white font-sans min-h-screen">
    
    <!-- Navigation -->
    <nav class="backdrop-blur-md bg-white/80 dark:bg-slate-900/80 border-b border-slate-200/50 dark:border-slate-700/50 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="<?php echo BASE_URL; ?>index.php" class="text-2xl font-bold tracking-tight text-blue-500 hover:text-blue-400 transition">
                AI Recruitment
            </a>
            <div class="flex items-center gap-4">
                <span class="text-slate-700 dark:text-slate-300">👤 <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                <a href="dashboard.php" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded hover:bg-blue-500">
                    Dashboard
                </a>
                <a href="../../logout.php" class="text-red-400 hover:underline">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-4 py-8">
        
        <!-- Back Button -->
        <div class="mb-6">
            <a href="javascript:history.back()" class="text-blue-500 hover:text-blue-400 flex items-center gap-2">
                ← Quay lại
            </a>
        </div>

        <!-- Candidate Header -->
        <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 border border-slate-200/50 dark:border-slate-700/50 shadow-lg p-8 mb-8">
            <div class="flex items-start gap-6">
                <!-- Avatar -->
                <div class="flex-shrink-0">
                    <img src="<?php 
                        if (!empty($candidate['avatar_url'])) {
                            if (strpos($candidate['avatar_url'], 'http') === 0 || strpos($candidate['avatar_url'], 'ui-avatars') === 0) {
                                echo $candidate['avatar_url'];
                            } else {
                                echo BASE_URL . $candidate['avatar_url'];
                            }
                        } else {
                            echo 'https://ui-avatars.com/api/?name=' . urlencode($candidate['full_name']);
                        }
                    ?>" alt="<?php echo htmlspecialchars($candidate['full_name']); ?>" 
                    class="w-24 h-24 rounded-xl ring-4 ring-white dark:ring-slate-800 object-cover">
                </div>

                <!-- Info -->
                <div class="flex-1">
                    <h1 class="text-3xl font-bold tracking-tight tracking-tight text-slate-900 dark:text-white mb-2">
                        <?php echo htmlspecialchars($candidate['full_name']); ?>
                    </h1>
                    <p class="text-slate-500 dark:text-slate-400 mb-4">
                        📧 <?php echo htmlspecialchars($candidate['email']); ?>
                    </p>
                    
                    <?php if (!empty($profile['phone'])): ?>
                        <p class="text-slate-500 dark:text-slate-400 mb-2">
                            📞 <?php echo htmlspecialchars($profile['phone']); ?>
                        </p>
                    <?php endif; ?>
                    
                    <?php if (!empty($profile['address'])): ?>
                        <p class="text-slate-500 dark:text-slate-400 mb-2">
                            📍 <?php echo htmlspecialchars($profile['address']); ?>
                        </p>
                    <?php endif; ?>

                    <?php if (!empty($profile['date_of_birth']) || !empty($profile['gender'])): ?>
                        <div class="flex gap-4 mt-4 text-sm text-slate-500 dark:text-slate-400">
                            <?php if (!empty($profile['date_of_birth'])): ?>
                                <span>🎂 <?php echo date('d/m/Y', strtotime($profile['date_of_birth'])); ?></span>
                            <?php endif; ?>
                            <?php if (!empty($profile['gender'])): ?>
                                <span>👤 <?php echo htmlspecialchars($profile['gender']); ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Actions -->
                <div class="flex flex-col gap-2">
                    <a href="mailto:<?php echo htmlspecialchars($candidate['email']); ?>" 
                       class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded-xl hover:bg-blue-500 transition text-center">
                        📧 Liên hệ
                    </a>
                    <?php if (!empty($profile['cv_file_url'])): ?>
                        <a href="../../<?php echo htmlspecialchars($profile['cv_file_url']); ?>" 
                           target="_blank"
                           class="bg-green-600 text-slate-900 dark:text-white px-4 py-2 rounded-xl hover:bg-green-500 transition text-center">
                            📄 Xem CV
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Professional Info -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            
            <!-- Desired Positions -->
            <?php if (!empty($desiredPositions)): ?>
                <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 border border-slate-200/50 dark:border-slate-700/50 shadow-lg p-6">
                    <h2 class="text-xl font-bold tracking-tight mb-4 flex items-center gap-2">
                        💼 Vị trí mong muốn
                    </h2>
                    <div class="space-y-2">
                        <?php foreach ($desiredPositions as $position): ?>
                            <div class="bg-slate-100 dark:bg-slate-700 px-4 py-3 rounded-xl border border-slate-300/50 dark:border-slate-600/50">
                                <?php echo htmlspecialchars($position); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Skills -->
            <?php if (!empty($skills)): ?>
                <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 border border-slate-200/50 dark:border-slate-700/50 shadow-lg p-6">
                    <h2 class="text-xl font-bold tracking-tight mb-4 flex items-center gap-2">
                        🔧 Kỹ năng
                    </h2>
                    <div class="flex flex-wrap gap-2">
                        <?php foreach ($skills as $skill): ?>
                            <span class="bg-blue-900/40 text-blue-300 px-3 py-2 rounded-full border border-blue-700 text-sm">
                                <?php echo htmlspecialchars($skill); ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Bio/About -->
        <?php if (!empty($profile['bio'])): ?>
            <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 border border-slate-200/50 dark:border-slate-700/50 shadow-lg p-6 mb-8">
                <h2 class="text-xl font-bold tracking-tight mb-4 flex items-center gap-2">
                    ✍️ Giới thiệu về bản thân
                </h2>
                <p class="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                    <?php echo htmlspecialchars($profile['bio']); ?>
                </p>
            </div>
        <?php endif; ?>

        <!-- CV Upload Status -->
        <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 border border-slate-200/50 dark:border-slate-700/50 shadow-lg p-6 mb-8">
            <h2 class="text-xl font-bold tracking-tight mb-4 flex items-center gap-2">
                📎 CV
            </h2>
            <?php if (!empty($profile['cv_file_url'])): ?>
                <div class="bg-green-900/40 border border-green-700 rounded-xl p-4">
                    <p class="text-green-300 mb-3">
                        ✅ Ứng viên đã tải CV
                    </p>
                    <a href="../../<?php echo htmlspecialchars($profile['cv_file_url']); ?>" 
                       target="_blank"
                       class="inline-block bg-green-700 text-slate-900 dark:text-white px-4 py-2 rounded-xl hover:bg-green-600 transition">
                        📥 Tải xuống CV
                    </a>
                </div>
            <?php else: ?>
                <div class="bg-yellow-900/40 border border-yellow-700 rounded-xl p-4">
                    <p class="text-yellow-300">
                        ⚠️ Ứng viên chưa tải CV
                    </p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Account Info -->
        <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 border border-slate-200/50 dark:border-slate-700/50 shadow-lg p-6">
            <h2 class="text-xl font-bold tracking-tight mb-4 flex items-center gap-2">
                ℹ️ Thông tin tài khoản
            </h2>
            <div class="grid grid-cols-2 gap-4 text-sm">
                <div>
                    <p class="text-slate-500 dark:text-slate-400 mb-1">Ngày tạo tài khoản</p>
                    <p class="text-gray-800 dark:text-gray-200">
                        <?php echo date('d/m/Y H:i', strtotime($candidate['created_at'])); ?>
                    </p>
                </div>
                <div>
                    <p class="text-slate-500 dark:text-slate-400 mb-1">Cập nhật lần cuối</p>
                    <p class="text-gray-800 dark:text-gray-200">
                        <?php echo !empty($profile['updated_at']) ? date('d/m/Y H:i', strtotime($profile['updated_at'])) : 'Chưa cập nhật'; ?>
                    </p>
                </div>
            </div>
        </div>

    </div>

</body>
</html>
