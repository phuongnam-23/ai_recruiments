<?php
// views/recruiter/applications.php

require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/Job.php';
require_once '../../utils/models/Application.php';
require_once '../../utils/models/User.php';
require_once '../../utils/Helpers.php'; 

requireRole('recruiter');
addSecurityHeaders();

$jobId = (int)($_GET['job_id'] ?? 0);
if (!$jobId) redirect('dashboard.php');

$jobModel = new Job();
$applicationModel = new Application();
$job = $jobModel->getJobById($jobId);

if (!$job || $job['recruiter_id'] != $_SESSION['user_id']) redirect('dashboard.php');

// Lấy danh sách đơn ứng tuyển (Không cần lọc status nữa)
$applications = $applicationModel->getApplicationsByJob($jobId);

// Xử lý Sắp xếp (Sort)
$sortType = $_GET['sort'] ?? 'match_desc';

usort($applications, function($a, $b) use ($sortType) {
    switch ($sortType) {
        case 'match_desc': 
            return ($b['match_score'] ?? 0) <=> ($a['match_score'] ?? 0);
        case 'newest': 
            return strtotime($b['applied_at']) <=> strtotime($a['applied_at']);
        case 'oldest': 
            return strtotime($a['applied_at']) <=> strtotime($b['applied_at']);
        default: return 0;
    }
});
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đơn apply - <?php echo htmlspecialchars($job['title']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900 font-sans text-slate-900 dark:text-white">
    
    <nav class="bg-white dark:bg-slate-800 shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <a href="dashboard.php" class="text-2xl font-bold tracking-tight text-blue-600">AI Recruitment</a>
            <div class="flex items-center gap-4">
                <span class="text-slate-600 dark:text-slate-300 font-medium">
                    👤 <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Recruiter'); ?>
                </span>
                <a href="../../logout.php" class="text-red-500 hover:text-red-700 font-medium text-sm">Đăng xuất</a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 p-6 mb-6">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 class="text-2xl font-bold"><?php echo htmlspecialchars($job['title']); ?></h1>
                    <div class="flex items-center gap-3 mt-2 text-sm text-slate-500 dark:text-slate-400">
                        <span><i class="fa-solid fa-users"></i> <?php echo count($applications); ?> đơn ứng tuyển</span>
                        <span>•</span>
                        <span><i class="fa-regular fa-clock"></i> Đăng ngày <?php echo date('d/m/Y', strtotime($job['created_at'])); ?></span>
                    </div>
                </div>
                <a href="dashboard.php" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl hover:bg-slate-200 transition font-medium text-sm">
                    ← Quay lại Dashboard
                </a>
            </div>
        </div>

        <div class="flex justify-end mb-4">
            <div class="flex items-center gap-2 bg-white dark:bg-slate-800 p-2 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
                <label class="text-sm font-medium text-slate-600 dark:text-slate-400 ml-2">Sắp xếp theo:</label>
                <select onchange="window.location.search = '?job_id=<?php echo $jobId; ?>&sort=' + this.value" 
                        class="bg-slate-50 dark:bg-slate-700 border-none rounded-lg text-sm px-4 py-2 focus:ring-2 focus:ring-blue-500 cursor-pointer outline-none font-medium">
                    <option value="match_desc" <?php echo $sortType=='match_desc'?'selected':''; ?>>✨ Độ phù hợp giảm dần</option>
                    <option value="newest" <?php echo $sortType=='newest'?'selected':''; ?>>🕒 Mới nhất</option>
                    <option value="oldest" <?php echo $sortType=='oldest'?'selected':''; ?>>⏳ Cũ nhất</option>
                </select>
            </div>
        </div>

        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead class="bg-slate-50 dark:bg-slate-700/50 text-slate-500 dark:text-slate-400 uppercase text-xs font-bold">
                    <tr>
                        <th class="px-6 py-4">Ứng viên</th>
                        <th class="px-6 py-4 text-center">AI Match</th>
                        <th class="px-6 py-4">Trạng thái</th>
                        <th class="px-6 py-4">Ngày apply</th>
                        <th class="px-6 py-4 text-center">Hành động</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                    <?php if (empty($applications)): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-slate-500 italic">
                                Chưa có ứng viên nào ứng tuyển vị trí này.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($applications as $app): ?>
                            <tr class="hover:bg-slate-50 dark:hover:bg-slate-700/30 transition">
                                <td class="px-6 py-4">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center text-white font-bold shadow-md">
                                            <?php echo strtoupper(substr($app['full_name'] ?? 'U', 0, 1)); ?>
                                        </div>
                                        <div>
                                            <a href="candidate-profile.php?id=<?php echo $app['candidate_id']; ?>" class="font-bold text-slate-900 dark:text-white hover:text-blue-600 transition">
                                                <?php echo htmlspecialchars($app['full_name']); ?>
                                            </a>
                                            <div class="text-xs text-slate-500"><?php echo htmlspecialchars($app['email']); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 text-center score-cell">
                                    <?php if ($app['match_score'] > 0): ?>
                                        <button onclick="hienThiPhanTichDiem(
                                            <?php echo htmlspecialchars(json_encode($app['ai_analysis'] ? json_decode($app['ai_analysis'], true) : null)); ?>, 
                                            '<?php echo $app['match_score']; ?>', 
                                            '<?php echo htmlspecialchars($app['full_name']); ?>',
                                            '<?php echo !empty($app['cv_file_url']) ? BASE_URL . $app['cv_file_url'] : ''; ?>' 
                                        )"
                                        class="group relative inline-flex items-center justify-center">
                                            <div class="<?php 
                                                $s = $app['match_score'];
                                                echo $s >= 80 ? 'text-green-600 bg-green-100 dark:bg-green-900/30' : ($s >= 50 ? 'text-amber-600 bg-amber-100 dark:bg-amber-900/30' : 'text-red-600 bg-red-100 dark:bg-red-900/30');
                                            ?> font-bold px-3 py-1 rounded-lg border border-transparent group-hover:border-current transition-all cursor-pointer">
                                                <?php echo $s; ?>%
                                            </div>
                                        </button>
                                    <?php else: ?>
                                        <button data-app-id="<?php echo $app['id']; ?>" data-job-id="<?php echo $jobId; ?>" data-candidate-name="<?php echo htmlspecialchars($app['full_name'] ?? 'Ứng viên'); ?>"
                                                onclick="tinhDiem(<?php echo $app['id']; ?>, <?php echo $jobId; ?>)" 
                                                class="text-xs bg-purple-100 text-purple-700 px-3 py-1 rounded-full border border-purple-200 hover:bg-purple-200 transition">
                                            ⚡ Phân tích
                                        </button>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4">
                                    <select onchange="capNhatTrangThaiUngTuyen(<?php echo $app['id']; ?>, this.value)" 
                                            class="bg-transparent border-none text-sm font-semibold cursor-pointer focus:ring-0 <?php
                                                $st = $app['status'];
                                                if($st=='pending') echo 'text-yellow-600';
                                                elseif($st=='reviewing') echo 'text-blue-600';
                                                elseif($st=='shortlisted') echo 'text-purple-600';
                                                elseif($st=='offered') echo 'text-green-600';
                                                else echo 'text-red-600';
                                            ?>">
                                        <option value="pending" <?php echo $st === 'pending' ? 'selected' : ''; ?>>Chờ xử lý</option>
                                        <option value="reviewing" <?php echo $st === 'reviewing' ? 'selected' : ''; ?>>Đang xem xét</option>
                                        <option value="shortlisted" <?php echo $st === 'shortlisted' ? 'selected' : ''; ?>>Được rút ngắn</option>
                                        <option value="interviewed" <?php echo $st === 'interviewed' ? 'selected' : ''; ?>>Phỏng vấn</option>
                                        <option value="offered" <?php echo $st === 'offered' ? 'selected' : ''; ?>>Đề nghị</option>
                                        <option value="rejected" <?php echo $st === 'rejected' ? 'selected' : ''; ?>>Từ chối</option>
                                    </select>
                                </td>
                                <td class="px-6 py-4 text-sm text-slate-500">
                                    <?php echo date('d/m/Y', strtotime($app['applied_at'])); ?>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <a href="candidate-profile.php?id=<?php echo $app['candidate_id']; ?>" 
                                       class="inline-flex items-center gap-1 text-slate-500 hover:text-blue-600 transition font-medium text-sm">
                                        <i class="fa-regular fa-eye"></i> Xem
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        window.addEventListener('DOMContentLoaded', function() {
            tinhDiemTuDong();
        });

        async function tinhDiemTuDong() {
            const buttons = document.querySelectorAll('button[data-app-id]');
            if (buttons.length === 0) return;
            for (let btn of buttons) {
                await tinhDiemTuDongMotUngVien(btn);
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }

        window.tinhDiemTuDongMotUngVien = async function(btn) {
            const applicationId = btn.getAttribute('data-app-id');
            const jobId = btn.getAttribute('data-job-id');
            try {
                const response = await fetch('../../api.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({
                        action: 'match-job', job_id: jobId, application_id: applicationId,
                        csrf_token: '<?php echo $_SESSION['csrf_token'] ?? ''; ?>'
                    })
                });
                const data = await response.json();
                if (data.success) {
                    const score = data.data.score;
                    const scoreCell = btn.closest('tr').querySelector('.score-cell');
                    if (scoreCell) {
                        const candidateName = btn.getAttribute('data-candidate-name') || 'Ứng viên';
                        const scoreColor = score >= 80 ? 'text-green-500' : (score >= 60 ? 'text-yellow-500' : 'text-red-500');
                        scoreCell.innerHTML = `<button onclick="location.reload()" class="font-semibold text-lg cursor-pointer hover:underline ${scoreColor}">${score}%</button>`;
                    }
                }
            } catch (error) { console.error(error); }
        };

        window.tinhDiem = async function(applicationId, jobId) {
            const btn = event.target;
            const textGoc = btn.innerHTML;
            try {
                btn.disabled = true; btn.innerHTML = '⏳...';
                const response = await fetch('../../api.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({
                        action: 'match-job', job_id: jobId, application_id: applicationId,
                        csrf_token: '<?php echo $_SESSION['csrf_token'] ?? ''; ?>'
                    })
                });
                const data = await response.json();
                if (data.success) { alert('✅ Điểm: ' + data.data.score + '%'); location.reload(); }
                else { alert('❌ Lỗi: ' + data.message); }
            } catch (error) { alert('❌ Lỗi: ' + error.message); } 
            finally { btn.disabled = false; btn.innerHTML = textGoc; }
        }

        function capNhatTrangThaiUngTuyen(applicationId, trangThai) {
            if(!confirm('Đổi trạng thái thành ' + trangThai + '?')) return;
            const csrfToken = '<?php echo $_SESSION['csrf_token'] ?? ''; ?>';
            fetch('../../api.php?action=update-application', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'application_id=' + applicationId + '&status=' + trangThai + '&csrf_token=' + encodeURIComponent(csrfToken)
            })
            .then(r => r.json())
            .then(d => { if(d.success) location.reload(); else alert(d.message); })
            .catch(e => alert('Lỗi kết nối'));
        }

        // HÀM HIỂN THỊ MODAL (Giữ nguyên logic xem CV)
        window.hienThiPhanTichDiem = function(data, diem, candidateName = 'Ứng viên', cvUrl = '') {
            const getScoreColor = (score) => {
                if (score >= 80) return { bg: 'bg-green-50', text: 'text-green-600', border: 'border-green-500', dark: 'dark:bg-green-900/20' };
                if (score >= 60) return { bg: 'bg-amber-50', text: 'text-amber-600', border: 'border-amber-500', dark: 'dark:bg-amber-900/20' };
                return { bg: 'bg-red-50', text: 'text-red-600', border: 'border-red-500', dark: 'dark:bg-red-900/20' };
            };
            const colors = getScoreColor(diem);
            const pros = data?.pros || [];
            const cons = data?.cons || [];
            const missingSkills = data?.missing_skills || [];
            const recommendation = data?.recommendation || 'CHƯA CÓ ĐÁNH GIÁ';
            const reason = data?.reason || 'Không có lý do được cung cấp';
            
            let cvButtonHtml = '';
            if (cvUrl && cvUrl.trim() !== '') {
                cvButtonHtml = `<a href="${cvUrl}" target="_blank" class="px-4 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 rounded-lg font-medium transition flex items-center gap-2"><i class="fa-solid fa-file-pdf text-red-500"></i> Xem CV Gốc</a>`;
            } else {
                cvButtonHtml = `<button disabled class="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-200 dark:border-slate-700 rounded-lg flex items-center gap-2"><i class="fa-solid fa-file-circle-xmark"></i> Không có CV</button>`;
            }

            const modalHTML = `
                <div class="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onclick="this.remove()">
                    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200/50 dark:border-slate-700/50 overflow-hidden max-h-[90vh] overflow-y-auto" onclick="event.stopPropagation()">
                        <div class="bg-gradient-to-r from-blue-600 to-indigo-700 p-6 text-white sticky top-0 z-10">
                            <div class="flex justify-between items-start">
                                <div><h2 class="text-2xl font-bold flex items-center gap-2">🏅 ${candidateName}</h2><p class="text-blue-100 text-sm mt-1">Phân tích chi tiết từ AI</p></div>
                                <button onclick="this.closest('.fixed').remove()" class="text-2xl hover:text-blue-200 transition">×</button>
                            </div>
                        </div>
                        <div class="p-6 space-y-6">
                            <div class="flex items-center justify-between p-4 rounded-xl ${colors.bg} ${colors.dark} border-l-4 ${colors.border}">
                                <div><p class="text-sm text-slate-600 dark:text-slate-400">📊 Điểm Phù Hợp</p><p class="text-3xl font-bold ${colors.text}">${diem}%</p></div>
                                <div class="text-6xl font-bold ${colors.text} opacity-30">${diem}%</div>
                            </div>
                            <div class="space-y-4">
                                ${pros.length > 0 ? `<div><h4 class="font-bold text-green-600 dark:text-green-400 mb-2"><i class="fa-solid fa-circle-check"></i> Điểm mạnh</h4><ul class="space-y-2">${pros.map(p => `<li class="flex gap-2 text-sm text-slate-700 dark:text-slate-300"><span class="text-green-500">•</span> ${p}</li>`).join('')}</ul></div>` : ''}
                                ${missingSkills.length > 0 ? `<div><h4 class="font-bold text-amber-600 dark:text-amber-400 mb-2"><i class="fa-solid fa-triangle-exclamation"></i> Kỹ năng thiếu</h4><ul class="space-y-2">${missingSkills.map(m => `<li class="flex gap-2 text-sm text-slate-700 dark:text-slate-300"><span class="text-amber-500">•</span> ${m}</li>`).join('')}</ul></div>` : ''}
                            </div>
                            <div class="bg-slate-100 dark:bg-slate-700/50 p-4 rounded-lg border-l-4 ${colors.border} space-y-2">
                                <div class="font-bold flex items-center gap-2 text-slate-900 dark:text-white"><i class="fa-solid fa-lightbulb text-yellow-500"></i> AI ĐỀ XUẤT: <span class="uppercase ${colors.text}">${recommendation}</span></div>
                                <p class="text-sm text-slate-700 dark:text-slate-300"><strong>Lý do:</strong> ${reason}</p>
                            </div>
                            <div class="pt-4 border-t border-slate-200 dark:border-slate-700 flex gap-2 flex-wrap justify-end items-center sticky bottom-0 bg-white dark:bg-slate-800 pb-2">
                                ${cvButtonHtml}
                                <button onclick="this.closest('.fixed').remove()" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition">✓ Đóng</button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            const temp = document.createElement('div');
            temp.innerHTML = modalHTML;
            document.body.appendChild(temp.firstElementChild);
        }
    </script>
</body>
</html>