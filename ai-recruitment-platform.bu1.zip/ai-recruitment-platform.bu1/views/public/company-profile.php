<?php
require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/CompanyReview.php';

addSecurityHeaders();

$recruiterId = isset($_GET['recruiter_id']) ? (int)$_GET['recruiter_id'] : 0;
if (!$recruiterId) {
    redirect('../../index.php');
}

$userModel = new User();
$recruiterUser = $userModel->getUserById($recruiterId);

if (!$recruiterUser || $recruiterUser['role'] !== 'recruiter') {
    redirect('../../index.php');
}

$recruiterModel = new RecruiterProfile();
$recruiterProfile = $recruiterModel->getProfileByUserId($recruiterId);

// Get company's active jobs
$jobModel = new Job();
$jobs = $jobModel->getJobsByRecruiter($recruiterId, 'active');

// Get company reviews - lấy company_id từ recruiter profile
$companyId = $recruiterProfile['id'] ?? 0;
$reviewModel = new CompanyReview();
$reviews = $reviewModel->getCompanyReviews($companyId, 10);
$ratingStats = $reviewModel->getCompanyRatingStats($companyId);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($recruiterProfile['company_name'] ?? 'Công ty'); ?> - AI Recruitment</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-slate-900">
    <!-- Navigation -->
    <nav class="bg-white/90 dark:bg-gray-900/80 backdrop-blur-md shadow-lg shadow-slate-900/5 sticky top-0 z-50 border-b border-slate-200 dark:border-slate-700">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center gap-8">
                <a href="<?php echo BASE_URL; ?>index.php" class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition">AI Recruitment</a>
                <div class="hidden md:flex gap-6">
                    <a href="<?php echo BASE_URL; ?>index.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500">Trang chủ</a>
                    <a href="jobs-list.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500">Tìm việc</a>
                    <a href="companies.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500">Công ty</a>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <?php if (isLoggedIn()): ?>
                    <span class="text-slate-700 dark:text-slate-300">👤 <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                    <a href="../<?php echo $_SESSION['role']; ?>/dashboard.php" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded hover:bg-blue-500">
                        Trang cá nhân
                    </a>
                    <a href="../../logout.php" class="text-red-400 hover:underline">Đăng xuất</a>
                <?php else: ?>
                    <a href="../../login.php" class="text-blue-500 hover:underline font-semibold">Đăng nhập</a>
                    <a href="../../register.php" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded hover:bg-blue-500">Đăng ký</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <a href="companies.php" class="text-blue-500 hover:underline mb-6 inline-block">← Quay lại danh sách công ty</a>

        <!-- Company Header -->
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-8 mb-8">
            <div class="flex justify-between items-start mb-6">
                <div class="flex-1">
                    <h1 class="text-4xl font-bold text-slate-900 dark:text-white mb-2">
                        <?php echo htmlspecialchars($recruiterProfile['company_name'] ?? 'Công ty'); ?>
                    </h1>
                    <p class="text-slate-700 dark:text-slate-300 text-lg mb-4">
                        <?php echo htmlspecialchars($recruiterProfile['industry'] ?? 'Không xác định'); ?>
                    </p>
                </div>
                
                <!-- Edit Button - Only show if current user is the company owner -->
                <?php if (isLoggedIn() && $_SESSION['user_id'] == $recruiterId): ?>
                    <button onclick="document.getElementById('editCompanyModal').classList.remove('hidden')" 
                            class="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-lg font-semibold transition shadow-lg flex items-center gap-2">
                        <i class="fa-solid fa-pen-to-square"></i> Chỉnh sửa hồ sơ
                    </button>
                <?php endif; ?>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6 pb-6 border-b">
                <div>
                    <p class="text-slate-700 dark:text-slate-300 text-sm mb-1">Quy mô công ty</p>
                    <p class="font-semibold">👥 <?php echo htmlspecialchars($recruiterProfile['company_size'] ?? 'Không xác định'); ?></p>
                </div>
                <div>
                    <p class="text-slate-700 dark:text-slate-300 text-sm mb-1">Địa điểm</p>
                    <p class="font-semibold">📍 <?php 
                        $locationParts = [];
                        if (!empty($recruiterProfile['company_address'])) {
                            $locationParts[] = $recruiterProfile['company_address'];
                        }
                        if (!empty($recruiterProfile['company_city']) && !stripos($recruiterProfile['company_address'] ?? '', $recruiterProfile['company_city'])) {
                            $locationParts[] = $recruiterProfile['company_city'];
                        }
                        
                        if (!empty($locationParts)) {
                            echo htmlspecialchars(implode(', ', $locationParts));
                        } elseif (!empty($recruiterProfile['location'])) {
                            echo htmlspecialchars($recruiterProfile['location']);
                        } else {
                            echo 'Không xác định';
                        }
                    ?></p>
                </div>
                <div>
                    <p class="text-slate-700 dark:text-slate-300 text-sm mb-1">Công việc đang tuyển</p>
                    <p class="font-semibold">📌 <?php echo count($jobs); ?> vị trí</p>
                </div>
            </div>

            <?php if ($recruiterProfile && $recruiterProfile['company_description']): ?>
                <div>
                    <h2 class="text-xl font-bold tracking-tight mb-3">Về chúng tôi</h2>
                    <p class="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                        <?php echo htmlspecialchars($recruiterProfile['company_description']); ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Company Reviews Section -->
        <div id="reviews" class="mt-12">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-3xl font-bold tracking-tight">Đánh giá công ty</h2>
                <?php if (isLoggedIn() && $_SESSION['role'] === 'candidate'): ?>
                    <a href="<?php echo BASE_URL; ?>views/candidate/write-review.php?company_id=<?php echo $companyId; ?>&redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold transition">
                        ✍️ Viết đánh giá
                    </a>
                <?php endif; ?>
            </div>

            <?php if ($ratingStats && $ratingStats['total_reviews'] > 0): ?>
                <!-- Rating Stats -->
                <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mb-8">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <!-- Overall Rating -->
                        <div class="text-center">
                            <div class="text-5xl font-bold text-blue-500 mb-2">
                                <?php echo number_format($ratingStats['average_rating'], 1); ?>
                            </div>
                            <div class="flex gap-1 justify-center mb-2">
                                <?php 
                                $avgRating = round($ratingStats['average_rating']);
                                for ($i = 1; $i <= 5; $i++) {
                                    echo $i <= $avgRating ? '<span class="text-yellow-400 text-2xl">⭐</span>' : '<span class="text-slate-300 text-2xl">⭐</span>';
                                }
                                ?>
                            </div>
                            <p class="text-slate-600 dark:text-slate-400">(<?php echo $ratingStats['total_reviews']; ?> đánh giá)</p>
                        </div>

                        <!-- Rating Distribution -->
                        <div class="space-y-3">
                            <?php 
                            $totalReviews = $ratingStats['total_reviews'];
                            $stars = [5, 4, 3, 2, 1];
                            foreach ($stars as $star) {
                                $count = $ratingStats[$star . '_star'] ?? 0;
                                $percentage = $totalReviews > 0 ? ($count / $totalReviews) * 100 : 0;
                                ?>
                                <div class="flex items-center gap-3">
                                    <span class="text-sm w-12 text-right"><?php echo $star; ?>⭐</span>
                                    <div class="flex-1 h-3 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                                        <div class="h-full bg-yellow-400" style="width: <?php echo $percentage; ?>%"></div>
                                    </div>
                                    <span class="text-sm w-10 text-right"><?php echo $count; ?></span>
                                </div>
                                <?php 
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <!-- Reviews List -->
                <div class="space-y-4">
                    <?php foreach ($reviews as $review): ?>
                        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6">
                            <div class="flex items-start justify-between mb-3">
                                <div class="flex items-center gap-3">
                                    <div class="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white text-lg font-bold">
                                        <?php echo strtoupper(substr($review['full_name'], 0, 1)); ?>
                                    </div>
                                    <div>
                                        <p class="font-semibold text-slate-900 dark:text-white">
                                            <?php echo htmlspecialchars($review['full_name']); ?>
                                        </p>
                                        <p class="text-sm text-slate-500 dark:text-slate-400">
                                            <?php echo htmlspecialchars($review['title'] ?? 'Không xác định'); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="flex gap-0.5">
                                    <?php 
                                    for ($i = 1; $i <= 5; $i++) {
                                        echo $i <= $review['rating'] ? '<span class="text-yellow-400">⭐</span>' : '<span class="text-slate-300">⭐</span>';
                                    }
                                    ?>
                                </div>
                            </div>

                            <p class="text-slate-700 dark:text-slate-300 mb-3">
                                <?php echo htmlspecialchars($review['review']); ?>
                            </p>

                            <div class="flex gap-2 text-xs">
                                <span class="bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300 px-2 py-1 rounded">✓ Verified</span>
                                <span class="text-slate-500 dark:text-slate-400">
                                    <?php 
                                    $date = new DateTime($review['created_at']);
                                    $interval = $date->diff(new DateTime());
                                    if ($interval->days == 0) {
                                        echo 'Hôm nay';
                                    } elseif ($interval->days == 1) {
                                        echo 'Hôm qua';
                                    } elseif ($interval->days < 30) {
                                        echo $interval->days . ' ngày trước';
                                    } else {
                                        echo $interval->m . ' tháng trước';
                                    }
                                    ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-8 text-center">
                    <p class="text-slate-600 dark:text-slate-400 mb-4">Công ty này chưa có đánh giá nào</p>
                    <?php if (isLoggedIn() && $_SESSION['role'] === 'candidate'): ?>
                        <p class="text-slate-500 dark:text-slate-500 mb-4">Hãy là người đầu tiên viết đánh giá!</p>
                        <a href="<?php echo BASE_URL; ?>views/candidate/write-review.php?company_id=<?php echo $companyId; ?>&redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-semibold transition">
                            ✍️ Viết đánh giá đầu tiên
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Company Jobs -->
        <div class="mt-12">
            <h2 class="text-3xl font-bold tracking-tight mb-6">📌 Công việc đang tuyển (<?php echo count($jobs); ?> vị trí)</h2>

            <?php if (!empty($jobs)): ?>
                <div class="space-y-4">
                    <?php foreach ($jobs as $job): ?>
                        <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg shadow-slate-500/5 hover:shadow-lg hover:shadow-blue-500/20 transition p-6 cursor-pointer"
                             onclick="window.location.href='job-detail.php?id=<?php echo $job['id']; ?>&view_id=<?php echo $job['id']; ?>'">
                            <div class="flex justify-between items-start mb-3">
                                <div>
                                    <h3 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white hover:text-blue-500">
                                        <?php echo htmlspecialchars($job['title']); ?>
                                    </h3>
                                    <p class="text-slate-500 dark:text-slate-400 mt-1">
                                        📍 <?php echo htmlspecialchars($job['city']); ?> | ⏰ <?php echo ucfirst(str_replace('_', ' ', $job['job_type'])); ?>
                                    </p>
                                </div>
                                <div class="text-right">
                                    <button type="button" class="text-3xl hover:scale-125 transition" onclick="saveJob(event, <?php echo $job['id']; ?>)">
                                        ❤️
                                    </button>
                                </div>
                            </div>

                            <p class="text-slate-700 dark:text-slate-300 mb-4 line-clamp-2">
                                <?php echo htmlspecialchars(substr($job['description'], 0, 200)); ?>...
                            </p>

                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 pb-4 border-b border-slate-200/50 dark:border-slate-700/50">
                                <div>
                                    <p class="text-xs text-slate-500 dark:text-slate-400 uppercase">Loại công việc</p>
                                    <p class="font-semibold text-gray-800 dark:text-gray-200"><?php echo ucfirst(str_replace('_', ' ', $job['job_type'])); ?></p>
                                </div>
                                <div>
                                    <p class="text-xs text-slate-500 dark:text-slate-400 uppercase">Cấp độ</p>
                                    <p class="font-semibold text-gray-800 dark:text-gray-200"><?php echo ucfirst(str_replace('_', ' ', $job['job_level'])); ?></p>
                                </div>
                                <div>
                                    <p class="text-xs text-slate-500 dark:text-slate-400 uppercase">Kinh nghiệm</p>
                                    <p class="font-semibold text-gray-800 dark:text-gray-200"><?php echo $job['experience_required']; ?>+ năm</p>
                                </div>
                                <div>
                                    <p class="text-xs text-slate-500 dark:text-slate-400 uppercase">Lương</p>
                                    <p class="font-semibold text-gray-800 dark:text-gray-200">
                                        <?php 
                                        if ($job['salary_min'] && $job['salary_max']) {
                                            echo number_format($job['salary_min']) . ' - ' . 
                                                 number_format($job['salary_max']);
                                        } else {
                                            echo 'Thỏa thuận';
                                        }
                                        ?>
                                    </p>
                                </div>
                            </div>

                            <?php if (!empty($job['required_skills'])): ?>
                                <div class="mb-4">
                                    <p class="text-xs text-slate-500 dark:text-slate-400 uppercase mb-2">Kỹ năng yêu cầu</p>
                                    <div class="flex flex-wrap gap-2">
                                        <?php 
                                        $skills = json_decode($job['required_skills'], true);
                                        if (is_array($skills)) {
                                            foreach (array_slice($skills, 0, 5) as $skill) {
                                                echo '<span class="bg-blue-900/40 text-blue-300 px-3 py-1 rounded-full text-sm border border-blue-700">' . 
                                                     htmlspecialchars($skill) . '</span>';
                                            }
                                            if (count($skills) > 5) {
                                                echo '<span class="bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 px-3 py-1 rounded-full text-sm border border-slate-300/50 dark:border-slate-600/50">+' . 
                                                     (count($skills) - 5) . ' khác</span>';
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="flex justify-between items-center pt-4">
                                <div class="text-sm text-slate-500 dark:text-slate-400">
                                    📅 <?php echo date('d/m/Y', strtotime($job['deadline'])); ?> | 👀 <?php echo $job['views_count'] ?? 0; ?> views | 📄 <?php echo $job['applications_count'] ?? 0; ?> đơn apply
                                </div>
                                <a href="job-detail.php?id=<?php echo $job['id']; ?>&view_id=<?php echo $job['id']; ?>" 
                                   class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl transition font-semibold" 
                                   onclick="event.stopPropagation()">
                                    Xem chi tiết →
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg p-8 text-center">
                    <p class="text-slate-700 dark:text-slate-300 text-lg mb-4">😅 Công ty này hiện chưa có công việc đang tuyển</p>
                    <p class="text-slate-500 dark:text-slate-400">Vui lòng quay lại sau để xem các cơ hội mới nhất</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Edit Company Profile Modal -->
    <?php if (isLoggedIn() && $_SESSION['user_id'] == $recruiterId): ?>
    <div id="editCompanyModal" class="hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 overflow-y-auto">
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <!-- Header -->
            <div class="sticky top-0 bg-gradient-to-r from-blue-600 to-purple-600 p-6 flex justify-between items-center">
                <div>
                    <h2 class="text-2xl font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-building"></i> Chỉnh sửa hồ sơ công ty
                    </h2>
                    <p class="text-blue-100 text-sm mt-1">Cập nhật thông tin công ty của bạn</p>
                </div>
                <button onclick="document.getElementById('editCompanyModal').classList.add('hidden')" class="text-white hover:text-gray-200 text-3xl">
                    ×
                </button>
            </div>

            <!-- Form -->
            <form id="editCompanyForm" method="POST" action="<?php echo BASE_URL; ?>api.php" class="p-6 space-y-6">
                <input type="hidden" name="action" value="update-recruiter-profile">
                <input type="hidden" name="user_id" value="<?php echo $recruiterId; ?>">

                <!-- Thông tin công ty -->
                <div class="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-6">
                    <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                        <i class="fa-solid fa-building text-purple-500"></i> Thông tin công ty
                    </h3>
                    
                    <!-- Tên công ty -->
                    <div class="mb-4">
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Tên công ty <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="company_name" value="<?php echo htmlspecialchars($recruiterProfile['company_name'] ?? ''); ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               placeholder="VD: FPT Software" required>
                    </div>

                    <!-- Grid 2 columns -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <!-- Quy mô -->
                        <div>
                            <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                                Quy mô <span class="text-red-500">*</span>
                            </label>
                            <select name="company_size" class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                                <option value="">-- Chọn --</option>
                                <option value="1-50" <?php echo ($recruiterProfile['company_size'] ?? '') === '1-50' ? 'selected' : ''; ?>>1-50 nhân viên</option>
                                <option value="51-200" <?php echo ($recruiterProfile['company_size'] ?? '') === '51-200' ? 'selected' : ''; ?>>51-200 nhân viên</option>
                                <option value="201-500" <?php echo ($recruiterProfile['company_size'] ?? '') === '201-500' ? 'selected' : ''; ?>>201-500 nhân viên</option>
                                <option value="501-1000" <?php echo ($recruiterProfile['company_size'] ?? '') === '501-1000' ? 'selected' : ''; ?>>501-1000 nhân viên</option>
                                <option value="1000+" <?php echo ($recruiterProfile['company_size'] ?? '') === '1000+' ? 'selected' : ''; ?>>1000+ nhân viên</option>
                            </select>
                        </div>

                        <!-- Ngành nghề -->
                        <div>
                            <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                                Ngành nghề <span class="text-red-500">*</span>
                            </label>
                            <select name="industry" class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                                <option value="">-- Chọn --</option>
                                <option value="Information Technology" <?php echo ($recruiterProfile['industry'] ?? '') === 'Information Technology' ? 'selected' : ''; ?>>Công nghệ thông tin</option>
                                <option value="IT Outsourcing" <?php echo ($recruiterProfile['industry'] ?? '') === 'IT Outsourcing' ? 'selected' : ''; ?>>IT Outsourcing</option>
                                <option value="Finance" <?php echo ($recruiterProfile['industry'] ?? '') === 'Finance' ? 'selected' : ''; ?>>Tài chính - Ngân hàng</option>
                                <option value="E-commerce" <?php echo ($recruiterProfile['industry'] ?? '') === 'E-commerce' ? 'selected' : ''; ?>>Thương mại điện tử</option>
                                <option value="Telecommunications" <?php echo ($recruiterProfile['industry'] ?? '') === 'Telecommunications' ? 'selected' : ''; ?>>Viễn thông</option>
                                <option value="Marketing" <?php echo ($recruiterProfile['industry'] ?? '') === 'Marketing' ? 'selected' : ''; ?>>Marketing - Quảng cáo</option>
                                <option value="Education" <?php echo ($recruiterProfile['industry'] ?? '') === 'Education' ? 'selected' : ''; ?>>Giáo dục - Đào tạo</option>
                                <option value="Healthcare" <?php echo ($recruiterProfile['industry'] ?? '') === 'Healthcare' ? 'selected' : ''; ?>>Y tế - Sức khỏe</option>
                            </select>
                        </div>
                    </div>

                    <!-- Website -->
                    <div class="mb-4">
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Website công ty
                        </label>
                        <input type="url" name="company_website" value="<?php echo htmlspecialchars($recruiterProfile['company_website'] ?? ''); ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               placeholder="https://example.com">
                    </div>

                    <!-- Thành phố -->
                    <div class="mb-4">
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Thành phố <span class="text-red-500">*</span>
                        </label>
                        <select name="company_city" class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                            <option value="">-- Chọn --</option>
                            <option value="Hà Nội" <?php echo ($recruiterProfile['company_city'] ?? '') === 'Hà Nội' ? 'selected' : ''; ?>>Hà Nội</option>
                            <option value="TP Hồ Chí Minh" <?php echo ($recruiterProfile['company_city'] ?? '') === 'TP Hồ Chí Minh' ? 'selected' : ''; ?>>TP Hồ Chí Minh</option>
                            <option value="Đà Nẵng" <?php echo ($recruiterProfile['company_city'] ?? '') === 'Đà Nẵng' ? 'selected' : ''; ?>>Đà Nẵng</option>
                            <option value="Hải Phòng" <?php echo ($recruiterProfile['company_city'] ?? '') === 'Hải Phòng' ? 'selected' : ''; ?>>Hải Phòng</option>
                            <option value="Cần Thơ" <?php echo ($recruiterProfile['company_city'] ?? '') === 'Cần Thơ' ? 'selected' : ''; ?>>Cần Thơ</option>
                        </select>
                    </div>

                    <!-- Địa chỉ chi tiết -->
                    <div class="mb-4">
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Địa chỉ chi tiết <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="company_address" value="<?php echo htmlspecialchars($recruiterProfile['company_address'] ?? ''); ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               placeholder="Tòa nhà, số nhà, tên đường, quận/huyện..." required>
                    </div>

                    <!-- Mô tả công ty -->
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Mô tả về công ty <span class="text-red-500">*</span>
                        </label>
                        <textarea name="company_description" rows="5" 
                                  class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                                  placeholder="Giới thiệu về công ty, lĩnh vực hoạt động, văn hóa doanh nghiệp..." 
                                  required><?php echo htmlspecialchars($recruiterProfile['company_description'] ?? ''); ?></textarea>
                        <p class="text-xs text-slate-500 mt-1">Tối thiểu 100 ký tự</p>
                    </div>
                </div>

                <!-- Thông tin pháp lý -->
                <div class="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-6">
                    <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                        <i class="fa-solid fa-file-contract text-green-500"></i> Thông tin pháp lý
                    </h3>
                    
                    <!-- Mã số thuế -->
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                            Mã số thuế
                        </label>
                        <input type="text" name="tax_code" value="<?php echo htmlspecialchars($recruiterProfile['tax_code'] ?? ''); ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               placeholder="VD: 0123456789">
                        <p class="text-xs text-slate-500 mt-1">Mã số thuế giúp xác minh tính hợp pháp của công ty</p>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="flex gap-4 justify-end pt-4 border-t border-slate-200 dark:border-slate-700">
                    <button type="button" onclick="document.getElementById('editCompanyModal').classList.add('hidden')" 
                            class="px-6 py-3 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 font-semibold transition">
                        Hủy
                    </button>
                    <button type="submit" 
                            class="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-lg font-semibold transition shadow-lg flex items-center gap-2">
                        <i class="fa-solid fa-save"></i> Lưu thay đổi
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
    // Handle form submission
    document.getElementById('editCompanyForm')?.addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        try {
            const response = await fetch('<?php echo BASE_URL; ?>api.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                alert('✅ Cập nhật hồ sơ công ty thành công!');
                location.reload();
            } else {
                alert('❌ Lỗi: ' + (data.message || 'Không thể cập nhật hồ sơ'));
            }
        } catch (error) {
            alert('❌ Lỗi: ' + error.message);
        }
    });
    </script>
    <?php endif; ?>

    <!-- Footer -->
    <footer class="bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 py-8 mt-16">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <p>&copy; 2024 AI Recruitment. Tất cả các quyền được bảo lưu.</p>
        </div>
    </footer>

    <script>
        function saveJob(event, jobId) {
            event.stopPropagation();
            const btn = event.target;
            
            if (btn.textContent === '❤️') {
                btn.textContent = '🤍';
                // Gọi API để lưu job
            } else {
                btn.textContent = '❤️';
                // Gọi API để xóa job
            }
        }
    </script>
</body>
</html>
