<?php
require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';

addSecurityHeaders();

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 12;
$offset = ($page - 1) * $limit;

// Search parameters
$keyword = isset($_GET['keyword']) ? sanitize($_GET['keyword']) : '';
$filters = [
    'city' => isset($_GET['location']) ? sanitize($_GET['location']) : '',
    'salary_min' => isset($_GET['salary_min']) ? (int)$_GET['salary_min'] : 0,
    'category' => isset($_GET['category']) ? sanitize($_GET['category']) : '',
    'job_type' => isset($_GET['job_type']) ? sanitize($_GET['job_type']) : '',
    'job_level' => isset($_GET['job_level']) ? sanitize($_GET['job_level']) : ''
];

// Get jobs with improved search
$jobModel = new Job();
$jobs = $jobModel->searchJobs($keyword, $filters, $limit, $offset);

// Get total count for pagination - need to count search results
$allResults = $jobModel->searchJobs($keyword, $filters, 10000, 0);
$totalJobs = count($allResults);
$totalPages = ceil($totalJobs / $limit);

// Check if search is active
$hasActiveSearch = !empty($keyword) || !empty($filters['city']) || !empty($filters['category']) || !empty($filters['job_type']) || !empty($filters['job_level']) || !empty($filters['salary_min']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tìm việc - AI Recruitment</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-50 dark:bg-slate-900">
    <!-- Navigation -->
    <nav class="bg-white dark:bg-slate-800 shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center gap-8">
                <a href="<?php echo BASE_URL; ?>index.php" class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition">AI Recruitment</a>
                <div class="hidden md:flex gap-6">
                    <a href="<?php echo BASE_URL; ?>index.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500">Trang chủ</a>
                    <a href="jobs-list.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500 font-semibold text-blue-500">Tìm việc</a>
                    <a href="companies.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500">Công ty</a>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <?php if (isLoggedIn()): ?>
                    <span class="text-slate-700 dark:text-slate-300">👤 <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                    <a href="../<?php echo $_SESSION['role']; ?>/dashboard.php" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded hover:bg-blue-500">
                        Trang cá nhân
                    </a>
                    <a href="../../logout.php" class="text-red-400 hover:underline">Đăng xuất</a>
                <?php else: ?>
                    <a href="../../login.php" class="text-blue-500 hover:underline font-semibold">Đăng nhập</a>
                    <a href="../../register.php" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded hover:bg-blue-500">Đăng ký</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <!-- Page Header -->
        <div class="mb-8">
            <h1 class="text-4xl font-bold mb-2">Tìm Việc Làm</h1>
            <p class="text-slate-700 dark:text-slate-300">Khám phá hàng nghìn cơ hội việc làm</p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <!-- Filters -->
            <div class="lg:col-span-1">
                <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 sticky top-24">
                    <h2 class="text-lg font-bold mb-6">🔍 Bộ lọc</h2>
                    
                    <form method="GET" action="jobs-list.php" class="space-y-4">
                        <!-- Keyword Search -->
                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Tìm kiếm</label>
                            <input type="text" name="keyword" placeholder="Vị trí, kỹ năng..." 
                                   value="<?php echo htmlspecialchars($keyword); ?>"
                                   class="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300/50 dark:border-slate-600/50 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500 text-slate-900 dark:text-white">
                        </div>

                        <!-- Location -->
                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Địa điểm</label>
                            <select name="location" class="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300/50 dark:border-slate-600/50 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500 text-slate-900 dark:text-white">
                                <option value="">-- Tất cả --</option>
                                <option value="Hà Nội" <?php echo $filters['city'] === 'Hà Nội' ? 'selected' : ''; ?>>Hà Nội</option>
                                <option value="TP Hồ Chí Minh" <?php echo $filters['city'] === 'TP Hồ Chí Minh' ? 'selected' : ''; ?>>TP Hồ Chí Minh</option>
                                <option value="Đà Nẵng" <?php echo $filters['city'] === 'Đà Nẵng' ? 'selected' : ''; ?>>Đà Nẵng</option>
                                <option value="Remote" <?php echo $filters['city'] === 'Remote' ? 'selected' : ''; ?>>Remote</option>
                            </select>
                        </div>

                        <!-- Category -->
                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Ngành</label>
                            <select name="category" class="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300/50 dark:border-slate-600/50 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500 text-slate-900 dark:text-white">
                                <option value="">-- Tất cả --</option>
                                <option value="Information Technology" <?php echo $filters['category'] === 'Information Technology' ? 'selected' : ''; ?>>CNTT</option>
                                <option value="Finance" <?php echo $filters['category'] === 'Finance' ? 'selected' : ''; ?>>Tài chính</option>
                                <option value="Marketing" <?php echo $filters['category'] === 'Marketing' ? 'selected' : ''; ?>>Marketing</option>
                                <option value="HR" <?php echo $filters['category'] === 'HR' ? 'selected' : ''; ?>>Nhân sự</option>
                                <option value="Sales" <?php echo $filters['category'] === 'Sales' ? 'selected' : ''; ?>>Bán hàng</option>
                            </select>
                        </div>

                        <!-- Job Type -->
                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Loại công việc</label>
                            <select name="job_type" class="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300/50 dark:border-slate-600/50 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500 text-slate-900 dark:text-white">
                                <option value="">-- Tất cả --</option>
                                <option value="full_time" <?php echo $filters['job_type'] === 'full_time' ? 'selected' : ''; ?>>Toàn thời gian</option>
                                <option value="part_time" <?php echo $filters['job_type'] === 'part_time' ? 'selected' : ''; ?>>Bán thời gian</option>
                                <option value="contract" <?php echo $filters['job_type'] === 'contract' ? 'selected' : ''; ?>>Hợp đồng</option>
                                <option value="remote" <?php echo $filters['job_type'] === 'remote' ? 'selected' : ''; ?>>Remote</option>
                            </select>
                        </div>

                        <!-- Job Level -->
                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Cấp độ</label>
                            <select name="job_level" class="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300/50 dark:border-slate-600/50 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500 text-slate-900 dark:text-white">
                                <option value="">-- Tất cả --</option>
                                <option value="junior" <?php echo $filters['job_level'] === 'junior' ? 'selected' : ''; ?>>Junior</option>
                                <option value="mid_level" <?php echo $filters['job_level'] === 'mid_level' ? 'selected' : ''; ?>>Mid-level</option>
                                <option value="senior" <?php echo $filters['job_level'] === 'senior' ? 'selected' : ''; ?>>Senior</option>
                                <option value="manager" <?php echo $filters['job_level'] === 'manager' ? 'selected' : ''; ?>>Quản lý</option>
                            </select>
                        </div>

                        <!-- Salary -->
                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Mức lương tối thiểu</label>
                            <input type="number" name="salary_min" placeholder="VD: 15000000" 
                                   value="<?php echo $filters['salary_min']; ?>"
                                   class="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300/50 dark:border-slate-600/50 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500 text-slate-900 dark:text-white">
                        </div>

                        <!-- Buttons -->
                        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-semibold text-sm transition">
                            🔍 Tìm kiếm
                        </button>
                        <a href="jobs-list.php" class="w-full bg-slate-300 dark:bg-slate-600 hover:bg-slate-400 dark:hover:bg-slate-700 text-slate-900 dark:text-white py-2 rounded-lg font-semibold text-sm text-center block transition">
                            ↻ Reset
                        </a>
                    </form>

                    <!-- Active Filters Summary -->
                    <?php if ($hasActiveSearch): ?>
                        <div class="mt-6 pt-6 border-t border-slate-200/50 dark:border-slate-700/50">
                            <p class="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2">✓ Đang lọc:</p>
                            <div class="flex flex-wrap gap-1">
                                <?php if (!empty($keyword)): ?>
                                    <span class="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 text-xs px-2 py-1 rounded">📌 <?php echo htmlspecialchars($keyword); ?></span>
                                <?php endif; ?>
                                <?php if (!empty($filters['city'])): ?>
                                    <span class="bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 text-xs px-2 py-1 rounded">📍 <?php echo htmlspecialchars($filters['city']); ?></span>
                                <?php endif; ?>
                                <?php if (!empty($filters['category'])): ?>
                                    <span class="bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 text-xs px-2 py-1 rounded">🏢 <?php echo htmlspecialchars($filters['category']); ?></span>
                                <?php endif; ?>
                                <?php if (!empty($filters['job_level'])): ?>
                                    <span class="bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 text-xs px-2 py-1 rounded">⭐ <?php echo ucfirst(str_replace('_', ' ', $filters['job_level'])); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Jobs List -->
            <div class="lg:col-span-3">
                <?php if (!empty($jobs)): ?>
                    <div class="space-y-6 mb-8">
                        <?php foreach ($jobs as $job): ?>
                            <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl hover:shadow-2xl transition p-6">
                                <div class="flex justify-between items-start mb-4">
                                    <div class="flex-1">
                                        <h3 class="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white mb-2">
                                            <a href="job-detail.php?id=<?php echo $job['id']; ?>" class="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                                                <?php echo htmlspecialchars($job['title']); ?>
                                            </a>
                                        </h3>
                                        <p class="text-blue-600 dark:text-blue-400 font-bold text-base flex items-center gap-2">
                                            <a href="company-profile.php?recruiter_id=<?php echo $job['recruiter_id']; ?>" class="hover:underline">
                                                🏢 <?php echo htmlspecialchars($job['company_name'] ?? 'Công ty'); ?>
                                            </a>
                                        </p>
                                    </div>
                                    <span class="bg-green-100 dark:bg-green-900/40 text-green-800 dark:text-green-300 text-sm font-bold px-4 py-2 rounded-lg border-2 border-green-400 dark:border-green-700 shadow-lg whitespace-nowrap ml-4">
                                        ✅ Đang tuyển
                                    </span>
                                </div>

                                <!-- Mô tả công việc -->
                                <div class="mb-4">
                                    <h4 class="text-sm font-semibold text-slate-600 dark:text-slate-400 mb-2">📋 Mô tả công việc</h4>
                                    <p class="text-slate-700 dark:text-slate-300">
                                        <?php echo htmlspecialchars(substr($job['description'] ?? '', 0, 150)); ?>...
                                    </p>
                                </div>

                                <!-- Thông tin công việc -->
                                <div class="mb-4">
                                    <h4 class="text-sm font-semibold text-slate-600 dark:text-slate-400 mb-2">ℹ️ Thông tin công việc</h4>
                                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-slate-700 dark:text-slate-300">
                                        <p>📍 <?php echo htmlspecialchars($job['location'] ?? 'Không xác định'); ?></p>
                                        <p>💰 <?php echo number_format($job['salary_min'] ?? 0, 0, '.', ','); ?> - <?php echo number_format($job['salary_max'] ?? 0, 0, '.', ','); ?> VND</p>
                                        <p>⏰ <?php echo $job['job_type']; ?></p>
                                        <p>📅 Hạn: <?php echo date('d/m/Y', strtotime($job['deadline'])); ?></p>
                                    </div>
                                </div>

                                <!-- Kỹ năng yêu cầu -->
                                <?php if ($job['required_skills']): ?>
                                <div class="mb-4">
                                    <h4 class="text-sm font-semibold text-slate-600 dark:text-slate-400 mb-2">🎯 Kỹ năng yêu cầu</h4>
                                    <div class="flex gap-2 flex-wrap">
                                        <?php foreach (array_slice(explode(',', $job['required_skills']), 0, 3) as $skill): ?>
                                            <span class="bg-blue-900/40 text-blue-300 text-xs px-2 py-1 rounded border border-blue-700">
                                                <?php echo htmlspecialchars(trim($skill)); ?>
                                            </span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <div class="flex gap-2 items-center">
                                    <a href="job-detail.php?id=<?php echo $job['id']; ?>" class="text-blue-500 font-semibold hover:underline flex-1">
                                        Xem chi tiết →
                                    </a>
                                    <?php if (isLoggedIn() && $_SESSION['role'] === 'candidate'): ?>
                                    <button onclick="checkJobMatch(<?php echo $job['id']; ?>, '<?php echo htmlspecialchars(addslashes($job['title'])); ?>')" 
                                            class="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 hover:scale-105 text-white text-sm px-3 py-2 rounded-lg shadow-lg shadow-indigo-500/20 transition transform">
                                        🎯 Check độ hợp
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <div class="flex justify-center gap-2 mb-8">
                            <?php if ($page > 1): ?>
                                <a href="?page=1&keyword=<?php echo urlencode($keyword); ?>&location=<?php echo urlencode($filters['city']); ?>&salary_min=<?php echo $filters['salary_min']; ?>" class="px-4 py-2 rounded border border-slate-200/50 dark:border-slate-700/50 hover:bg-white dark:bg-slate-800">« Đầu</a>
                                <a href="?page=<?php echo $page - 1; ?>&keyword=<?php echo urlencode($keyword); ?>&location=<?php echo urlencode($filters['city']); ?>&salary_min=<?php echo $filters['salary_min']; ?>" class="px-4 py-2 rounded border border-slate-200/50 dark:border-slate-700/50 hover:bg-white dark:bg-slate-800">‹ Trước</a>
                            <?php endif; ?>

                            <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                                <a href="?page=<?php echo $i; ?>&keyword=<?php echo urlencode($keyword); ?>&location=<?php echo urlencode($filters['city']); ?>&salary_min=<?php echo $filters['salary_min']; ?>" 
                                   class="px-4 py-2 rounded <?php echo $i === $page ? 'bg-blue-600 text-slate-900 dark:text-white' : 'border border-slate-200/50 dark:border-slate-700/50 hover:bg-white dark:bg-slate-800'; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>

                            <?php if ($page < $totalPages): ?>
                                <a href="?page=<?php echo $page + 1; ?>&keyword=<?php echo urlencode($keyword); ?>&location=<?php echo urlencode($filters['city']); ?>&salary_min=<?php echo $filters['salary_min']; ?>" class="px-4 py-2 rounded border border-slate-200/50 dark:border-slate-700/50 hover:bg-white dark:bg-slate-800">Sau ›</a>
                                <a href="?page=<?php echo $totalPages; ?>&keyword=<?php echo urlencode($keyword); ?>&location=<?php echo urlencode($filters['city']); ?>&salary_min=<?php echo $filters['salary_min']; ?>" class="px-4 py-2 rounded border border-slate-200/50 dark:border-slate-700/50 hover:bg-white dark:bg-slate-800">Cuối »</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="bg-yellow-900/40 border border-yellow-700 text-yellow-300 p-8 rounded text-center">
                        <p class="text-lg mb-4">Không tìm thấy công việc phù hợp</p>
                        <a href="jobs-list.php" class="text-blue-500 hover:underline font-semibold">Xóa bộ lọc →</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 py-8 mt-16">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <p>&copy; 2024 AI Recruitment. Tất cả các quyền được bảo lưu.</p>
        </div>
    </footer>

    <!-- Job Match Result Modal -->
    <div id="matchModal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div class="backdrop-blur-md bg-white/95 dark:bg-slate-800/95 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <!-- Modal Header -->
            <div class="sticky top-0 bg-white dark:bg-slate-800 p-6 border-b border-slate-200/50 dark:border-slate-700/50 flex justify-between items-center">
                <div>
                    <h2 class="text-2xl font-bold text-slate-900 dark:text-white">🎯 Độ phù hợp công việc</h2>
                    <p id="jobTitleMatch" class="text-slate-500 dark:text-slate-400 text-sm mt-1"></p>
                </div>
                <button onclick="document.getElementById('matchModal').classList.add('hidden')" class="text-3xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">×</button>
            </div>

            <!-- Modal Body -->
            <div id="matchContent" class="p-6 space-y-6">
                <div class="flex items-center justify-center">
                    <div class="w-20 h-20 border-4 border-blue-500 border-t-purple-500 rounded-full animate-spin"></div>
                </div>
                <p class="text-center text-slate-500 dark:text-slate-400">⏳ Đang phân tích...</p>
            </div>
        </div>
    </div>

    <script>
        window.checkJobMatch = async function(jobId, jobTitle) {
            const modal = document.getElementById('matchModal');
            const content = document.getElementById('matchContent');
            const titleEl = document.getElementById('jobTitleMatch');
            
            modal.classList.remove('hidden');
            titleEl.textContent = jobTitle;
            content.innerHTML = '<div class="flex items-center justify-center"><div class="w-20 h-20 border-4 border-blue-500 border-t-purple-500 rounded-full animate-spin"></div></div><p class="text-center text-slate-500 dark:text-slate-400">⏳ Đang phân tích...</p>';
            
            try {
                const response = await fetch('<?php echo BASE_URL; ?>api.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        action: 'match-job',
                        job_id: jobId
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    const analysis = data.data.analysis || {};
                    const score = data.data.score || 0;
                    
                    let html = `
                    <div class="text-center mb-6">
                        <div class="text-6xl font-bold mb-2 ${score >= 80 ? 'text-green-500' : score >= 60 ? 'text-yellow-500' : 'text-red-500'}">
                            ${score}%
                        </div>
                        <p class="text-slate-600 dark:text-slate-400">Mức độ phù hợp</p>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        ${analysis.pros && analysis.pros.length ? `
                        <div class="bg-green-900/20 border border-green-700/50 p-4 rounded-xl">
                            <h3 class="font-semibold text-green-500 mb-2">✅ Điểm mạnh</h3>
                            <ul class="text-sm text-slate-700 dark:text-slate-300 space-y-1">
                                ${analysis.pros.map(p => `<li>• ${p}</li>`).join('')}
                            </ul>
                        </div>
                        ` : ''}
                        
                        ${analysis.cons && analysis.cons.length ? `
                        <div class="bg-red-900/20 border border-red-700/50 p-4 rounded-xl">
                            <h3 class="font-semibold text-red-400 mb-2">⚠️ Điểm yếu</h3>
                            <ul class="text-sm text-slate-700 dark:text-slate-300 space-y-1">
                                ${analysis.cons.map(c => `<li>• ${c}</li>`).join('')}
                            </ul>
                        </div>
                        ` : ''}
                    </div>
                    
                    ${analysis.missing_skills && analysis.missing_skills.length ? `
                    <div class="bg-yellow-900/20 border border-yellow-700/50 p-4 rounded-xl">
                        <h3 class="font-semibold text-yellow-400 mb-2">🎓 Kỹ năng cần học</h3>
                        <div class="flex flex-wrap gap-2">
                            ${analysis.missing_skills.map(s => `<span class="bg-yellow-900/40 text-yellow-300 text-xs px-2 py-1 rounded border border-yellow-700">${s}</span>`).join('')}
                        </div>
                    </div>
                    ` : ''}
                    
                    ${analysis.reason ? `
                    <div class="bg-slate-100/50 dark:bg-slate-700/30 p-4 rounded-xl">
                        <p class="text-sm text-slate-700 dark:text-slate-300"><strong>💬 Nhận xét:</strong> ${analysis.reason}</p>
                    </div>
                    ` : ''}
                    
                    <div class="border-t border-slate-200/50 dark:border-slate-700/50 pt-4">
                        <p class="text-xs text-slate-500 dark:text-slate-400 mb-4">
                            ${score >= 80 ? '✨ Công việc này rất phù hợp với bạn!' : score >= 60 ? '👍 Bạn có khả năng đủ để ứng tuyển. Hãy cố gắng thêm!' : '💪 Hãy cải thiện kỹ năng trước khi ứng tuyển.'}
                        </p>
                        <a href="job-detail.php?id=${jobId}" class="block text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-lg transition">
                            Xem chi tiết công việc
                        </a>
                    </div>
                    `;
                    
                    content.innerHTML = html;
                } else {
                    content.innerHTML = `<div class="text-center p-8"><p class="text-red-500 font-semibold">❌ ${data.message || 'Lỗi phân tích'}</p></div>`;
                }
            } catch (error) {
                content.innerHTML = `<div class="text-center p-8"><p class="text-red-500 font-semibold">❌ Lỗi: ${error.message}</p></div>`;
            }
        }
    </script>
</body>
</html>
