<?php
require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';

addSecurityHeaders();

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 12;
$offset = ($page - 1) * $limit;

// Search
$keyword = isset($_GET['keyword']) ? sanitize($_GET['keyword']) : '';

// Get recruiters
$recruiterModel = new RecruiterProfile();
$jobModel = new Job();
$recruiters = $recruiterModel->getAllRecruiters(1000, 0);

// Get job counts for each recruiter and normalize location
foreach ($recruiters as &$recruiter) {
    $recruiterJobs = $jobModel->getJobsByRecruiter($recruiter['user_id']);
    $recruiter['total_jobs'] = count($recruiterJobs);
    $recruiter['active_jobs'] = count(array_filter($recruiterJobs, function($job) {
        return $job['status'] === 'active';
    }));
    
    // Đồng nhất thông tin địa điểm - ưu tiên địa chỉ đầy đủ
    $locationParts = [];
    if (!empty($recruiter['company_address'])) {
        $locationParts[] = $recruiter['company_address'];
    }
    if (!empty($recruiter['company_city']) && !stripos($recruiter['company_address'] ?? '', $recruiter['company_city'])) {
        $locationParts[] = $recruiter['company_city'];
    }
    
    if (!empty($locationParts)) {
        $recruiter['display_location'] = implode(', ', $locationParts);
    } elseif (!empty($recruiter['location'])) {
        $recruiter['display_location'] = $recruiter['location'];
    } else {
        $recruiter['display_location'] = 'Không xác định';
    }
}

$totalRecruiters = count($recruiters);
$totalPages = ceil($totalRecruiters / $limit);

// Filter by keyword if provided
if (!empty($keyword)) {
    $recruiters = array_filter($recruiters, function ($recruiter) use ($keyword) {
        return stripos($recruiter['company_name'], $keyword) !== false || 
               stripos($recruiter['industry'], $keyword) !== false;
    });
}

// Paginate
$recruiters = array_slice($recruiters, $offset, $limit);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách công ty - AI Recruitment</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-50 dark:bg-slate-900">
    <!-- Navigation -->
    <nav class="bg-white dark:bg-slate-800 shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center gap-8">
                <a href="<?php echo BASE_URL; ?>index.php" class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition">AI Recruitment</a>
                <div class="hidden md:flex gap-6">
                    <a href="<?php echo BASE_URL; ?>index.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500">Trang chủ</a>
                    <a href="jobs-list.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500">Tìm việc</a>
                    <a href="companies.php" class="text-slate-700 dark:text-slate-300 hover:text-blue-500 font-semibold text-blue-500">Công ty</a>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <?php if (isLoggedIn()): ?>
                    <span class="text-slate-700 dark:text-slate-300">👤 <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                    <a href="../<?php echo $_SESSION['role']; ?>/dashboard.php" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded hover:bg-blue-500">
                        Trang cá nhân
                    </a>
                    <a href="../../logout.php" class="text-red-400 hover:underline">Đăng xuất</a>
                <?php else: ?>
                    <a href="../../login.php" class="text-blue-500 hover:underline font-semibold">Đăng nhập</a>
                    <a href="../../register.php" class="bg-blue-600 text-slate-900 dark:text-white px-4 py-2 rounded hover:bg-blue-500">Đăng ký</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <!-- Page Header -->
        <div class="mb-8">
            <h1 class="text-4xl font-bold mb-2">Danh Sách Công Ty</h1>
            <p class="text-slate-700 dark:text-slate-300">Khám phá các công ty đang tuyển dụng</p>
        </div>

        <!-- Search -->
        <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mb-8">
            <form method="GET" action="companies.php" class="flex gap-4">
                <div class="flex-1">
                    <input type="text" name="keyword" placeholder="Tìm công ty, ngành..." 
                           value="<?php echo htmlspecialchars($keyword); ?>"
                           class="w-full px-4 py-3 rounded border border-slate-200/50 dark:border-slate-700/50 focus:outline-none focus:border-blue-500">
                </div>
                <button type="submit" class="bg-blue-600 text-slate-900 dark:text-white px-8 py-3 rounded hover:bg-blue-500 font-semibold">
                    Tìm kiếm
                </button>
                <a href="companies.php" class="bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white px-8 py-3 rounded hover:bg-gray-300 font-semibold">
                    Xóa
                </a>
            </form>
        </div>

        <!-- Companies Grid -->
        <?php if (!empty($recruiters)): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <?php foreach ($recruiters as $recruiter): ?>
                    <a href="company-profile.php?recruiter_id=<?php echo $recruiter['user_id']; ?>" 
                       class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl hover:shadow-2xl transition p-6 hover:border-blue-400 dark:hover:border-blue-400">
                        
                        <!-- Company Header -->
                        <div class="mb-4 pb-4 border-b border-slate-200 dark:border-slate-700">
                            <h3 class="text-xl font-bold tracking-tight text-slate-900 dark:text-white mb-2 hover:text-blue-500">
                                <?php echo htmlspecialchars($recruiter['company_name']); ?>
                            </h3>
                            <p class="text-slate-600 dark:text-slate-400 text-sm font-medium">
                                <?php echo htmlspecialchars($recruiter['industry'] ?? 'Không xác định'); ?>
                            </p>
                        </div>

                        <!-- Company Info Grid -->
                        <div class="space-y-3 mb-4">
                            <!-- Ngành nghề -->
                            <div>
                                <h4 class="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wide">Ngành nghề</h4>
                                <p class="text-sm text-slate-700 dark:text-slate-300 flex items-center gap-2">
                                    <span>🏢</span>
                                    <span><?php echo htmlspecialchars($recruiter['industry'] ?? 'Công nghệ thông tin'); ?></span>
                                </p>
                            </div>

                            <!-- Quy mô công ty -->
                            <div>
                                <h4 class="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wide">Quy mô công ty</h4>
                                <p class="text-sm text-slate-700 dark:text-slate-300 flex items-center gap-2">
                                    <span>👥</span>
                                    <span><?php echo htmlspecialchars($recruiter['company_size'] ?? 'Không xác định'); ?></span>
                                </p>
                            </div>

                            <!-- Địa điểm -->
                            <div>
                                <h4 class="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wide">Địa điểm</h4>
                                <p class="text-sm text-slate-700 dark:text-slate-300 flex items-center gap-2">
                                    <span>📍</span>
                                    <span><?php echo htmlspecialchars($recruiter['display_location']); ?></span>
                                </p>
                            </div>

                            <!-- Công việc đang tuyển -->
                            <div>
                                <h4 class="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wide">Công việc đang tuyển</h4>
                                <p class="text-sm font-bold flex items-center gap-2">
                                    <span>📢</span>
                                    <span class="text-green-600 dark:text-green-400"><?php echo $recruiter['active_jobs'] ?? 0; ?> vị trí</span>
                                </p>
                            </div>
                        </div>

                        <button class="w-full bg-blue-600 text-white py-2.5 rounded-lg hover:bg-blue-700 transition font-semibold flex items-center justify-center gap-2">
                            <span>Xem trang công ty</span>
                            <span>→</span>
                        </button>
                    </a>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="flex justify-center gap-2 mb-8">
                    <?php if ($page > 1): ?>
                        <a href="?page=1&keyword=<?php echo urlencode($keyword); ?>" class="px-4 py-2 rounded border border-slate-200/50 dark:border-slate-700/50 hover:bg-white dark:bg-slate-800">« Đầu</a>
                        <a href="?page=<?php echo $page - 1; ?>&keyword=<?php echo urlencode($keyword); ?>" class="px-4 py-2 rounded border border-slate-200/50 dark:border-slate-700/50 hover:bg-white dark:bg-slate-800">‹ Trước</a>
                    <?php endif; ?>

                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                        <a href="?page=<?php echo $i; ?>&keyword=<?php echo urlencode($keyword); ?>" 
                           class="px-4 py-2 rounded <?php echo $i === $page ? 'bg-blue-600 text-slate-900 dark:text-white' : 'border border-slate-200/50 dark:border-slate-700/50 hover:bg-white dark:bg-slate-800'; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&keyword=<?php echo urlencode($keyword); ?>" class="px-4 py-2 rounded border border-slate-200/50 dark:border-slate-700/50 hover:bg-white dark:bg-slate-800">Sau ›</a>
                        <a href="?page=<?php echo $totalPages; ?>&keyword=<?php echo urlencode($keyword); ?>" class="px-4 py-2 rounded border border-slate-200/50 dark:border-slate-700/50 hover:bg-white dark:bg-slate-800">Cuối »</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="bg-yellow-50 border border-yellow-200 text-yellow-800 p-8 rounded text-center">
                <p class="text-lg mb-4">Không tìm thấy công ty phù hợp</p>
                <a href="companies.php" class="text-blue-500 hover:underline font-semibold">Xóa bộ lọc →</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer class="bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 py-8 mt-16">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <p>&copy; 2024 AI Recruitment. Tất cả các quyền được bảo lưu.</p>
        </div>
    </footer>
</body>
</html>
