<?php
require_once '../../config/init.php';
require_once '../../utils/middleware/Auth.php';
require_once '../../utils/models/User.php';
require_once '../../utils/models/CandidateProfile.php';
require_once '../../utils/models/Application.php';
require_once '../../utils/models/Job.php';
require_once '../../utils/models/RecruiterProfile.php';
require_once '../../utils/models/CompanyReview.php';
require_once '../../utils/models/SavedJob.php';

addSecurityHeaders();

$jobId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$jobId) {
    redirect('../../index.php');
}

$jobModel = new Job();
$job = $jobModel->getJobById($jobId);

if (!$job || $job['status'] !== 'active') {
    redirect('../../index.php');
}

// Tăng lượt xem khi có người xem job
$jobModel->incrementViewCount($jobId);

// Get recruiter info
$userModel = new User();
$recruiter = $userModel->getUserById($job['recruiter_id']);
$recruiterModel = new RecruiterProfile();
$recruiterProfile = $recruiterModel->getProfileByUserId($job['recruiter_id']);

// Get company reviews - lấy company_id từ recruiter profile
$companyId = $recruiterProfile['id'] ?? 0;
$reviewModel = new CompanyReview();
$reviews = $reviewModel->getCompanyReviews($companyId, 3);
$ratingStats = $reviewModel->getCompanyRatingStats($companyId);

// Get similar jobs
$similarJobs = $jobModel->getSimilarJobs(
    $jobId, 
    $job['category'] ?? '', 
    $job['city'] ?? '', 
    $job['required_skills'] ?? '',
    6
);

// Check if job is saved
$isSaved = false;
if (isLoggedIn() && $_SESSION['role'] === 'candidate') {
    $savedJobModel = new SavedJob();
    $isSaved = $savedJobModel->isSaved($_SESSION['user_id'], $jobId);
}

// Check if user has applied
$hasApplied = false;
$applicationStatus = null;
$userCV = null;
if (isLoggedIn() && $_SESSION['role'] === 'candidate') {
    $appModel = new Application();
    $existingApp = $appModel->getApplicationByJobAndCandidate($jobId, $_SESSION['user_id']);
    
    // Chỉ coi là đã ứng tuyển nếu status không phải withdrawn
    if ($existingApp && $existingApp['status'] !== 'withdrawn') {
        $hasApplied = true;
        $applicationStatus = $existingApp['status'];
    }
    
    // Get candidate's CV (ensure profile exists)
    $candidateModel = new CandidateProfile();
    $profile = $candidateModel->getProfile($_SESSION['user_id']);
    
    // If profile doesn't exist, create it
    if (!$profile) {
        $candidateModel->createProfile($_SESSION['user_id']);
        $profile = $candidateModel->getProfile($_SESSION['user_id']);
    }
    
    $userCV = $profile['cv_file_url'] ?? null;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($job['title']); ?> - AI Recruitment</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 min-h-screen text-slate-900 dark:text-white transition-colors duration-300">
    <!-- Navigation -->
    <nav class="bg-white shadow sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center gap-8">
                <a href="<?php echo BASE_URL; ?>index.php" class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition">AI Recruitment</a>
                <div class="hidden md:flex gap-6">
                    <a href="<?php echo BASE_URL; ?>index.php" class="text-gray-700 hover:text-blue-500">Trang chủ</a>
                    <a href="jobs-list.php" class="text-gray-700 hover:text-blue-500">Tìm việc</a>
                    <a href="companies.php" class="text-gray-700 hover:text-blue-500">Công ty</a>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <?php if (isLoggedIn()): ?>
                    <span class="text-gray-700">👤 <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                    <a href="../<?php echo $_SESSION['role']; ?>/dashboard.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-500">
                        Trang cá nhân
                    </a>
                    <a href="../../logout.php" class="text-red-400 hover:underline">Đăng xuất</a>
                <?php else: ?>
                    <a href="../../login.php" class="text-blue-500 hover:underline font-semibold">Đăng nhập</a>
                    <a href="../../register.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-500">Đăng ký</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <a href="jobs-list.php" class="text-blue-600 dark:text-blue-400 hover:underline mb-6 inline-block font-medium">← Quay lại danh sách</a>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Main Content -->
            <div class="lg:col-span-2">
                <!-- Job Header -->
                <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl hover:shadow-2xl transition p-8 mb-6">
                    <div class="flex justify-between items-start mb-6">
                        <div>
                            <h1 class="text-4xl font-extrabold text-slate-900 dark:text-white mb-2"><?php echo htmlspecialchars($job['title']); ?></h1>
                            <p class="text-xl text-blue-600 dark:text-blue-400 font-bold">
                                <a href="company-profile.php?recruiter_id=<?php echo $job['recruiter_id']; ?>" class="hover:underline">
                                    <?php echo htmlspecialchars($recruiterProfile['company_name'] ?? 'Công ty'); ?>
                                </a>
                            </p>
                        </div>
                        <span class="bg-green-100 dark:bg-green-900/40 text-green-800 dark:text-green-300 text-lg font-bold px-4 py-2 rounded-lg border-2 border-green-400 dark:border-green-700">Đang tuyển</span>
                    </div>

                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 pb-6 border-b-2 border-slate-200 dark:border-slate-700">
                        <div>
                            <p class="text-slate-600 dark:text-slate-400 text-sm font-medium">Địa điểm</p>
                            <p class="font-bold text-slate-900 dark:text-white">📍 <?php echo htmlspecialchars($job['location']); ?></p>
                        </div>
                        <div>
                            <p class="text-slate-600 dark:text-slate-400 text-sm font-medium">Mức lương</p>
                            <p class="font-bold text-slate-900 dark:text-white">💰 <?php echo number_format($job['salary_min'], 0, '.', ','); ?> - <?php echo number_format($job['salary_max'], 0, '.', ','); ?> VND</p>
                        </div>
                        <div>
                            <p class="text-slate-600 dark:text-slate-400 text-sm font-medium">Loại hình</p>
                            <p class="font-bold text-slate-900 dark:text-white">⏰ <?php echo htmlspecialchars($job['job_type']); ?></p>
                        </div>
                        <div>
                            <p class="text-slate-600 dark:text-slate-400 text-sm font-medium">Hạn nộp</p>
                            <p class="font-bold text-slate-900 dark:text-white">📅 <?php echo !empty($job['deadline']) ? date('d/m/Y', strtotime($job['deadline'])) : 'Chưa xác định'; ?></p>
                        </div>
                    </div>
                </div>

                <!-- Job Description -->
                <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl hover:shadow-2xl transition p-8 mb-6">
                    <h2 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white mb-4">Mô tả công việc</h2>
                    <div class="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                        <?php echo htmlspecialchars($job['description']); ?>
                    </div>
                </div>

                <!-- Requirements -->
                <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl hover:shadow-2xl transition p-8 mb-6">
                    <h2 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white mb-4">Yêu cầu công việc</h2>
                    <div class="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                        <?php echo htmlspecialchars($job['requirements'] ?? 'Không có yêu cầu cụ thể'); ?>
                    </div>
                </div>

                <!-- Skills -->
                <?php if ($job['required_skills']): ?>
                    <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl hover:shadow-2xl transition p-8 mb-6">
                        <h2 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white mb-4">Kỹ năng yêu cầu</h2>
                        <div class="flex gap-2 flex-wrap">
                            <?php foreach (explode(',', $job['required_skills']) as $skill): ?>
                                <span class="bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-300 px-4 py-2 rounded-full font-medium border-2 border-blue-300 dark:border-blue-700">
                                    <?php echo htmlspecialchars(trim($skill)); ?>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Benefits -->
                <?php if ($job['benefits']): ?>
                    <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl hover:shadow-2xl transition p-8 mb-6">
                        <h2 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white mb-4">Quyền lợi</h2>
                        <div class="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                            <?php echo htmlspecialchars($job['benefits']); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Benefits Highlights -->
                <?php if ($job['benefits']): 
                    // Parse benefits to create highlights
                    $benefitsText = $job['benefits'];
                    $commonBenefits = [
                        ['icon' => '💰', 'keyword' => ['lương', 'thưởng', 'bonus', 'salary'], 'title' => 'Lương thưởng hấp dẫn'],
                        ['icon' => '🏥', 'keyword' => ['bảo hiểm', 'insurance', 'y tế', 'health'], 'title' => 'Bảo hiểm đầy đủ'],
                        ['icon' => '🏖️', 'keyword' => ['nghỉ phép', 'du lịch', 'vacation', 'holiday'], 'title' => 'Nghỉ phép & du lịch'],
                        ['icon' => '📚', 'keyword' => ['đào tạo', 'training', 'học', 'khóa học'], 'title' => 'Đào tạo & phát triển'],
                        ['icon' => '🏠', 'keyword' => ['flexible', 'remote', 'wfh', 'làm từ xa', 'linh hoạt'], 'title' => 'Làm việc linh hoạt'],
                        ['icon' => '🎯', 'keyword' => ['thăng tiến', 'career', 'promotion', 'phát triển'], 'title' => 'Cơ hội thăng tiến'],
                    ];
                    
                    $highlightedBenefits = [];
                    foreach ($commonBenefits as $benefit) {
                        foreach ($benefit['keyword'] as $keyword) {
                            if (stripos($benefitsText, $keyword) !== false) {
                                $highlightedBenefits[] = $benefit;
                                break;
                            }
                        }
                    }
                ?>
                    <?php if (!empty($highlightedBenefits)): ?>
                        <div class="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-2xl border-2 border-blue-300 dark:border-blue-700 shadow-xl p-8 mb-6">
                            <h2 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                                <span class="text-blue-600 dark:text-blue-400">✨</span>
                                Điểm nổi bật về phúc lợi
                            </h2>
                            <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                                <?php foreach ($highlightedBenefits as $benefit): ?>
                                    <div class="bg-white dark:bg-slate-800 rounded-xl p-4 shadow-sm hover:shadow-lg border-2 border-slate-200 dark:border-slate-700 transition">
                                        <div class="text-3xl mb-2"><?php echo $benefit['icon']; ?></div>
                                        <p class="font-bold text-slate-900 dark:text-white text-sm">
                                            <?php echo $benefit['title']; ?>
                                        </p>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <!-- Similar Jobs -->
                <?php if (!empty($similarJobs)): ?>
                    <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-8">
                        <div class="flex justify-between items-center mb-6">
                            <h2 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Việc làm tương tự</h2>
                            <a href="jobs-list.php?category=<?php echo urlencode($job['category']); ?>" class="text-blue-600 dark:text-blue-400 hover:underline text-sm font-bold">
                                Xem thêm →
                            </a>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <?php foreach ($similarJobs as $similarJob): ?>
                                <a href="job-detail.php?id=<?php echo $similarJob['id']; ?>" 
                                   class="block bg-slate-50 dark:bg-slate-700/50 rounded-xl p-5 hover:shadow-lg hover:border-blue-400 dark:hover:border-blue-500 border-2 border-slate-200 dark:border-slate-600 transition group">
                                    <div class="flex items-start gap-4 mb-3">
                                        <?php if (!empty($similarJob['company_logo_url'])): ?>
                                            <img src="<?php echo BASE_URL . htmlspecialchars($similarJob['company_logo_url']); ?>" 
                                                 alt="Logo" 
                                                 class="w-12 h-12 rounded-lg object-cover">
                                        <?php else: ?>
                                            <div class="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center text-white font-bold">
                                                <?php echo strtoupper(substr($similarJob['company_name'] ?? 'C', 0, 1)); ?>
                                            </div>
                                        <?php endif; ?>
                                        <div class="flex-1 min-w-0">
                                            <h3 class="font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition truncate">
                                                <?php echo htmlspecialchars($similarJob['title']); ?>
                                            </h3>
                                            <p class="text-sm text-slate-600 dark:text-slate-400 truncate">
                                                <?php echo htmlspecialchars($similarJob['company_name'] ?? 'Công ty'); ?>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-3 text-xs text-slate-600 dark:text-slate-400 font-medium">
                                        <span class="flex items-center gap-1">
                                            📍 <?php echo htmlspecialchars($similarJob['city'] ?? $similarJob['location']); ?>
                                        </span>
                                        <span class="flex items-center gap-1">
                                            💰 <?php echo number_format($similarJob['salary_min'], 0, '.', ','); ?>đ
                                        </span>
                                    </div>
                                    <?php if (!empty($similarJob['required_skills'])): ?>
                                        <div class="flex gap-2 flex-wrap mt-3">
                                            <?php 
                                            $skills = array_slice(explode(',', $similarJob['required_skills']), 0, 3);
                                            foreach ($skills as $skill): 
                                            ?>
                                                <span class="bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-300 px-2 py-1 rounded text-xs font-medium border border-blue-300 dark:border-blue-700">
                                                    <?php echo htmlspecialchars(trim($skill)); ?>
                                                </span>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="lg:col-span-1">
                <!-- Save Button -->
                <?php if (isLoggedIn() && $_SESSION['role'] === 'candidate'): ?>
                <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mb-6 sticky top-24">
                    <button onclick="toggleSaveJob(<?php echo $jobId; ?>)" id="save-job-btn" class="w-full <?php echo $isSaved ? 'bg-yellow-100 dark:bg-yellow-900/40 border-2 border-yellow-400 dark:border-yellow-700 text-yellow-800 dark:text-yellow-300' : 'bg-slate-100 dark:bg-slate-700 border-2 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300'; ?> py-3 rounded-xl font-bold hover:shadow-lg transition flex items-center justify-center gap-2">
                        <span id="save-icon"><?php echo $isSaved ? '🔖' : '📑'; ?></span>
                        <span id="save-text"><?php echo $isSaved ? 'Đã lưu tin' : 'Lưu tin'; ?></span>
                    </button>
                </div>
                <?php endif; ?>

                <!-- Apply Button -->
                <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mb-6 sticky top-24">
                    <?php if (isLoggedIn() && $_SESSION['role'] === 'candidate'): ?>
                        <?php if ($hasApplied): ?>
                            <div class="bg-green-100 dark:bg-green-900/40 border-2 border-green-400 dark:border-green-700 text-green-800 dark:text-green-300 p-4 rounded-xl text-center font-bold">
                                <p class="font-bold">✅ Bạn đã ứng tuyển</p>
                                <p class="text-sm mt-2">Chúc bạn may mắn!</p>
                            </div>
                        <?php elseif (empty($userCV)): ?>
                            <div class="bg-yellow-100 dark:bg-yellow-900/40 border-2 border-yellow-400 dark:border-yellow-700 text-yellow-800 dark:text-yellow-300 p-4 rounded-xl text-center mb-4 font-bold">
                                <p class="font-bold mb-3">📄 Bạn cần tải CV để ứng tuyển</p>
                                <p class="text-sm mb-4">Hãy tải CV của bạn để hoàn thành hồ sơ</p>
                                <a href="<?php echo BASE_URL; ?>views/candidate/upload-cv.php" class="inline-block bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-6 py-2.5 rounded-lg font-bold shadow-lg shadow-blue-500/30 transition transform hover:-translate-y-0.5">
                                    📤 Tải CV ngay
                                </a>
                            </div>
                        <?php else: ?>
                            <form method="POST" action="../../api.php" id="apply-form">
                                <input type="hidden" name="action" value="apply-job">
                                <input type="hidden" name="job_id" value="<?php echo $jobId; ?>">
                                <?php if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); ?>
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <button type="submit" class="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white py-3 rounded-xl font-bold shadow-lg shadow-blue-500/30 transition transform hover:-translate-y-0.5">
                                    🚀 Ứng tuyển ngay
                                </button>
                            </form>
                        <?php endif; ?>
                    <?php elseif (isLoggedIn()): ?>
                        <div class="bg-yellow-100 dark:bg-yellow-900/40 border-2 border-yellow-400 dark:border-yellow-700 text-yellow-800 dark:text-yellow-300 p-4 rounded-xl text-center font-bold">
                            <p class="font-bold">Bạn cần là ứng viên để ứng tuyển</p>
                        </div>
                    <?php else: ?>
                        <a href="../../login.php" class="w-full block bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white py-3 rounded-xl font-bold shadow-lg shadow-blue-500/30 transition transform hover:-translate-y-0.5 text-center">
                            🔐 Đăng nhập để ứng tuyển
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Report Button -->
                <div class="mb-6">
                    <button onclick='moModalBaoCao(<?php echo $jobId; ?>, "<?php echo htmlspecialchars($job['title'], ENT_QUOTES); ?>")' class="w-full bg-red-100 dark:bg-red-900/40 border-2 border-red-400 dark:border-red-700 text-red-800 dark:text-red-300 py-3 rounded-xl font-bold hover:bg-red-200 dark:hover:bg-red-900/60 transition flex items-center justify-center gap-2">
                        🚩 Báo cáo vi phạm
                    </button>
                </div>

                <!-- Company Info -->
                <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6">
                    <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-4">Về công ty</h3>
                    <p class="font-bold text-blue-600 dark:text-blue-400 mb-2 text-lg">
                        <a href="company-profile.php?recruiter_id=<?php echo $job['recruiter_id']; ?>" class="hover:underline">
                            <?php echo htmlspecialchars($recruiterProfile['company_name'] ?? 'Công ty'); ?>
                        </a>
                    </p>
                    
                    <div class="space-y-2 text-slate-700 dark:text-slate-300 text-sm mb-4">
                        <p><strong>Quy mô:</strong> <?php echo htmlspecialchars($recruiterProfile['company_size'] ?? 'Không xác định'); ?></p>
                        <p><strong>Ngành:</strong> <?php echo htmlspecialchars($recruiterProfile['industry'] ?? 'Không xác định'); ?></p>
                        <p><strong>Địa điểm:</strong> <?php echo htmlspecialchars($recruiterProfile['location'] ?? 'Không xác định'); ?></p>
                    </div>

                    <a href="company-profile.php?recruiter_id=<?php echo $job['recruiter_id']; ?>" class="text-blue-600 dark:text-blue-400 font-bold hover:underline">
                        Xem trang công ty →
                    </a>
                </div>

                <!-- Company Reviews -->
                <div class="bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm rounded-2xl border-2 border-slate-300 dark:border-slate-600 shadow-xl p-6 mt-6">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-bold text-slate-900 dark:text-white">Đánh giá công ty</h3>
                        <?php if (isLoggedIn() && $_SESSION['role'] === 'candidate'): ?>
                            <a href="<?php echo BASE_URL; ?>views/candidate/write-review.php?company_id=<?php echo $companyId; ?>&redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>" class="text-sm bg-blue-600 dark:bg-blue-500 text-white px-3 py-1.5 rounded-lg hover:bg-blue-700 dark:hover:bg-blue-600 transition font-bold">
                                ✍️ Viết đánh giá
                            </a>
                        <?php endif; ?>
                    </div>

                    <!-- Overall Rating -->
                    <?php if ($ratingStats && $ratingStats['total_reviews'] > 0): ?>
                        <div class="flex items-center gap-4 mb-6 pb-6 border-b-2 border-slate-200 dark:border-slate-700">
                            <div class="text-center">
                                <div class="text-4xl font-extrabold text-blue-600 dark:text-blue-400">
                                    <?php echo number_format($ratingStats['average_rating'], 1); ?>
                                </div>
                                <div class="flex gap-1 justify-center mt-1">
                                    <?php 
                                    $avgRating = round($ratingStats['average_rating']);
                                    for ($i = 1; $i <= 5; $i++) {
                                        echo $i <= $avgRating ? '<span class="text-yellow-400">⭐</span>' : '<span class="text-slate-300 dark:text-slate-600">⭐</span>';
                                    }
                                    ?>
                                </div>
                                <p class="text-xs text-slate-600 dark:text-slate-400 mt-2 font-medium">(<?php echo $ratingStats['total_reviews']; ?> reviews)</p>
                            </div>
                            <div class="flex-1 space-y-2">
                                <?php 
                                $totalReviews = $ratingStats['total_reviews'];
                                $stars = [5, 4, 3, 2, 1];
                                foreach ($stars as $star) {
                                    $count = $ratingStats[$star . '_star'] ?? 0;
                                    $percentage = $totalReviews > 0 ? ($count / $totalReviews) * 100 : 0;
                                    ?>
                                    <div class="flex items-center gap-2">
                                        <span class="text-xs text-slate-700 dark:text-slate-300 font-medium"><?php echo $star; ?>⭐</span>
                                        <div class="flex-1 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                                            <div class="h-full bg-yellow-400" style="width: <?php echo $percentage; ?>%"></div>
                                        </div>
                                        <span class="text-xs text-slate-700 dark:text-slate-300 w-8 text-right font-medium"><?php echo $count; ?></span>
                                    </div>
                                    <?php 
                                }
                                ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Reviews List -->
                    <div class="space-y-4 max-h-96 overflow-y-auto">
                        <?php if (!empty($reviews)): ?>
                            <?php foreach ($reviews as $review): ?>
                                <div class="pb-4 border-b-2 border-slate-200 dark:border-slate-700 last:border-b-0">
                                    <div class="flex items-center justify-between mb-2">
                                        <div class="flex items-center gap-2">
                                            <div class="w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold">
                                                <?php echo strtoupper(substr($review['full_name'], 0, 1)); ?>
                                            </div>
                                            <div>
                                                <p class="font-bold text-slate-900 dark:text-white">
                                                    <?php echo htmlspecialchars($review['full_name']); ?>
                                                </p>
                                                <p class="text-xs text-slate-600 dark:text-slate-400">
                                                    <?php echo htmlspecialchars($review['job_position'] ?? 'Không xác định'); ?>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="flex gap-0.5">
                                            <?php 
                                            for ($i = 1; $i <= 5; $i++) {
                                                echo $i <= $review['rating'] ? '<span class="text-yellow-400">⭐</span>' : '<span class="text-slate-300 dark:text-slate-600">⭐</span>';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <p class="font-bold text-slate-900 dark:text-white text-sm mb-1">
                                        <?php echo htmlspecialchars($review['title']); ?>
                                    </p>
                                    <p class="text-sm text-slate-700 dark:text-slate-300">
                                        <?php echo htmlspecialchars($review['comment']); ?>
                                    </p>
                                    <div class="flex gap-2 mt-2">
                                        <span class="text-xs bg-green-100 dark:bg-green-900/40 text-green-800 dark:text-green-300 px-2 py-1 rounded font-medium border border-green-300 dark:border-green-700">✓ Verified Employee</span>
                                        <span class="text-xs text-slate-600 dark:text-slate-400 font-medium">
                                            <?php 
                                            $date = new DateTime($review['created_at']);
                                            $interval = $date->diff(new DateTime());
                                            if ($interval->days == 0) {
                                                echo 'Hôm nay';
                                            } elseif ($interval->days == 1) {
                                                echo 'Hôm qua';
                                            } elseif ($interval->days < 30) {
                                                echo $interval->days . ' ngày trước';
                                            } else {
                                                echo $interval->m . ' tháng trước';
                                            }
                                            ?>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-slate-500 dark:text-slate-400 text-center py-4 font-medium">Chưa có đánh giá nào</p>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($reviews)): ?>
                        <div class="mt-4">
                            <a href="company-profile.php?recruiter_id=<?php echo $job['recruiter_id']; ?>#reviews" class="text-blue-600 dark:text-blue-400 font-bold hover:underline text-sm">
                                Xem tất cả đánh giá →
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-white text-gray-500 py-8 mt-16">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <p>&copy; 2024 AI Recruitment. Tất cả các quyền được bảo lưu.</p>
        </div>
    </footer>

    <script>
        // Toggle Save Job
        async function toggleSaveJob(jobId) {
            const btn = document.getElementById('save-job-btn');
            const icon = document.getElementById('save-icon');
            const text = document.getElementById('save-text');
            const originalHTML = btn.innerHTML;
            
            btn.disabled = true;
            btn.innerHTML = '⏳ Đang xử lý...';
            
            try {
                const formData = new FormData();
                formData.append('action', 'toggle-save-job');
                formData.append('job_id', jobId);
                formData.append('csrf_token', '<?php echo $_SESSION['csrf_token'] ?? ''; ?>');
                
                const response = await fetch('../../api.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Update button UI
                    if (data.saved) {
                        btn.className = 'w-full bg-yellow-100 dark:bg-yellow-900/40 border-2 border-yellow-400 dark:border-yellow-700 text-yellow-800 dark:text-yellow-300 py-3 rounded-xl font-bold hover:shadow-lg transition flex items-center justify-center gap-2';
                        icon.textContent = '🔖';
                        text.textContent = 'Đã lưu tin';
                    } else {
                        btn.className = 'w-full bg-slate-100 dark:bg-slate-700 border-2 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 py-3 rounded-xl font-bold hover:shadow-lg transition flex items-center justify-center gap-2';
                        icon.textContent = '📑';
                        text.textContent = 'Lưu tin';
                    }
                    
                    // Show toast notification
                    const toast = document.createElement('div');
                    toast.className = 'fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 font-bold';
                    toast.textContent = data.message;
                    document.body.appendChild(toast);
                    setTimeout(() => toast.remove(), 3000);
                } else {
                    alert('❌ ' + data.message);
                    btn.innerHTML = originalHTML;
                }
                
                btn.disabled = false;
            } catch (error) {
                console.error('Save Error:', error);
                alert('❌ Lỗi: ' + error.message);
                btn.innerHTML = originalHTML;
                btn.disabled = false;
            }
        }

        // Report Modal Function
        window.moModalBaoCao = function(jobId, jobTitle) {
            console.log('moModalBaoCao called:', jobId, jobTitle);
            const modalHTML = `
                <div class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                    <div class="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-96 overflow-y-auto">
                        <div class="bg-gradient-to-r from-red-600 to-red-700 text-white p-6">
                            <div class="flex justify-between items-center">
                                <div>
                                    <h2 class="text-2xl font-bold">🚩 Báo cáo vi phạm</h2>
                                    <p class="text-red-100 text-sm mt-1">Bài đăng: ${jobTitle.substring(0, 50)}</p>
                                </div>
                                <button onclick="this.closest('.fixed').remove()" class="text-white hover:bg-red-700 rounded p-2 transition">✕</button>
                            </div>
                        </div>
                        <div class="p-6">
                            <form id="report-form">
                                <input type="hidden" name="job_id" value="${jobId}">
                                
                                <div class="mb-6">
                                    <label for="reason" class="block text-sm font-semibold mb-2 text-gray-700">
                                        <span class="text-red-500">*</span> Lý do báo cáo
                                    </label>
                                    <select name="reason" id="reason" required class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-red-500">
                                        <option value="">-- Chọn lý do --</option>
                                        <option value="noi-dung-khong-phu-hop">Nội dung không phù hợp</option>
                                        <option value="thong-tin-sai-lac">Thông tin sai lạc</option>
                                        <option value="lua-dao-hay-scam">Lừa đảo hoặc scam</option>
                                        <option value="hanh-vi-cam-de">Hành vi cấm đề cập</option>
                                        <option value="spam">Spam</option>
                                        <option value="khac">Khác</option>
                                    </select>
                                </div>
                                
                                <div class="mb-6">
                                    <label for="description" class="block text-sm font-semibold mb-2 text-gray-700">
                                        <span class="text-red-500">*</span> Chi tiết báo cáo
                                    </label>
                                    <textarea name="description" id="description" required rows="4" placeholder="Vui lòng mô tả chi tiết vấn đề..." class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-red-500 resize-none"></textarea>
                                </div>
                                
                                <div class="flex gap-3">
                                    <button type="button" onclick="this.closest('.fixed').remove()" class="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-gray-700 font-semibold hover:bg-gray-100 transition">
                                        ✕ Hủy
                                    </button>
                                    <button type="submit" class="flex-1 px-4 py-3 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white rounded-lg font-bold transition transform hover:-translate-y-0.5 shadow-lg shadow-red-500/30">
                                        📤 Gửi báo cáo
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            `;
            
            const temp = document.createElement('div');
            temp.innerHTML = modalHTML;
            const modal = temp.firstElementChild;
            document.body.appendChild(modal);
            
            // Handle form submission
            document.getElementById('report-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const submitBtn = e.target.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.disabled = true;
                submitBtn.textContent = '⏳ Đang gửi...';
                
                try {
                    const formData = new FormData(e.target);
                    formData.append('action', 'submit-report');
                    formData.append('reported_type', 'job');
                    
                    const response = await fetch('../../api.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const responseText = await response.text();
                    let data;
                    try {
                        data = JSON.parse(responseText);
                    } catch (parseError) {
                        console.error('JSON Parse Error:', parseError);
                        throw new Error('Server returned invalid JSON');
                    }
                    
                    if (data.success) {
                        alert('✅ ' + data.message);
                        modal.remove();
                    } else {
                        alert('❌ ' + data.message);
                        submitBtn.disabled = false;
                        submitBtn.textContent = originalText;
                    }
                } catch (error) {
                    console.error('Report Error:', error);
                    alert('❌ Lỗi: ' + error.message);
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            });
        };

        // Handle apply form submission
        const applyForm = document.getElementById('apply-form');
        if (applyForm) {
            applyForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const button = applyForm.querySelector('button');
                const originalText = button.textContent;
                button.disabled = true;
                button.textContent = '⏳ Đang xử lý...';
                
                try {
                    const formData = new FormData(applyForm);
                    const response = await fetch('../../api.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    // Get response text first
                    const responseText = await response.text();
                    
                    // Try to parse JSON
                    let data;
                    try {
                        data = JSON.parse(responseText);
                    } catch (parseError) {
                        console.error('JSON Parse Error:', parseError);
                        console.error('Response was:', responseText);
                        alert('❌ Lỗi server: Không thể xử lý phản hồi');
                        button.disabled = false;
                        button.textContent = originalText;
                        return;
                    }
                    
                    if (data.success) {
                        alert('✅ ' + data.message);
                        location.reload();
                    } else {
                        alert('❌ ' + data.message);
                        button.disabled = false;
                        button.textContent = originalText;
                    }
                } catch (error) {
                    console.error('Apply Error:', error);
                    alert('❌ Lỗi kết nối: ' + error.message);
                    button.disabled = false;
                    button.textContent = originalText;
                }
            });
        }
    </script>

    <!-- AI Chatbot Widget -->
    <?php include __DIR__ . '/../components/chatbot-widget.php'; ?>
</body>
</html>
