<?php
require_once 'config/init.php';

$jobModel = new Job();

// Test với recruiter_id = 103 (Viettel)
echo "=== Test getJobsByRecruiter ===\n";
echo "recruiter_id = 103 (Viettel Telecom)\n\n";

$jobs = $jobModel->getJobsByRecruiter(103, 'active');
echo "Jobs (status='active'): " . count($jobs) . "\n";
foreach ($jobs as $job) {
    echo "  - [ID:" . $job['id'] . "] " . $job['title'] . " (status: " . $job['status'] . ")\n";
}

echo "\n";

// Try without status filter
$jobsAll = $jobModel->getJobsByRecruiter(103);
echo "Jobs (no status filter): " . count($jobsAll) . "\n";
foreach ($jobsAll as $job) {
    echo "  - [ID:" . $job['id'] . "] " . $job['title'] . " (status: " . $job['status'] . ")\n";
}
